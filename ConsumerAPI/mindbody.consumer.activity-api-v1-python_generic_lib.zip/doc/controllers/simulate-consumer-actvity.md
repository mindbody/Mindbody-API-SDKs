# Simulate Consumer Actvity

```python
simulate_consumer_actvity_controller = client.simulate_consumer_actvity
```

## Class Name

`SimulateConsumerActvityController`

## Methods

* [Create Test Data for Verified Visits](../../doc/controllers/simulate-consumer-actvity.md#create-test-data-for-verified-visits)
* [Create Test Data for Verified Purchases](../../doc/controllers/simulate-consumer-actvity.md#create-test-data-for-verified-purchases)


# Create Test Data for Verified Visits

Create a new test visit. <br> <a href="https://api.mindbodyonline.com/partnergateway/consumer/activity/v1/simulate/visit" target="_blank">https://api.mindbodyonline.com/partnergateway/consumer/activity/v1/simulate/visit</a>

```python
def create_test_data_for_verified_visits(self,
                                        api_key,
                                        body=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `api_key` | `string` | Header, Required | - |
| `body` | [`CreateVisitRequest`](../../doc/models/create-visit-request.md) | Body, Optional | Visit object |

## Response Type

`void`

## Example Usage

```python
api_key = 'API-Key4'

result = simulate_consumer_actvity_controller.create_test_data_for_verified_visits(api_key)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 401 | Unauthorized | [`ProblemDetailsException`](../../doc/models/problem-details-exception.md) |
| 403 | Forbidden | [`ProblemDetailsException`](../../doc/models/problem-details-exception.md) |


# Create Test Data for Verified Purchases

Create a new test purchase. <br> <a href="https://api.mindbodyonline.com/partnergateway/consumer/activity/v1/simulate/purchase" target="_blank">https://api.mindbodyonline.com/partnergateway/consumer/activity/v1/simulate/purchase</a>

```python
def create_test_data_for_verified_purchases(self,
                                           api_key,
                                           body=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `api_key` | `string` | Header, Required | - |
| `body` | [`CreatePurchaseRequest`](../../doc/models/create-purchase-request.md) | Body, Optional | Purchase object |

## Response Type

`void`

## Example Usage

```python
api_key = 'API-Key4'

result = simulate_consumer_actvity_controller.create_test_data_for_verified_purchases(api_key)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 401 | Unauthorized | [`ProblemDetailsException`](../../doc/models/problem-details-exception.md) |
| 403 | Forbidden | [`ProblemDetailsException`](../../doc/models/problem-details-exception.md) |

