
# Problem Details Exception

## Structure

`ProblemDetailsException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mtype` | `string` | Optional | - |
| `title` | `string` | Optional | - |
| `status` | `int` | Optional | - |
| `detail` | `string` | Optional | - |
| `instance` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "type": null,
  "title": null,
  "status": null,
  "detail": null,
  "instance": null
}
```

