// <copyright file="MindbodyConsumerActivityAPIV1Client.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MindbodyConsumerActivityAPIV1.Standard
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Text;
    using MindbodyConsumerActivityAPIV1.Standard.Authentication;
    using MindbodyConsumerActivityAPIV1.Standard.Controllers;
    using MindbodyConsumerActivityAPIV1.Standard.Http.Client;
    using MindbodyConsumerActivityAPIV1.Standard.Utilities;

    /// <summary>
    /// The gateway for the SDK. This class acts as a factory for Controller and
    /// holds the configuration of the SDK.
    /// </summary>
    public sealed class MindbodyConsumerActivityAPIV1Client : IConfiguration
    {
        // A map of environments and their corresponding servers/baseurls
        private static readonly Dictionary<Environment, Dictionary<Server, string>> EnvironmentsMap =
            new Dictionary<Environment, Dictionary<Server, string>>
        {
            {
                Environment.Production, new Dictionary<Server, string>
                {
                    { Server.Default, "https://api.mindbodyonline.com/partnergateway" },
                }
            },
        };

        private readonly IDictionary<string, IAuthManager> authManagers;
        private readonly IHttpClient httpClient;
        private readonly CustomHeaderAuthenticationManager customHeaderAuthenticationManager;

        private readonly Lazy<BusinessDirectoryController> businessDirectory;
        private readonly Lazy<ConsumerController> consumer;
        private readonly Lazy<SimulateConsumerActvityController> simulateConsumerActvity;

        private MindbodyConsumerActivityAPIV1Client(
            Environment environment,
            string authorization,
            IDictionary<string, IAuthManager> authManagers,
            IHttpClient httpClient,
            IHttpClientConfiguration httpClientConfiguration)
        {
            this.Environment = environment;
            this.httpClient = httpClient;
            this.authManagers = (authManagers == null) ? new Dictionary<string, IAuthManager>() : new Dictionary<string, IAuthManager>(authManagers);
            this.HttpClientConfiguration = httpClientConfiguration;

            this.businessDirectory = new Lazy<BusinessDirectoryController>(
                () => new BusinessDirectoryController(this, this.httpClient, this.authManagers));
            this.consumer = new Lazy<ConsumerController>(
                () => new ConsumerController(this, this.httpClient, this.authManagers));
            this.simulateConsumerActvity = new Lazy<SimulateConsumerActvityController>(
                () => new SimulateConsumerActvityController(this, this.httpClient, this.authManagers));

            if (this.authManagers.ContainsKey("global"))
            {
                this.customHeaderAuthenticationManager = (CustomHeaderAuthenticationManager)this.authManagers["global"];
            }

            if (!this.authManagers.ContainsKey("global")
                || !this.CustomHeaderAuthenticationCredentials.Equals(authorization))
            {
                this.customHeaderAuthenticationManager = new CustomHeaderAuthenticationManager(authorization);
                this.authManagers["global"] = this.customHeaderAuthenticationManager;
            }
        }

        /// <summary>
        /// Gets BusinessDirectoryController controller.
        /// </summary>
        public BusinessDirectoryController BusinessDirectoryController => this.businessDirectory.Value;

        /// <summary>
        /// Gets ConsumerController controller.
        /// </summary>
        public ConsumerController ConsumerController => this.consumer.Value;

        /// <summary>
        /// Gets SimulateConsumerActvityController controller.
        /// </summary>
        public SimulateConsumerActvityController SimulateConsumerActvityController => this.simulateConsumerActvity.Value;

        /// <summary>
        /// Gets the configuration of the Http Client associated with this client.
        /// </summary>
        public IHttpClientConfiguration HttpClientConfiguration { get; }

        /// <summary>
        /// Gets Environment.
        /// Current API environment.
        /// </summary>
        public Environment Environment { get; }

        /// <summary>
        /// Gets auth managers.
        /// </summary>
        internal IDictionary<string, IAuthManager> AuthManagers => this.authManagers;

        /// <summary>
        /// Gets http client.
        /// </summary>
        internal IHttpClient HttpClient => this.httpClient;

        /// <summary>
        /// Gets the credentials to use with CustomHeaderAuthentication.
        /// </summary>
        public ICustomHeaderAuthenticationCredentials CustomHeaderAuthenticationCredentials => this.customHeaderAuthenticationManager;

        /// <summary>
        /// Gets the URL for a particular alias in the current environment and appends
        /// it with template parameters.
        /// </summary>
        /// <param name="alias">Default value:DEFAULT.</param>
        /// <returns>Returns the baseurl.</returns>
        public string GetBaseUri(Server alias = Server.Default)
        {
            StringBuilder url = new StringBuilder(EnvironmentsMap[this.Environment][alias]);
            ApiHelper.AppendUrlWithTemplateParameters(url, this.GetBaseUriParameters());

            return url.ToString();
        }

        /// <summary>
        /// Creates an object of the MindbodyConsumerActivityAPIV1Client using the values provided for the builder.
        /// </summary>
        /// <returns>Builder.</returns>
        public Builder ToBuilder()
        {
            Builder builder = new Builder()
                .Environment(this.Environment)
                .CustomHeaderAuthenticationCredentials(this.customHeaderAuthenticationManager.Authorization)
                .HttpClient(this.httpClient)
                .AuthManagers(this.authManagers)
                .HttpClientConfig(config => config.Build());

            return builder;
        }

        /// <inheritdoc/>
        public override string ToString()
        {
            return
                $"Environment = {this.Environment}, " +
                $"HttpClientConfiguration = {this.HttpClientConfiguration}, ";
        }

        /// <summary>
        /// Creates the client using builder.
        /// </summary>
        /// <returns> MindbodyConsumerActivityAPIV1Client.</returns>
        internal static MindbodyConsumerActivityAPIV1Client CreateFromEnvironment()
        {
            var builder = new Builder();

            string environment = System.Environment.GetEnvironmentVariable("MINDBODY_CONSUMER_ACTIVITY_APIV_1_STANDARD_ENVIRONMENT");
            string authorization = System.Environment.GetEnvironmentVariable("MINDBODY_CONSUMER_ACTIVITY_APIV_1_STANDARD_AUTHORIZATION");

            if (environment != null)
            {
                builder.Environment(ApiHelper.JsonDeserialize<Environment>($"\"{environment}\""));
            }

            if (authorization != null)
            {
                builder.CustomHeaderAuthenticationCredentials(authorization);
            }

            return builder.Build();
        }

        /// <summary>
        /// Makes a list of the BaseURL parameters.
        /// </summary>
        /// <returns>Returns the parameters list.</returns>
        private List<KeyValuePair<string, object>> GetBaseUriParameters()
        {
            List<KeyValuePair<string, object>> kvpList = new List<KeyValuePair<string, object>>()
            {
            };
            return kvpList;
        }

        /// <summary>
        /// Builder class.
        /// </summary>
        public class Builder
        {
            private Environment environment = MindbodyConsumerActivityAPIV1.Standard.Environment.Production;
            private string authorization = "";
            private IDictionary<string, IAuthManager> authManagers = new Dictionary<string, IAuthManager>();
            private HttpClientConfiguration.Builder httpClientConfig = new HttpClientConfiguration.Builder();
            private IHttpClient httpClient;

            /// <summary>
            /// Sets credentials for CustomHeaderAuthentication.
            /// </summary>
            /// <param name="authorization">Authorization.</param>
            /// <returns>Builder.</returns>
            public Builder CustomHeaderAuthenticationCredentials(string authorization)
            {
                this.authorization = authorization ?? throw new ArgumentNullException(nameof(authorization));
                return this;
            }

            /// <summary>
            /// Sets Environment.
            /// </summary>
            /// <param name="environment"> Environment. </param>
            /// <returns> Builder. </returns>
            public Builder Environment(Environment environment)
            {
                this.environment = environment;
                return this;
            }

            /// <summary>
            /// Sets HttpClientConfig.
            /// </summary>
            /// <param name="action"> Action. </param>
            /// <returns>Builder.</returns>
            public Builder HttpClientConfig(Action<HttpClientConfiguration.Builder> action)
            {
                if (action is null)
                {
                    throw new ArgumentNullException(nameof(action));
                }

                action(this.httpClientConfig);
                return this;
            }

            /// <summary>
            /// Sets the IHttpClient for the Builder.
            /// </summary>
            /// <param name="httpClient"> http client. </param>
            /// <returns>Builder.</returns>
            internal Builder HttpClient(IHttpClient httpClient)
            {
                this.httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
                return this;
            }

            /// <summary>
            /// Sets the authentication managers for the Builder.
            /// </summary>
            /// <param name="authManagers"> auth managers. </param>
            /// <returns>Builder.</returns>
            internal Builder AuthManagers(IDictionary<string, IAuthManager> authManagers)
            {
                this.authManagers = authManagers ?? throw new ArgumentNullException(nameof(authManagers));
                return this;
            }

            /// <summary>
            /// Creates an object of the MindbodyConsumerActivityAPIV1Client using the values provided for the builder.
            /// </summary>
            /// <returns>MindbodyConsumerActivityAPIV1Client.</returns>
            public MindbodyConsumerActivityAPIV1Client Build()
            {
                this.httpClient = new HttpClientWrapper(this.httpClientConfig.Build());

                return new MindbodyConsumerActivityAPIV1Client(
                    this.environment,
                    this.authorization,
                    this.authManagers,
                    this.httpClient,
                    this.httpClientConfig.Build());
            }
        }
    }
}
