// <copyright file="BusinessResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MindbodyConsumerActivityAPIV1.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MindbodyConsumerActivityAPIV1.Standard;
    using MindbodyConsumerActivityAPIV1.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// BusinessResponse.
    /// </summary>
    public class BusinessResponse
    {
        private List<Models.Business> businesses;
        private Dictionary<string, bool> shouldSerialize = new Dictionary<string, bool>
        {
            { "businesses", false },
        };

        /// <summary>
        /// Initializes a new instance of the <see cref="BusinessResponse"/> class.
        /// </summary>
        public BusinessResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="BusinessResponse"/> class.
        /// </summary>
        /// <param name="pageCount">pageCount.</param>
        /// <param name="businesses">businesses.</param>
        public BusinessResponse(
            int? pageCount = null,
            List<Models.Business> businesses = null)
        {
            this.PageCount = pageCount;
            if (businesses != null)
            {
                this.Businesses = businesses;
            }

        }

        /// <summary>
        /// The total number of pages
        /// </summary>
        [JsonProperty("pageCount", NullValueHandling = NullValueHandling.Ignore)]
        public int? PageCount { get; set; }

        /// <summary>
        /// A list of business data.
        /// </summary>
        [JsonProperty("businesses")]
        public List<Models.Business> Businesses
        {
            get
            {
                return this.businesses;
            }

            set
            {
                this.shouldSerialize["businesses"] = true;
                this.businesses = value;
            }
        }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"BusinessResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <summary>
        /// Marks the field to not be serailized.
        /// </summary>
        public void UnsetBusinesses()
        {
            this.shouldSerialize["businesses"] = false;
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeBusinesses()
        {
            return this.shouldSerialize["businesses"];
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is BusinessResponse other &&
                ((this.PageCount == null && other.PageCount == null) || (this.PageCount?.Equals(other.PageCount) == true)) &&
                ((this.Businesses == null && other.Businesses == null) || (this.Businesses?.Equals(other.Businesses) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PageCount = {(this.PageCount == null ? "null" : this.PageCount.ToString())}");
            toStringOutput.Add($"this.Businesses = {(this.Businesses == null ? "null" : $"[{string.Join(", ", this.Businesses)} ]")}");
        }
    }
}