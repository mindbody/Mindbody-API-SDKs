
# Error

Contains information about a problem encountered while performing an operation.

## Structure

`Error`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Code` | `string` | Optional | The application-specific error code. |
| `Message` | `string` | Optional | Explanation concerning this occurence of this error. |

## Example (as JSON)

```json
{
  "code": null,
  "message": null
}
```

