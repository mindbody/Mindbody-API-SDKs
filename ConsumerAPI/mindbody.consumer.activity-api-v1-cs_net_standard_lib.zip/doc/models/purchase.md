
# Purchase

## Structure

`Purchase`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ConsumerId` | `string` | Optional | The Id of the consumer. |
| `ProductName` | `string` | Optional | The product name of the purchase. |
| `ProductCategory` | `string` | Optional | The product category of the purchase. |
| `PaymentMethod` | `string` | Optional | The payment method of the purchase. |
| `AmountPaid` | `double?` | Optional | The amount paid for the purchase. |
| `PurchaseDate` | `DateTime?` | Optional | The date of the purchase. |
| `ProductType` | `string` | Optional | The product type of the purchase. |
| `Quantity` | `int?` | Optional | The quantity of the product purchased. |

## Example (as JSON)

```json
{
  "consumerId": null,
  "productName": null,
  "productCategory": null,
  "paymentMethod": null,
  "amountPaid": null,
  "purchaseDate": null,
  "productType": null,
  "quantity": null
}
```

