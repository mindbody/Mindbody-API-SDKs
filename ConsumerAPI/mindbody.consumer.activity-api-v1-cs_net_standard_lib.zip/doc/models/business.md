
# Business

## Structure

`Business`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `string` | Optional | The id of the business. |
| `Name` | `string` | Optional | The name of the business. |
| `WebsiteUrl` | `string` | Optional | The website url of the business. |
| `Locations` | [`List<Models.Location>`](../../doc/models/location.md) | Optional | The locations of the business. |

## Example (as JSON)

```json
{
  "id": null,
  "name": null,
  "websiteUrl": null,
  "locations": null
}
```

