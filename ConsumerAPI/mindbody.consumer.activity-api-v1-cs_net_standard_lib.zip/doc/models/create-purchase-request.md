
# Create Purchase Request

PurchaseRequest object

## Structure

`CreatePurchaseRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ProductName` | `string` | Optional | The service name of the purchase |
| `ProductCategory` | `string` | Optional | The service category of the purchase |
| `PaymentMethod` | `string` | Optional | The payment method of the purchase |
| `AmountPaid` | `double?` | Optional | The amount Paid for the purchase |
| `PurchaseDate` | `DateTime?` | Optional | The date of the purchase |
| `Quantity` | `int?` | Optional | The quantity of the purchase |
| `ProductType` | `string` | Optional | The product type of the purchase |

## Example (as JSON)

```json
{
  "productName": null,
  "productCategory": null,
  "paymentMethod": null,
  "amountPaid": null,
  "purchaseDate": null,
  "quantity": null,
  "productType": null
}
```

