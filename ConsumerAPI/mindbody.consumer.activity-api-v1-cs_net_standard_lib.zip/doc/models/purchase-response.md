
# Purchase Response

Purchase Response Properties

## Structure

`PurchaseResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Purchases` | [`List<Models.Purchase>`](../../doc/models/purchase.md) | Optional | A list of all verified purchases of a consumer for a given duration. |

## Example (as JSON)

```json
{
  "purchases": null
}
```

