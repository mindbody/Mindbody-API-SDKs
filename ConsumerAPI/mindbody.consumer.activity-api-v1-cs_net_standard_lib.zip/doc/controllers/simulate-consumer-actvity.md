# Simulate Consumer Actvity

```csharp
SimulateConsumerActvityController simulateConsumerActvityController = client.SimulateConsumerActvityController;
```

## Class Name

`SimulateConsumerActvityController`

## Methods

* [Create Test Data for Verified Visits](../../doc/controllers/simulate-consumer-actvity.md#create-test-data-for-verified-visits)
* [Create Test Data for Verified Purchases](../../doc/controllers/simulate-consumer-actvity.md#create-test-data-for-verified-purchases)


# Create Test Data for Verified Visits

Create a new test visit. <br> <a href="https://api.mindbodyonline.com/partnergateway/consumer/activity/v1/simulate/visit" target="_blank">https://api.mindbodyonline.com/partnergateway/consumer/activity/v1/simulate/visit</a>

```csharp
CreateTestDataForVerifiedVisitsAsync(
    string aPIKey,
    Models.CreateVisitRequest body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `aPIKey` | `string` | Header, Required | - |
| `body` | [`Models.CreateVisitRequest`](../../doc/models/create-visit-request.md) | Body, Optional | Visit object |

## Response Type

`Task`

## Example Usage

```csharp
string aPIKey = "API-Key4";

try
{
    await simulateConsumerActvityController.CreateTestDataForVerifiedVisitsAsync(aPIKey, null);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 401 | Unauthorized | [`ProblemDetailsException`](../../doc/models/problem-details-exception.md) |
| 403 | Forbidden | [`ProblemDetailsException`](../../doc/models/problem-details-exception.md) |


# Create Test Data for Verified Purchases

Create a new test purchase. <br> <a href="https://api.mindbodyonline.com/partnergateway/consumer/activity/v1/simulate/purchase" target="_blank">https://api.mindbodyonline.com/partnergateway/consumer/activity/v1/simulate/purchase</a>

```csharp
CreateTestDataForVerifiedPurchasesAsync(
    string aPIKey,
    Models.CreatePurchaseRequest body = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `aPIKey` | `string` | Header, Required | - |
| `body` | [`Models.CreatePurchaseRequest`](../../doc/models/create-purchase-request.md) | Body, Optional | Purchase object |

## Response Type

`Task`

## Example Usage

```csharp
string aPIKey = "API-Key4";

try
{
    await simulateConsumerActvityController.CreateTestDataForVerifiedPurchasesAsync(aPIKey, null);
}
catch (ApiException e){};
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 401 | Unauthorized | [`ProblemDetailsException`](../../doc/models/problem-details-exception.md) |
| 403 | Forbidden | [`ProblemDetailsException`](../../doc/models/problem-details-exception.md) |

