# Simulate Consumer Actvity

```php
$simulateConsumerActvityController = $client->getSimulateConsumerActvityController();
```

## Class Name

`SimulateConsumerActvityController`

## Methods

* [Create Test Data for Verified Visits](../../doc/controllers/simulate-consumer-actvity.md#create-test-data-for-verified-visits)
* [Create Test Data for Verified Purchases](../../doc/controllers/simulate-consumer-actvity.md#create-test-data-for-verified-purchases)


# Create Test Data for Verified Visits

Create a new test visit. <br> <a href="https://api.mindbodyonline.com/partnergateway/consumer/activity/v1/simulate/visit" target="_blank">https://api.mindbodyonline.com/partnergateway/consumer/activity/v1/simulate/visit</a>

```php
function createTestDataForVerifiedVisits(string $aPIKey, ?CreateVisitRequest $body = null): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `aPIKey` | `string` | Header, Required | - |
| `body` | [`?CreateVisitRequest`](../../doc/models/create-visit-request.md) | Body, Optional | Visit object |

## Response Type

`void`

## Example Usage

```php
$aPIKey = 'API-Key4';

$simulateConsumerActvityController->createTestDataForVerifiedVisits($aPIKey);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 401 | Unauthorized | [`ProblemDetailsException`](../../doc/models/problem-details-exception.md) |
| 403 | Forbidden | [`ProblemDetailsException`](../../doc/models/problem-details-exception.md) |


# Create Test Data for Verified Purchases

Create a new test purchase. <br> <a href="https://api.mindbodyonline.com/partnergateway/consumer/activity/v1/simulate/purchase" target="_blank">https://api.mindbodyonline.com/partnergateway/consumer/activity/v1/simulate/purchase</a>

```php
function createTestDataForVerifiedPurchases(string $aPIKey, ?CreatePurchaseRequest $body = null): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `aPIKey` | `string` | Header, Required | - |
| `body` | [`?CreatePurchaseRequest`](../../doc/models/create-purchase-request.md) | Body, Optional | Purchase object |

## Response Type

`void`

## Example Usage

```php
$aPIKey = 'API-Key4';

$simulateConsumerActvityController->createTestDataForVerifiedPurchases($aPIKey);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 401 | Unauthorized | [`ProblemDetailsException`](../../doc/models/problem-details-exception.md) |
| 403 | Forbidden | [`ProblemDetailsException`](../../doc/models/problem-details-exception.md) |

