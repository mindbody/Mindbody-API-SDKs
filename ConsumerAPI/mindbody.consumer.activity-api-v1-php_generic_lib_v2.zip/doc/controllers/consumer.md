# Consumer

```php
$consumerController = $client->getConsumerController();
```

## Class Name

`ConsumerController`

## Methods

* [GET Consumer Visits](../../doc/controllers/consumer.md#get-consumer-visits)
* [Get Verified Purchases](../../doc/controllers/consumer.md#get-verified-purchases)
* [Disconnect Consumer From a Partner](../../doc/controllers/consumer.md#disconnect-consumer-from-a-partner)


# GET Consumer Visits

Return a list of all verified visits of a consumer for a given duration.  <br> <a href="https://api.mindbodyonline.com/partnergateway/consumer/activity/v1/visits" target="_blank">https://api.mindbodyonline.com/partnergateway/consumer/activity/v1/visits</a>

```php
function gETConsumerVisits(
    string $aPIKey,
    string $applicationId,
    \DateTime $startDate,
    \DateTime $endDate,
    string $clientId,
    ?bool $isTestData = null
): VisitResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `aPIKey` | `string` | Header, Required | - |
| `applicationId` | `string` | Header, Required | Application Id of the Partner making a request to the API. |
| `startDate` | `\DateTime` | Query, Required | Start date of the visit activity. It should be in "yyyy-mm-dd" format and it cannot be older than 3 months. |
| `endDate` | `\DateTime` | Query, Required | End date of the visit activity. It should be in "yyyy-mm-dd" format and future date is not allowed. |
| `clientId` | `string` | Header, Required | OAuth Client Id of the Partner making a request to the API |
| `isTestData` | `?bool` | Query, Optional | Is Test Data of visit activity. If enable then return test data of consumer else provide actual data. |

## Response Type

[`VisitResponse`](../../doc/models/visit-response.md)

## Example Usage

```php
$aPIKey = 'API-Key4';
$applicationId = 'applicationId0';
$startDate = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');
$endDate = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');
$clientId = 'clientId6';

$result = $consumerController->gETConsumerVisits($aPIKey, $applicationId, $startDate, $endDate, $clientId);
```

## Example Response *(as JSON)*

```json
{
  "visits": [
    {
      "consumerId": "1234",
      "serviceName": "Gym Arrival",
      "serviceCategory": "Gym Arrival",
      "paymentMethod": "cash",
      "amountPaid": 25,
      "visitDate": "2021-09-30T08:51:58.610Z",
      "bookingDate": "2021-09-30T08:51:58.610Z",
      "businessName": "GymBusiness",
      "locationName": "Gym Location",
      "addressLine1": "SR street",
      "addressLine2": "SR block",
      "city": "Pune",
      "stateCode": "MM",
      "countryCode": "IN",
      "postalCode": "411038"
    },
    {
      "consumerId": "12345",
      "serviceName": "Yoga class",
      "serviceCategory": "Yoga",
      "paymentMethod": "cheque",
      "amountPaid": 10,
      "visitDate": "2021-09-30T08:51:58.610Z",
      "bookingDate": "2021-09-30T08:51:58.610Z",
      "businessName": "GymBusiness",
      "locationName": "Gym Location",
      "addressLine1": "SR street",
      "addressLine2": "SR block",
      "city": "Pune",
      "stateCode": "MM",
      "countryCode": "IN",
      "postalCode": "411038"
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 401 | Unauthorized | [`ProblemDetailsException`](../../doc/models/problem-details-exception.md) |
| 403 | Forbidden | [`ProblemDetailsException`](../../doc/models/problem-details-exception.md) |


# Get Verified Purchases

Return a list of all verified purchases of a consumer for a given duration. <br> <a href="https://api.mindbodyonline.com/partnergateway/consumer/activity/v1/purchases" target="_blank">https://api.mindbodyonline.com/partnergateway/consumer/activity/v1/purchases</a>

```php
function getVerifiedPurchases(
    string $aPIKey,
    string $applicationId,
    \DateTime $startDate,
    \DateTime $endDate,
    string $clientId,
    ?string $productType = null,
    ?bool $isTestData = null
): PurchaseResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `aPIKey` | `string` | Header, Required | - |
| `applicationId` | `string` | Header, Required | Application Id of the Partner making a request to the API. |
| `startDate` | `\DateTime` | Query, Required | Start date of the Purchase activity. It should be in "yyyy-mm-dd" format and it cannot be older than 3 months. |
| `endDate` | `\DateTime` | Query, Required | End date of the Purchase activity. It should be in "yyyy-mm-dd" format and future date is not allowed. |
| `clientId` | `string` | Header, Required | OAuth Client Id of the Partner making a request to the API |
| `productType` | `?string` | Query, Optional | Product Type of the Purchase activity. |
| `isTestData` | `?bool` | Query, Optional | Is test data of purchase activity. If enable then return test data of consumer else provide actual data. |

## Response Type

[`PurchaseResponse`](../../doc/models/purchase-response.md)

## Example Usage

```php
$aPIKey = 'API-Key4';
$applicationId = 'applicationId0';
$startDate = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');
$endDate = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');
$clientId = 'clientId6';

$result = $consumerController->getVerifiedPurchases($aPIKey, $applicationId, $startDate, $endDate, $clientId);
```

## Example Response *(as JSON)*

```json
{
  "purchases": [
    {
      "consumerId": "1234",
      "productName": "Yoga matt",
      "productCategory": "Yoga",
      "paymentMethod": "cash",
      "amountPaid": 10,
      "purchaseDate": "2021-09-30T11:13:47.953Z",
      "productType": "Retail",
      "quantity": 2
    },
    {
      "consumerId": "12345",
      "productName": "Gym gloves",
      "productCategory": "Gym",
      "paymentMethod": "cheque",
      "amountPaid": 50,
      "purchaseDate": "2021-09-30T11:13:47.953Z",
      "productType": "Retail",
      "quantity": 1
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 401 | Unauthorized | [`ProblemDetailsException`](../../doc/models/problem-details-exception.md) |
| 403 | Forbidden | [`ProblemDetailsException`](../../doc/models/problem-details-exception.md) |


# Disconnect Consumer From a Partner

Disconnect consumer from a partner. <br> <a href="https://api.mindbodyonline.com/partnergateway/consumer/activity/v1/consumer" target="_blank">https://api.mindbodyonline.com/partnergateway/consumer/activity/v1/consumer</a>

```php
function disconnectConsumerFromAPartner(string $aPIKey, string $clientId): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `aPIKey` | `string` | Header, Required | - |
| `clientId` | `string` | Header, Required | OAuth Client Id of the Partner making a request to the API |

## Response Type

`void`

## Example Usage

```php
$aPIKey = 'API-Key4';
$clientId = 'clientId6';

$consumerController->disconnectConsumerFromAPartner($aPIKey, $clientId);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |

