
# Create Visit Request

VisitRequest object

## Structure

`CreateVisitRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `serviceName` | `?string` | Optional | The service name of the visit | getServiceName(): ?string | setServiceName(?string serviceName): void |
| `serviceCategory` | `?string` | Optional | The service category of the visit | getServiceCategory(): ?string | setServiceCategory(?string serviceCategory): void |
| `paymentMethod` | `?string` | Optional | The payment method of the visit | getPaymentMethod(): ?string | setPaymentMethod(?string paymentMethod): void |
| `amountPaid` | `?float` | Optional | The amount paid for the visit | getAmountPaid(): ?float | setAmountPaid(?float amountPaid): void |
| `visitDate` | `?\DateTime` | Optional | The date of the visit | getVisitDate(): ?\DateTime | setVisitDate(?\DateTime visitDate): void |
| `bookingDate` | `?\DateTime` | Optional | The booking date of the visit | getBookingDate(): ?\DateTime | setBookingDate(?\DateTime bookingDate): void |
| `businessName` | `?string` | Optional | The business name of the site where this visit was made | getBusinessName(): ?string | setBusinessName(?string businessName): void |
| `locationName` | `?string` | Optional | The location name of the site where this visit was made | getLocationName(): ?string | setLocationName(?string locationName): void |
| `addressLine1` | `?string` | Optional | The first line of the visit location’s street address | getAddressLine1(): ?string | setAddressLine1(?string addressLine1): void |
| `addressLine2` | `?string` | Optional | A second address line for the visit location’s street address, if needed | getAddressLine2(): ?string | setAddressLine2(?string addressLine2): void |
| `city` | `?string` | Optional | The visit location’s city | getCity(): ?string | setCity(?string city): void |
| `stateCode` | `?string` | Optional | The visit location’s state or province code | getStateCode(): ?string | setStateCode(?string stateCode): void |
| `countryCode` | `?string` | Optional | The visit location’s country code | getCountryCode(): ?string | setCountryCode(?string countryCode): void |
| `postalCode` | `?string` | Optional | The visit location’s postal code | getPostalCode(): ?string | setPostalCode(?string postalCode): void |

## Example (as JSON)

```json
{
  "serviceName": null,
  "serviceCategory": null,
  "paymentMethod": null,
  "amountPaid": null,
  "visitDate": null,
  "bookingDate": null,
  "businessName": null,
  "locationName": null,
  "addressLine1": null,
  "addressLine2": null,
  "city": null,
  "stateCode": null,
  "countryCode": null,
  "postalCode": null
}
```

