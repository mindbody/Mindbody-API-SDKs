
# Create Purchase Request

PurchaseRequest object

## Structure

`CreatePurchaseRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `productName` | `?string` | Optional | The service name of the purchase | getProductName(): ?string | setProductName(?string productName): void |
| `productCategory` | `?string` | Optional | The service category of the purchase | getProductCategory(): ?string | setProductCategory(?string productCategory): void |
| `paymentMethod` | `?string` | Optional | The payment method of the purchase | getPaymentMethod(): ?string | setPaymentMethod(?string paymentMethod): void |
| `amountPaid` | `?float` | Optional | The amount Paid for the purchase | getAmountPaid(): ?float | setAmountPaid(?float amountPaid): void |
| `purchaseDate` | `?\DateTime` | Optional | The date of the purchase | getPurchaseDate(): ?\DateTime | setPurchaseDate(?\DateTime purchaseDate): void |
| `quantity` | `?int` | Optional | The quantity of the purchase | getQuantity(): ?int | setQuantity(?int quantity): void |
| `productType` | `?string` | Optional | The product type of the purchase | getProductType(): ?string | setProductType(?string productType): void |

## Example (as JSON)

```json
{
  "productName": null,
  "productCategory": null,
  "paymentMethod": null,
  "amountPaid": null,
  "purchaseDate": null,
  "quantity": null,
  "productType": null
}
```

