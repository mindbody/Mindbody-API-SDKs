
# Business Response

Business response properties

## Structure

`BusinessResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `pageCount` | `?int` | Optional | The total number of pages | getPageCount(): ?int | setPageCount(?int pageCount): void |
| `businesses` | [`?(Business[])`](../../doc/models/business.md) | Optional | A list of business data. | getBusinesses(): ?array | setBusinesses(?array businesses): void |

## Example (as JSON)

```json
{
  "pageCount": null,
  "businesses": null
}
```

