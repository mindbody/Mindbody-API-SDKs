
# Business

## Structure

`Business`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?string` | Optional | The id of the business. | getId(): ?string | setId(?string id): void |
| `name` | `?string` | Optional | The name of the business. | getName(): ?string | setName(?string name): void |
| `websiteUrl` | `?string` | Optional | The website url of the business. | getWebsiteUrl(): ?string | setWebsiteUrl(?string websiteUrl): void |
| `locations` | [`?(Location[])`](../../doc/models/location.md) | Optional | The locations of the business. | getLocations(): ?array | setLocations(?array locations): void |

## Example (as JSON)

```json
{
  "id": null,
  "name": null,
  "websiteUrl": null,
  "locations": null
}
```

