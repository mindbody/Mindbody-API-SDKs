
# Error

Contains information about a problem encountered while performing an operation.

## Structure

`Error`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `code` | `?string` | Optional | The application-specific error code. | getCode(): ?string | setCode(?string code): void |
| `message` | `?string` | Optional | Explanation concerning this occurence of this error. | getMessage(): ?string | setMessage(?string message): void |

## Example (as JSON)

```json
{
  "code": null,
  "message": null
}
```

