
# Visit Response

Visits response properties

## Structure

`VisitResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `visits` | [`?(Visit[])`](../../doc/models/visit.md) | Optional | A list of all verified visits of a consumer for a given duration. | getVisits(): ?array | setVisits(?array visits): void |

## Example (as JSON)

```json
{
  "visits": null
}
```

