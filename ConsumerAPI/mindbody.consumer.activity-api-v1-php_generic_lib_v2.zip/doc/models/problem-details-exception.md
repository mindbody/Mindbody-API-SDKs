
# Problem Details Exception

## Structure

`ProblemDetailsException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | `?string` | Optional | - | getType(): ?string | setType(?string type): void |
| `title` | `?string` | Optional | - | getTitle(): ?string | setTitle(?string title): void |
| `status` | `?int` | Optional | - | getStatus(): ?int | setStatus(?int status): void |
| `detail` | `?string` | Optional | - | getDetail(): ?string | setDetail(?string detail): void |
| `instance` | `?string` | Optional | - | getInstance(): ?string | setInstance(?string instance): void |

## Example (as JSON)

```json
{
  "type": null,
  "title": null,
  "status": null,
  "detail": null,
  "instance": null
}
```

