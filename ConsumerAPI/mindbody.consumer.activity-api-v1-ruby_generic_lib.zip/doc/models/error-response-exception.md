
# Error Response Exception

Error response

## Structure

`ErrorResponseException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `errors` | [`Array<Error>`](../../doc/models/error.md) | Optional | Collection of errors describing why the request was not processed. |

## Example (as JSON)

```json
{}
```

