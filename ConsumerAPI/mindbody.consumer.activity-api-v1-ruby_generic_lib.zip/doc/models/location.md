
# Location

## Structure

`Location`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `String` | Optional | The id of the location of business. |
| `name` | `String` | Optional | The name of the location of business. |
| `address_line_1` | `String` | Optional | The first line of the business location’s street address. |
| `address_line_2` | `String` | Optional | A second address line for the business location’s street address, if needed. |
| `city` | `String` | Optional | The business location’s city. |
| `state_prov_code` | `String` | Optional | The business location’s state or province code. |
| `postal_code` | `String` | Optional | The business location’s postal code. |
| `country_code` | `String` | Optional | The business location’s country code. |
| `booking_url` | `String` | Optional | The booking url of the business. |

## Example (as JSON)

```json
{
  "id": null,
  "name": null,
  "addressLine1": null,
  "addressLine2": null,
  "city": null,
  "stateProvCode": null,
  "postalCode": null,
  "countryCode": null,
  "bookingUrl": null
}
```

