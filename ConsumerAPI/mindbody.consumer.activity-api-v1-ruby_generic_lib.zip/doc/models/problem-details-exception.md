
# Problem Details Exception

## Structure

`ProblemDetailsException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | `String` | Optional | - |
| `title` | `String` | Optional | - |
| `status` | `Integer` | Optional | - |
| `detail` | `String` | Optional | - |
| `instance` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "type": null,
  "title": null,
  "status": null,
  "detail": null,
  "instance": null
}
```

