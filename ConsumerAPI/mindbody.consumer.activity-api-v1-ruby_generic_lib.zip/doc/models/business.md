
# Business

## Structure

`Business`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `String` | Optional | The id of the business. |
| `name` | `String` | Optional | The name of the business. |
| `website_url` | `String` | Optional | The website url of the business. |
| `locations` | [`Array<Location>`](../../doc/models/location.md) | Optional | The locations of the business. |

## Example (as JSON)

```json
{
  "id": null,
  "name": null,
  "websiteUrl": null,
  "locations": null
}
```

