# Business Directory

```ruby
business_directory_controller = client.business_directory
```

## Class Name

`BusinessDirectoryController`


# Returns Business Data for Authorized Customer

Returns a list of the businesses on the Mindbody Platform. <br> <a href="https://api.mindbodyonline.com/partnergateway/consumer/activity/v1/businesses" target="_blank">https://api.mindbodyonline.com/partnergateway/consumer/activity/v1/businesses</a>

```ruby
def returns_business_data_for_authorized_customer(api_key,
                                                  page_number: nil,
                                                  business_ids: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `api_key` | `String` | Header, Required | API key of the end user. |
| `page_number` | `Integer` | Query, Optional | Indicates the number of a page. For page number, only values greater than 0 are valid. Page number defaults to 1. |
| `business_ids` | `Array<String>` | Query, Optional | Business Ids are the Ids of businesses to restrict results to. |

## Response Type

[`BusinessResponse`](../../doc/models/business-response.md)

## Example Usage

```ruby
api_key = 'API-Key4'

result = business_directory_controller.returns_business_data_for_authorized_customer(api_key, )
```

## Example Response *(as JSON)*

```json
{
  "pageCount": 10,
  "businesses": [
    {
      "id": "fdcaf363-9952-4896-b7f7-da3158954f4a",
      "name": "Chaitanya's Studio",
      "websiteUrl": "https://www.test.com",
      "locations": [
        {
          "id": "db9441b0-9545-47fa-808a-7588df1445d7",
          "name": "Location 1",
          "addressLine1": "Address Line 1",
          "addressLine2": "Address Line 2",
          "city": "Pune",
          "stateProvCode": "MM",
          "postalCode": "411038",
          "countryCode": "IN",
          "bookingUrl": "http://www.test123.com"
        }
      ]
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`ErrorResponseException`](../../doc/models/error-response-exception.md) |
| 401 | Unauthorized | [`ProblemDetailsException`](../../doc/models/problem-details-exception.md) |
| 403 | Forbidden | [`ProblemDetailsException`](../../doc/models/problem-details-exception.md) |

