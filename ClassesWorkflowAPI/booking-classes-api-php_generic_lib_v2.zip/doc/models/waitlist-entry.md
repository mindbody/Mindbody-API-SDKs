
# Waitlist Entry

## Structure

`WaitlistEntry`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `classId` | `?int` | Optional | - | getClassId(): ?int | setClassId(?int classId): void |
| `requestDateTime` | `?DateTime` | Optional | - | getRequestDateTime(): ?\DateTime | setRequestDateTime(?\DateTime requestDateTime): void |
| `requestedFrom` | [`?string(RequestedFromEnum)`](../../doc/models/requested-from-enum.md) | Optional | - | getRequestedFrom(): ?string | setRequestedFrom(?string requestedFrom): void |
| `visitId` | `?int` | Optional | - | getVisitId(): ?int | setVisitId(?int visitId): void |

## Example (as JSON)

```json
{
  "id": 80,
  "classId": 212,
  "requestDateTime": "2016-03-13T12:52:32.123Z",
  "requestedFrom": "online",
  "visitId": 220
}
```

