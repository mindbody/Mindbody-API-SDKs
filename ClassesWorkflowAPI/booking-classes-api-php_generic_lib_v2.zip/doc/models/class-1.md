
# Class 1

## Structure

`Class1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |

## Example (as JSON)

```json
{
  "id": 60
}
```

