
# Session

## Structure

`Session`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `sessionCount` | `?int` | Optional | - | getSessionCount(): ?int | setSessionCount(?int sessionCount): void |
| `type` | [`?string(Type1Enum)`](../../doc/models/type-1-enum.md) | Optional | - | getType(): ?string | setType(?string type): void |

## Example (as JSON)

```json
{
  "sessionCount": 66,
  "type": "single"
}
```

