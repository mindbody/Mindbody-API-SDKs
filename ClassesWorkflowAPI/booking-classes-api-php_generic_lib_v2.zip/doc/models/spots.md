
# Spots

## Structure

`Spots`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `reserved` | `?(int[])` | Optional | - | getReserved(): ?array | setReserved(?array reserved): void |
| `available` | `?(int[])` | Optional | - | getAvailable(): ?array | setAvailable(?array available): void |
| `unavailable` | `?(int[])` | Optional | - | getUnavailable(): ?array | setUnavailable(?array unavailable): void |
| `mine` | `?(array<?int>)` | Optional | - | getMine(): ?array | setMine(?array mine): void |

## Example (as JSON)

```json
{
  "reserved": [
    125
  ],
  "available": [
    28
  ],
  "unavailable": [
    80
  ],
  "mine": [
    111
  ]
}
```

