
# Address

## Structure

`Address`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `street` | `?string` | Optional | - | getStreet(): ?string | setStreet(?string street): void |
| `city` | `?string` | Optional | - | getCity(): ?string | setCity(?string city): void |
| `state` | `?string` | Optional | - | getState(): ?string | setState(?string state): void |
| `country` | `?string` | Optional | - | getCountry(): ?string | setCountry(?string country): void |
| `latitude` | `?float` | Optional | - | getLatitude(): ?float | setLatitude(?float latitude): void |
| `longitude` | `?float` | Optional | - | getLongitude(): ?float | setLongitude(?float longitude): void |
| `postalCode` | `?string` | Optional | - | getPostalCode(): ?string | setPostalCode(?string postalCode): void |

## Example (as JSON)

```json
{
  "street": "street8",
  "city": "city8",
  "state": "state4",
  "country": "country2",
  "latitude": 56.42
}
```

