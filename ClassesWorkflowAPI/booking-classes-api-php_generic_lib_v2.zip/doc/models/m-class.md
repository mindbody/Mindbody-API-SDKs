
# M Class

## Structure

`MClass`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `description` | [`?Description`](../../doc/models/description.md) | Optional | - | getDescription(): ?Description | setDescription(?Description description): void |
| `instructors` | [`?(Instructor[])`](../../doc/models/instructor.md) | Optional | - | getInstructors(): ?array | setInstructors(?array instructors): void |
| `capacity` | [`?Capacity`](../../doc/models/capacity.md) | Optional | - | getCapacity(): ?Capacity | setCapacity(?Capacity capacity): void |
| `bookingWindow` | [`?BookingWindow`](../../doc/models/booking-window.md) | Optional | - | getBookingWindow(): ?BookingWindow | setBookingWindow(?BookingWindow bookingWindow): void |
| `startDateTime` | `?DateTime` | Optional | - | getStartDateTime(): ?\DateTime | setStartDateTime(?\DateTime startDateTime): void |
| `endDateTime` | `?DateTime` | Optional | - | getEndDateTime(): ?\DateTime | setEndDateTime(?\DateTime endDateTime): void |
| `notes` | `?string` | Optional | - | getNotes(): ?string | setNotes(?string notes): void |
| `bookingInfo` | [`?BookingInfo`](../../doc/models/booking-info.md) | Optional | - | getBookingInfo(): ?BookingInfo | setBookingInfo(?BookingInfo bookingInfo): void |

## Example (as JSON)

```json
{
  "description": {
    "name": "name0",
    "description": "description0",
    "imageUrl": "imageUrl0",
    "notes": "notes0",
    "prerequisites": "prerequisites2"
  },
  "instructors": [
    {
      "level": "firstAssistant",
      "displayName": "displayName2"
    },
    {
      "level": "firstAssistant",
      "displayName": "displayName2"
    }
  ],
  "capacity": {
    "totalCapacity": 150,
    "totalBooked": 136,
    "webCapacity": 14,
    "webBooked": 206,
    "waitlistCapacity": 152
  },
  "bookingWindow": {
    "startDateTime": "2016-03-13T12:52:32.123Z",
    "endDateTime": "2016-03-13T12:52:32.123Z",
    "dailyStartTime": "2016-03-13T12:52:32.123Z",
    "dailyEndTime": "2016-03-13T12:52:32.123Z"
  },
  "startDateTime": "2016-03-13T12:52:32.123Z"
}
```

