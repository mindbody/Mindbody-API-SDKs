
# Booking Window

## Structure

`BookingWindow`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `startDateTime` | `?DateTime` | Optional | - | getStartDateTime(): ?\DateTime | setStartDateTime(?\DateTime startDateTime): void |
| `endDateTime` | `?DateTime` | Optional | - | getEndDateTime(): ?\DateTime | setEndDateTime(?\DateTime endDateTime): void |
| `dailyStartTime` | `?DateTime` | Optional | - | getDailyStartTime(): ?\DateTime | setDailyStartTime(?\DateTime dailyStartTime): void |
| `dailyEndTime` | `?DateTime` | Optional | - | getDailyEndTime(): ?\DateTime | setDailyEndTime(?\DateTime dailyEndTime): void |

## Example (as JSON)

```json
{
  "startDateTime": "2016-03-13T12:52:32.123Z",
  "endDateTime": "2016-03-13T12:52:32.123Z",
  "dailyStartTime": "2016-03-13T12:52:32.123Z",
  "dailyEndTime": "2016-03-13T12:52:32.123Z"
}
```

