
# Location

## Structure

`Location`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `address` | [`?Address`](../../doc/models/address.md) | Optional | - | getAddress(): ?Address | setAddress(?Address address): void |
| `name` | `?string` | Optional | - | getName(): ?string | setName(?string name): void |
| `description` | `?string` | Optional | - | getDescription(): ?string | setDescription(?string description): void |

## Example (as JSON)

```json
{
  "id": 12,
  "address": {
    "street": "street6",
    "city": "city6",
    "state": "state2",
    "country": "country0",
    "latitude": 75.2
  },
  "name": "name4",
  "description": "description4"
}
```

