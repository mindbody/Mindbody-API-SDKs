
# Pricing Option

## Structure

`PricingOption`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `price` | [`?Price`](../../doc/models/price.md) | Optional | - | getPrice(): ?Price | setPrice(?Price price): void |
| `id` | `?string` | Optional | - | getId(): ?string | setId(?string id): void |
| `name` | `?string` | Optional | - | getName(): ?string | setName(?string name): void |
| `session` | [`?Session`](../../doc/models/session.md) | Optional | - | getSession(): ?Session | setSession(?Session session): void |
| `offer` | [`?Offer`](../../doc/models/offer.md) | Optional | - | getOffer(): ?Offer | setOffer(?Offer offer): void |
| `expiration` | [`?Expiration`](../../doc/models/expiration.md) | Optional | - | getExpiration(): ?Expiration | setExpiration(?Expiration expiration): void |
| `membership` | [`?Membership`](../../doc/models/membership.md) | Optional | - | getMembership(): ?Membership | setMembership(?Membership membership): void |

## Example (as JSON)

```json
{
  "price": {
    "unitPrice": 156.68
  },
  "id": "id8",
  "name": "name8",
  "session": {
    "sessionCount": 226,
    "type": "unlimited"
  },
  "offer": {
    "type": "introForNewClients"
  }
}
```

