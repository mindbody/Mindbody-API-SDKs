
# Requested From Enum

## Enumeration

`RequestedFromEnum`

## Fields

| Name |
|  --- |
| `ONLINE` |
| `OFFLINE` |

