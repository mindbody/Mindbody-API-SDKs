
# Description

## Structure

`Description`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `name` | `?string` | Optional | - | getName(): ?string | setName(?string name): void |
| `description` | `?string` | Optional | - | getDescription(): ?string | setDescription(?string description): void |
| `imageUrl` | `?string` | Optional | - | getImageUrl(): ?string | setImageUrl(?string imageUrl): void |
| `notes` | `?string` | Optional | - | getNotes(): ?string | setNotes(?string notes): void |
| `prerequisites` | `?string` | Optional | - | getPrerequisites(): ?string | setPrerequisites(?string prerequisites): void |

## Example (as JSON)

```json
{
  "name": "name6",
  "description": "description6",
  "imageUrl": "imageUrl6",
  "notes": "notes6",
  "prerequisites": "prerequisites4"
}
```

