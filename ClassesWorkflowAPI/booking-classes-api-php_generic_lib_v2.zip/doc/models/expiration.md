
# Expiration

## Structure

`Expiration`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `activationType` | [`?string(ActivationTypeEnum)`](../../doc/models/activation-type-enum.md) | Optional | - | getActivationType(): ?string | setActivationType(?string activationType): void |
| `duration` | `?int` | Optional | - | getDuration(): ?int | setDuration(?int duration): void |
| `durationUnit` | [`?string(DurationUnitEnum)`](../../doc/models/duration-unit-enum.md) | Optional | - | getDurationUnit(): ?string | setDurationUnit(?string durationUnit): void |

## Example (as JSON)

```json
{
  "activationType": "dateOfFirstVisit",
  "duration": 22,
  "durationUnit": "days"
}
```

