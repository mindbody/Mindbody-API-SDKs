
# Workflows Class Bookings Classes Request

## Structure

`WorkflowsClassBookingsClassesRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `bookingMethod` | [`?BookingMethod1`](../../doc/models/booking-method-1.md) | Optional | - | getBookingMethod(): ?BookingMethod1 | setBookingMethod(?BookingMethod1 bookingMethod): void |
| `class` | [`?Class1`](../../doc/models/class-1.md) | Optional | - | getClass(): ?Class1 | setClass(?Class1 class): void |
| `notification` | [`?string(NotificationEnum)`](../../doc/models/notification-enum.md) | Optional | - | getNotification(): ?string | setNotification(?string notification): void |
| `spotInfo` | [`?SpotInfo`](../../doc/models/spot-info.md) | Optional | - | getSpotInfo(): ?SpotInfo | setSpotInfo(?SpotInfo spotInfo): void |

## Example (as JSON)

```json
{
  "bookingMethod": {
    "type": "pricingOption",
    "id": "id4",
    "waitlistEntryId": 190
  },
  "class": {
    "id": 44
  },
  "notification": "email",
  "spotInfo": {
    "spotNumber": 152,
    "confirmationType": "manual",
    "spotAssignment": "manual"
  }
}
```

