// <copyright file="Class2.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using BookingClassesAPI.Standard;
using BookingClassesAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace BookingClassesAPI.Standard.Models
{
    /// <summary>
    /// Class2.
    /// </summary>
    public class Class2
    {
        private string notes;
        private Dictionary<string, bool> shouldSerialize = new Dictionary<string, bool>
        {
            { "notes", false },
        };

        /// <summary>
        /// Initializes a new instance of the <see cref="Class2"/> class.
        /// </summary>
        public Class2()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Class2"/> class.
        /// </summary>
        /// <param name="location">location.</param>
        /// <param name="description">description.</param>
        /// <param name="instructors">instructors.</param>
        /// <param name="capacity">capacity.</param>
        /// <param name="bookingWindow">bookingWindow.</param>
        /// <param name="startDateTime">startDateTime.</param>
        /// <param name="endDateTime">endDateTime.</param>
        /// <param name="notes">notes.</param>
        /// <param name="bookingInfo">bookingInfo.</param>
        public Class2(
            Models.Location location = null,
            Models.Description description = null,
            List<Models.Instructor> instructors = null,
            Models.Capacity capacity = null,
            Models.BookingWindow bookingWindow = null,
            DateTime? startDateTime = null,
            DateTime? endDateTime = null,
            string notes = null,
            Models.BookingInfo bookingInfo = null)
        {
            this.Location = location;
            this.Description = description;
            this.Instructors = instructors;
            this.Capacity = capacity;
            this.BookingWindow = bookingWindow;
            this.StartDateTime = startDateTime;
            this.EndDateTime = endDateTime;

            if (notes != null)
            {
                this.Notes = notes;
            }
            this.BookingInfo = bookingInfo;
        }

        /// <summary>
        /// Gets or sets Location.
        /// </summary>
        [JsonProperty("location", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Location Location { get; set; }

        /// <summary>
        /// Gets or sets Description.
        /// </summary>
        [JsonProperty("description", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Description Description { get; set; }

        /// <summary>
        /// Gets or sets Instructors.
        /// </summary>
        [JsonProperty("instructors", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.Instructor> Instructors { get; set; }

        /// <summary>
        /// Gets or sets Capacity.
        /// </summary>
        [JsonProperty("capacity", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Capacity Capacity { get; set; }

        /// <summary>
        /// Gets or sets BookingWindow.
        /// </summary>
        [JsonProperty("bookingWindow", NullValueHandling = NullValueHandling.Ignore)]
        public Models.BookingWindow BookingWindow { get; set; }

        /// <summary>
        /// Gets or sets StartDateTime.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("startDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? StartDateTime { get; set; }

        /// <summary>
        /// Gets or sets EndDateTime.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("endDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? EndDateTime { get; set; }

        /// <summary>
        /// Gets or sets Notes.
        /// </summary>
        [JsonProperty("notes")]
        public string Notes
        {
            get
            {
                return this.notes;
            }

            set
            {
                this.shouldSerialize["notes"] = true;
                this.notes = value;
            }
        }

        /// <summary>
        /// Gets or sets BookingInfo.
        /// </summary>
        [JsonProperty("bookingInfo", NullValueHandling = NullValueHandling.Ignore)]
        public Models.BookingInfo BookingInfo { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"Class2 : ({string.Join(", ", toStringOutput)})";
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetNotes()
        {
            this.shouldSerialize["notes"] = false;
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeNotes()
        {
            return this.shouldSerialize["notes"];
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is Class2 other &&
                (this.Location == null && other.Location == null ||
                 this.Location?.Equals(other.Location) == true) &&
                (this.Description == null && other.Description == null ||
                 this.Description?.Equals(other.Description) == true) &&
                (this.Instructors == null && other.Instructors == null ||
                 this.Instructors?.Equals(other.Instructors) == true) &&
                (this.Capacity == null && other.Capacity == null ||
                 this.Capacity?.Equals(other.Capacity) == true) &&
                (this.BookingWindow == null && other.BookingWindow == null ||
                 this.BookingWindow?.Equals(other.BookingWindow) == true) &&
                (this.StartDateTime == null && other.StartDateTime == null ||
                 this.StartDateTime?.Equals(other.StartDateTime) == true) &&
                (this.EndDateTime == null && other.EndDateTime == null ||
                 this.EndDateTime?.Equals(other.EndDateTime) == true) &&
                (this.Notes == null && other.Notes == null ||
                 this.Notes?.Equals(other.Notes) == true) &&
                (this.BookingInfo == null && other.BookingInfo == null ||
                 this.BookingInfo?.Equals(other.BookingInfo) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"Location = {(this.Location == null ? "null" : this.Location.ToString())}");
            toStringOutput.Add($"Description = {(this.Description == null ? "null" : this.Description.ToString())}");
            toStringOutput.Add($"Instructors = {(this.Instructors == null ? "null" : $"[{string.Join(", ", this.Instructors)} ]")}");
            toStringOutput.Add($"Capacity = {(this.Capacity == null ? "null" : this.Capacity.ToString())}");
            toStringOutput.Add($"BookingWindow = {(this.BookingWindow == null ? "null" : this.BookingWindow.ToString())}");
            toStringOutput.Add($"StartDateTime = {(this.StartDateTime == null ? "null" : this.StartDateTime.ToString())}");
            toStringOutput.Add($"EndDateTime = {(this.EndDateTime == null ? "null" : this.EndDateTime.ToString())}");
            toStringOutput.Add($"Notes = {this.Notes ?? "null"}");
            toStringOutput.Add($"BookingInfo = {(this.BookingInfo == null ? "null" : this.BookingInfo.ToString())}");
        }
    }
}