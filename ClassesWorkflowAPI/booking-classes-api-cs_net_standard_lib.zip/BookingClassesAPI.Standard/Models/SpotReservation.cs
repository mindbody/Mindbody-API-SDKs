// <copyright file="SpotReservation.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using BookingClassesAPI.Standard;
using BookingClassesAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace BookingClassesAPI.Standard.Models
{
    /// <summary>
    /// SpotReservation.
    /// </summary>
    public class SpotReservation
    {
        private DateTime? confirmationDate;
        private Dictionary<string, bool> shouldSerialize = new Dictionary<string, bool>
        {
            { "confirmationDate", false },
        };

        /// <summary>
        /// Initializes a new instance of the <see cref="SpotReservation"/> class.
        /// </summary>
        public SpotReservation()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="SpotReservation"/> class.
        /// </summary>
        /// <param name="visitId">visitId.</param>
        /// <param name="classId">classId.</param>
        /// <param name="reservationType">reservationType.</param>
        /// <param name="status">status.</param>
        /// <param name="confirmationDate">confirmationDate.</param>
        public SpotReservation(
            string visitId = null,
            string classId = null,
            string reservationType = null,
            Models.Status2Enum? status = null,
            DateTime? confirmationDate = null)
        {
            this.VisitId = visitId;
            this.ClassId = classId;
            this.ReservationType = reservationType;
            this.Status = status;

            if (confirmationDate != null)
            {
                this.ConfirmationDate = confirmationDate;
            }
        }

        /// <summary>
        /// Gets or sets VisitId.
        /// </summary>
        [JsonProperty("visitId", NullValueHandling = NullValueHandling.Ignore)]
        public string VisitId { get; set; }

        /// <summary>
        /// Gets or sets ClassId.
        /// </summary>
        [JsonProperty("classId", NullValueHandling = NullValueHandling.Ignore)]
        public string ClassId { get; set; }

        /// <summary>
        /// Gets or sets ReservationType.
        /// </summary>
        [JsonProperty("reservationType", NullValueHandling = NullValueHandling.Ignore)]
        public string ReservationType { get; set; }

        /// <summary>
        /// Gets or sets Status.
        /// </summary>
        [JsonProperty("status", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Status2Enum? Status { get; set; }

        /// <summary>
        /// Gets or sets ConfirmationDate.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("confirmationDate")]
        public DateTime? ConfirmationDate
        {
            get
            {
                return this.confirmationDate;
            }

            set
            {
                this.shouldSerialize["confirmationDate"] = true;
                this.confirmationDate = value;
            }
        }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"SpotReservation : ({string.Join(", ", toStringOutput)})";
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetConfirmationDate()
        {
            this.shouldSerialize["confirmationDate"] = false;
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeConfirmationDate()
        {
            return this.shouldSerialize["confirmationDate"];
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is SpotReservation other &&
                (this.VisitId == null && other.VisitId == null ||
                 this.VisitId?.Equals(other.VisitId) == true) &&
                (this.ClassId == null && other.ClassId == null ||
                 this.ClassId?.Equals(other.ClassId) == true) &&
                (this.ReservationType == null && other.ReservationType == null ||
                 this.ReservationType?.Equals(other.ReservationType) == true) &&
                (this.Status == null && other.Status == null ||
                 this.Status?.Equals(other.Status) == true) &&
                (this.ConfirmationDate == null && other.ConfirmationDate == null ||
                 this.ConfirmationDate?.Equals(other.ConfirmationDate) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"VisitId = {this.VisitId ?? "null"}");
            toStringOutput.Add($"ClassId = {this.ClassId ?? "null"}");
            toStringOutput.Add($"ReservationType = {this.ReservationType ?? "null"}");
            toStringOutput.Add($"Status = {(this.Status == null ? "null" : this.Status.ToString())}");
            toStringOutput.Add($"ConfirmationDate = {(this.ConfirmationDate == null ? "null" : this.ConfirmationDate.ToString())}");
        }
    }
}