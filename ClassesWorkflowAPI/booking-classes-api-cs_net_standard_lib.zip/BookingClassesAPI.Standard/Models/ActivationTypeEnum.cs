// <copyright file="ActivationTypeEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using APIMatic.Core.Utilities.Converters;
using BookingClassesAPI.Standard;
using BookingClassesAPI.Standard.Utilities;
using Newtonsoft.Json;

namespace BookingClassesAPI.Standard.Models
{
    /// <summary>
    /// ActivationTypeEnum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum ActivationTypeEnum
    {
        /// <summary>
        /// DateOfFirstVisit.
        /// </summary>
        [EnumMember(Value = "dateOfFirstVisit")]
        DateOfFirstVisit,

        /// <summary>
        /// DateOfPurchase.
        /// </summary>
        [EnumMember(Value = "dateOfPurchase")]
        DateOfPurchase
    }
}