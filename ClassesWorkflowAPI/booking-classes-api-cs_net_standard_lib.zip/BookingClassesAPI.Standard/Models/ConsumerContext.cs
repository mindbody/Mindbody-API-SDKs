// <copyright file="ConsumerContext.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using BookingClassesAPI.Standard;
using BookingClassesAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace BookingClassesAPI.Standard.Models
{
    /// <summary>
    /// ConsumerContext.
    /// </summary>
    public class ConsumerContext
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ConsumerContext"/> class.
        /// </summary>
        public ConsumerContext()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ConsumerContext"/> class.
        /// </summary>
        /// <param name="waitlistEntries">waitlistEntries.</param>
        /// <param name="bookingMethods">bookingMethods.</param>
        public ConsumerContext(
            List<Models.WaitlistEntry> waitlistEntries = null,
            List<Models.BookingMethod> bookingMethods = null)
        {
            this.WaitlistEntries = waitlistEntries;
            this.BookingMethods = bookingMethods;
        }

        /// <summary>
        /// Gets or sets WaitlistEntries.
        /// </summary>
        [JsonProperty("waitlistEntries", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.WaitlistEntry> WaitlistEntries { get; set; }

        /// <summary>
        /// Gets or sets BookingMethods.
        /// </summary>
        [JsonProperty("bookingMethods", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.BookingMethod> BookingMethods { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"ConsumerContext : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is ConsumerContext other &&
                (this.WaitlistEntries == null && other.WaitlistEntries == null ||
                 this.WaitlistEntries?.Equals(other.WaitlistEntries) == true) &&
                (this.BookingMethods == null && other.BookingMethods == null ||
                 this.BookingMethods?.Equals(other.BookingMethods) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"WaitlistEntries = {(this.WaitlistEntries == null ? "null" : $"[{string.Join(", ", this.WaitlistEntries)} ]")}");
            toStringOutput.Add($"BookingMethods = {(this.BookingMethods == null ? "null" : $"[{string.Join(", ", this.BookingMethods)} ]")}");
        }
    }
}