// <copyright file="Expiration.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using BookingClassesAPI.Standard;
using BookingClassesAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace BookingClassesAPI.Standard.Models
{
    /// <summary>
    /// Expiration.
    /// </summary>
    public class Expiration
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Expiration"/> class.
        /// </summary>
        public Expiration()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Expiration"/> class.
        /// </summary>
        /// <param name="activationType">activationType.</param>
        /// <param name="duration">duration.</param>
        /// <param name="durationUnit">durationUnit.</param>
        public Expiration(
            Models.ActivationTypeEnum? activationType = null,
            int? duration = null,
            Models.DurationUnitEnum? durationUnit = null)
        {
            this.ActivationType = activationType;
            this.Duration = duration;
            this.DurationUnit = durationUnit;
        }

        /// <summary>
        /// Gets or sets ActivationType.
        /// </summary>
        [JsonProperty("activationType", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ActivationTypeEnum? ActivationType { get; set; }

        /// <summary>
        /// Gets or sets Duration.
        /// </summary>
        [JsonProperty("duration", NullValueHandling = NullValueHandling.Ignore)]
        public int? Duration { get; set; }

        /// <summary>
        /// Gets or sets DurationUnit.
        /// </summary>
        [JsonProperty("durationUnit", NullValueHandling = NullValueHandling.Ignore)]
        public Models.DurationUnitEnum? DurationUnit { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"Expiration : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is Expiration other &&
                (this.ActivationType == null && other.ActivationType == null ||
                 this.ActivationType?.Equals(other.ActivationType) == true) &&
                (this.Duration == null && other.Duration == null ||
                 this.Duration?.Equals(other.Duration) == true) &&
                (this.DurationUnit == null && other.DurationUnit == null ||
                 this.DurationUnit?.Equals(other.DurationUnit) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"ActivationType = {(this.ActivationType == null ? "null" : this.ActivationType.ToString())}");
            toStringOutput.Add($"Duration = {(this.Duration == null ? "null" : this.Duration.ToString())}");
            toStringOutput.Add($"DurationUnit = {(this.DurationUnit == null ? "null" : this.DurationUnit.ToString())}");
        }
    }
}