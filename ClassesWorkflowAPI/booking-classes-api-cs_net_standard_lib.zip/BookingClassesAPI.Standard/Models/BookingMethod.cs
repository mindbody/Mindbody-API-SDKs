// <copyright file="BookingMethod.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using BookingClassesAPI.Standard;
using BookingClassesAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace BookingClassesAPI.Standard.Models
{
    /// <summary>
    /// BookingMethod.
    /// </summary>
    public class BookingMethod
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BookingMethod"/> class.
        /// </summary>
        public BookingMethod()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="BookingMethod"/> class.
        /// </summary>
        /// <param name="id">id.</param>
        /// <param name="name">name.</param>
        /// <param name="remaining">remaining.</param>
        /// <param name="remainingAfterScheduledVisits">remainingAfterScheduledVisits.</param>
        /// <param name="expirationDate">expirationDate.</param>
        /// <param name="activationDate">activationDate.</param>
        /// <param name="status">status.</param>
        public BookingMethod(
            string id = null,
            string name = null,
            int? remaining = null,
            int? remainingAfterScheduledVisits = null,
            DateTime? expirationDate = null,
            DateTime? activationDate = null,
            Models.Status1Enum? status = null)
        {
            this.Id = id;
            this.Name = name;
            this.Remaining = remaining;
            this.RemainingAfterScheduledVisits = remainingAfterScheduledVisits;
            this.ExpirationDate = expirationDate;
            this.ActivationDate = activationDate;
            this.Status = status;
        }

        /// <summary>
        /// Gets or sets Id.
        /// </summary>
        [JsonProperty("id", NullValueHandling = NullValueHandling.Ignore)]
        public string Id { get; set; }

        /// <summary>
        /// Gets or sets Name.
        /// </summary>
        [JsonProperty("name", NullValueHandling = NullValueHandling.Ignore)]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets Remaining.
        /// </summary>
        [JsonProperty("remaining", NullValueHandling = NullValueHandling.Ignore)]
        public int? Remaining { get; set; }

        /// <summary>
        /// Gets or sets RemainingAfterScheduledVisits.
        /// </summary>
        [JsonProperty("remainingAfterScheduledVisits", NullValueHandling = NullValueHandling.Ignore)]
        public int? RemainingAfterScheduledVisits { get; set; }

        /// <summary>
        /// Gets or sets ExpirationDate.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("expirationDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? ExpirationDate { get; set; }

        /// <summary>
        /// Gets or sets ActivationDate.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("activationDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? ActivationDate { get; set; }

        /// <summary>
        /// Gets or sets Status.
        /// </summary>
        [JsonProperty("status", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Status1Enum? Status { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"BookingMethod : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is BookingMethod other &&
                (this.Id == null && other.Id == null ||
                 this.Id?.Equals(other.Id) == true) &&
                (this.Name == null && other.Name == null ||
                 this.Name?.Equals(other.Name) == true) &&
                (this.Remaining == null && other.Remaining == null ||
                 this.Remaining?.Equals(other.Remaining) == true) &&
                (this.RemainingAfterScheduledVisits == null && other.RemainingAfterScheduledVisits == null ||
                 this.RemainingAfterScheduledVisits?.Equals(other.RemainingAfterScheduledVisits) == true) &&
                (this.ExpirationDate == null && other.ExpirationDate == null ||
                 this.ExpirationDate?.Equals(other.ExpirationDate) == true) &&
                (this.ActivationDate == null && other.ActivationDate == null ||
                 this.ActivationDate?.Equals(other.ActivationDate) == true) &&
                (this.Status == null && other.Status == null ||
                 this.Status?.Equals(other.Status) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"Id = {this.Id ?? "null"}");
            toStringOutput.Add($"Name = {this.Name ?? "null"}");
            toStringOutput.Add($"Remaining = {(this.Remaining == null ? "null" : this.Remaining.ToString())}");
            toStringOutput.Add($"RemainingAfterScheduledVisits = {(this.RemainingAfterScheduledVisits == null ? "null" : this.RemainingAfterScheduledVisits.ToString())}");
            toStringOutput.Add($"ExpirationDate = {(this.ExpirationDate == null ? "null" : this.ExpirationDate.ToString())}");
            toStringOutput.Add($"ActivationDate = {(this.ActivationDate == null ? "null" : this.ActivationDate.ToString())}");
            toStringOutput.Add($"Status = {(this.Status == null ? "null" : this.Status.ToString())}");
        }
    }
}