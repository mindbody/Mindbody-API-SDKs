// <copyright file="ClassesByLocation.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using BookingClassesAPI.Standard;
using BookingClassesAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace BookingClassesAPI.Standard.Models
{
    /// <summary>
    /// ClassesByLocation.
    /// </summary>
    public class ClassesByLocation
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ClassesByLocation"/> class.
        /// </summary>
        public ClassesByLocation()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ClassesByLocation"/> class.
        /// </summary>
        /// <param name="location">location.</param>
        /// <param name="classes">classes.</param>
        public ClassesByLocation(
            Models.Location location = null,
            List<Models.Class> classes = null)
        {
            this.Location = location;
            this.Classes = classes;
        }

        /// <summary>
        /// Gets or sets Location.
        /// </summary>
        [JsonProperty("location", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Location Location { get; set; }

        /// <summary>
        /// Gets or sets Classes.
        /// </summary>
        [JsonProperty("classes", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.Class> Classes { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"ClassesByLocation : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is ClassesByLocation other &&
                (this.Location == null && other.Location == null ||
                 this.Location?.Equals(other.Location) == true) &&
                (this.Classes == null && other.Classes == null ||
                 this.Classes?.Equals(other.Classes) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"Location = {(this.Location == null ? "null" : this.Location.ToString())}");
            toStringOutput.Add($"Classes = {(this.Classes == null ? "null" : $"[{string.Join(", ", this.Classes)} ]")}");
        }
    }
}