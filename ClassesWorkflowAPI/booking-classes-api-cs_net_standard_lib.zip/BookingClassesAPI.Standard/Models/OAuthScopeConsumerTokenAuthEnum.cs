// <copyright file="OAuthScopeConsumerTokenAuthEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using APIMatic.Core.Utilities.Converters;
using BookingClassesAPI.Standard;
using BookingClassesAPI.Standard.Utilities;
using Newtonsoft.Json;
using System.Reflection;

namespace BookingClassesAPI.Standard.Models
{
    /// <summary>
    /// OAuthScopeConsumerTokenAuthEnum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum OAuthScopeConsumerTokenAuthEnum
    {
        /// <summary>
        ///book classes
        /// Write.
        /// </summary>
        [EnumMember(Value = "write")]
        Write,

        /// <summary>
        ///see bookable classes
        /// Read.
        /// </summary>
        [EnumMember(Value = "read")]
        Read
    }

    static class OAuthScopeConsumerTokenAuthEnumExtention
    {
        internal static string GetValues(this IEnumerable<OAuthScopeConsumerTokenAuthEnum> values)
        {
            return values != null ? string.Join(" ", values.Select(s => s.GetValue()).Where(s => !string.IsNullOrEmpty(s)).ToArray()) : null;
        }

        private static string GetValue(this Enum value)
        {
            return value.GetType()
                .GetTypeInfo()
                .DeclaredMembers
                .SingleOrDefault(x => x.Name == value.ToString())
                ?.GetCustomAttribute<EnumMemberAttribute>(false)
                ?.Value;
        }
    }
}