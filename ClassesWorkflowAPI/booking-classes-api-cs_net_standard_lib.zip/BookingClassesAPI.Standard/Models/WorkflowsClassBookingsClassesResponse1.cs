// <copyright file="WorkflowsClassBookingsClassesResponse1.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using BookingClassesAPI.Standard;
using BookingClassesAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace BookingClassesAPI.Standard.Models
{
    /// <summary>
    /// WorkflowsClassBookingsClassesResponse1.
    /// </summary>
    public class WorkflowsClassBookingsClassesResponse1
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="WorkflowsClassBookingsClassesResponse1"/> class.
        /// </summary>
        public WorkflowsClassBookingsClassesResponse1()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="WorkflowsClassBookingsClassesResponse1"/> class.
        /// </summary>
        /// <param name="visit">visit.</param>
        /// <param name="bookingStatus">bookingStatus.</param>
        /// <param name="waitlistEntry">waitlistEntry.</param>
        /// <param name="spotReservation">spotReservation.</param>
        /// <param name="error">error.</param>
        public WorkflowsClassBookingsClassesResponse1(
            Models.Visit visit = null,
            Models.BookingStatusEnum? bookingStatus = null,
            Models.WaitlistEntry1 waitlistEntry = null,
            Models.SpotReservation spotReservation = null,
            Models.Error error = null)
        {
            this.Visit = visit;
            this.BookingStatus = bookingStatus;
            this.WaitlistEntry = waitlistEntry;
            this.SpotReservation = spotReservation;
            this.Error = error;
        }

        /// <summary>
        /// Gets or sets Visit.
        /// </summary>
        [JsonProperty("visit", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Visit Visit { get; set; }

        /// <summary>
        /// Gets or sets BookingStatus.
        /// </summary>
        [JsonProperty("bookingStatus", NullValueHandling = NullValueHandling.Ignore)]
        public Models.BookingStatusEnum? BookingStatus { get; set; }

        /// <summary>
        /// Gets or sets WaitlistEntry.
        /// </summary>
        [JsonProperty("waitlistEntry", NullValueHandling = NullValueHandling.Ignore)]
        public Models.WaitlistEntry1 WaitlistEntry { get; set; }

        /// <summary>
        /// Gets or sets SpotReservation.
        /// </summary>
        [JsonProperty("spotReservation", NullValueHandling = NullValueHandling.Ignore)]
        public Models.SpotReservation SpotReservation { get; set; }

        /// <summary>
        /// Gets or sets Error.
        /// </summary>
        [JsonProperty("error", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Error Error { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"WorkflowsClassBookingsClassesResponse1 : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is WorkflowsClassBookingsClassesResponse1 other &&
                (this.Visit == null && other.Visit == null ||
                 this.Visit?.Equals(other.Visit) == true) &&
                (this.BookingStatus == null && other.BookingStatus == null ||
                 this.BookingStatus?.Equals(other.BookingStatus) == true) &&
                (this.WaitlistEntry == null && other.WaitlistEntry == null ||
                 this.WaitlistEntry?.Equals(other.WaitlistEntry) == true) &&
                (this.SpotReservation == null && other.SpotReservation == null ||
                 this.SpotReservation?.Equals(other.SpotReservation) == true) &&
                (this.Error == null && other.Error == null ||
                 this.Error?.Equals(other.Error) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"Visit = {(this.Visit == null ? "null" : this.Visit.ToString())}");
            toStringOutput.Add($"BookingStatus = {(this.BookingStatus == null ? "null" : this.BookingStatus.ToString())}");
            toStringOutput.Add($"WaitlistEntry = {(this.WaitlistEntry == null ? "null" : this.WaitlistEntry.ToString())}");
            toStringOutput.Add($"SpotReservation = {(this.SpotReservation == null ? "null" : this.SpotReservation.ToString())}");
            toStringOutput.Add($"Error = {(this.Error == null ? "null" : this.Error.ToString())}");
        }
    }
}