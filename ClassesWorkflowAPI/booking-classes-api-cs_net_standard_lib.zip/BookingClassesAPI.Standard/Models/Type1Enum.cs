// <copyright file="Type1Enum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using APIMatic.Core.Utilities.Converters;
using BookingClassesAPI.Standard;
using BookingClassesAPI.Standard.Utilities;
using Newtonsoft.Json;

namespace BookingClassesAPI.Standard.Models
{
    /// <summary>
    /// Type1Enum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum Type1Enum
    {
        /// <summary>
        /// Single.
        /// </summary>
        [EnumMember(Value = "single")]
        Single,

        /// <summary>
        /// Series.
        /// </summary>
        [EnumMember(Value = "series")]
        Series,

        /// <summary>
        /// Unlimited.
        /// </summary>
        [EnumMember(Value = "unlimited")]
        Unlimited
    }
}