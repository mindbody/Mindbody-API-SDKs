// <copyright file="Type2Enum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using APIMatic.Core.Utilities.Converters;
using BookingClassesAPI.Standard;
using BookingClassesAPI.Standard.Utilities;
using Newtonsoft.Json;

namespace BookingClassesAPI.Standard.Models
{
    /// <summary>
    /// Type2Enum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum Type2Enum
    {
        /// <summary>
        /// Intro.
        /// </summary>
        [EnumMember(Value = "intro")]
        Intro,

        /// <summary>
        /// IntroForNewClients.
        /// </summary>
        [EnumMember(Value = "introForNewClients")]
        IntroForNewClients,

        /// <summary>
        /// Regular.
        /// </summary>
        [EnumMember(Value = "regular")]
        Regular
    }
}