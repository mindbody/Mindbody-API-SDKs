// <copyright file="IApiKeyAuthCredentials.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;

namespace BookingClassesAPI.Standard.Authentication
{
    /// <summary>
    /// Authentication configuration interface for ApiKeyAuth.
    /// </summary>
    public interface IApiKeyAuthCredentials
    {
        /// <summary>
        /// Gets string value for apiKey.
        /// </summary>
        string ApiKey { get; }

        /// <summary>
        ///  Returns true if credentials matched.
        /// </summary>
        /// <param name="apiKey"> The string value for credentials.</param>
        /// <returns>True if credentials matched.</returns>
        bool Equals(string apiKey);
    }
}