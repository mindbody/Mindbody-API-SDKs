
# Membership

## Structure

`Membership`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "id": "id8"
}
```

