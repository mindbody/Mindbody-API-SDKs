
# Pricing Option

## Structure

`PricingOption`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Price` | [`Price`](../../doc/models/price.md) | Optional | - |
| `Id` | `string` | Optional | - |
| `Name` | `string` | Optional | - |
| `Session` | [`Session`](../../doc/models/session.md) | Optional | - |
| `Offer` | [`Offer`](../../doc/models/offer.md) | Optional | - |
| `Expiration` | [`Expiration`](../../doc/models/expiration.md) | Optional | - |
| `Membership` | [`Membership`](../../doc/models/membership.md) | Optional | - |

## Example (as JSON)

```json
{
  "price": {
    "unitPrice": 156.68
  },
  "id": "id8",
  "name": "name8",
  "session": {
    "sessionCount": 226,
    "type": "unlimited"
  },
  "offer": {
    "type": "introForNewClients"
  }
}
```

