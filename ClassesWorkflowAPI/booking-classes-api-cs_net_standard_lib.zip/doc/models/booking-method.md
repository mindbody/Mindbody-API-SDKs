
# Booking Method

## Structure

`BookingMethod`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `string` | Optional | - |
| `Name` | `string` | Optional | - |
| `Remaining` | `int?` | Optional | - |
| `RemainingAfterScheduledVisits` | `int?` | Optional | - |
| `ExpirationDate` | `DateTime?` | Optional | - |
| `ActivationDate` | `DateTime?` | Optional | - |
| `Status` | [`Status1Enum?`](../../doc/models/status-1-enum.md) | Optional | - |

## Example (as JSON)

```json
{
  "id": "id4",
  "name": "name4",
  "remaining": 248,
  "remainingAfterScheduledVisits": 158,
  "expirationDate": "2016-03-13T12:52:32.123Z"
}
```

