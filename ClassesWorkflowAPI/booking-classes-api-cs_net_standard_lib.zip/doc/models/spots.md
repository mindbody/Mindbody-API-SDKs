
# Spots

## Structure

`Spots`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Reserved` | `List<int>` | Optional | - |
| `Available` | `List<int>` | Optional | - |
| `Unavailable` | `List<int>` | Optional | - |
| `Mine` | `List<int?>` | Optional | - |

## Example (as JSON)

```json
{
  "reserved": [
    125
  ],
  "available": [
    28
  ],
  "unavailable": [
    80
  ],
  "mine": [
    111
  ]
}
```

