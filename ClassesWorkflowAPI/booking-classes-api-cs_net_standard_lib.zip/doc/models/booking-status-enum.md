
# Booking Status Enum

## Enumeration

`BookingStatusEnum`

## Fields

| Name |
|  --- |
| `Success` |
| `Error` |
| `AwaitingPayment` |
| `Waitlist` |

