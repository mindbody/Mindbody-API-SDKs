
# Pagination

## Structure

`Pagination`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `HasNextPage` | `bool?` | Optional | - |
| `HasPreviousPage` | `bool?` | Optional | - |
| `StartCursor` | `string` | Optional | - |
| `EndCursor` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "hasNextPage": false,
  "hasPreviousPage": false,
  "startCursor": "startCursor8",
  "endCursor": "endCursor2"
}
```

