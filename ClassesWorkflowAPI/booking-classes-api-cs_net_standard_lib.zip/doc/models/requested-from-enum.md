
# Requested From Enum

## Enumeration

`RequestedFromEnum`

## Fields

| Name |
|  --- |
| `Online` |
| `Offline` |

