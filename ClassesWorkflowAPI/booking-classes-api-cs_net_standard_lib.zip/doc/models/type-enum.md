
# Type Enum

## Enumeration

`TypeEnum`

## Fields

| Name |
|  --- |
| `Pass` |
| `PricingOption` |
| `Free` |
| `Waitlist` |
| `Unpaid` |

