
# Workflows Class Bookings Classes Response 2

## Structure

`WorkflowsClassBookingsClassesResponse2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Class` | [`Class2`](../../doc/models/class-2.md) | Optional | - |
| `ConsumerContext` | [`ConsumerContext1`](../../doc/models/consumer-context-1.md) | Optional | - |

## Example (as JSON)

```json
{
  "class": {
    "location": {
      "id": 26,
      "address": {
        "street": "street6",
        "city": "city6",
        "state": "state2",
        "country": "country0",
        "latitude": 75.2
      },
      "name": "name4",
      "description": "description6"
    },
    "description": {
      "name": "name0",
      "description": "description0",
      "imageUrl": "imageUrl0",
      "notes": "notes0",
      "prerequisites": "prerequisites2"
    },
    "instructors": [
      {
        "level": "firstAssistant",
        "displayName": "displayName2"
      },
      {
        "level": "firstAssistant",
        "displayName": "displayName2"
      }
    ],
    "capacity": {
      "totalCapacity": 150,
      "totalBooked": 136,
      "webCapacity": 14,
      "webBooked": 206,
      "waitlistCapacity": 152
    },
    "bookingWindow": {
      "startDateTime": "2016-03-13T12:52:32.123Z",
      "endDateTime": "2016-03-13T12:52:32.123Z",
      "dailyStartTime": "2016-03-13T12:52:32.123Z",
      "dailyEndTime": "2016-03-13T12:52:32.123Z"
    }
  },
  "consumerContext": {
    "waitlistEntries": [
      {
        "id": 248,
        "classId": 124,
        "requestDateTime": "2016-03-13T12:52:32.123Z",
        "requestedFrom": "online",
        "visitId": 132
      },
      {
        "id": 248,
        "classId": 124,
        "requestDateTime": "2016-03-13T12:52:32.123Z",
        "requestedFrom": "online",
        "visitId": 132
      }
    ],
    "bookingMethods": [
      {
        "id": "id0",
        "name": "name0",
        "remaining": 204,
        "remainingAfterScheduledVisits": 114,
        "expirationDate": "2016-03-13T12:52:32.123Z"
      },
      {
        "id": "id0",
        "name": "name0",
        "remaining": 204,
        "remainingAfterScheduledVisits": 114,
        "expirationDate": "2016-03-13T12:52:32.123Z"
      },
      {
        "id": "id0",
        "name": "name0",
        "remaining": 204,
        "remainingAfterScheduledVisits": 114,
        "expirationDate": "2016-03-13T12:52:32.123Z"
      }
    ],
    "pricingOptions": [
      {
        "price": {
          "unitPrice": 156.68
        },
        "id": "id2",
        "name": "name2",
        "session": {
          "sessionCount": 226,
          "type": "unlimited"
        },
        "offer": {
          "type": "introForNewClients"
        }
      },
      {
        "price": {
          "unitPrice": 156.68
        },
        "id": "id2",
        "name": "name2",
        "session": {
          "sessionCount": 226,
          "type": "unlimited"
        },
        "offer": {
          "type": "introForNewClients"
        }
      },
      {
        "price": {
          "unitPrice": 156.68
        },
        "id": "id2",
        "name": "name2",
        "session": {
          "sessionCount": 226,
          "type": "unlimited"
        },
        "offer": {
          "type": "introForNewClients"
        }
      }
    ]
  }
}
```

