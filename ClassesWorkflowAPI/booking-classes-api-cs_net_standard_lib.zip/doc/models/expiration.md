
# Expiration

## Structure

`Expiration`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ActivationType` | [`ActivationTypeEnum?`](../../doc/models/activation-type-enum.md) | Optional | - |
| `Duration` | `int?` | Optional | - |
| `DurationUnit` | [`DurationUnitEnum?`](../../doc/models/duration-unit-enum.md) | Optional | - |

## Example (as JSON)

```json
{
  "activationType": "dateOfFirstVisit",
  "duration": 22,
  "durationUnit": "days"
}
```

