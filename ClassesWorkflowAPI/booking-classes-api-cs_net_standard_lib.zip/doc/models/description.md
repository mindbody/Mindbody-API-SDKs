
# Description

## Structure

`Description`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Optional | - |
| `Description` | `string` | Optional | - |
| `ImageUrl` | `string` | Optional | - |
| `Notes` | `string` | Optional | - |
| `Prerequisites` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "name": "name6",
  "description": "description6",
  "imageUrl": "imageUrl6",
  "notes": "notes6",
  "prerequisites": "prerequisites4"
}
```

