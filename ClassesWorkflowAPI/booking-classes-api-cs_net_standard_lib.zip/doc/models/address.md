
# Address

## Structure

`Address`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Street` | `string` | Optional | - |
| `City` | `string` | Optional | - |
| `State` | `string` | Optional | - |
| `Country` | `string` | Optional | - |
| `Latitude` | `double?` | Optional | - |
| `Longitude` | `double?` | Optional | - |
| `PostalCode` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "street": "street8",
  "city": "city8",
  "state": "state4",
  "country": "country2",
  "latitude": 56.42
}
```

