
# Consumer Context

## Structure

`ConsumerContext`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `WaitlistEntries` | [`List<WaitlistEntry>`](../../doc/models/waitlist-entry.md) | Optional | - |
| `BookingMethods` | [`List<BookingMethod>`](../../doc/models/booking-method.md) | Optional | - |

## Example (as JSON)

```json
{
  "waitlistEntries": [
    {
      "id": 248,
      "classId": 124,
      "requestDateTime": "2016-03-13T12:52:32.123Z",
      "requestedFrom": "online",
      "visitId": 132
    },
    {
      "id": 248,
      "classId": 124,
      "requestDateTime": "2016-03-13T12:52:32.123Z",
      "requestedFrom": "online",
      "visitId": 132
    }
  ],
  "bookingMethods": [
    {
      "id": "id0",
      "name": "name0",
      "remaining": 204,
      "remainingAfterScheduledVisits": 114,
      "expirationDate": "2016-03-13T12:52:32.123Z"
    },
    {
      "id": "id0",
      "name": "name0",
      "remaining": 204,
      "remainingAfterScheduledVisits": 114,
      "expirationDate": "2016-03-13T12:52:32.123Z"
    },
    {
      "id": "id0",
      "name": "name0",
      "remaining": 204,
      "remainingAfterScheduledVisits": 114,
      "expirationDate": "2016-03-13T12:52:32.123Z"
    }
  ]
}
```

