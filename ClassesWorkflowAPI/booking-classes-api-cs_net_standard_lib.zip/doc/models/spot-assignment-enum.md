
# Spot Assignment Enum

## Enumeration

`SpotAssignmentEnum`

## Fields

| Name |
|  --- |
| `Manual` |
| `Auto` |

