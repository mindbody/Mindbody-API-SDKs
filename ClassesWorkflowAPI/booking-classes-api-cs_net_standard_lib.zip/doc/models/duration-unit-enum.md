
# Duration Unit Enum

## Enumeration

`DurationUnitEnum`

## Fields

| Name |
|  --- |
| `Days` |
| `Months` |

