
# Confirmation Type Enum

## Enumeration

`ConfirmationTypeEnum`

## Fields

| Name |
|  --- |
| `Manual` |
| `Auto` |

