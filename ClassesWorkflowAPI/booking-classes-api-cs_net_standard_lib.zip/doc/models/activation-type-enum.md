
# Activation Type Enum

## Enumeration

`ActivationTypeEnum`

## Fields

| Name |
|  --- |
| `DateOfFirstVisit` |
| `DateOfPurchase` |

