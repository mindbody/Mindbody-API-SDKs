
# Spot Reservation

## Structure

`SpotReservation`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `VisitId` | `string` | Optional | - |
| `ClassId` | `string` | Optional | - |
| `ReservationType` | `string` | Optional | - |
| `Status` | [`Status2Enum?`](../../doc/models/status-2-enum.md) | Optional | - |
| `ConfirmationDate` | `DateTime?` | Optional | - |

## Example (as JSON)

```json
{
  "visitId": "visitId6",
  "classId": "classId6",
  "reservationType": "reservationType4",
  "status": "confirmed",
  "confirmationDate": "2016-03-13T12:52:32.123Z"
}
```

