
# Waitlist Entry 1

## Structure

`WaitlistEntry1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | - |

## Example (as JSON)

```json
{
  "id": 40
}
```

