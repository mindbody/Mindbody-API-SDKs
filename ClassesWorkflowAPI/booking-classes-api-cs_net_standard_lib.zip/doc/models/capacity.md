
# Capacity

## Structure

`Capacity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `TotalCapacity` | `int?` | Optional | - |
| `TotalBooked` | `int?` | Optional | - |
| `WebCapacity` | `int?` | Optional | - |
| `WebBooked` | `int?` | Optional | - |
| `WaitlistCapacity` | `int?` | Optional | - |
| `Spots` | [`Spots`](../../doc/models/spots.md) | Optional | - |

## Example (as JSON)

```json
{
  "totalCapacity": 22,
  "totalBooked": 248,
  "webCapacity": 142,
  "webBooked": 78,
  "waitlistCapacity": 232
}
```

