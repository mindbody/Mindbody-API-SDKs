
# Spot Info

## Structure

`SpotInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SpotNumber` | `int?` | Optional | - |
| `ConfirmationType` | [`ConfirmationTypeEnum?`](../../doc/models/confirmation-type-enum.md) | Optional | - |
| `SpotAssignment` | [`SpotAssignmentEnum?`](../../doc/models/spot-assignment-enum.md) | Optional | - |

## Example (as JSON)

```json
{
  "spotNumber": 32,
  "confirmationType": "manual",
  "spotAssignment": "manual"
}
```

