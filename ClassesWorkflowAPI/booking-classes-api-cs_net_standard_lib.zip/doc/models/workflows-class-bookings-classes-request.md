
# Workflows Class Bookings Classes Request

## Structure

`WorkflowsClassBookingsClassesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BookingMethod` | [`BookingMethod1`](../../doc/models/booking-method-1.md) | Optional | - |
| `Class` | [`Class1`](../../doc/models/class-1.md) | Optional | - |
| `Notification` | [`NotificationEnum?`](../../doc/models/notification-enum.md) | Optional | - |
| `SpotInfo` | [`SpotInfo`](../../doc/models/spot-info.md) | Optional | - |

## Example (as JSON)

```json
{
  "bookingMethod": {
    "type": "pricingOption",
    "id": "id4",
    "waitlistEntryId": 190
  },
  "class": {
    "id": 44
  },
  "notification": "email",
  "spotInfo": {
    "spotNumber": 152,
    "confirmationType": "manual",
    "spotAssignment": "manual"
  }
}
```

