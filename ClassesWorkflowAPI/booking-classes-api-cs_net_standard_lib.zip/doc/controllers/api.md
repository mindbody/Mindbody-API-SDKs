# API

```csharp
APIController aPIController = client.APIController;
```

## Class Name

`APIController`

## Methods

* [Get Available Classes for Booking](../../doc/controllers/api.md#get-available-classes-for-booking)
* [Book a Class or Add to Waitlist](../../doc/controllers/api.md#book-a-class-or-add-to-waitlist)
* [Get Detailed Information About a Specific Class](../../doc/controllers/api.md#get-detailed-information-about-a-specific-class)


# Get Available Classes for Booking

Retrieves a list of bookable classes along with consumer context information, including available payment methods and the ability to view waitlist entries.

```csharp
GetAvailableClassesForBookingAsync(
    string studioId,
    List<int> locationIds = null,
    List<int> instructorIds = null,
    DateTime? startDate = null,
    DateTime? endDate = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `studioId` | `string` | Header, Required | The Studio ID to filter the classes for. |
| `locationIds` | `List<int>` | Query, Optional | A list of location IDs to filter classes by location. |
| `instructorIds` | `List<int>` | Query, Optional | A list of instructor IDs to filter classes by instructor. |
| `startDate` | `DateTime?` | Query, Optional | The start date for the class filter. Defaults to the current date. |
| `endDate` | `DateTime?` | Query, Optional | The end date for the class filter. Defaults to one day after startDate. |

## Response Type

[`Task<Models.WorkflowsClassBookingsClassesResponse>`](../../doc/models/workflows-class-bookings-classes-response.md)

## Example Usage

```csharp
string studioId = "studioId2";
List<int> locationIds = new List<int>
{
    135,
};

List<int> instructorIds = new List<int>
{
    231,
    232,
};

DateTime? startDate = DateTime.Parse("2016-03-13");
DateTime? endDate = DateTime.Parse("2016-03-13");
try
{
    WorkflowsClassBookingsClassesResponse result = await aPIController.GetAvailableClassesForBookingAsync(
        studioId,
        locationIds,
        instructorIds,
        startDate,
        endDate
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request due to missing or invalid parameters. | [`BadRequestException`](../../doc/models/bad-request-exception.md) |
| 500 | Internal server error. | [`InternalServerErrorException`](../../doc/models/internal-server-error-exception.md) |


# Book a Class or Add to Waitlist

Allows a consumer to book a class directly or add to the waitlist. Also manages the spot reservation for the class.

```csharp
BookAClassOrAddToWaitlistAsync(
    string studioId,
    List<Models.WorkflowsClassBookingsClassesRequest> body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `studioId` | `string` | Header, Required | The Studio ID to filter the classes for. |
| `body` | [`List<WorkflowsClassBookingsClassesRequest>`](../../doc/models/workflows-class-bookings-classes-request.md) | Body, Required | - |

## Response Type

[`Task<List<Models.WorkflowsClassBookingsClassesResponse1>>`](../../doc/models/workflows-class-bookings-classes-response-1.md)

## Example Usage

```csharp
string studioId = "studioId2";
List<WorkflowsClassBookingsClassesRequest> body = new List<WorkflowsClassBookingsClassesRequest>
{
    new WorkflowsClassBookingsClassesRequest
    {
        BookingMethod = new BookingMethod1
        {
            Type = TypeEnum.PricingOption,
            Id = "id4",
            WaitlistEntryId = 190,
        },
        MClass = new Class1
        {
            Id = 44,
        },
        Notification = NotificationEnum.Email,
        SpotInfo = new SpotInfo
        {
            SpotNumber = 152,
            ConfirmationType = ConfirmationTypeEnum.Manual,
            SpotAssignment = SpotAssignmentEnum.Manual,
        },
    },
    new WorkflowsClassBookingsClassesRequest
    {
        BookingMethod = new BookingMethod1
        {
            Type = TypeEnum.PricingOption,
            Id = "id4",
            WaitlistEntryId = 190,
        },
        MClass = new Class1
        {
            Id = 44,
        },
        Notification = NotificationEnum.Email,
        SpotInfo = new SpotInfo
        {
            SpotNumber = 152,
            ConfirmationType = ConfirmationTypeEnum.Manual,
            SpotAssignment = SpotAssignmentEnum.Manual,
        },
    },
};

try
{
    List<WorkflowsClassBookingsClassesResponse1> result = await aPIController.BookAClassOrAddToWaitlistAsync(
        studioId,
        body
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request due to missing or invalid parameters. | [`BadRequestException`](../../doc/models/bad-request-exception.md) |
| 500 | Internal server error. | [`InternalServerErrorException`](../../doc/models/internal-server-error-exception.md) |


# Get Detailed Information About a Specific Class

Retrieves details of a specific class, including pricing options and consumer-related context for booking.

```csharp
GetDetailedInformationAboutASpecificClassAsync(
    int id,
    string studioId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | The unique ID of the class to retrieve. |
| `studioId` | `string` | Header, Required | The Studio ID to filter the class for. |

## Response Type

[`Task<Models.WorkflowsClassBookingsClassesResponse2>`](../../doc/models/workflows-class-bookings-classes-response-2.md)

## Example Usage

```csharp
int id = 112;
string studioId = "studioId2";
try
{
    WorkflowsClassBookingsClassesResponse2 result = await aPIController.GetDetailedInformationAboutASpecificClassAsync(
        id,
        studioId
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request due to missing or invalid parameters. | [`BadRequestException`](../../doc/models/bad-request-exception.md) |
| 500 | Internal server error. | [`InternalServerErrorException`](../../doc/models/internal-server-error-exception.md) |

