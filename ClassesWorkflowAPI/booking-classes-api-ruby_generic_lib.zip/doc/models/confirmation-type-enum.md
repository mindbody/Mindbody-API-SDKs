
# Confirmation Type Enum

## Enumeration

`ConfirmationTypeEnum`

## Fields

| Name |
|  --- |
| `MANUAL` |
| `AUTO` |

