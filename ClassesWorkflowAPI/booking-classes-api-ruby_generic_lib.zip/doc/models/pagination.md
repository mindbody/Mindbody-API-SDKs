
# Pagination

## Structure

`Pagination`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `has_next_page` | `TrueClass \| FalseClass` | Optional | - |
| `has_previous_page` | `TrueClass \| FalseClass` | Optional | - |
| `start_cursor` | `String` | Optional | - |
| `end_cursor` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "hasNextPage": false,
  "hasPreviousPage": false,
  "startCursor": "startCursor8",
  "endCursor": "endCursor2"
}
```

