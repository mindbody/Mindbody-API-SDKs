
# Description

## Structure

`Description`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Optional | - |
| `description` | `String` | Optional | - |
| `image_url` | `String` | Optional | - |
| `notes` | `String` | Optional | - |
| `prerequisites` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "name": "name6",
  "description": "description6",
  "imageUrl": "imageUrl6",
  "notes": "notes6",
  "prerequisites": "prerequisites4"
}
```

