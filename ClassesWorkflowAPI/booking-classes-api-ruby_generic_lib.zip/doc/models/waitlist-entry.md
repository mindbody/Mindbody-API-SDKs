
# Waitlist Entry

## Structure

`WaitlistEntry`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Optional | - |
| `class_id` | `Integer` | Optional | - |
| `request_date_time` | `DateTime` | Optional | - |
| `requested_from` | [`RequestedFromEnum`](../../doc/models/requested-from-enum.md) | Optional | - |
| `visit_id` | `Integer` | Optional | - |

## Example (as JSON)

```json
{
  "id": 80,
  "classId": 212,
  "requestDateTime": "2016-03-13T12:52:32.123Z",
  "requestedFrom": "online",
  "visitId": 220
}
```

