
# Status Enum

## Enumeration

`StatusEnum`

## Fields

| Name |
|  --- |
| `FREE` |
| `BOOKANDPAYLATER` |
| `PAYMENTREQUIRED` |

