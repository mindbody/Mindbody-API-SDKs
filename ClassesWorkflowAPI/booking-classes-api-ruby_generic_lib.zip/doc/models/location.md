
# Location

## Structure

`Location`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Optional | - |
| `address` | [`Address`](../../doc/models/address.md) | Optional | - |
| `name` | `String` | Optional | - |
| `description` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "id": 12,
  "address": {
    "street": "street6",
    "city": "city6",
    "state": "state2",
    "country": "country0",
    "latitude": 75.2
  },
  "name": "name4",
  "description": "description4"
}
```

