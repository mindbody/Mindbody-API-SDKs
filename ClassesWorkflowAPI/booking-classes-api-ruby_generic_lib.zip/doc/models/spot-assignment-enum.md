
# Spot Assignment Enum

## Enumeration

`SpotAssignmentEnum`

## Fields

| Name |
|  --- |
| `MANUAL` |
| `AUTO` |

