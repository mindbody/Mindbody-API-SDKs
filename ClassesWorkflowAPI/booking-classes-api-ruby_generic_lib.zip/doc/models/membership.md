
# Membership

## Structure

`Membership`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "id": "id8"
}
```

