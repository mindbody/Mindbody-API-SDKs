
# Spot Reservation

## Structure

`SpotReservation`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `visit_id` | `String` | Optional | - |
| `class_id` | `String` | Optional | - |
| `reservation_type` | `String` | Optional | - |
| `status` | [`Status2Enum`](../../doc/models/status-2-enum.md) | Optional | - |
| `confirmation_date` | `DateTime` | Optional | - |

## Example (as JSON)

```json
{
  "visitId": "visitId6",
  "classId": "classId6",
  "reservationType": "reservationType4",
  "status": "confirmed",
  "confirmationDate": "2016-03-13T12:52:32.123Z"
}
```

