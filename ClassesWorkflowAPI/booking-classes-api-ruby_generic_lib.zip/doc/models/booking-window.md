
# Booking Window

## Structure

`BookingWindow`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `start_date_time` | `DateTime` | Optional | - |
| `end_date_time` | `DateTime` | Optional | - |
| `daily_start_time` | `DateTime` | Optional | - |
| `daily_end_time` | `DateTime` | Optional | - |

## Example (as JSON)

```json
{
  "startDateTime": "2016-03-13T12:52:32.123Z",
  "endDateTime": "2016-03-13T12:52:32.123Z",
  "dailyStartTime": "2016-03-13T12:52:32.123Z",
  "dailyEndTime": "2016-03-13T12:52:32.123Z"
}
```

