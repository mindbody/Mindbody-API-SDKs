
# Expiration

## Structure

`Expiration`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `activation_type` | [`ActivationTypeEnum`](../../doc/models/activation-type-enum.md) | Optional | - |
| `duration` | `Integer` | Optional | - |
| `duration_unit` | [`DurationUnitEnum`](../../doc/models/duration-unit-enum.md) | Optional | - |

## Example (as JSON)

```json
{
  "activationType": "dateOfFirstVisit",
  "duration": 22,
  "durationUnit": "days"
}
```

