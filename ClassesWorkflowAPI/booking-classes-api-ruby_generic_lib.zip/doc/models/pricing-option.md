
# Pricing Option

## Structure

`PricingOption`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `price` | [`Price`](../../doc/models/price.md) | Optional | - |
| `id` | `String` | Optional | - |
| `name` | `String` | Optional | - |
| `session` | [`Session`](../../doc/models/session.md) | Optional | - |
| `offer` | [`Offer`](../../doc/models/offer.md) | Optional | - |
| `expiration` | [`Expiration`](../../doc/models/expiration.md) | Optional | - |
| `membership` | [`Membership`](../../doc/models/membership.md) | Optional | - |

## Example (as JSON)

```json
{
  "price": {
    "unitPrice": 156.68
  },
  "id": "id8",
  "name": "name8",
  "session": {
    "sessionCount": 226,
    "type": "unlimited"
  },
  "offer": {
    "type": "introForNewClients"
  }
}
```

