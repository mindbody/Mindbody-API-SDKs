
# Bad Request Exception

## Structure

`BadRequestException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code` | `String` | Optional | - |
| `message` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "code": "BAD_REQUEST",
  "message": "Required parameters are missing or invalid."
}
```

