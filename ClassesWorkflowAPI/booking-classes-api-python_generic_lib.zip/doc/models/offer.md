
# Offer

## Structure

`Offer`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mtype` | [`Type2Enum`](../../doc/models/type-2-enum.md) | Optional | - |

## Example (as JSON)

```json
{
  "type": "intro"
}
```

