
# Booking Status Enum

## Enumeration

`BookingStatusEnum`

## Fields

| Name |
|  --- |
| `SUCCESS` |
| `ERROR` |
| `AWAITING_PAYMENT` |
| `WAITLIST` |

