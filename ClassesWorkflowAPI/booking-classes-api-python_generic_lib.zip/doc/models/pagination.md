
# Pagination

## Structure

`Pagination`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `has_next_page` | `bool` | Optional | - |
| `has_previous_page` | `bool` | Optional | - |
| `start_cursor` | `str` | Optional | - |
| `end_cursor` | `str` | Optional | - |

## Example (as JSON)

```json
{
  "hasNextPage": false,
  "hasPreviousPage": false,
  "startCursor": "startCursor8",
  "endCursor": "endCursor2"
}
```

