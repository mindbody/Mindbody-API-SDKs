
# Description

## Structure

`Description`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `str` | Optional | - |
| `description` | `str` | Optional | - |
| `image_url` | `str` | Optional | - |
| `notes` | `str` | Optional | - |
| `prerequisites` | `str` | Optional | - |

## Example (as JSON)

```json
{
  "name": "name6",
  "description": "description6",
  "imageUrl": "imageUrl6",
  "notes": "notes6",
  "prerequisites": "prerequisites4"
}
```

