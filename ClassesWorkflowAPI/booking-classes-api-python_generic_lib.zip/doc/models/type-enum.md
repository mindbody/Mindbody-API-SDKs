
# Type Enum

## Enumeration

`TypeEnum`

## Fields

| Name |
|  --- |
| `ENUM_PASS` |
| `PRICINGOPTION` |
| `FREE` |
| `WAITLIST` |
| `UNPAID` |

