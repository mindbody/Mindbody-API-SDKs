
# Level Enum

## Enumeration

`LevelEnum`

## Fields

| Name |
|  --- |
| `PRIMARY` |
| `FIRSTASSISTANT` |
| `SECONDASSISTANT` |

