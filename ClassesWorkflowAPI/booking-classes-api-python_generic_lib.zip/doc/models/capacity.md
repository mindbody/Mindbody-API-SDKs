
# Capacity

## Structure

`Capacity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `total_capacity` | `int` | Optional | - |
| `total_booked` | `int` | Optional | - |
| `web_capacity` | `int` | Optional | - |
| `web_booked` | `int` | Optional | - |
| `waitlist_capacity` | `int` | Optional | - |
| `spots` | [`Spots`](../../doc/models/spots.md) | Optional | - |

## Example (as JSON)

```json
{
  "totalCapacity": 22,
  "totalBooked": 248,
  "webCapacity": 142,
  "webBooked": 78,
  "waitlistCapacity": 232
}
```

