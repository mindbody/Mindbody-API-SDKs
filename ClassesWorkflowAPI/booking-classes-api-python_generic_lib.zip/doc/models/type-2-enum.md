
# Type 2 Enum

## Enumeration

`Type2Enum`

## Fields

| Name |
|  --- |
| `INTRO` |
| `INTROFORNEWCLIENTS` |
| `REGULAR` |

