
# Spot Reservation

## Structure

`SpotReservation`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `visit_id` | `str` | Optional | - |
| `class_id` | `str` | Optional | - |
| `reservation_type` | `str` | Optional | - |
| `status` | [`Status2Enum`](../../doc/models/status-2-enum.md) | Optional | - |
| `confirmation_date` | `datetime` | Optional | - |

## Example (as JSON)

```json
{
  "visitId": "visitId6",
  "classId": "classId6",
  "reservationType": "reservationType4",
  "status": "confirmed",
  "confirmationDate": "2016-03-13T12:52:32.123Z"
}
```

