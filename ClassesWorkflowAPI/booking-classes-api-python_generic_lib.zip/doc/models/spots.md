
# Spots

## Structure

`Spots`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reserved` | `List[int]` | Optional | - |
| `available` | `List[int]` | Optional | - |
| `unavailable` | `List[int]` | Optional | - |
| `mine` | `List[int]` | Optional | - |

## Example (as JSON)

```json
{
  "reserved": [
    125
  ],
  "available": [
    28
  ],
  "unavailable": [
    80
  ],
  "mine": [
    111
  ]
}
```

