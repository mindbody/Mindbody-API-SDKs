
# Address

## Structure

`Address`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `street` | `str` | Optional | - |
| `city` | `str` | Optional | - |
| `state` | `str` | Optional | - |
| `country` | `str` | Optional | - |
| `latitude` | `float` | Optional | - |
| `longitude` | `float` | Optional | - |
| `postal_code` | `str` | Optional | - |

## Example (as JSON)

```json
{
  "street": "street8",
  "city": "city8",
  "state": "state4",
  "country": "country2",
  "latitude": 56.42
}
```

