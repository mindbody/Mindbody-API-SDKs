
# Waitlist Entry 1

## Structure

`WaitlistEntry1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | - |

## Example (as JSON)

```json
{
  "id": 40
}
```

