
# Booking Method 1

## Structure

`BookingMethod1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mtype` | [`TypeEnum`](../../doc/models/type-enum.md) | Optional | - |
| `id` | `str` | Optional | - |
| `waitlist_entry_id` | `int` | Optional | - |

## Example (as JSON)

```json
{
  "type": "unpaid",
  "id": "id6",
  "waitlistEntryId": 118
}
```

