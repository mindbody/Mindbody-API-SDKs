
# Push Api Result Subscription

A result returned for every request to the push API

## Structure

`PushApiResultSubscription`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ErrorInformation` | [`List<PushApiError>`](../../doc/models/push-api-error.md) | Optional | - |
| `IsSuccess` | `bool?` | Optional | - |
| `MValue` | [`Subscription`](../../doc/models/subscription.md) | Optional | A webhook subscription |

## Example (as JSON)

```json
{
  "errorInformation": [
    {
      "errorCode": 122,
      "errorMessage": "errorMessage6",
      "errorType": "errorType8"
    },
    {
      "errorCode": 122,
      "errorMessage": "errorMessage6",
      "errorType": "errorType8"
    }
  ],
  "isSuccess": false,
  "value": {
    "eventIds": [
      "eventIds4"
    ],
    "eventSchemaVersion": 26.12,
    "referenceId": "referenceId4",
    "status": "status4",
    "statusChangeDate": "2016-03-13T12:52:32.123Z"
  }
}
```

