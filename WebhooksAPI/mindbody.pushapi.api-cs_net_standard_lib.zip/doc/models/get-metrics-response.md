
# Get Metrics Response

A wrapper for returning subscription metrics to API users

## Structure

`GetMetricsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Items` | [`List<Metric>`](../../doc/models/metric.md) | Optional | Contains the metrics for the passed subscription |

## Example (as JSON)

```json
{
  "items": [
    {
      "creationDateTime": "2016-03-13T12:52:32.123Z",
      "messagesAttempted": 10,
      "messagesDelivered": 166,
      "messagesFailed": 116,
      "messagesUndelivered": 232
    },
    {
      "creationDateTime": "2016-03-13T12:52:32.123Z",
      "messagesAttempted": 10,
      "messagesDelivered": 166,
      "messagesFailed": 116,
      "messagesUndelivered": 232
    }
  ]
}
```

