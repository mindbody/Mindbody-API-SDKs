
# Push Api Result Deactivate Subscription Response

A result returned for every request to the push API

## Structure

`PushApiResultDeactivateSubscriptionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ErrorInformation` | [`List<PushApiError>`](../../doc/models/push-api-error.md) | Optional | - |
| `IsSuccess` | `bool?` | Optional | - |
| `MValue` | [`DeactivateSubscriptionResponse`](../../doc/models/deactivate-subscription-response.md) | Optional | Returned after a subscription is deactivated |

## Example (as JSON)

```json
{
  "errorInformation": [
    {
      "errorCode": 122,
      "errorMessage": "errorMessage6",
      "errorType": "errorType8"
    }
  ],
  "isSuccess": false,
  "value": {
    "deactivationDateTime": "2016-03-13T12:52:32.123Z",
    "message": "message2",
    "referenceId": "referenceId4",
    "subscriptionId": "0000053e-0000-0000-0000-000000000000"
  }
}
```

