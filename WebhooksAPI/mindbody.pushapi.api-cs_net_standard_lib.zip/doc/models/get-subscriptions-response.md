
# Get Subscriptions Response

A wrapper for a get subscriptions request

## Structure

`GetSubscriptionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Items` | [`List<Subscription>`](../../doc/models/subscription.md) | Optional | A list of subscriptions |

## Example (as JSON)

```json
{
  "items": [
    {
      "eventIds": [
        "eventIds2"
      ],
      "eventSchemaVersion": 181.18,
      "referenceId": "referenceId0",
      "status": "status0",
      "statusChangeDate": "2016-03-13T12:52:32.123Z"
    }
  ]
}
```

