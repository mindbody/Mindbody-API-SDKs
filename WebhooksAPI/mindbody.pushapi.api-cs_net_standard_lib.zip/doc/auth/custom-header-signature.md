
# Custom Header Signature



Documentation for accessing and setting credentials for API-Key.

## Auth Credentials

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| API-Key | `string` | API Key Authentication | `APIKey` | `APIKey` |



**Note:** Auth credentials can be set using `CustomHeaderAuthenticationCredentials` in the client builder and accessed through `CustomHeaderAuthenticationCredentials` method in the client instance.

## Usage Example

### Client Initialization

You must provide credentials in the client as shown in the following code snippet.

```csharp
using MindbodyPushApiApi.Standard;
using MindbodyPushApiApi.Standard.Authentication;

namespace ConsoleApp;

MindbodyPushApiApiClient client = new MindbodyPushApiApiClient.Builder()
    .CustomHeaderAuthenticationCredentials(
        new CustomHeaderAuthenticationModel.Builder(
            "API-Key"
        )
        .Build())
    .Build();
```


