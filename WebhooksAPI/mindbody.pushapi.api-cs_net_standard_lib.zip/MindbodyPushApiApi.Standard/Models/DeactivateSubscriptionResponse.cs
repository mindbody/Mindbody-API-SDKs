// <copyright file="DeactivateSubscriptionResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using MindbodyPushApiApi.Standard;
using MindbodyPushApiApi.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace MindbodyPushApiApi.Standard.Models
{
    /// <summary>
    /// DeactivateSubscriptionResponse.
    /// </summary>
    public class DeactivateSubscriptionResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DeactivateSubscriptionResponse"/> class.
        /// </summary>
        public DeactivateSubscriptionResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DeactivateSubscriptionResponse"/> class.
        /// </summary>
        /// <param name="deactivationDateTime">deactivationDateTime.</param>
        /// <param name="message">message.</param>
        /// <param name="referenceId">referenceId.</param>
        /// <param name="subscriptionId">subscriptionId.</param>
        public DeactivateSubscriptionResponse(
            DateTime? deactivationDateTime = null,
            string message = null,
            string referenceId = null,
            Guid? subscriptionId = null)
        {
            this.DeactivationDateTime = deactivationDateTime;
            this.Message = message;
            this.ReferenceId = referenceId;
            this.SubscriptionId = subscriptionId;
        }

        /// <summary>
        /// The UTC date and time when the deactivation took place.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("deactivationDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? DeactivationDateTime { get; set; }

        /// <summary>
        /// A message about the deactivation request. Unless an error occurs, this message always `"Subscription deactivated successfully."`.
        /// </summary>
        [JsonProperty("message", NullValueHandling = NullValueHandling.Ignore)]
        public string Message { get; set; }

        /// <summary>
        /// The subscription's reference ID, assigned when the subscription was created.
        /// </summary>
        [JsonProperty("referenceId", NullValueHandling = NullValueHandling.Ignore)]
        public string ReferenceId { get; set; }

        /// <summary>
        /// The subscription ID (a GUID).
        /// </summary>
        [JsonProperty("subscriptionId", NullValueHandling = NullValueHandling.Ignore)]
        public Guid? SubscriptionId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"DeactivateSubscriptionResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is DeactivateSubscriptionResponse other &&
                (this.DeactivationDateTime == null && other.DeactivationDateTime == null ||
                 this.DeactivationDateTime?.Equals(other.DeactivationDateTime) == true) &&
                (this.Message == null && other.Message == null ||
                 this.Message?.Equals(other.Message) == true) &&
                (this.ReferenceId == null && other.ReferenceId == null ||
                 this.ReferenceId?.Equals(other.ReferenceId) == true) &&
                (this.SubscriptionId == null && other.SubscriptionId == null ||
                 this.SubscriptionId?.Equals(other.SubscriptionId) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"DeactivationDateTime = {(this.DeactivationDateTime == null ? "null" : this.DeactivationDateTime.ToString())}");
            toStringOutput.Add($"Message = {this.Message ?? "null"}");
            toStringOutput.Add($"ReferenceId = {this.ReferenceId ?? "null"}");
            toStringOutput.Add($"SubscriptionId = {(this.SubscriptionId == null ? "null" : this.SubscriptionId.ToString())}");
        }
    }
}