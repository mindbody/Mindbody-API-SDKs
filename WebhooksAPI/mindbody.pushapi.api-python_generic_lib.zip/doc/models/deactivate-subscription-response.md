
# Deactivate Subscription Response

Returned after a subscription is deactivated

## Structure

`DeactivateSubscriptionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `deactivation_date_time` | `datetime` | Optional | The UTC date and time when the deactivation took place. |
| `message` | `str` | Optional | A message about the deactivation request. Unless an error occurs, this message always `"Subscription deactivated successfully."`. |
| `reference_id` | `str` | Optional | The subscription's reference ID, assigned when the subscription was created. |
| `subscription_id` | `uuid\|str` | Optional | The subscription ID (a GUID). |

## Example (as JSON)

```json
{
  "subscriptionId": "00000000-0000-0000-0000-000000000000",
  "deactivationDateTime": "2016-03-13T12:52:32.123Z",
  "message": "message4",
  "referenceId": "referenceId6"
}
```

