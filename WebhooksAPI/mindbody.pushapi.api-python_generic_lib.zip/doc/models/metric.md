
# Metric

Metrics for subscription

## Structure

`Metric`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `creation_date_time` | `datetime` | Optional | The UTC date and time when the subscription was created. |
| `messages_attempted` | `int` | Optional | The number of event notifications Mindbody attempted to deliver to the subscription `webhookUrl`, including retries. |
| `messages_delivered` | `int` | Optional | The number of event notifications Mindbody successfully delivered to the subscription `webhookUrl`. |
| `messages_failed` | `int` | Optional | The number of event notifications that Mindbody stopped trying to send after 3 hours. |
| `messages_undelivered` | `int` | Optional | The number of event notifications where MINDBODY received a failure response from the subscription `webhookUrl`. |
| `status` | `str` | Optional | The subscription's current status. **Possible Values**:<br /><br>`PendingActivation` - The subscription is created but not receiving event notifications.To start receiving event notifications, set the subscription’s status to Active using the PATCH Subscription endpoint.<br /><br>`Active` - The subscription is active and can receive event notifications.<br /><br>`DeactivatedByUser` - You deactivated the subscription.<br /><br>`DeactivatedByAdmin` - Mindbody deactivated your subscription.<br /><br>`DeactivatedTooManyFailedMessageDeliveryAttempts` - The subscription was deactivated because Mindbody stopped receiving a 2xx HTTP status code from the webhookUrl when posting events. An automated email will be sent to the developer portal email on the account with additional details.<br /><br>`DeactivatedByEventDeactivation` - One of the event IDs associated with the subscription was deactivated, which invalidated and deactivated the subscription. If this occurs, you must create a new subscription using only up-to-date event IDs.<br /> |
| `status_change_date` | `datetime` | Optional | The UTC date and time when the subscription `status` was last updated. |
| `subscription_id` | `uuid\|str` | Optional | The subscription's ID (a GUID). |

## Example (as JSON)

```json
{
  "subscriptionId": "00000000-0000-0000-0000-000000000000",
  "creationDateTime": "2016-03-13T12:52:32.123Z",
  "messagesAttempted": 102,
  "messagesDelivered": 22,
  "messagesFailed": 228,
  "messagesUndelivered": 88
}
```

