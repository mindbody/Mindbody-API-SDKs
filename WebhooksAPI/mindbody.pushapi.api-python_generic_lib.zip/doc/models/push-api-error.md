
# Push Api Error

An error returned by the push API for application errors

## Structure

`PushApiError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error_code` | `int` | Optional | A unique ID for the returned error code |
| `error_message` | `str` | Optional | A message indicating what went wrong |
| `error_type` | `str` | Optional | A category/type associated with the error |

## Example (as JSON)

```json
{
  "errorCode": 58,
  "errorMessage": "errorMessage6",
  "errorType": "errorType2"
}
```

