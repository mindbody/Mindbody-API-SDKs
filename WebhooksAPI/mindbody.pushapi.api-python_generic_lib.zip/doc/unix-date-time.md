
# UnixDateTime

A utility class for wrapping datetime to support Unix date format.

## Methods

| Name | Description |
|  --- | --- |
| from_datetime | Converts a datetime object to a Unix timestamp (seconds since epoch). |
| from_value | Parses a Unix timestamp into a datetime object. |

