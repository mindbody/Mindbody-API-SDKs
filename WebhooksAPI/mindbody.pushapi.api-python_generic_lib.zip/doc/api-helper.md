
# ApiHelper

A utility class for processing API Calls. Also contains classes for supporting standard datetime formats.

## Methods

| Name | Description |
|  --- | --- |
| json_deserialize | Deserializes a JSON string to a Python dictionary. |

