
# Patch Subscription Request

A request to patch update a subscription

## Structure

`PatchSubscriptionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `event_ids` | `Array<String>` | Optional | A list of event IDs that you want to update or subscribe to. |
| `event_schema_version` | `Float` | Optional | The event schema version associated with the subscription. Currently, this is always `1`. |
| `reference_id` | `String` | Optional | An arbitrary field that you can set to a value of your choice. Mindbody stores and returns this value for the subscription you are activating. Most commonly, this field stores a GUID that you can use in your application. |
| `status` | `String` | Optional | The subscription’s current status, as of the last update. |
| `webhook_url` | `String` | Optional | The URL registered as the target of the webhook deliveries. Mindbody posts the event notifications to this URL. Webhook URL Requirements lists considerations and requirements for this URL. |

## Example (as JSON)

```json
{
  "eventIds": [
    "eventIds6",
    "eventIds7"
  ],
  "eventSchemaVersion": 63.24,
  "referenceId": "referenceId6",
  "status": "status6",
  "webhookUrl": "webhookUrl6"
}
```

