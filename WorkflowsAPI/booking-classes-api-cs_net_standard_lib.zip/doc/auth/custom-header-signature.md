
# Custom Header Signature



Documentation for accessing and setting credentials for ApiKeyAuth.

## Auth Credentials

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| Api-Key | `string` | - | `ApiKey` | `ApiKey` |



**Note:** Auth credentials can be set using `ApiKeyAuthCredentials` in the client builder and accessed through `ApiKeyAuthCredentials` method in the client instance.

## Usage Example

### Client Initialization

You must provide credentials in the client as shown in the following code snippet.

```csharp
BookingClassesAPIClient client = new BookingClassesAPIClient.Builder()
    .ApiKeyAuthCredentials(
        new ApiKeyAuthModel.Builder(
            "Api-Key"
        )
        .Build())
    .Build();
```


