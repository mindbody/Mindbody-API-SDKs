
# Error

## Structure

`Error`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Code` | `string` | Optional | - |
| `Message` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "code": "code2",
  "message": "message4"
}
```

