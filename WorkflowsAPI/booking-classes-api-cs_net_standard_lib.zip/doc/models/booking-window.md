
# Booking Window

## Structure

`BookingWindow`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `StartDateTime` | `DateTime?` | Optional | - |
| `EndDateTime` | `DateTime?` | Optional | - |
| `DailyStartTime` | `DateTime?` | Optional | - |
| `DailyEndTime` | `DateTime?` | Optional | - |

## Example (as JSON)

```json
{
  "startDateTime": "2016-03-13T12:52:32.123Z",
  "endDateTime": "2016-03-13T12:52:32.123Z",
  "dailyStartTime": "2016-03-13T12:52:32.123Z",
  "dailyEndTime": "2016-03-13T12:52:32.123Z"
}
```

