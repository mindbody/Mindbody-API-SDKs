
# Waitlist Entry

## Structure

`WaitlistEntry`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | - |
| `ClassId` | `int?` | Optional | - |
| `RequestDateTime` | `DateTime?` | Optional | - |
| `RequestedFrom` | [`RequestedFromEnum?`](../../doc/models/requested-from-enum.md) | Optional | - |
| `VisitId` | `int?` | Optional | - |

## Example (as JSON)

```json
{
  "id": 80,
  "classId": 212,
  "requestDateTime": "2016-03-13T12:52:32.123Z",
  "requestedFrom": "online",
  "visitId": 220
}
```

