
# Booking Method 1

## Structure

`BookingMethod1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Type` | [`TypeEnum?`](../../doc/models/type-enum.md) | Optional | - |
| `Id` | `string` | Optional | - |
| `WaitlistEntryId` | `int?` | Optional | - |

## Example (as JSON)

```json
{
  "type": "unpaid",
  "id": "id6",
  "waitlistEntryId": 118
}
```

