
# Visit

## Structure

`Visit`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | - |
| `StartDateTime` | `DateTime?` | Optional | - |
| `EndDateTime` | `DateTime?` | Optional | - |

## Example (as JSON)

```json
{
  "id": 44,
  "startDateTime": "2016-03-13T12:52:32.123Z",
  "endDateTime": "2016-03-13T12:52:32.123Z"
}
```

