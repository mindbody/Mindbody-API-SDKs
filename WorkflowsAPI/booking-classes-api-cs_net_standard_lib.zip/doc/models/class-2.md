
# Class 2

## Structure

`Class2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Location` | [`Location`](../../doc/models/location.md) | Optional | - |
| `Description` | [`Description`](../../doc/models/description.md) | Optional | - |
| `Instructors` | [`List<Instructor>`](../../doc/models/instructor.md) | Optional | - |
| `Capacity` | [`Capacity`](../../doc/models/capacity.md) | Optional | - |
| `BookingWindow` | [`BookingWindow`](../../doc/models/booking-window.md) | Optional | - |
| `StartDateTime` | `DateTime?` | Optional | - |
| `EndDateTime` | `DateTime?` | Optional | - |
| `Notes` | `string` | Optional | - |
| `BookingInfo` | [`BookingInfo`](../../doc/models/booking-info.md) | Optional | - |

## Example (as JSON)

```json
{
  "location": {
    "id": 26,
    "address": {
      "street": "street6",
      "city": "city6",
      "state": "state2",
      "country": "country0",
      "latitude": 75.2
    },
    "name": "name4",
    "description": "description6"
  },
  "description": {
    "name": "name0",
    "description": "description0",
    "imageUrl": "imageUrl0",
    "notes": "notes0",
    "prerequisites": "prerequisites2"
  },
  "instructors": [
    {
      "level": "firstAssistant",
      "displayName": "displayName2"
    },
    {
      "level": "firstAssistant",
      "displayName": "displayName2"
    },
    {
      "level": "firstAssistant",
      "displayName": "displayName2"
    }
  ],
  "capacity": {
    "totalCapacity": 150,
    "totalBooked": 136,
    "webCapacity": 14,
    "webBooked": 206,
    "waitlistCapacity": 152
  },
  "bookingWindow": {
    "startDateTime": "2016-03-13T12:52:32.123Z",
    "endDateTime": "2016-03-13T12:52:32.123Z",
    "dailyStartTime": "2016-03-13T12:52:32.123Z",
    "dailyEndTime": "2016-03-13T12:52:32.123Z"
  }
}
```

