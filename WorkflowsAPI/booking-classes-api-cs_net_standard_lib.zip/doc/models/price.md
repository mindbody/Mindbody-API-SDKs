
# Price

## Structure

`Price`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `UnitPrice` | `double?` | Optional | - |

## Example (as JSON)

```json
{
  "unitPrice": 211.36
}
```

