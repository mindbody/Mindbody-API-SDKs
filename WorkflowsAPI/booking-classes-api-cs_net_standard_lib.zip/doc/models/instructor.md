
# Instructor

## Structure

`Instructor`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Level` | [`LevelEnum?`](../../doc/models/level-enum.md) | Optional | - |
| `DisplayName` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "level": "secondAssistant",
  "displayName": "displayName0"
}
```

