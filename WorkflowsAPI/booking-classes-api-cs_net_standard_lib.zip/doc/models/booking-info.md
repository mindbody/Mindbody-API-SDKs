
# Booking Info

## Structure

`BookingInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Status` | [`StatusEnum?`](../../doc/models/status-enum.md) | Optional | - |

## Example (as JSON)

```json
{
  "status": "free"
}
```

