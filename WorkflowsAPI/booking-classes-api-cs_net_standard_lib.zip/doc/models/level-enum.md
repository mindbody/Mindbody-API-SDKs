
# Level Enum

## Enumeration

`LevelEnum`

## Fields

| Name |
|  --- |
| `Primary` |
| `FirstAssistant` |
| `SecondAssistant` |

