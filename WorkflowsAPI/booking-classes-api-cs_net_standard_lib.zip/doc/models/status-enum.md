
# Status Enum

## Enumeration

`StatusEnum`

## Fields

| Name |
|  --- |
| `Free` |
| `BookAndPayLater` |
| `PaymentRequired` |

