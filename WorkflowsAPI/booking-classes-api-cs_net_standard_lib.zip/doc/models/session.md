
# Session

## Structure

`Session`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SessionCount` | `int?` | Optional | - |
| `Type` | [`Type1Enum?`](../../doc/models/type-1-enum.md) | Optional | - |

## Example (as JSON)

```json
{
  "sessionCount": 66,
  "type": "single"
}
```

