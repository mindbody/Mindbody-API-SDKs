
# Type 2 Enum

## Enumeration

`Type2Enum`

## Fields

| Name |
|  --- |
| `Intro` |
| `IntroForNewClients` |
| `Regular` |

