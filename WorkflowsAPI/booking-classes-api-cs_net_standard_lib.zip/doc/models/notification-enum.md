
# Notification Enum

## Enumeration

`NotificationEnum`

## Fields

| Name |
|  --- |
| `Default` |
| `Email` |
| `None` |

