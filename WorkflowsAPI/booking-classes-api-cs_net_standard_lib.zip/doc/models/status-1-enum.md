
# Status 1 Enum

## Enumeration

`Status1Enum`

## Fields

| Name |
|  --- |
| `Active` |
| `Inactive` |

