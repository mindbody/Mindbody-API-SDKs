// <copyright file="BookingStatusEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using APIMatic.Core.Utilities.Converters;
using BookingClassesAPI.Standard;
using BookingClassesAPI.Standard.Utilities;
using Newtonsoft.Json;

namespace BookingClassesAPI.Standard.Models
{
    /// <summary>
    /// BookingStatusEnum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum BookingStatusEnum
    {
        /// <summary>
        /// Success.
        /// </summary>
        [EnumMember(Value = "success")]
        Success,

        /// <summary>
        /// Error.
        /// </summary>
        [EnumMember(Value = "error")]
        Error,

        /// <summary>
        /// AwaitingPayment.
        /// </summary>
        [EnumMember(Value = "awaiting_payment")]
        AwaitingPayment,

        /// <summary>
        /// Waitlist.
        /// </summary>
        [EnumMember(Value = "waitlist")]
        Waitlist
    }
}