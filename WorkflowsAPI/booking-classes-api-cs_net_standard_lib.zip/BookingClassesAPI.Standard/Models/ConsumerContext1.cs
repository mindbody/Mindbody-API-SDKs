// <copyright file="ConsumerContext1.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using BookingClassesAPI.Standard;
using BookingClassesAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace BookingClassesAPI.Standard.Models
{
    /// <summary>
    /// ConsumerContext1.
    /// </summary>
    public class ConsumerContext1
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ConsumerContext1"/> class.
        /// </summary>
        public ConsumerContext1()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ConsumerContext1"/> class.
        /// </summary>
        /// <param name="waitlistEntries">waitlistEntries.</param>
        /// <param name="bookingMethods">bookingMethods.</param>
        /// <param name="pricingOptions">pricingOptions.</param>
        public ConsumerContext1(
            List<Models.WaitlistEntry> waitlistEntries = null,
            List<Models.BookingMethod> bookingMethods = null,
            List<Models.PricingOption> pricingOptions = null)
        {
            this.WaitlistEntries = waitlistEntries;
            this.BookingMethods = bookingMethods;
            this.PricingOptions = pricingOptions;
        }

        /// <summary>
        /// Gets or sets WaitlistEntries.
        /// </summary>
        [JsonProperty("waitlistEntries", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.WaitlistEntry> WaitlistEntries { get; set; }

        /// <summary>
        /// Gets or sets BookingMethods.
        /// </summary>
        [JsonProperty("bookingMethods", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.BookingMethod> BookingMethods { get; set; }

        /// <summary>
        /// Gets or sets PricingOptions.
        /// </summary>
        [JsonProperty("pricingOptions", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.PricingOption> PricingOptions { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"ConsumerContext1 : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is ConsumerContext1 other &&
                (this.WaitlistEntries == null && other.WaitlistEntries == null ||
                 this.WaitlistEntries?.Equals(other.WaitlistEntries) == true) &&
                (this.BookingMethods == null && other.BookingMethods == null ||
                 this.BookingMethods?.Equals(other.BookingMethods) == true) &&
                (this.PricingOptions == null && other.PricingOptions == null ||
                 this.PricingOptions?.Equals(other.PricingOptions) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"WaitlistEntries = {(this.WaitlistEntries == null ? "null" : $"[{string.Join(", ", this.WaitlistEntries)} ]")}");
            toStringOutput.Add($"BookingMethods = {(this.BookingMethods == null ? "null" : $"[{string.Join(", ", this.BookingMethods)} ]")}");
            toStringOutput.Add($"PricingOptions = {(this.PricingOptions == null ? "null" : $"[{string.Join(", ", this.PricingOptions)} ]")}");
        }
    }
}