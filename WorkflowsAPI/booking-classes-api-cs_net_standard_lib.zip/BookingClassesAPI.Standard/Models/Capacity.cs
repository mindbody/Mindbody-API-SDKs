// <copyright file="Capacity.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using BookingClassesAPI.Standard;
using BookingClassesAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace BookingClassesAPI.Standard.Models
{
    /// <summary>
    /// Capacity.
    /// </summary>
    public class Capacity
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Capacity"/> class.
        /// </summary>
        public Capacity()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Capacity"/> class.
        /// </summary>
        /// <param name="totalCapacity">totalCapacity.</param>
        /// <param name="totalBooked">totalBooked.</param>
        /// <param name="webCapacity">webCapacity.</param>
        /// <param name="webBooked">webBooked.</param>
        /// <param name="waitlistCapacity">waitlistCapacity.</param>
        /// <param name="spots">spots.</param>
        public Capacity(
            int? totalCapacity = null,
            int? totalBooked = null,
            int? webCapacity = null,
            int? webBooked = null,
            int? waitlistCapacity = null,
            Models.Spots spots = null)
        {
            this.TotalCapacity = totalCapacity;
            this.TotalBooked = totalBooked;
            this.WebCapacity = webCapacity;
            this.WebBooked = webBooked;
            this.WaitlistCapacity = waitlistCapacity;
            this.Spots = spots;
        }

        /// <summary>
        /// Gets or sets TotalCapacity.
        /// </summary>
        [JsonProperty("totalCapacity", NullValueHandling = NullValueHandling.Ignore)]
        public int? TotalCapacity { get; set; }

        /// <summary>
        /// Gets or sets TotalBooked.
        /// </summary>
        [JsonProperty("totalBooked", NullValueHandling = NullValueHandling.Ignore)]
        public int? TotalBooked { get; set; }

        /// <summary>
        /// Gets or sets WebCapacity.
        /// </summary>
        [JsonProperty("webCapacity", NullValueHandling = NullValueHandling.Ignore)]
        public int? WebCapacity { get; set; }

        /// <summary>
        /// Gets or sets WebBooked.
        /// </summary>
        [JsonProperty("webBooked", NullValueHandling = NullValueHandling.Ignore)]
        public int? WebBooked { get; set; }

        /// <summary>
        /// Gets or sets WaitlistCapacity.
        /// </summary>
        [JsonProperty("waitlistCapacity", NullValueHandling = NullValueHandling.Ignore)]
        public int? WaitlistCapacity { get; set; }

        /// <summary>
        /// Gets or sets Spots.
        /// </summary>
        [JsonProperty("spots", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Spots Spots { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"Capacity : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is Capacity other &&
                (this.TotalCapacity == null && other.TotalCapacity == null ||
                 this.TotalCapacity?.Equals(other.TotalCapacity) == true) &&
                (this.TotalBooked == null && other.TotalBooked == null ||
                 this.TotalBooked?.Equals(other.TotalBooked) == true) &&
                (this.WebCapacity == null && other.WebCapacity == null ||
                 this.WebCapacity?.Equals(other.WebCapacity) == true) &&
                (this.WebBooked == null && other.WebBooked == null ||
                 this.WebBooked?.Equals(other.WebBooked) == true) &&
                (this.WaitlistCapacity == null && other.WaitlistCapacity == null ||
                 this.WaitlistCapacity?.Equals(other.WaitlistCapacity) == true) &&
                (this.Spots == null && other.Spots == null ||
                 this.Spots?.Equals(other.Spots) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"TotalCapacity = {(this.TotalCapacity == null ? "null" : this.TotalCapacity.ToString())}");
            toStringOutput.Add($"TotalBooked = {(this.TotalBooked == null ? "null" : this.TotalBooked.ToString())}");
            toStringOutput.Add($"WebCapacity = {(this.WebCapacity == null ? "null" : this.WebCapacity.ToString())}");
            toStringOutput.Add($"WebBooked = {(this.WebBooked == null ? "null" : this.WebBooked.ToString())}");
            toStringOutput.Add($"WaitlistCapacity = {(this.WaitlistCapacity == null ? "null" : this.WaitlistCapacity.ToString())}");
            toStringOutput.Add($"Spots = {(this.Spots == null ? "null" : this.Spots.ToString())}");
        }
    }
}