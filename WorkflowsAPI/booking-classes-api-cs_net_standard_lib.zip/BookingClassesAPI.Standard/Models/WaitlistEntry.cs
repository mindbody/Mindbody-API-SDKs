// <copyright file="WaitlistEntry.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using BookingClassesAPI.Standard;
using BookingClassesAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace BookingClassesAPI.Standard.Models
{
    /// <summary>
    /// WaitlistEntry.
    /// </summary>
    public class WaitlistEntry
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="WaitlistEntry"/> class.
        /// </summary>
        public WaitlistEntry()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="WaitlistEntry"/> class.
        /// </summary>
        /// <param name="id">id.</param>
        /// <param name="classId">classId.</param>
        /// <param name="requestDateTime">requestDateTime.</param>
        /// <param name="requestedFrom">requestedFrom.</param>
        /// <param name="visitId">visitId.</param>
        public WaitlistEntry(
            int? id = null,
            int? classId = null,
            DateTime? requestDateTime = null,
            Models.RequestedFromEnum? requestedFrom = null,
            int? visitId = null)
        {
            this.Id = id;
            this.ClassId = classId;
            this.RequestDateTime = requestDateTime;
            this.RequestedFrom = requestedFrom;
            this.VisitId = visitId;
        }

        /// <summary>
        /// Gets or sets Id.
        /// </summary>
        [JsonProperty("id", NullValueHandling = NullValueHandling.Ignore)]
        public int? Id { get; set; }

        /// <summary>
        /// Gets or sets ClassId.
        /// </summary>
        [JsonProperty("classId", NullValueHandling = NullValueHandling.Ignore)]
        public int? ClassId { get; set; }

        /// <summary>
        /// Gets or sets RequestDateTime.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("requestDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? RequestDateTime { get; set; }

        /// <summary>
        /// Gets or sets RequestedFrom.
        /// </summary>
        [JsonProperty("requestedFrom", NullValueHandling = NullValueHandling.Ignore)]
        public Models.RequestedFromEnum? RequestedFrom { get; set; }

        /// <summary>
        /// Gets or sets VisitId.
        /// </summary>
        [JsonProperty("visitId", NullValueHandling = NullValueHandling.Ignore)]
        public int? VisitId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"WaitlistEntry : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is WaitlistEntry other &&
                (this.Id == null && other.Id == null ||
                 this.Id?.Equals(other.Id) == true) &&
                (this.ClassId == null && other.ClassId == null ||
                 this.ClassId?.Equals(other.ClassId) == true) &&
                (this.RequestDateTime == null && other.RequestDateTime == null ||
                 this.RequestDateTime?.Equals(other.RequestDateTime) == true) &&
                (this.RequestedFrom == null && other.RequestedFrom == null ||
                 this.RequestedFrom?.Equals(other.RequestedFrom) == true) &&
                (this.VisitId == null && other.VisitId == null ||
                 this.VisitId?.Equals(other.VisitId) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"Id = {(this.Id == null ? "null" : this.Id.ToString())}");
            toStringOutput.Add($"ClassId = {(this.ClassId == null ? "null" : this.ClassId.ToString())}");
            toStringOutput.Add($"RequestDateTime = {(this.RequestDateTime == null ? "null" : this.RequestDateTime.ToString())}");
            toStringOutput.Add($"RequestedFrom = {(this.RequestedFrom == null ? "null" : this.RequestedFrom.ToString())}");
            toStringOutput.Add($"VisitId = {(this.VisitId == null ? "null" : this.VisitId.ToString())}");
        }
    }
}