// <copyright file="LevelEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using APIMatic.Core.Utilities.Converters;
using BookingClassesAPI.Standard;
using BookingClassesAPI.Standard.Utilities;
using Newtonsoft.Json;

namespace BookingClassesAPI.Standard.Models
{
    /// <summary>
    /// LevelEnum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum LevelEnum
    {
        /// <summary>
        /// Primary.
        /// </summary>
        [EnumMember(Value = "primary")]
        Primary,

        /// <summary>
        /// FirstAssistant.
        /// </summary>
        [EnumMember(Value = "firstAssistant")]
        FirstAssistant,

        /// <summary>
        /// SecondAssistant.
        /// </summary>
        [EnumMember(Value = "secondAssistant")]
        SecondAssistant
    }
}