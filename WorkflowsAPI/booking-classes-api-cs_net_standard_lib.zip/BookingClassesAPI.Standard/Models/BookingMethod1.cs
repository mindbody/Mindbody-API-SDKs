// <copyright file="BookingMethod1.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using BookingClassesAPI.Standard;
using BookingClassesAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace BookingClassesAPI.Standard.Models
{
    /// <summary>
    /// BookingMethod1.
    /// </summary>
    public class BookingMethod1
    {
        private int? waitlistEntryId;
        private Dictionary<string, bool> shouldSerialize = new Dictionary<string, bool>
        {
            { "waitlistEntryId", false },
        };

        /// <summary>
        /// Initializes a new instance of the <see cref="BookingMethod1"/> class.
        /// </summary>
        public BookingMethod1()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="BookingMethod1"/> class.
        /// </summary>
        /// <param name="type">type.</param>
        /// <param name="id">id.</param>
        /// <param name="waitlistEntryId">waitlistEntryId.</param>
        public BookingMethod1(
            Models.TypeEnum? type = null,
            string id = null,
            int? waitlistEntryId = null)
        {
            this.Type = type;
            this.Id = id;

            if (waitlistEntryId != null)
            {
                this.WaitlistEntryId = waitlistEntryId;
            }
        }

        /// <summary>
        /// Gets or sets Type.
        /// </summary>
        [JsonProperty("type", NullValueHandling = NullValueHandling.Ignore)]
        public Models.TypeEnum? Type { get; set; }

        /// <summary>
        /// Gets or sets Id.
        /// </summary>
        [JsonProperty("id", NullValueHandling = NullValueHandling.Ignore)]
        public string Id { get; set; }

        /// <summary>
        /// Gets or sets WaitlistEntryId.
        /// </summary>
        [JsonProperty("waitlistEntryId")]
        public int? WaitlistEntryId
        {
            get
            {
                return this.waitlistEntryId;
            }

            set
            {
                this.shouldSerialize["waitlistEntryId"] = true;
                this.waitlistEntryId = value;
            }
        }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"BookingMethod1 : ({string.Join(", ", toStringOutput)})";
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetWaitlistEntryId()
        {
            this.shouldSerialize["waitlistEntryId"] = false;
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeWaitlistEntryId()
        {
            return this.shouldSerialize["waitlistEntryId"];
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is BookingMethod1 other &&
                (this.Type == null && other.Type == null ||
                 this.Type?.Equals(other.Type) == true) &&
                (this.Id == null && other.Id == null ||
                 this.Id?.Equals(other.Id) == true) &&
                (this.WaitlistEntryId == null && other.WaitlistEntryId == null ||
                 this.WaitlistEntryId?.Equals(other.WaitlistEntryId) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"Type = {(this.Type == null ? "null" : this.Type.ToString())}");
            toStringOutput.Add($"Id = {this.Id ?? "null"}");
            toStringOutput.Add($"WaitlistEntryId = {(this.WaitlistEntryId == null ? "null" : this.WaitlistEntryId.ToString())}");
        }
    }
}