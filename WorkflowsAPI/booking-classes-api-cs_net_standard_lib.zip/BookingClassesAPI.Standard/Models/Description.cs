// <copyright file="Description.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using BookingClassesAPI.Standard;
using BookingClassesAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace BookingClassesAPI.Standard.Models
{
    /// <summary>
    /// Description.
    /// </summary>
    public class Description
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Description"/> class.
        /// </summary>
        public Description()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Description"/> class.
        /// </summary>
        /// <param name="name">name.</param>
        /// <param name="descriptionProp">description.</param>
        /// <param name="imageUrl">imageUrl.</param>
        /// <param name="notes">notes.</param>
        /// <param name="prerequisites">prerequisites.</param>
        public Description(
            string name = null,
            string descriptionProp = null,
            string imageUrl = null,
            string notes = null,
            string prerequisites = null)
        {
            this.Name = name;
            this.DescriptionProp = descriptionProp;
            this.ImageUrl = imageUrl;
            this.Notes = notes;
            this.Prerequisites = prerequisites;
        }

        /// <summary>
        /// Gets or sets Name.
        /// </summary>
        [JsonProperty("name", NullValueHandling = NullValueHandling.Ignore)]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets DescriptionProp.
        /// </summary>
        [JsonProperty("description", NullValueHandling = NullValueHandling.Ignore)]
        public string DescriptionProp { get; set; }

        /// <summary>
        /// Gets or sets ImageUrl.
        /// </summary>
        [JsonProperty("imageUrl", NullValueHandling = NullValueHandling.Ignore)]
        public string ImageUrl { get; set; }

        /// <summary>
        /// Gets or sets Notes.
        /// </summary>
        [JsonProperty("notes", NullValueHandling = NullValueHandling.Ignore)]
        public string Notes { get; set; }

        /// <summary>
        /// Gets or sets Prerequisites.
        /// </summary>
        [JsonProperty("prerequisites", NullValueHandling = NullValueHandling.Ignore)]
        public string Prerequisites { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"Description : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is Description other &&
                (this.Name == null && other.Name == null ||
                 this.Name?.Equals(other.Name) == true) &&
                (this.DescriptionProp == null && other.DescriptionProp == null ||
                 this.DescriptionProp?.Equals(other.DescriptionProp) == true) &&
                (this.ImageUrl == null && other.ImageUrl == null ||
                 this.ImageUrl?.Equals(other.ImageUrl) == true) &&
                (this.Notes == null && other.Notes == null ||
                 this.Notes?.Equals(other.Notes) == true) &&
                (this.Prerequisites == null && other.Prerequisites == null ||
                 this.Prerequisites?.Equals(other.Prerequisites) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"Name = {this.Name ?? "null"}");
            toStringOutput.Add($"DescriptionProp = {this.DescriptionProp ?? "null"}");
            toStringOutput.Add($"ImageUrl = {this.ImageUrl ?? "null"}");
            toStringOutput.Add($"Notes = {this.Notes ?? "null"}");
            toStringOutput.Add($"Prerequisites = {this.Prerequisites ?? "null"}");
        }
    }
}