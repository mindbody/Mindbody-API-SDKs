// <copyright file="Spots.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using BookingClassesAPI.Standard;
using BookingClassesAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace BookingClassesAPI.Standard.Models
{
    /// <summary>
    /// Spots.
    /// </summary>
    public class Spots
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Spots"/> class.
        /// </summary>
        public Spots()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Spots"/> class.
        /// </summary>
        /// <param name="reserved">reserved.</param>
        /// <param name="available">available.</param>
        /// <param name="unavailable">unavailable.</param>
        /// <param name="mine">mine.</param>
        public Spots(
            List<int> reserved = null,
            List<int> available = null,
            List<int> unavailable = null,
            List<int?> mine = null)
        {
            this.Reserved = reserved;
            this.Available = available;
            this.Unavailable = unavailable;
            this.Mine = mine;
        }

        /// <summary>
        /// Gets or sets Reserved.
        /// </summary>
        [JsonProperty("reserved", NullValueHandling = NullValueHandling.Ignore)]
        public List<int> Reserved { get; set; }

        /// <summary>
        /// Gets or sets Available.
        /// </summary>
        [JsonProperty("available", NullValueHandling = NullValueHandling.Ignore)]
        public List<int> Available { get; set; }

        /// <summary>
        /// Gets or sets Unavailable.
        /// </summary>
        [JsonProperty("unavailable", NullValueHandling = NullValueHandling.Ignore)]
        public List<int> Unavailable { get; set; }

        /// <summary>
        /// Gets or sets Mine.
        /// </summary>
        [JsonProperty("mine", NullValueHandling = NullValueHandling.Ignore)]
        public List<int?> Mine { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"Spots : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is Spots other &&
                (this.Reserved == null && other.Reserved == null ||
                 this.Reserved?.Equals(other.Reserved) == true) &&
                (this.Available == null && other.Available == null ||
                 this.Available?.Equals(other.Available) == true) &&
                (this.Unavailable == null && other.Unavailable == null ||
                 this.Unavailable?.Equals(other.Unavailable) == true) &&
                (this.Mine == null && other.Mine == null ||
                 this.Mine?.Equals(other.Mine) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"Reserved = {(this.Reserved == null ? "null" : $"[{string.Join(", ", this.Reserved)} ]")}");
            toStringOutput.Add($"Available = {(this.Available == null ? "null" : $"[{string.Join(", ", this.Available)} ]")}");
            toStringOutput.Add($"Unavailable = {(this.Unavailable == null ? "null" : $"[{string.Join(", ", this.Unavailable)} ]")}");
            toStringOutput.Add($"Mine = {(this.Mine == null ? "null" : $"[{string.Join(", ", this.Mine)} ]")}");
        }
    }
}