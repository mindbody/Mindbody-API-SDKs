// <copyright file="PricingOption.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using BookingClassesAPI.Standard;
using BookingClassesAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace BookingClassesAPI.Standard.Models
{
    /// <summary>
    /// PricingOption.
    /// </summary>
    public class PricingOption
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PricingOption"/> class.
        /// </summary>
        public PricingOption()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PricingOption"/> class.
        /// </summary>
        /// <param name="price">price.</param>
        /// <param name="id">id.</param>
        /// <param name="name">name.</param>
        /// <param name="session">session.</param>
        /// <param name="offer">offer.</param>
        /// <param name="expiration">expiration.</param>
        /// <param name="membership">membership.</param>
        public PricingOption(
            Models.Price price = null,
            string id = null,
            string name = null,
            Models.Session session = null,
            Models.Offer offer = null,
            Models.Expiration expiration = null,
            Models.Membership membership = null)
        {
            this.Price = price;
            this.Id = id;
            this.Name = name;
            this.Session = session;
            this.Offer = offer;
            this.Expiration = expiration;
            this.Membership = membership;
        }

        /// <summary>
        /// Gets or sets Price.
        /// </summary>
        [JsonProperty("price", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Price Price { get; set; }

        /// <summary>
        /// Gets or sets Id.
        /// </summary>
        [JsonProperty("id", NullValueHandling = NullValueHandling.Ignore)]
        public string Id { get; set; }

        /// <summary>
        /// Gets or sets Name.
        /// </summary>
        [JsonProperty("name", NullValueHandling = NullValueHandling.Ignore)]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets Session.
        /// </summary>
        [JsonProperty("session", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Session Session { get; set; }

        /// <summary>
        /// Gets or sets Offer.
        /// </summary>
        [JsonProperty("offer", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Offer Offer { get; set; }

        /// <summary>
        /// Gets or sets Expiration.
        /// </summary>
        [JsonProperty("expiration", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Expiration Expiration { get; set; }

        /// <summary>
        /// Gets or sets Membership.
        /// </summary>
        [JsonProperty("membership", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Membership Membership { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"PricingOption : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is PricingOption other &&
                (this.Price == null && other.Price == null ||
                 this.Price?.Equals(other.Price) == true) &&
                (this.Id == null && other.Id == null ||
                 this.Id?.Equals(other.Id) == true) &&
                (this.Name == null && other.Name == null ||
                 this.Name?.Equals(other.Name) == true) &&
                (this.Session == null && other.Session == null ||
                 this.Session?.Equals(other.Session) == true) &&
                (this.Offer == null && other.Offer == null ||
                 this.Offer?.Equals(other.Offer) == true) &&
                (this.Expiration == null && other.Expiration == null ||
                 this.Expiration?.Equals(other.Expiration) == true) &&
                (this.Membership == null && other.Membership == null ||
                 this.Membership?.Equals(other.Membership) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"Price = {(this.Price == null ? "null" : this.Price.ToString())}");
            toStringOutput.Add($"Id = {this.Id ?? "null"}");
            toStringOutput.Add($"Name = {this.Name ?? "null"}");
            toStringOutput.Add($"Session = {(this.Session == null ? "null" : this.Session.ToString())}");
            toStringOutput.Add($"Offer = {(this.Offer == null ? "null" : this.Offer.ToString())}");
            toStringOutput.Add($"Expiration = {(this.Expiration == null ? "null" : this.Expiration.ToString())}");
            toStringOutput.Add($"Membership = {(this.Membership == null ? "null" : this.Membership.ToString())}");
        }
    }
}