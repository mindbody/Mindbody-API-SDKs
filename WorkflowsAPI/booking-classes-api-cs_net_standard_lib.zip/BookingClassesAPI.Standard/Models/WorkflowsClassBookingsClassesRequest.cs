// <copyright file="WorkflowsClassBookingsClassesRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using BookingClassesAPI.Standard;
using BookingClassesAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace BookingClassesAPI.Standard.Models
{
    /// <summary>
    /// WorkflowsClassBookingsClassesRequest.
    /// </summary>
    public class WorkflowsClassBookingsClassesRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="WorkflowsClassBookingsClassesRequest"/> class.
        /// </summary>
        public WorkflowsClassBookingsClassesRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="WorkflowsClassBookingsClassesRequest"/> class.
        /// </summary>
        /// <param name="bookingMethod">bookingMethod.</param>
        /// <param name="mClass">class.</param>
        /// <param name="notification">notification.</param>
        /// <param name="spotInfo">spotInfo.</param>
        public WorkflowsClassBookingsClassesRequest(
            Models.BookingMethod1 bookingMethod = null,
            Models.Class1 mClass = null,
            Models.NotificationEnum? notification = null,
            Models.SpotInfo spotInfo = null)
        {
            this.BookingMethod = bookingMethod;
            this.MClass = mClass;
            this.Notification = notification;
            this.SpotInfo = spotInfo;
        }

        /// <summary>
        /// Gets or sets BookingMethod.
        /// </summary>
        [JsonProperty("bookingMethod", NullValueHandling = NullValueHandling.Ignore)]
        public Models.BookingMethod1 BookingMethod { get; set; }

        /// <summary>
        /// Gets or sets MClass.
        /// </summary>
        [JsonProperty("class", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Class1 MClass { get; set; }

        /// <summary>
        /// Gets or sets Notification.
        /// </summary>
        [JsonProperty("notification", NullValueHandling = NullValueHandling.Ignore)]
        public Models.NotificationEnum? Notification { get; set; }

        /// <summary>
        /// Gets or sets SpotInfo.
        /// </summary>
        [JsonProperty("spotInfo", NullValueHandling = NullValueHandling.Ignore)]
        public Models.SpotInfo SpotInfo { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"WorkflowsClassBookingsClassesRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is WorkflowsClassBookingsClassesRequest other &&
                (this.BookingMethod == null && other.BookingMethod == null ||
                 this.BookingMethod?.Equals(other.BookingMethod) == true) &&
                (this.MClass == null && other.MClass == null ||
                 this.MClass?.Equals(other.MClass) == true) &&
                (this.Notification == null && other.Notification == null ||
                 this.Notification?.Equals(other.Notification) == true) &&
                (this.SpotInfo == null && other.SpotInfo == null ||
                 this.SpotInfo?.Equals(other.SpotInfo) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"BookingMethod = {(this.BookingMethod == null ? "null" : this.BookingMethod.ToString())}");
            toStringOutput.Add($"MClass = {(this.MClass == null ? "null" : this.MClass.ToString())}");
            toStringOutput.Add($"Notification = {(this.Notification == null ? "null" : this.Notification.ToString())}");
            toStringOutput.Add($"SpotInfo = {(this.SpotInfo == null ? "null" : this.SpotInfo.ToString())}");
        }
    }
}