// <copyright file="TypeEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using APIMatic.Core.Utilities.Converters;
using BookingClassesAPI.Standard;
using BookingClassesAPI.Standard.Utilities;
using Newtonsoft.Json;

namespace BookingClassesAPI.Standard.Models
{
    /// <summary>
    /// TypeEnum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum TypeEnum
    {
        /// <summary>
        /// Pass.
        /// </summary>
        [EnumMember(Value = "pass")]
        Pass,

        /// <summary>
        /// PricingOption.
        /// </summary>
        [EnumMember(Value = "pricingOption")]
        PricingOption,

        /// <summary>
        /// Free.
        /// </summary>
        [EnumMember(Value = "free")]
        Free,

        /// <summary>
        /// Waitlist.
        /// </summary>
        [EnumMember(Value = "waitlist")]
        Waitlist,

        /// <summary>
        /// Unpaid.
        /// </summary>
        [EnumMember(Value = "unpaid")]
        Unpaid
    }
}