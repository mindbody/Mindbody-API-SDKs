// <copyright file="StatusEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using APIMatic.Core.Utilities.Converters;
using BookingClassesAPI.Standard;
using BookingClassesAPI.Standard.Utilities;
using Newtonsoft.Json;

namespace BookingClassesAPI.Standard.Models
{
    /// <summary>
    /// StatusEnum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum StatusEnum
    {
        /// <summary>
        /// Free.
        /// </summary>
        [EnumMember(Value = "free")]
        Free,

        /// <summary>
        /// BookAndPayLater.
        /// </summary>
        [EnumMember(Value = "bookAndPayLater")]
        BookAndPayLater,

        /// <summary>
        /// PaymentRequired.
        /// </summary>
        [EnumMember(Value = "paymentRequired")]
        PaymentRequired
    }
}