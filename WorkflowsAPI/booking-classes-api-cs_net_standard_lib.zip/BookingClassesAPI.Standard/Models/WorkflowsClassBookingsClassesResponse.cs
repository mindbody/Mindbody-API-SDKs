// <copyright file="WorkflowsClassBookingsClassesResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using BookingClassesAPI.Standard;
using BookingClassesAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace BookingClassesAPI.Standard.Models
{
    /// <summary>
    /// WorkflowsClassBookingsClassesResponse.
    /// </summary>
    public class WorkflowsClassBookingsClassesResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="WorkflowsClassBookingsClassesResponse"/> class.
        /// </summary>
        public WorkflowsClassBookingsClassesResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="WorkflowsClassBookingsClassesResponse"/> class.
        /// </summary>
        /// <param name="pagination">pagination.</param>
        /// <param name="classesByLocation">classesByLocation.</param>
        /// <param name="consumerContext">consumerContext.</param>
        public WorkflowsClassBookingsClassesResponse(
            Models.Pagination pagination = null,
            List<Models.ClassesByLocation> classesByLocation = null,
            Models.ConsumerContext consumerContext = null)
        {
            this.Pagination = pagination;
            this.ClassesByLocation = classesByLocation;
            this.ConsumerContext = consumerContext;
        }

        /// <summary>
        /// Gets or sets Pagination.
        /// </summary>
        [JsonProperty("pagination", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Pagination Pagination { get; set; }

        /// <summary>
        /// Gets or sets ClassesByLocation.
        /// </summary>
        [JsonProperty("classesByLocation", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ClassesByLocation> ClassesByLocation { get; set; }

        /// <summary>
        /// Gets or sets ConsumerContext.
        /// </summary>
        [JsonProperty("consumerContext", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ConsumerContext ConsumerContext { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"WorkflowsClassBookingsClassesResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is WorkflowsClassBookingsClassesResponse other &&
                (this.Pagination == null && other.Pagination == null ||
                 this.Pagination?.Equals(other.Pagination) == true) &&
                (this.ClassesByLocation == null && other.ClassesByLocation == null ||
                 this.ClassesByLocation?.Equals(other.ClassesByLocation) == true) &&
                (this.ConsumerContext == null && other.ConsumerContext == null ||
                 this.ConsumerContext?.Equals(other.ConsumerContext) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"Pagination = {(this.Pagination == null ? "null" : this.Pagination.ToString())}");
            toStringOutput.Add($"ClassesByLocation = {(this.ClassesByLocation == null ? "null" : $"[{string.Join(", ", this.ClassesByLocation)} ]")}");
            toStringOutput.Add($"ConsumerContext = {(this.ConsumerContext == null ? "null" : this.ConsumerContext.ToString())}");
        }
    }
}