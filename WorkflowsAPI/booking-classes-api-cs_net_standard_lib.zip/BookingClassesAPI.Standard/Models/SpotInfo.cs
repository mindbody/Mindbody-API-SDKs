// <copyright file="SpotInfo.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using BookingClassesAPI.Standard;
using BookingClassesAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace BookingClassesAPI.Standard.Models
{
    /// <summary>
    /// SpotInfo.
    /// </summary>
    public class SpotInfo
    {
        private int? spotNumber;
        private Dictionary<string, bool> shouldSerialize = new Dictionary<string, bool>
        {
            { "spotNumber", false },
        };

        /// <summary>
        /// Initializes a new instance of the <see cref="SpotInfo"/> class.
        /// </summary>
        public SpotInfo()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="SpotInfo"/> class.
        /// </summary>
        /// <param name="spotNumber">spotNumber.</param>
        /// <param name="confirmationType">confirmationType.</param>
        /// <param name="spotAssignment">spotAssignment.</param>
        public SpotInfo(
            int? spotNumber = null,
            Models.ConfirmationTypeEnum? confirmationType = null,
            Models.SpotAssignmentEnum? spotAssignment = null)
        {

            if (spotNumber != null)
            {
                this.SpotNumber = spotNumber;
            }
            this.ConfirmationType = confirmationType;
            this.SpotAssignment = spotAssignment;
        }

        /// <summary>
        /// Gets or sets SpotNumber.
        /// </summary>
        [JsonProperty("spotNumber")]
        public int? SpotNumber
        {
            get
            {
                return this.spotNumber;
            }

            set
            {
                this.shouldSerialize["spotNumber"] = true;
                this.spotNumber = value;
            }
        }

        /// <summary>
        /// Gets or sets ConfirmationType.
        /// </summary>
        [JsonProperty("confirmationType", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ConfirmationTypeEnum? ConfirmationType { get; set; }

        /// <summary>
        /// Gets or sets SpotAssignment.
        /// </summary>
        [JsonProperty("spotAssignment", NullValueHandling = NullValueHandling.Ignore)]
        public Models.SpotAssignmentEnum? SpotAssignment { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"SpotInfo : ({string.Join(", ", toStringOutput)})";
        }

        /// <summary>
        /// Marks the field to not be serialized.
        /// </summary>
        public void UnsetSpotNumber()
        {
            this.shouldSerialize["spotNumber"] = false;
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeSpotNumber()
        {
            return this.shouldSerialize["spotNumber"];
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is SpotInfo other &&
                (this.SpotNumber == null && other.SpotNumber == null ||
                 this.SpotNumber?.Equals(other.SpotNumber) == true) &&
                (this.ConfirmationType == null && other.ConfirmationType == null ||
                 this.ConfirmationType?.Equals(other.ConfirmationType) == true) &&
                (this.SpotAssignment == null && other.SpotAssignment == null ||
                 this.SpotAssignment?.Equals(other.SpotAssignment) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"SpotNumber = {(this.SpotNumber == null ? "null" : this.SpotNumber.ToString())}");
            toStringOutput.Add($"ConfirmationType = {(this.ConfirmationType == null ? "null" : this.ConfirmationType.ToString())}");
            toStringOutput.Add($"SpotAssignment = {(this.SpotAssignment == null ? "null" : this.SpotAssignment.ToString())}");
        }
    }
}