// <copyright file="RequestedFromEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using APIMatic.Core.Utilities.Converters;
using BookingClassesAPI.Standard;
using BookingClassesAPI.Standard.Utilities;
using Newtonsoft.Json;

namespace BookingClassesAPI.Standard.Models
{
    /// <summary>
    /// RequestedFromEnum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum RequestedFromEnum
    {
        /// <summary>
        /// Online.
        /// </summary>
        [EnumMember(Value = "online")]
        Online,

        /// <summary>
        /// Offline.
        /// </summary>
        [EnumMember(Value = "offline")]
        Offline
    }
}