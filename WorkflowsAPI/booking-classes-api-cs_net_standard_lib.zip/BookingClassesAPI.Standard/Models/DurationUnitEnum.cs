// <copyright file="DurationUnitEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using APIMatic.Core.Utilities.Converters;
using BookingClassesAPI.Standard;
using BookingClassesAPI.Standard.Utilities;
using Newtonsoft.Json;

namespace BookingClassesAPI.Standard.Models
{
    /// <summary>
    /// DurationUnitEnum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum DurationUnitEnum
    {
        /// <summary>
        /// Days.
        /// </summary>
        [EnumMember(Value = "days")]
        Days,

        /// <summary>
        /// Months.
        /// </summary>
        [EnumMember(Value = "months")]
        Months
    }
}