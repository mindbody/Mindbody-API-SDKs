// <copyright file="Pagination.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using BookingClassesAPI.Standard;
using BookingClassesAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace BookingClassesAPI.Standard.Models
{
    /// <summary>
    /// Pagination.
    /// </summary>
    public class Pagination
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Pagination"/> class.
        /// </summary>
        public Pagination()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Pagination"/> class.
        /// </summary>
        /// <param name="hasNextPage">hasNextPage.</param>
        /// <param name="hasPreviousPage">hasPreviousPage.</param>
        /// <param name="startCursor">startCursor.</param>
        /// <param name="endCursor">endCursor.</param>
        public Pagination(
            bool? hasNextPage = null,
            bool? hasPreviousPage = null,
            string startCursor = null,
            string endCursor = null)
        {
            this.HasNextPage = hasNextPage;
            this.HasPreviousPage = hasPreviousPage;
            this.StartCursor = startCursor;
            this.EndCursor = endCursor;
        }

        /// <summary>
        /// Gets or sets HasNextPage.
        /// </summary>
        [JsonProperty("hasNextPage", NullValueHandling = NullValueHandling.Ignore)]
        public bool? HasNextPage { get; set; }

        /// <summary>
        /// Gets or sets HasPreviousPage.
        /// </summary>
        [JsonProperty("hasPreviousPage", NullValueHandling = NullValueHandling.Ignore)]
        public bool? HasPreviousPage { get; set; }

        /// <summary>
        /// Gets or sets StartCursor.
        /// </summary>
        [JsonProperty("startCursor", NullValueHandling = NullValueHandling.Ignore)]
        public string StartCursor { get; set; }

        /// <summary>
        /// Gets or sets EndCursor.
        /// </summary>
        [JsonProperty("endCursor", NullValueHandling = NullValueHandling.Ignore)]
        public string EndCursor { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"Pagination : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is Pagination other &&
                (this.HasNextPage == null && other.HasNextPage == null ||
                 this.HasNextPage?.Equals(other.HasNextPage) == true) &&
                (this.HasPreviousPage == null && other.HasPreviousPage == null ||
                 this.HasPreviousPage?.Equals(other.HasPreviousPage) == true) &&
                (this.StartCursor == null && other.StartCursor == null ||
                 this.StartCursor?.Equals(other.StartCursor) == true) &&
                (this.EndCursor == null && other.EndCursor == null ||
                 this.EndCursor?.Equals(other.EndCursor) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"HasNextPage = {(this.HasNextPage == null ? "null" : this.HasNextPage.ToString())}");
            toStringOutput.Add($"HasPreviousPage = {(this.HasPreviousPage == null ? "null" : this.HasPreviousPage.ToString())}");
            toStringOutput.Add($"StartCursor = {this.StartCursor ?? "null"}");
            toStringOutput.Add($"EndCursor = {this.EndCursor ?? "null"}");
        }
    }
}