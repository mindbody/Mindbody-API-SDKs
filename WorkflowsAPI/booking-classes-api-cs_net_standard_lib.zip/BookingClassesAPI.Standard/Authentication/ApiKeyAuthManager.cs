// <copyright file="ApiKeyAuthManager.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using BookingClassesAPI.Standard.Http.Request;
using APIMatic.Core.Authentication;

namespace BookingClassesAPI.Standard.Authentication
{
    /// <summary>
    /// ApiKeyAuthManager Class.
    /// </summary>
    internal class ApiKeyAuthManager : AuthManager, IApiKeyAuthCredentials
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ApiKeyAuthManager"/> class.
        /// </summary>
        /// <param name="apiKeyAuth">ApiKeyAuth.</param>
        public ApiKeyAuthManager(ApiKeyAuthModel apiKeyAuthModel)
        {
            ApiKey = apiKeyAuthModel?.ApiKey;
            Parameters(paramBuilder => paramBuilder
                .Header(header => header.Setup("Api-Key", ApiKey).Required())
            );
        }

        /// <summary>
        /// Gets string value for apiKey.
        /// </summary>
        public string ApiKey { get; }

        /// <summary>
        /// Check if credentials match.
        /// </summary>
        /// <param name="apiKey"> The string value for credentials.</param>
        /// <returns> True if credentials matched.</returns>
        public bool Equals(string apiKey)
        {
            return apiKey.Equals(this.ApiKey);
        }
    }

    public sealed class ApiKeyAuthModel
    {
        internal ApiKeyAuthModel()
        {
        }

        internal string ApiKey { get; set; }

        /// <summary>
        /// Creates an object of the ApiKeyAuthModel using the values provided for the builder.
        /// </summary>
        /// <returns>Builder.</returns>
        public Builder ToBuilder()
        {
            return new Builder(ApiKey);
        }

        /// <summary>
        /// Builder class for ApiKeyAuthModel.
        /// </summary>
        public class Builder
        {
            private string apiKey;

            public Builder(string apiKey)
            {
                this.apiKey = apiKey ?? throw new ArgumentNullException(nameof(apiKey));
            }

            /// <summary>
            /// Sets ApiKey.
            /// </summary>
            /// <param name="apiKey">ApiKey.</param>
            /// <returns>Builder.</returns>
            public Builder ApiKey(string apiKey)
            {
                this.apiKey = apiKey ?? throw new ArgumentNullException(nameof(apiKey));
                return this;
            }


            /// <summary>
            /// Creates an object of the ApiKeyAuthModel using the values provided for the builder.
            /// </summary>
            /// <returns>ApiKeyAuthModel.</returns>
            public ApiKeyAuthModel Build()
            {
                return new ApiKeyAuthModel()
                {
                    ApiKey = this.apiKey
                };
            }
        }
    }
    
}