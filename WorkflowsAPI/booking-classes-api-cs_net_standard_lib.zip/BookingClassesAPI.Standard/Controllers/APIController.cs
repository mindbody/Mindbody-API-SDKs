// <copyright file="APIController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using APIMatic.Core;
using APIMatic.Core.Types;
using APIMatic.Core.Utilities;
using APIMatic.Core.Utilities.Date.Xml;
using BookingClassesAPI.Standard;
using BookingClassesAPI.Standard.Exceptions;
using BookingClassesAPI.Standard.Http.Client;
using BookingClassesAPI.Standard.Utilities;
using Newtonsoft.Json.Converters;
using System.Net.Http;

namespace BookingClassesAPI.Standard.Controllers
{
    /// <summary>
    /// APIController.
    /// </summary>
    public class APIController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="APIController"/> class.
        /// </summary>
        internal APIController(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// Retrieves a list of bookable classes along with consumer context information, including available payment methods and the ability to view waitlist entries.
        /// </summary>
        /// <param name="studioId">Required parameter: The Studio ID to filter the classes for..</param>
        /// <param name="locationIds">Optional parameter: A list of location IDs to filter classes by location..</param>
        /// <param name="instructorIds">Optional parameter: A list of instructor IDs to filter classes by instructor..</param>
        /// <param name="startDate">Optional parameter: The start date for the class filter. Defaults to the current date..</param>
        /// <param name="endDate">Optional parameter: The end date for the class filter. Defaults to one day after startDate..</param>
        /// <returns>Returns the Models.WorkflowsClassBookingsClassesResponse response from the API call.</returns>
        public Models.WorkflowsClassBookingsClassesResponse GetAvailableClassesForBooking(
                string studioId,
                List<int> locationIds = null,
                List<int> instructorIds = null,
                DateTime? startDate = null,
                DateTime? endDate = null)
            => CoreHelper.RunTask(GetAvailableClassesForBookingAsync(studioId, locationIds, instructorIds, startDate, endDate));

        /// <summary>
        /// Retrieves a list of bookable classes along with consumer context information, including available payment methods and the ability to view waitlist entries.
        /// </summary>
        /// <param name="studioId">Required parameter: The Studio ID to filter the classes for..</param>
        /// <param name="locationIds">Optional parameter: A list of location IDs to filter classes by location..</param>
        /// <param name="instructorIds">Optional parameter: A list of instructor IDs to filter classes by instructor..</param>
        /// <param name="startDate">Optional parameter: The start date for the class filter. Defaults to the current date..</param>
        /// <param name="endDate">Optional parameter: The end date for the class filter. Defaults to one day after startDate..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.WorkflowsClassBookingsClassesResponse response from the API call.</returns>
        public async Task<Models.WorkflowsClassBookingsClassesResponse> GetAvailableClassesForBookingAsync(
                string studioId,
                List<int> locationIds = null,
                List<int> instructorIds = null,
                DateTime? startDate = null,
                DateTime? endDate = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.WorkflowsClassBookingsClassesResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/workflows/class-bookings/classes")
                  .WithOrAuth(_orAuth => _orAuth
                      .Add("ApiKeyAuth")
                      .Add("ConsumerTokenAuth")
                  )
                  .Parameters(_parameters => _parameters
                      .Header(_header => _header.Setup("studioId", studioId))
                      .Query(_query => _query.Setup("locationIds", locationIds))
                      .Query(_query => _query.Setup("instructorIds", instructorIds))
                      .Query(_query => _query.Setup("startDate", startDate.HasValue ? startDate.Value.ToString("yyyy'-'MM'-'dd") : null))
                      .Query(_query => _query.Setup("endDate", endDate.HasValue ? endDate.Value.ToString("yyyy'-'MM'-'dd") : null))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("Bad request due to missing or invalid parameters.", (_reason, _context) => new BadRequestException(_reason, _context)))
                  .ErrorCase("500", CreateErrorCase("Internal server error.", (_reason, _context) => new InternalServerErrorException(_reason, _context))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Allows a consumer to book a class directly or add to the waitlist. Also manages the spot reservation for the class.
        /// </summary>
        /// <param name="studioId">Required parameter: The Studio ID to filter the classes for..</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the List of Models.WorkflowsClassBookingsClassesResponse1 response from the API call.</returns>
        public List<Models.WorkflowsClassBookingsClassesResponse1> BookAClassOrAddToWaitlist(
                string studioId,
                List<Models.WorkflowsClassBookingsClassesRequest> body)
            => CoreHelper.RunTask(BookAClassOrAddToWaitlistAsync(studioId, body));

        /// <summary>
        /// Allows a consumer to book a class directly or add to the waitlist. Also manages the spot reservation for the class.
        /// </summary>
        /// <param name="studioId">Required parameter: The Studio ID to filter the classes for..</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the List of Models.WorkflowsClassBookingsClassesResponse1 response from the API call.</returns>
        public async Task<List<Models.WorkflowsClassBookingsClassesResponse1>> BookAClassOrAddToWaitlistAsync(
                string studioId,
                List<Models.WorkflowsClassBookingsClassesRequest> body,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<List<Models.WorkflowsClassBookingsClassesResponse1>>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/workflows/class-bookings/classes")
                  .WithOrAuth(_orAuth => _orAuth
                      .Add("ApiKeyAuth")
                      .Add("ConsumerTokenAuth")
                  )
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(body))
                      .Header(_header => _header.Setup("studioId", studioId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("Bad request due to missing or invalid parameters.", (_reason, _context) => new BadRequestException(_reason, _context)))
                  .ErrorCase("500", CreateErrorCase("Internal server error.", (_reason, _context) => new InternalServerErrorException(_reason, _context))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Retrieves details of a specific class, including pricing options and consumer-related context for booking.
        /// </summary>
        /// <param name="id">Required parameter: The unique ID of the class to retrieve..</param>
        /// <param name="studioId">Required parameter: The Studio ID to filter the class for..</param>
        /// <returns>Returns the Models.WorkflowsClassBookingsClassesResponse2 response from the API call.</returns>
        public Models.WorkflowsClassBookingsClassesResponse2 GetDetailedInformationAboutASpecificClass(
                int id,
                string studioId)
            => CoreHelper.RunTask(GetDetailedInformationAboutASpecificClassAsync(id, studioId));

        /// <summary>
        /// Retrieves details of a specific class, including pricing options and consumer-related context for booking.
        /// </summary>
        /// <param name="id">Required parameter: The unique ID of the class to retrieve..</param>
        /// <param name="studioId">Required parameter: The Studio ID to filter the class for..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.WorkflowsClassBookingsClassesResponse2 response from the API call.</returns>
        public async Task<Models.WorkflowsClassBookingsClassesResponse2> GetDetailedInformationAboutASpecificClassAsync(
                int id,
                string studioId,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.WorkflowsClassBookingsClassesResponse2>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/workflows/class-bookings/classes/{id}")
                  .WithOrAuth(_orAuth => _orAuth
                      .Add("ApiKeyAuth")
                      .Add("ConsumerTokenAuth")
                  )
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("id", id))
                      .Header(_header => _header.Setup("studioId", studioId))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .ErrorCase("400", CreateErrorCase("Bad request due to missing or invalid parameters.", (_reason, _context) => new BadRequestException(_reason, _context)))
                  .ErrorCase("500", CreateErrorCase("Internal server error.", (_reason, _context) => new InternalServerErrorException(_reason, _context))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);
    }
}