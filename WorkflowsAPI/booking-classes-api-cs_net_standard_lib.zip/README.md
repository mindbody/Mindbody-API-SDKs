
# Getting Started with Booking Classes API

## Introduction

The Booking Classes API is designed to facilitate the booking process for consumers looking to reserve spots in fitness or activity classes. This API offers three main endpoints to retrieve class listings, view details about specific classes, and make bookings or add consumers to waitlists. The API also provides consumer context, including available payment methods, waitlist entries, and bookings. This allows for a more personalized and efficient class booking experience.

## Building

The generated code uses the Newtonsoft Json.NET NuGet Package. If the automatic NuGet package restore is enabled, these dependencies will be installed automatically. Therefore, you will need internet access for build.

* Open the solution (BookingClassesAPI.sln) file.

Invoke the build process using Ctrl + Shift + B shortcut key or using the Build menu as shown below.

The build process generates a portable class library, which can be used like a normal class library. More information on how to use can be found at the MSDN Portable Class Libraries documentation.

The supported version is **.NET Standard 2.0**. For checking compatibility of your .NET implementation with the generated library, [click here](https://dotnet.microsoft.com/en-us/platform/dotnet-standard#versions).

## Installation

The following section explains how to use the BookingClassesAPI.Standard library in a new project.

### 1. Starting a new project

For starting a new project, right click on the current solution from the solution explorer and choose `Add -> New Project`.

![Add a new project in Visual Studio](https://apidocs.io/illustration/cs?workspaceFolder=Booking%20Classes%20API-CSharp&workspaceName=BookingClassesAPI&projectName=BookingClassesAPI.Standard&rootNamespace=BookingClassesAPI.Standard&step=addProject)

Next, choose `Console Application`, provide `TestConsoleProject` as the project name and click OK.

![Create a new Console Application in Visual Studio](https://apidocs.io/illustration/cs?workspaceFolder=Booking%20Classes%20API-CSharp&workspaceName=BookingClassesAPI&projectName=BookingClassesAPI.Standard&rootNamespace=BookingClassesAPI.Standard&step=createProject)

### 2. Set as startup project

The new console project is the entry point for the eventual execution. This requires us to set the `TestConsoleProject` as the start-up project. To do this, right-click on the `TestConsoleProject` and choose `Set as StartUp Project` form the context menu.

![Adding a project reference](https://apidocs.io/illustration/cs?workspaceFolder=Booking%20Classes%20API-CSharp&workspaceName=BookingClassesAPI&projectName=BookingClassesAPI.Standard&rootNamespace=BookingClassesAPI.Standard&step=setStartup)

### 3. Add reference of the library project

In order to use the `BookingClassesAPI.Standard` library in the new project, first we must add a project reference to the `TestConsoleProject`. First, right click on the `References` node in the solution explorer and click `Add Reference...`

![Adding a project reference](https://apidocs.io/illustration/cs?workspaceFolder=Booking%20Classes%20API-CSharp&workspaceName=BookingClassesAPI&projectName=BookingClassesAPI.Standard&rootNamespace=BookingClassesAPI.Standard&step=addReference)

Next, a window will be displayed where we must set the `checkbox` on `BookingClassesAPI.Standard` and click `OK`. By doing this, we have added a reference of the `BookingClassesAPI.Standard` project into the new `TestConsoleProject`.

![Creating a project reference](https://apidocs.io/illustration/cs?workspaceFolder=Booking%20Classes%20API-CSharp&workspaceName=BookingClassesAPI&projectName=BookingClassesAPI.Standard&rootNamespace=BookingClassesAPI.Standard&step=createReference)

### 4. Write sample code

Once the `TestConsoleProject` is created, a file named `Program.cs` will be visible in the solution explorer with an empty `Main` method. This is the entry point for the execution of the entire solution. Here, you can add code to initialize the client library and acquire the instance of a Controller class. Sample code to initialize the client library and using Controller methods is given in the subsequent sections.

![Adding a project reference](https://apidocs.io/illustration/cs?workspaceFolder=Booking%20Classes%20API-CSharp&workspaceName=BookingClassesAPI&projectName=BookingClassesAPI.Standard&rootNamespace=BookingClassesAPI.Standard&step=addCode)

## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| Environment | `Environment` | The API environment. <br> **Default: `Environment.Production`** |
| Timeout | `TimeSpan` | Http client timeout.<br>*Default*: `TimeSpan.FromSeconds(100)` |
| HttpClientConfiguration | [`Action<HttpClientConfiguration.Builder>`](doc/http-client-configuration-builder.md) | Action delegate that configures the HTTP client by using the HttpClientConfiguration.Builder for customizing API call settings.<br>*Default*: `new HttpClient()` |
| ApiKeyAuthCredentials | [`ApiKeyAuthCredentials`](doc/auth/custom-header-signature.md) | The Credentials Setter for Custom Header Signature |
| ConsumerTokenAuthCredentials | [`ConsumerTokenAuthCredentials`](doc/auth/oauth-2-implicit-grant.md) | The Credentials Setter for OAuth 2 Implicit Grant |

The API client can be initialized as follows:

```csharp
BookingClassesAPIClient client = new BookingClassesAPIClient.Builder()
    .ApiKeyAuthCredentials(
        new ApiKeyAuthModel.Builder(
            "Api-Key"
        )
        .Build())
    .ConsumerTokenAuthCredentials(
        new ConsumerTokenAuthModel.Builder(
            "OAuthClientId",
            "OAuthRedirectUri"
        )
        .OAuthScopes(
            new List<OAuthScopeConsumerTokenAuthEnum>
            {
                OAuthScopeConsumerTokenAuthEnum.Write,
                OAuthScopeConsumerTokenAuthEnum.Read,
            })
        .Build())
    .Environment(BookingClassesAPI.Standard.Environment.Production)
    .Build();
```

## Authorization

This API uses the following authentication schemes.

* [`ApiKeyAuth (Custom Header Signature)`](doc/auth/custom-header-signature.md)
* [`ConsumerTokenAuth (OAuth 2 Implicit Grant)`](doc/auth/oauth-2-implicit-grant.md)

## List of APIs

* [API](doc/controllers/api.md)

## SDK Infrastructure

### Configuration

* [HttpClientConfiguration](doc/http-client-configuration.md)
* [HttpClientConfigurationBuilder](doc/http-client-configuration-builder.md)

### HTTP

* [HttpCallback](doc/http-callback.md)
* [HttpContext](doc/http-context.md)
* [HttpRequest](doc/http-request.md)
* [HttpResponse](doc/http-response.md)
* [HttpStringResponse](doc/http-string-response.md)

### Utilities

* [ApiException](doc/api-exception.md)
* [ApiHelper](doc/api-helper.md)
* [CustomDateTimeConverter](doc/custom-date-time-converter.md)
* [UnixDateTimeConverter](doc/unix-date-time-converter.md)

