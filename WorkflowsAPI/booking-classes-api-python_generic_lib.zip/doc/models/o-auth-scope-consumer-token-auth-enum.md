
# O Auth Scope Consumer Token Auth Enum

OAuth 2 scopes supported by the API

## Enumeration

`OAuthScopeConsumerTokenAuthEnum`

## Fields

| Name | Description |
|  --- | --- |
| `WRITE` | book classes |
| `READ` | see bookable classes |

