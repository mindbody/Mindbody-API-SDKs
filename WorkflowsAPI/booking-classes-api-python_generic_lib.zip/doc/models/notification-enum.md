
# Notification Enum

## Enumeration

`NotificationEnum`

## Fields

| Name |
|  --- |
| `DEFAULT` |
| `EMAIL` |
| `NONE` |

