
# Membership

## Structure

`Membership`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `str` | Optional | - |

## Example (as JSON)

```json
{
  "id": "id8"
}
```

