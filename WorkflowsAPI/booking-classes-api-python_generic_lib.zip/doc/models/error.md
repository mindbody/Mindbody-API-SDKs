
# Error

## Structure

`Error`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code` | `str` | Optional | - |
| `message` | `str` | Optional | - |

## Example (as JSON)

```json
{
  "code": "code2",
  "message": "message4"
}
```

