
# Location

## Structure

`Location`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | - |
| `address` | [`Address`](../../doc/models/address.md) | Optional | - |
| `name` | `str` | Optional | - |
| `description` | `str` | Optional | - |

## Example (as JSON)

```json
{
  "id": 12,
  "address": {
    "street": "street6",
    "city": "city6",
    "state": "state2",
    "country": "country0",
    "latitude": 75.2
  },
  "name": "name4",
  "description": "description4"
}
```

