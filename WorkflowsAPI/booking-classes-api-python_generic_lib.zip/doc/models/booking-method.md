
# Booking Method

## Structure

`BookingMethod`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `str` | Optional | - |
| `name` | `str` | Optional | - |
| `remaining` | `int` | Optional | - |
| `remaining_after_scheduled_visits` | `int` | Optional | - |
| `expiration_date` | `datetime` | Optional | - |
| `activation_date` | `datetime` | Optional | - |
| `status` | [`Status1Enum`](../../doc/models/status-1-enum.md) | Optional | - |

## Example (as JSON)

```json
{
  "id": "id4",
  "name": "name4",
  "remaining": 248,
  "remainingAfterScheduledVisits": 158,
  "expirationDate": "2016-03-13T12:52:32.123Z"
}
```

