
# Waitlist Entry

## Structure

`WaitlistEntry`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | - |
| `class_id` | `int` | Optional | - |
| `request_date_time` | `datetime` | Optional | - |
| `requested_from` | [`RequestedFromEnum`](../../doc/models/requested-from-enum.md) | Optional | - |
| `visit_id` | `int` | Optional | - |

## Example (as JSON)

```json
{
  "id": 80,
  "classId": 212,
  "requestDateTime": "2016-03-13T12:52:32.123Z",
  "requestedFrom": "online",
  "visitId": 220
}
```

