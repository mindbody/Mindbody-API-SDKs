
# Bad Request Exception

## Structure

`BadRequestException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code` | `str` | Optional | - |
| `message` | `str` | Optional | - |

## Example (as JSON)

```json
{
  "code": "BAD_REQUEST",
  "message": "Required parameters are missing or invalid."
}
```

