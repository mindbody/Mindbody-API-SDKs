
# Consumer Context 1

## Structure

`ConsumerContext1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `waitlistEntries` | [`?(WaitlistEntry[])`](../../doc/models/waitlist-entry.md) | Optional | - | getWaitlistEntries(): ?array | setWaitlistEntries(?array waitlistEntries): void |
| `bookingMethods` | [`?(BookingMethod[])`](../../doc/models/booking-method.md) | Optional | - | getBookingMethods(): ?array | setBookingMethods(?array bookingMethods): void |
| `pricingOptions` | [`?(PricingOption[])`](../../doc/models/pricing-option.md) | Optional | - | getPricingOptions(): ?array | setPricingOptions(?array pricingOptions): void |

## Example (as JSON)

```json
{
  "waitlistEntries": [
    {
      "id": 248,
      "classId": 124,
      "requestDateTime": "2016-03-13T12:52:32.123Z",
      "requestedFrom": "online",
      "visitId": 132
    },
    {
      "id": 248,
      "classId": 124,
      "requestDateTime": "2016-03-13T12:52:32.123Z",
      "requestedFrom": "online",
      "visitId": 132
    }
  ],
  "bookingMethods": [
    {
      "id": "id0",
      "name": "name0",
      "remaining": 204,
      "remainingAfterScheduledVisits": 114,
      "expirationDate": "2016-03-13T12:52:32.123Z"
    },
    {
      "id": "id0",
      "name": "name0",
      "remaining": 204,
      "remainingAfterScheduledVisits": 114,
      "expirationDate": "2016-03-13T12:52:32.123Z"
    },
    {
      "id": "id0",
      "name": "name0",
      "remaining": 204,
      "remainingAfterScheduledVisits": 114,
      "expirationDate": "2016-03-13T12:52:32.123Z"
    }
  ],
  "pricingOptions": [
    {
      "price": {
        "unitPrice": 156.68
      },
      "id": "id2",
      "name": "name2",
      "session": {
        "sessionCount": 226,
        "type": "unlimited"
      },
      "offer": {
        "type": "introForNewClients"
      }
    },
    {
      "price": {
        "unitPrice": 156.68
      },
      "id": "id2",
      "name": "name2",
      "session": {
        "sessionCount": 226,
        "type": "unlimited"
      },
      "offer": {
        "type": "introForNewClients"
      }
    },
    {
      "price": {
        "unitPrice": 156.68
      },
      "id": "id2",
      "name": "name2",
      "session": {
        "sessionCount": 226,
        "type": "unlimited"
      },
      "offer": {
        "type": "introForNewClients"
      }
    }
  ]
}
```

