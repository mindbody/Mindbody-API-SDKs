
# Type Enum

## Enumeration

`TypeEnum`

## Fields

| Name |
|  --- |
| `PASS` |
| `PRICINGOPTION` |
| `FREE` |
| `WAITLIST` |
| `UNPAID` |

