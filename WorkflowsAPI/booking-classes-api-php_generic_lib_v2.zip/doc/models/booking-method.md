
# Booking Method

## Structure

`BookingMethod`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?string` | Optional | - | getId(): ?string | setId(?string id): void |
| `name` | `?string` | Optional | - | getName(): ?string | setName(?string name): void |
| `remaining` | `?int` | Optional | - | getRemaining(): ?int | setRemaining(?int remaining): void |
| `remainingAfterScheduledVisits` | `?int` | Optional | - | getRemainingAfterScheduledVisits(): ?int | setRemainingAfterScheduledVisits(?int remainingAfterScheduledVisits): void |
| `expirationDate` | `?DateTime` | Optional | - | getExpirationDate(): ?\DateTime | setExpirationDate(?\DateTime expirationDate): void |
| `activationDate` | `?DateTime` | Optional | - | getActivationDate(): ?\DateTime | setActivationDate(?\DateTime activationDate): void |
| `status` | [`?string(Status1Enum)`](../../doc/models/status-1-enum.md) | Optional | - | getStatus(): ?string | setStatus(?string status): void |

## Example (as JSON)

```json
{
  "id": "id4",
  "name": "name4",
  "remaining": 248,
  "remainingAfterScheduledVisits": 158,
  "expirationDate": "2016-03-13T12:52:32.123Z"
}
```

