
# Spot Reservation

## Structure

`SpotReservation`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `visitId` | `?string` | Optional | - | getVisitId(): ?string | setVisitId(?string visitId): void |
| `classId` | `?string` | Optional | - | getClassId(): ?string | setClassId(?string classId): void |
| `reservationType` | `?string` | Optional | - | getReservationType(): ?string | setReservationType(?string reservationType): void |
| `status` | [`?string(Status2Enum)`](../../doc/models/status-2-enum.md) | Optional | - | getStatus(): ?string | setStatus(?string status): void |
| `confirmationDate` | `?DateTime` | Optional | - | getConfirmationDate(): ?\DateTime | setConfirmationDate(?\DateTime confirmationDate): void |

## Example (as JSON)

```json
{
  "visitId": "visitId6",
  "classId": "classId6",
  "reservationType": "reservationType4",
  "status": "confirmed",
  "confirmationDate": "2016-03-13T12:52:32.123Z"
}
```

