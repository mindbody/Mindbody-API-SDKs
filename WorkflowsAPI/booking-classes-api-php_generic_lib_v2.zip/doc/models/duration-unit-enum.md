
# Duration Unit Enum

## Enumeration

`DurationUnitEnum`

## Fields

| Name |
|  --- |
| `DAYS` |
| `MONTHS` |

