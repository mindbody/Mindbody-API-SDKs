
# Activation Type Enum

## Enumeration

`ActivationTypeEnum`

## Fields

| Name |
|  --- |
| `DATEOFFIRSTVISIT` |
| `DATEOFPURCHASE` |

