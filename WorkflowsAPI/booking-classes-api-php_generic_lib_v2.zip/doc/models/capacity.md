
# Capacity

## Structure

`Capacity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `totalCapacity` | `?int` | Optional | - | getTotalCapacity(): ?int | setTotalCapacity(?int totalCapacity): void |
| `totalBooked` | `?int` | Optional | - | getTotalBooked(): ?int | setTotalBooked(?int totalBooked): void |
| `webCapacity` | `?int` | Optional | - | getWebCapacity(): ?int | setWebCapacity(?int webCapacity): void |
| `webBooked` | `?int` | Optional | - | getWebBooked(): ?int | setWebBooked(?int webBooked): void |
| `waitlistCapacity` | `?int` | Optional | - | getWaitlistCapacity(): ?int | setWaitlistCapacity(?int waitlistCapacity): void |
| `spots` | [`?Spots`](../../doc/models/spots.md) | Optional | - | getSpots(): ?Spots | setSpots(?Spots spots): void |

## Example (as JSON)

```json
{
  "totalCapacity": 22,
  "totalBooked": 248,
  "webCapacity": 142,
  "webBooked": 78,
  "waitlistCapacity": 232
}
```

