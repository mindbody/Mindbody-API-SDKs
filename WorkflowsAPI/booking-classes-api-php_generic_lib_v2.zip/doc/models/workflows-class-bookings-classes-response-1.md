
# Workflows Class Bookings Classes Response 1

## Structure

`WorkflowsClassBookingsClassesResponse1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `visit` | [`?Visit`](../../doc/models/visit.md) | Optional | - | getVisit(): ?Visit | setVisit(?Visit visit): void |
| `bookingStatus` | [`?string(BookingStatusEnum)`](../../doc/models/booking-status-enum.md) | Optional | - | getBookingStatus(): ?string | setBookingStatus(?string bookingStatus): void |
| `waitlistEntry` | [`?WaitlistEntry1`](../../doc/models/waitlist-entry-1.md) | Optional | - | getWaitlistEntry(): ?WaitlistEntry1 | setWaitlistEntry(?WaitlistEntry1 waitlistEntry): void |
| `spotReservation` | [`?SpotReservation`](../../doc/models/spot-reservation.md) | Optional | - | getSpotReservation(): ?SpotReservation | setSpotReservation(?SpotReservation spotReservation): void |
| `error` | [`?Error`](../../doc/models/error.md) | Optional | - | getError(): ?Error | setError(?Error error): void |

## Example (as JSON)

```json
{
  "visit": {
    "id": 54,
    "startDateTime": "2016-03-13T12:52:32.123Z",
    "endDateTime": "2016-03-13T12:52:32.123Z"
  },
  "bookingStatus": "awaiting_payment",
  "waitlistEntry": {
    "id": 176
  },
  "spotReservation": {
    "visitId": "visitId8",
    "classId": "classId0",
    "reservationType": "reservationType8",
    "status": "confirmed",
    "confirmationDate": "2016-03-13T12:52:32.123Z"
  },
  "error": {
    "code": "code2",
    "message": "message4"
  }
}
```

