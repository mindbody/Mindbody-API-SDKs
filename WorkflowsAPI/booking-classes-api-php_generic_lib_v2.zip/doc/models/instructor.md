
# Instructor

## Structure

`Instructor`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `level` | [`?string(LevelEnum)`](../../doc/models/level-enum.md) | Optional | - | getLevel(): ?string | setLevel(?string level): void |
| `displayName` | `?string` | Optional | - | getDisplayName(): ?string | setDisplayName(?string displayName): void |

## Example (as JSON)

```json
{
  "level": "secondAssistant",
  "displayName": "displayName0"
}
```

