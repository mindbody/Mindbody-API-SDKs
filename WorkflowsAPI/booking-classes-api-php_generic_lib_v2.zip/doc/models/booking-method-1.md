
# Booking Method 1

## Structure

`BookingMethod1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | [`?string(TypeEnum)`](../../doc/models/type-enum.md) | Optional | - | getType(): ?string | setType(?string type): void |
| `id` | `?string` | Optional | - | getId(): ?string | setId(?string id): void |
| `waitlistEntryId` | `?int` | Optional | - | getWaitlistEntryId(): ?int | setWaitlistEntryId(?int waitlistEntryId): void |

## Example (as JSON)

```json
{
  "type": "unpaid",
  "id": "id6",
  "waitlistEntryId": 118
}
```

