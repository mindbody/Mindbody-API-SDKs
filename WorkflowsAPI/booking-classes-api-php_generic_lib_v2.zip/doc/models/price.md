
# Price

## Structure

`Price`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `unitPrice` | `?float` | Optional | - | getUnitPrice(): ?float | setUnitPrice(?float unitPrice): void |

## Example (as JSON)

```json
{
  "unitPrice": 211.36
}
```

