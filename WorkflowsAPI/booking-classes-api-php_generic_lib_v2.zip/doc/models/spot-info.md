
# Spot Info

## Structure

`SpotInfo`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `spotNumber` | `?int` | Optional | - | getSpotNumber(): ?int | setSpotNumber(?int spotNumber): void |
| `confirmationType` | [`?string(ConfirmationTypeEnum)`](../../doc/models/confirmation-type-enum.md) | Optional | - | getConfirmationType(): ?string | setConfirmationType(?string confirmationType): void |
| `spotAssignment` | [`?string(SpotAssignmentEnum)`](../../doc/models/spot-assignment-enum.md) | Optional | - | getSpotAssignment(): ?string | setSpotAssignment(?string spotAssignment): void |

## Example (as JSON)

```json
{
  "spotNumber": 32,
  "confirmationType": "manual",
  "spotAssignment": "manual"
}
```

