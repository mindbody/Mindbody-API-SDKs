
# Pagination

## Structure

`Pagination`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `hasNextPage` | `?bool` | Optional | - | getHasNextPage(): ?bool | setHasNextPage(?bool hasNextPage): void |
| `hasPreviousPage` | `?bool` | Optional | - | getHasPreviousPage(): ?bool | setHasPreviousPage(?bool hasPreviousPage): void |
| `startCursor` | `?string` | Optional | - | getStartCursor(): ?string | setStartCursor(?string startCursor): void |
| `endCursor` | `?string` | Optional | - | getEndCursor(): ?string | setEndCursor(?string endCursor): void |

## Example (as JSON)

```json
{
  "hasNextPage": false,
  "hasPreviousPage": false,
  "startCursor": "startCursor8",
  "endCursor": "endCursor2"
}
```

