# API

```php
$aPIController = $client->getAPIController();
```

## Class Name

`APIController`

## Methods

* [Get Available Classes for Booking](../../doc/controllers/api.md#get-available-classes-for-booking)
* [Book a Class or Add to Waitlist](../../doc/controllers/api.md#book-a-class-or-add-to-waitlist)
* [Get Detailed Information About a Specific Class](../../doc/controllers/api.md#get-detailed-information-about-a-specific-class)


# Get Available Classes for Booking

Retrieves a list of bookable classes along with consumer context information, including available payment methods and the ability to view waitlist entries.

```php
function getAvailableClassesForBooking(
    string $studioId,
    ?array $locationIds = null,
    ?array $instructorIds = null,
    ?\DateTime $startDate = null,
    ?\DateTime $endDate = null
): WorkflowsClassBookingsClassesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `studioId` | `string` | Header, Required | The Studio ID to filter the classes for. |
| `locationIds` | `?(int[])` | Query, Optional | A list of location IDs to filter classes by location. |
| `instructorIds` | `?(int[])` | Query, Optional | A list of instructor IDs to filter classes by instructor. |
| `startDate` | `?DateTime` | Query, Optional | The start date for the class filter. Defaults to the current date. |
| `endDate` | `?DateTime` | Query, Optional | The end date for the class filter. Defaults to one day after startDate. |

## Response Type

[`WorkflowsClassBookingsClassesResponse`](../../doc/models/workflows-class-bookings-classes-response.md)

## Example Usage

```php
$studioId = 'studioId2';

$result = $aPIController->getAvailableClassesForBooking($studioId);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request due to missing or invalid parameters. | [`BadRequestException`](../../doc/models/bad-request-exception.md) |
| 500 | Internal server error. | [`InternalServerErrorException`](../../doc/models/internal-server-error-exception.md) |


# Book a Class or Add to Waitlist

Allows a consumer to book a class directly or add to the waitlist. Also manages the spot reservation for the class.

```php
function bookAClassOrAddToWaitlist(string $studioId, array $body): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `studioId` | `string` | Header, Required | The Studio ID to filter the classes for. |
| `body` | [`WorkflowsClassBookingsClassesRequest[]`](../../doc/models/workflows-class-bookings-classes-request.md) | Body, Required | - |

## Response Type

[`WorkflowsClassBookingsClassesResponse1[]`](../../doc/models/workflows-class-bookings-classes-response-1.md)

## Example Usage

```php
$studioId = 'studioId2';

$body = [
    WorkflowsClassBookingsClassesRequestBuilder::init()->build()
];

$result = $aPIController->bookAClassOrAddToWaitlist(
    $studioId,
    $body
);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request due to missing or invalid parameters. | [`BadRequestException`](../../doc/models/bad-request-exception.md) |
| 500 | Internal server error. | [`InternalServerErrorException`](../../doc/models/internal-server-error-exception.md) |


# Get Detailed Information About a Specific Class

Retrieves details of a specific class, including pricing options and consumer-related context for booking.

```php
function getDetailedInformationAboutASpecificClass(
    int $id,
    string $studioId
): WorkflowsClassBookingsClassesResponse2
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Template, Required | The unique ID of the class to retrieve. |
| `studioId` | `string` | Header, Required | The Studio ID to filter the class for. |

## Response Type

[`WorkflowsClassBookingsClassesResponse2`](../../doc/models/workflows-class-bookings-classes-response-2.md)

## Example Usage

```php
$id = 112;

$studioId = 'studioId2';

$result = $aPIController->getDetailedInformationAboutASpecificClass(
    $id,
    $studioId
);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request due to missing or invalid parameters. | [`BadRequestException`](../../doc/models/bad-request-exception.md) |
| 500 | Internal server error. | [`InternalServerErrorException`](../../doc/models/internal-server-error-exception.md) |

