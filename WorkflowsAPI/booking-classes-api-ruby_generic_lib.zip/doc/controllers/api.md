# API

```ruby
client_controller = client.client
```

## Class Name

`APIController`

## Methods

* [Get Available Classes for Booking](../../doc/controllers/api.md#get-available-classes-for-booking)
* [Book a Class or Add to Waitlist](../../doc/controllers/api.md#book-a-class-or-add-to-waitlist)
* [Get Detailed Information About a Specific Class](../../doc/controllers/api.md#get-detailed-information-about-a-specific-class)


# Get Available Classes for Booking

Retrieves a list of bookable classes along with consumer context information, including available payment methods and the ability to view waitlist entries.

```ruby
def get_available_classes_for_booking(studio_id,
                                      location_ids: nil,
                                      instructor_ids: nil,
                                      start_date: nil,
                                      end_date: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `studio_id` | `String` | Header, Required | The Studio ID to filter the classes for. |
| `location_ids` | `Array<Integer>` | Query, Optional | A list of location IDs to filter classes by location. |
| `instructor_ids` | `Array<Integer>` | Query, Optional | A list of instructor IDs to filter classes by instructor. |
| `start_date` | `Date` | Query, Optional | The start date for the class filter. Defaults to the current date. |
| `end_date` | `Date` | Query, Optional | The end date for the class filter. Defaults to one day after startDate. |

## Response Type

[`WorkflowsClassBookingsClassesResponse`](../../doc/models/workflows-class-bookings-classes-response.md)

## Example Usage

```ruby
studio_id = 'studioId2'

result = client_controller.get_available_classes_for_booking(studio_id)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request due to missing or invalid parameters. | [`BadRequestException`](../../doc/models/bad-request-exception.md) |
| 500 | Internal server error. | [`InternalServerErrorException`](../../doc/models/internal-server-error-exception.md) |


# Book a Class or Add to Waitlist

Allows a consumer to book a class directly or add to the waitlist. Also manages the spot reservation for the class.

```ruby
def book_a_class_or_add_to_waitlist(studio_id,
                                    body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `studio_id` | `String` | Header, Required | The Studio ID to filter the classes for. |
| `body` | [`Array<WorkflowsClassBookingsClassesRequest>`](../../doc/models/workflows-class-bookings-classes-request.md) | Body, Required | - |

## Response Type

[`Array<WorkflowsClassBookingsClassesResponse1>`](../../doc/models/workflows-class-bookings-classes-response-1.md)

## Example Usage

```ruby
studio_id = 'studioId2'

body = [
  WorkflowsClassBookingsClassesRequest.new
]

result = client_controller.book_a_class_or_add_to_waitlist(
  studio_id,
  body
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request due to missing or invalid parameters. | [`BadRequestException`](../../doc/models/bad-request-exception.md) |
| 500 | Internal server error. | [`InternalServerErrorException`](../../doc/models/internal-server-error-exception.md) |


# Get Detailed Information About a Specific Class

Retrieves details of a specific class, including pricing options and consumer-related context for booking.

```ruby
def get_detailed_information_about_a_specific_class(id,
                                                    studio_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Template, Required | The unique ID of the class to retrieve. |
| `studio_id` | `String` | Header, Required | The Studio ID to filter the class for. |

## Response Type

[`WorkflowsClassBookingsClassesResponse2`](../../doc/models/workflows-class-bookings-classes-response-2.md)

## Example Usage

```ruby
id = 112

studio_id = 'studioId2'

result = client_controller.get_detailed_information_about_a_specific_class(
  id,
  studio_id
)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request due to missing or invalid parameters. | [`BadRequestException`](../../doc/models/bad-request-exception.md) |
| 500 | Internal server error. | [`InternalServerErrorException`](../../doc/models/internal-server-error-exception.md) |

