
# Capacity

## Structure

`Capacity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `total_capacity` | `Integer` | Optional | - |
| `total_booked` | `Integer` | Optional | - |
| `web_capacity` | `Integer` | Optional | - |
| `web_booked` | `Integer` | Optional | - |
| `waitlist_capacity` | `Integer` | Optional | - |
| `spots` | [`Spots`](../../doc/models/spots.md) | Optional | - |

## Example (as JSON)

```json
{
  "totalCapacity": 22,
  "totalBooked": 248,
  "webCapacity": 142,
  "webBooked": 78,
  "waitlistCapacity": 232
}
```

