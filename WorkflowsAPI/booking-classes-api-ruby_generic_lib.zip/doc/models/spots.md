
# Spots

## Structure

`Spots`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reserved` | `Array<Integer>` | Optional | - |
| `available` | `Array<Integer>` | Optional | - |
| `unavailable` | `Array<Integer>` | Optional | - |
| `mine` | `Array<Integer>` | Optional | - |

## Example (as JSON)

```json
{
  "reserved": [
    125
  ],
  "available": [
    28
  ],
  "unavailable": [
    80
  ],
  "mine": [
    111
  ]
}
```

