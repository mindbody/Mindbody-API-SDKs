
# Status 1 Enum

## Enumeration

`Status1Enum`

## Fields

| Name |
|  --- |
| `ACTIVE` |
| `INACTIVE` |

