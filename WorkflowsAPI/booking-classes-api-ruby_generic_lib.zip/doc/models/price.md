
# Price

## Structure

`Price`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `unit_price` | `Float` | Optional | - |

## Example (as JSON)

```json
{
  "unitPrice": 211.36
}
```

