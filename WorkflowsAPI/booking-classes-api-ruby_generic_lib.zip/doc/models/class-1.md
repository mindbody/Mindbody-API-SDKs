
# Class 1

## Structure

`Class1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Optional | - |

## Example (as JSON)

```json
{
  "id": 60
}
```

