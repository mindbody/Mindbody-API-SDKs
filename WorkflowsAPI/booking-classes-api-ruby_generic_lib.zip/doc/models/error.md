
# Error

## Structure

`Error`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code` | `String` | Optional | - |
| `message` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "code": "code2",
  "message": "message4"
}
```

