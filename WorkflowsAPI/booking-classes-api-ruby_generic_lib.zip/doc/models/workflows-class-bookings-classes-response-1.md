
# Workflows Class Bookings Classes Response 1

## Structure

`WorkflowsClassBookingsClassesResponse1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `visit` | [`Visit`](../../doc/models/visit.md) | Optional | - |
| `booking_status` | [`BookingStatusEnum`](../../doc/models/booking-status-enum.md) | Optional | - |
| `waitlist_entry` | [`WaitlistEntry1`](../../doc/models/waitlist-entry-1.md) | Optional | - |
| `spot_reservation` | [`SpotReservation`](../../doc/models/spot-reservation.md) | Optional | - |
| `error` | [`Error`](../../doc/models/error.md) | Optional | - |

## Example (as JSON)

```json
{
  "visit": {
    "id": 54,
    "startDateTime": "2016-03-13T12:52:32.123Z",
    "endDateTime": "2016-03-13T12:52:32.123Z"
  },
  "bookingStatus": "awaiting_payment",
  "waitlistEntry": {
    "id": 176
  },
  "spotReservation": {
    "visitId": "visitId8",
    "classId": "classId0",
    "reservationType": "reservationType8",
    "status": "confirmed",
    "confirmationDate": "2016-03-13T12:52:32.123Z"
  },
  "error": {
    "code": "code2",
    "message": "message4"
  }
}
```

