
# Visit

## Structure

`Visit`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Optional | - |
| `start_date_time` | `DateTime` | Optional | - |
| `end_date_time` | `DateTime` | Optional | - |

## Example (as JSON)

```json
{
  "id": 44,
  "startDateTime": "2016-03-13T12:52:32.123Z",
  "endDateTime": "2016-03-13T12:52:32.123Z"
}
```

