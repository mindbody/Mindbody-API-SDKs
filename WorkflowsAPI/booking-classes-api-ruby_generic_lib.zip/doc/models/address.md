
# Address

## Structure

`Address`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `street` | `String` | Optional | - |
| `city` | `String` | Optional | - |
| `state` | `String` | Optional | - |
| `country` | `String` | Optional | - |
| `latitude` | `Float` | Optional | - |
| `longitude` | `Float` | Optional | - |
| `postal_code` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "street": "street8",
  "city": "city8",
  "state": "state4",
  "country": "country2",
  "latitude": 56.42
}
```

