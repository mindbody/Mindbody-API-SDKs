
# Instructor

## Structure

`Instructor`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `level` | [`LevelEnum`](../../doc/models/level-enum.md) | Optional | - |
| `display_name` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "level": "secondAssistant",
  "displayName": "displayName0"
}
```

