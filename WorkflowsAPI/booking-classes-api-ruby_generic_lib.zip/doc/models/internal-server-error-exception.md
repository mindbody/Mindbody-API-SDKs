
# Internal Server Error Exception

## Structure

`InternalServerErrorException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `code` | `String` | Optional | - |
| `message` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "code": "INTERNAL_SERVER_ERROR",
  "message": "An unexpected error occurred."
}
```

