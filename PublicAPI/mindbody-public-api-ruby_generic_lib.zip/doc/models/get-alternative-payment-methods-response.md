
# Get Alternative Payment Methods Response

Response for the GetAlternativePaymentMethods method.

## Structure

`GetAlternativePaymentMethodsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payment_methods` | [`Array<AlternativePaymentMethod>`](../../doc/models/alternative-payment-method.md) | Optional | Contains information about the alternative payment methods. |

## Example (as JSON)

```json
{
  "PaymentMethods": [
    {
      "Id": 146,
      "Name": "Name0"
    },
    {
      "Id": 146,
      "Name": "Name0"
    }
  ]
}
```

