
# Update Class Schedule Notes Request

A model for requesting the updates of notes of a class schedule.

## Structure

`UpdateClassScheduleNotesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `notes` | `String` | Optional | Gets the class notes. |

## Example (as JSON)

```json
{
  "Notes": "Notes8"
}
```

