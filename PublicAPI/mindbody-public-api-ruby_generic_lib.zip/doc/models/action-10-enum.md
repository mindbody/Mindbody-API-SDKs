
# Action 10 Enum

Indicates if rewards were earned or redeemed.

## Enumeration

`Action10Enum`

## Fields

| Name |
|  --- |
| `EARNED` |
| `REDEEMED` |
| `RETURNED` |
| `REMOVED` |
| `LATECANCELED` |

