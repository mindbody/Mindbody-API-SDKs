
# Program Membership

## Structure

`ProgramMembership`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Optional | The service category’s ID. |
| `name` | `String` | Optional | The name of this service category. |

## Example (as JSON)

```json
{
  "Id": 48,
  "Name": "Name0"
}
```

