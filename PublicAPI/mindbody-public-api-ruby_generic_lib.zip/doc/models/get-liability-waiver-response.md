
# Get Liability Waiver Response

## Structure

`GetLiabilityWaiverResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `liability_waiver` | `String` | Optional | Contains Liability Waiver text for a site |

## Example (as JSON)

```json
{
  "LiabilityWaiver": "LiabilityWaiver0"
}
```

