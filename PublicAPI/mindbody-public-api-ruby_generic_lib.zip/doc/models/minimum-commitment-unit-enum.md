
# Minimum Commitment Unit Enum

Minimum commitment unit type.

## Enumeration

`MinimumCommitmentUnitEnum`

## Fields

| Name |
|  --- |
| `WEEKS` |
| `MONTHS` |
| `YEARS` |

