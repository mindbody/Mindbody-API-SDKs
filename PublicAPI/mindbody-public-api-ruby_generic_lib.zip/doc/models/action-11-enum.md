
# Action 11 Enum

Indicates if rewards were earned or redeemed.

## Enumeration

`Action11Enum`

## Fields

| Name |
|  --- |
| `EARNED` |
| `REDEEMED` |
| `RETURNED` |
| `REMOVED` |
| `LATECANCELED` |

