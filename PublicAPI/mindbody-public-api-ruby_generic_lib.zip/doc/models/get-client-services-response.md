
# Get Client Services Response

Contains the response for the GetClientServices endpoint.

## Structure

`GetClientServicesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `client_services` | [`Array[ClientServiceWithActivationType]`](../../doc/models/client-service-with-activation-type.md) | Optional | Contains information about client pricing options, including activation behavior details.<br>Each item includes ActivationType and CannotPayForClassesBeforeActivation fields<br>to help determine booking eligibility based on the pricing option's activation configuration. |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "ClientServices": [
    {
      "ActivationType": "OnFirstVisit",
      "CannotPayForClassesBeforeActivation": false,
      "ActiveDate": "2016-03-13T12:52:32.123Z",
      "Count": 38,
      "Current": false
    }
  ]
}
```

