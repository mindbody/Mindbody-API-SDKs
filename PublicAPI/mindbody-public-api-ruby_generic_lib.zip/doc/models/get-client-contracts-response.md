
# Get Client Contracts Response

## Structure

`GetClientContractsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `contracts` | [`Array[ClientContract]`](../../doc/models/client-contract.md) | Optional | Contains the details of the client’s contract. |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "Contracts": [
    {
      "PayerClientId": 234,
      "AgreementDate": "2016-03-13T12:52:32.123Z",
      "AutopayStatus": "Active",
      "AutoRenewing": false,
      "FirstAutoPay": 14.62
    },
    {
      "PayerClientId": 234,
      "AgreementDate": "2016-03-13T12:52:32.123Z",
      "AutopayStatus": "Active",
      "AutoRenewing": false,
      "FirstAutoPay": 14.62
    },
    {
      "PayerClientId": 234,
      "AgreementDate": "2016-03-13T12:52:32.123Z",
      "AutopayStatus": "Active",
      "AutoRenewing": false,
      "FirstAutoPay": 14.62
    }
  ]
}
```

