
# Action 8 Enum

The action performed on this object.

## Enumeration

`Action8Enum`

## Fields

| Name |
|  --- |
| `NONE` |
| `ADDED` |
| `UPDATED` |
| `FAILED` |
| `REMOVED` |

