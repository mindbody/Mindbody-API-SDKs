
# Client Contract

A client contract.

## Structure

`ClientContract`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payer_client_id` | `Integer` | Optional | The ID of the client who holds the contract. |
| `agreement_date` | `DateTime` | Optional | The date on which the contract was signed. |
| `autopay_status` | [`AutopayStatusEnum`](../../doc/models/autopay-status-enum.md) | Optional | The status of the client’s autopay. |
| `auto_renewing` | `TrueClass \| FalseClass` | Optional | Determines if the contract is auto-renewing. |
| `first_auto_pay` | `Float` | Optional | The amount of the first autopay transaction. |
| `last_auto_pay` | `Float` | Optional | The amount of the last autopay transaction. |
| `normal_auto_pay` | `Float` | Optional | The amount of the normal recurring autopay transaction. |
| `is_month_to_month` | `TrueClass \| FalseClass` | Optional | Indicates if the contract renews on a month-to-month basis. |
| `auto_renew_client_contract_id` | `Integer` | Optional | The ID of the contract that this one auto-renews from. |
| `contract_text` | `String` | Optional | The full text of the contract. |
| `contract_auto_renewed` | `TrueClass \| FalseClass` | Optional | Indicates whether the contract was auto-renewed from a previous one. |
| `contract_name` | `String` | Optional | The name of the contract. |
| `end_date` | `DateTime` | Optional | The date that the contract expires. |
| `id` | `Integer` | Optional | The unique ID of the sale of the contract. Each time a contract is sold, this ID increases sequentially. |
| `origination_location_id` | `Integer` | Optional | The ID of the location where the contract was issued. |
| `start_date` | `DateTime` | Optional | The date that the contract became active. |
| `site_id` | `Integer` | Optional | The ID of the site where the contract was issued. |
| `upcoming_autopay_events` | [`Array[UpcomingAutopayEvent]`](../../doc/models/upcoming-autopay-event.md) | Optional | Contains details of the autopay events. |
| `contract_id` | `Integer` | Optional | The ID of the contract. |
| `termination_date` | `DateTime` | Optional | The date that the contract was terminated. |
| `minimum_commitment_value` | `Integer` | Optional | Minimum commitment value. |
| `minimum_commitment_unit` | [`MinimumCommitmentUnitEnum`](../../doc/models/minimum-commitment-unit-enum.md) | Optional | Minimum commitment unit type. |
| `minimum_commitment_end_date` | `DateTime` | Optional | The earliest date a contract termination can take effect if a minimum commitment applies.<br>This represents the last day the client is obligated to remain on the contract.<br>Returned even if the commitment has already been fulfilled. |

## Example (as JSON)

```json
{
  "PayerClientId": 182,
  "AgreementDate": "2016-03-13T12:52:32.123Z",
  "AutopayStatus": "Suspended",
  "AutoRenewing": false,
  "FirstAutoPay": 152.34
}
```

