
# Size

## Structure

`Size`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Optional | The unique ID of the product size. |
| `name` | `String` | Optional | The name of the size of product. |

## Example (as JSON)

```json
{
  "Id": 112,
  "Name": "Name8"
}
```

