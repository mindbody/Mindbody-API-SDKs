
# Appointment Staff

## Structure

`AppointmentStaff`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Optional | - |
| `first_name` | `String` | Optional | - |
| `last_name` | `String` | Optional | - |
| `display_name` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "Id": 130,
  "FirstName": "FirstName2",
  "LastName": "LastName2",
  "DisplayName": "DisplayName4"
}
```

