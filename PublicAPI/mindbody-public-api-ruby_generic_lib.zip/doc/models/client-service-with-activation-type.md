
# Client Service With Activation Type

Represents a pricing option (service) on a client's account, including activation behavior details.
This model extends ClientService to include additional fields that describe
how and when the pricing option becomes active for use.

For more information about pricing option activation, see the following support articles:

- [How to change a pricing option activation date set to begin on the client's first visit](https://support.mindbodyonline.com/s/article/203268693-How-do-I-adjust-a-pricing-option-that-activates-on-the-date-of-client-s-first-visit-to-cover-a-visit-before-its-activation-date)
- [How to set offset activation dates for contracts](https://support.mindbodyonline.com/s/article/Offset-Activation)
- [How do I expire or terminate an unused pricing option that activates on the date of the first visit](https://support.mindbodyonline.com/s/article/How-do-I-expire-terminate-an-unused-pricing-option-that-activates-on-date-of-first-visit)
- [Pricing option activation date options](https://support.mindbodyonline.com/s/article/203257593-What-are-the-differences-between-the-different-pricing-option-activation-dates)

## Structure

`ClientServiceWithActivationType`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `activation_type` | [`ActivationTypeEnum`](../../doc/models/activation-type-enum.md) | Optional | Specifies how this pricing option is configured to activate.<br>This value reflects the activation behavior defined in the Core system when the pricing option was created.<br>Use this field to determine whether the ActiveDate represents the purchase date<br>or a future date pending the client's first visit.<br>Possible values:<br><br>- OnFirstVisit: The pricing option activates on the client's first visit (check-in) after purchase.<br>  The ActiveDate is set to the date of that first visit.<br>  Until the client checks in, the ActiveDate may be null or set to a future/placeholder date.<br>- OnPurchase: The pricing option activates immediately upon purchase.<br>  The ActiveDate is set to the purchase date. |
| `cannot_pay_for_classes_before_activation` | `TrueClass \| FalseClass` | Optional | Indicates whether the site enforces activation date restrictions for booking.<br>This value reflects the site-level setting "EnforceActivationDates" (also known as "Check Activation Dates")<br>for the subscriber identified by SiteId.<br>When integrating with booking workflows, use this field in conjunction with ActivationType<br>to determine if a pricing option can be applied for a booking:<br><br>- true: The site enforces activation dates. The client cannot use this pricing option to pay for<br>  classes or appointments scheduled before the ActiveDate.<br>- false: The site allows booking before activation. The client can use this pricing option to pay for<br>  classes or appointments scheduled before the ActiveDate.<br>  This is commonly used with "Activate on First Visit" pricing options to allow immediate booking. |
| `active_date` | `DateTime` | Optional | The date that this pricing option became active and could be used to pay for services. |
| `count` | `Integer` | Optional | The number of service sessions this pricing option contained when first purchased. |
| `current` | `TrueClass \| FalseClass` | Optional | When `true`, there are service sessions remaining on the pricing option that can be used pay for the current session.<br /><br>When `false`, the client cannot use this pricing option to pay for other services. |
| `expiration_date` | `DateTime` | Optional | The date when the pricing option expires and can no longer be used to pay for services, even if unused service sessions remain on the option; expressed as UTC. |
| `id` | `Integer` | Optional | The unique ID assigned to this pricing option, specific to when it was purchased by the client. |
| `product_id` | `Integer` | Optional | The unique ID of this pricing option, not specific to any client's purchase of it. |
| `name` | `String` | Optional | The name of this pricing option. |
| `payment_date` | `DateTime` | Optional | The date on which the client paid for this pricing option. |
| `program` | [`Program`](../../doc/models/program.md) | Optional | Contains information about the service category this service falls under. |
| `remaining` | `Integer` | Optional | The number of service sessions remaining in the pricing option that can still be used. |
| `site_id` | `Integer` | Optional | The ID of the subscriber site associated with this pricing option. |
| `action` | [`Action1Enum`](../../doc/models/action-1-enum.md) | Optional | The action taken. |
| `client_id` | `String` | Optional | The Client ID assigned to this pricing option, specific to when it was purchased by the client. |
| `returned` | `TrueClass \| FalseClass` | Optional | Identification for purchased service is returned or not. |

## Example (as JSON)

```json
{
  "ActivationType": "OnFirstVisit",
  "CannotPayForClassesBeforeActivation": false,
  "ActiveDate": "2016-03-13T12:52:32.123Z",
  "Count": 210,
  "Current": false
}
```

