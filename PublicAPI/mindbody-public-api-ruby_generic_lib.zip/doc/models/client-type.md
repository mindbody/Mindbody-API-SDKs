
# Client Type

Represents a client's type classification.

## Structure

`ClientType`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Optional | The unique identifier for the client type. |
| `name` | `String` | Optional | The display name of the client type. |

## Example (as JSON)

```json
{
  "Id": 78,
  "Name": "Name2"
}
```

