
# Type 2 Enum

Contains the class description session type.

## Enumeration

`Type2Enum`

## Fields

| Name |
|  --- |
| `ALL` |
| `CLASS` |
| `ENROLLMENT` |
| `APPOINTMENT` |
| `RESOURCE` |
| `MEDIA` |
| `ARRIVAL` |

