
# Discount

Discount for a promo code

## Structure

`Discount`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | `String` | Optional | Type of discount percentage/amount |
| `amount` | `Float` | Optional | Amount of discount |

## Example (as JSON)

```json
{
  "Type": "Type6",
  "Amount": 80.68
}
```

