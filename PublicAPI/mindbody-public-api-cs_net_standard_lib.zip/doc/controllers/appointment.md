# Appointment

```csharp
AppointmentController appointmentController = client.AppointmentController;
```

## Class Name

`AppointmentController`

## Methods

* [Get Active Session Times](../../doc/controllers/appointment.md#get-active-session-times)
* [Get Add Ons](../../doc/controllers/appointment.md#get-add-ons)
* [Get Appointment Options](../../doc/controllers/appointment.md#get-appointment-options)
* [Get Available Dates](../../doc/controllers/appointment.md#get-available-dates)
* [Get Bookable Items](../../doc/controllers/appointment.md#get-bookable-items)
* [Get Schedule Items](../../doc/controllers/appointment.md#get-schedule-items)
* [Get Staff Appointments](../../doc/controllers/appointment.md#get-staff-appointments)
* [Get Unavailabilities](../../doc/controllers/appointment.md#get-unavailabilities)
* [Add Appointment](../../doc/controllers/appointment.md#add-appointment)
* [Add Appointment Add On](../../doc/controllers/appointment.md#add-appointment-add-on)
* [Add Multiple Appointments](../../doc/controllers/appointment.md#add-multiple-appointments)
* [Update Availability](../../doc/controllers/appointment.md#update-availability)
* [Add Availabilities](../../doc/controllers/appointment.md#add-availabilities)
* [Update Appointment](../../doc/controllers/appointment.md#update-appointment)
* [Remove From Waitlist](../../doc/controllers/appointment.md#remove-from-waitlist)
* [Delete Availability](../../doc/controllers/appointment.md#delete-availability)
* [Delete Appointment Add On](../../doc/controllers/appointment.md#delete-appointment-add-on)


# Get Active Session Times

This is not appointment availability but rather the active business hours for studios and which increments services can be booked at. See BookableItems for appointment availability.

```csharp
GetActiveSessionTimesAsync(
    string version,
    string siteId,
    string authorization = null,
    DateTime? requestEndTime = null,
    int? requestLimit = null,
    int? requestOffset = null,
    Models.RequestScheduleTypeEnum? requestScheduleType = null,
    List<int> requestSessionTypeIds = null,
    DateTime? requestStartTime = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestEndTime` | `DateTime?` | Query, Optional | Filters results to times that end on or before this time on the current date. Any date provided is ignored..<br><br />Default: **23:59:59** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestScheduleType` | [`RequestScheduleTypeEnum?`](../../doc/models/request-schedule-type-enum.md) | Query, Optional | Filters on the provided the schedule type. Either `SessionTypeIds` or `ScheduleType` must be provided. |
| `requestSessionTypeIds` | `List<int>` | Query, Optional | Filters on the provided session type IDs. Either `SessionTypeIds` or `ScheduleType` must be provided. |
| `requestStartTime` | `DateTime?` | Query, Optional | Filters results to times that start on or after this time on the current date. Any date provided is ignored.<br><br />Default: **00:00:00** |

## Response Type

[`Task<Models.GetActiveSessionTimesResponse>`](../../doc/models/get-active-session-times-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
DateTime? requestEndTime = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
int? requestLimit = 62;
int? requestOffset = 100;
RequestScheduleTypeEnum? requestScheduleType = RequestScheduleTypeEnum.Resource;
List<int> requestSessionTypeIds = new List<int>
{
    228,
    229,
};

DateTime? requestStartTime = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
try
{
    GetActiveSessionTimesResponse result = await appointmentController.GetActiveSessionTimesAsync(
        version,
        siteId,
        authorization,
        requestEndTime,
        requestLimit,
        requestOffset,
        requestScheduleType,
        requestSessionTypeIds,
        requestStartTime
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Add Ons

Get active appointment add-ons.

```csharp
GetAddOnsAsync(
    string version,
    string siteId,
    string authorization = null,
    int? requestLimit = null,
    int? requestOffset = null,
    int? requestStaffId = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestStaffId` | `int?` | Query, Optional | Filter to add-ons only performed by this staff member. |

## Response Type

[`Task<Models.GetAddOnsResponse>`](../../doc/models/get-add-ons-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
int? requestLimit = 62;
int? requestOffset = 100;
int? requestStaffId = 180;
try
{
    GetAddOnsResponse result = await appointmentController.GetAddOnsAsync(
        version,
        siteId,
        authorization,
        requestLimit,
        requestOffset,
        requestStaffId
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Appointment Options

This endpoint has no query parameters.

```csharp
GetAppointmentOptionsAsync(
    string version,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.GetAppointmentOptionsResponse>`](../../doc/models/get-appointment-options-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
try
{
    GetAppointmentOptionsResponse result = await appointmentController.GetAppointmentOptionsAsync(
        version,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Available Dates

Returns a list of dates to narrow down staff availability when booking. Dates are those which staff are scheduled to work and do not guarantee booking availabilities. After this call is made, use GET BookableItems to retrieve availabilities for specific dates before booking.

```csharp
GetAvailableDatesAsync(
    string version,
    int requestSessionTypeId,
    string siteId,
    string authorization = null,
    DateTime? requestEndDate = null,
    int? requestLocationId = null,
    long? requestStaffId = null,
    DateTime? requestStartDate = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestSessionTypeId` | `int` | Query, Required | required requested session type ID. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestEndDate` | `DateTime?` | Query, Optional | The end date of the requested date range.<br><br />Default: **StartDate** |
| `requestLocationId` | `int?` | Query, Optional | optional requested location ID. |
| `requestStaffId` | `long?` | Query, Optional | optional requested staff ID. |
| `requestStartDate` | `DateTime?` | Query, Optional | The start date of the requested date range. If omitted, the default is used.<br><br />Default: **today’s date** |

## Response Type

[`Task<Models.GetAvailableDatesResponse>`](../../doc/models/get-available-dates-response.md)

## Example Usage

```csharp
string version = "6";
int requestSessionTypeId = 100;
string siteId = "-99";
string authorization = "authorization6";
DateTime? requestEndDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
int? requestLocationId = 90;
long? requestStaffId = 180L;
DateTime? requestStartDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
try
{
    GetAvailableDatesResponse result = await appointmentController.GetAvailableDatesAsync(
        version,
        requestSessionTypeId,
        siteId,
        authorization,
        requestEndDate,
        requestLocationId,
        requestStaffId,
        requestStartDate
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Bookable Items

Returns a list of availabilities with the information needed to book appointments. Availabilities include information such as the location and its amenities, staff members, programs, and session types. Recommended to use with GET AvailableDates to see what dates the staff is scheduled to work and narrow down the dates searched. Recommended to use with GET ActiveSessionTimes to see which increments each business allows for booking appointments.
Notes:

- With a wider range of dates, this call may take longer to return results.
- With a higher number of request.sessionTypeIds, this call may take longer to return results.

```csharp
GetBookableItemsAsync(
    string version,
    List<int> requestSessionTypeIds,
    string siteId,
    string authorization = null,
    long? requestAppointmentId = null,
    DateTime? requestEndDate = null,
    bool? requestIgnoreDefaultSessionLength = null,
    int? requestLimit = null,
    List<int> requestLocationIds = null,
    int? requestOffset = null,
    List<long> requestStaffIds = null,
    DateTime? requestStartDate = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestSessionTypeIds` | `List<int>` | Query, Required | A list of the requested session type IDs. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestAppointmentId` | `long?` | Query, Optional | If provided, filters out the appointment with this ID. |
| `requestEndDate` | `DateTime?` | Query, Optional | The end date of the requested date range.<br><br />Default: **StartDate** |
| `requestIgnoreDefaultSessionLength` | `bool?` | Query, Optional | When `true`, availabilities that are non-default return, for example, a 30-minute availability with a 60-minute default session length.<br /><br>When `false`, only availabilities that have the default session length return. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationIds` | `List<int>` | Query, Optional | A list of the requested location IDs. |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestStaffIds` | `List<long>` | Query, Optional | A list of the requested staff IDs. Omit parameter to return all staff availabilities. |
| `requestStartDate` | `DateTime?` | Query, Optional | The start date of the requested date range.<br><br />Default: **today’s date** |

## Response Type

[`Task<Models.GetBookableItemsResponse>`](../../doc/models/get-bookable-items-response.md)

## Example Usage

```csharp
string version = "6";
List<int> requestSessionTypeIds = new List<int>
{
    228,
    229,
};

string siteId = "-99";
string authorization = "authorization6";
long? requestAppointmentId = 194L;
DateTime? requestEndDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
bool? requestIgnoreDefaultSessionLength = false;
int? requestLimit = 62;
List<int> requestLocationIds = new List<int>
{
    192,
};

int? requestOffset = 100;
List<long> requestStaffIds = new List<long>
{
    23L,
    24L,
    25L,
};

DateTime? requestStartDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
try
{
    GetBookableItemsResponse result = await appointmentController.GetBookableItemsAsync(
        version,
        requestSessionTypeIds,
        siteId,
        authorization,
        requestAppointmentId,
        requestEndDate,
        requestIgnoreDefaultSessionLength,
        requestLimit,
        requestLocationIds,
        requestOffset,
        requestStaffIds,
        requestStartDate
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Schedule Items

Returns a list of schedule items, including appointments, availabilities, and unavailabilities. Unavailabilities are the times at which appointments cannot be booked, for example, on holidays or after hours when the business is closed.

```csharp
GetScheduleItemsAsync(
    string version,
    string siteId,
    string authorization = null,
    DateTime? requestEndDate = null,
    bool? requestIgnorePrepFinishTimes = null,
    int? requestLimit = null,
    List<int> requestLocationIds = null,
    int? requestOffset = null,
    List<long> requestStaffIds = null,
    DateTime? requestStartDate = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestEndDate` | `DateTime?` | Query, Optional | The end date of the requested date range.<br><br />Default: **today’s date** |
| `requestIgnorePrepFinishTimes` | `bool?` | Query, Optional | When `true`, appointment preparation and finish unavailabilities are not returned.<br><br />Default: **false** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationIds` | `List<int>` | Query, Optional | A list of requested location IDs. |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestStaffIds` | `List<long>` | Query, Optional | A list of requested staff IDs. |
| `requestStartDate` | `DateTime?` | Query, Optional | The start date of the requested date range.<br><br />Default: **today’s date** |

## Response Type

[`Task<Models.GetScheduleItemsResponse>`](../../doc/models/get-schedule-items-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
DateTime? requestEndDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
bool? requestIgnorePrepFinishTimes = false;
int? requestLimit = 62;
List<int> requestLocationIds = new List<int>
{
    192,
};

int? requestOffset = 100;
List<long> requestStaffIds = new List<long>
{
    23L,
    24L,
    25L,
};

DateTime? requestStartDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
try
{
    GetScheduleItemsResponse result = await appointmentController.GetScheduleItemsAsync(
        version,
        siteId,
        authorization,
        requestEndDate,
        requestIgnorePrepFinishTimes,
        requestLimit,
        requestLocationIds,
        requestOffset,
        requestStaffIds,
        requestStartDate
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Staff Appointments

Returns a list of appointments by staff member.

```csharp
GetStaffAppointmentsAsync(
    string version,
    string siteId,
    string authorization = null,
    List<int> requestAppointmentIds = null,
    string requestClientId = null,
    DateTime? requestEndDate = null,
    int? requestLimit = null,
    List<int> requestLocationIds = null,
    int? requestOffset = null,
    List<long> requestStaffIds = null,
    DateTime? requestStartDate = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestAppointmentIds` | `List<int>` | Query, Optional | A list of the requested appointment IDs. |
| `requestClientId` | `string` | Query, Optional | The client ID to be returned. |
| `requestEndDate` | `DateTime?` | Query, Optional | The end date of the requested date range.<br><br />Default: **StartDate** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationIds` | `List<int>` | Query, Optional | A list of the requested location IDs. |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestStaffIds` | `List<long>` | Query, Optional | List of staff IDs to be returned. Omit parameter to return staff appointments for all staff. |
| `requestStartDate` | `DateTime?` | Query, Optional | The start date of the requested date range. If omitted, the default is used.<br><br />Default: **today’s date** |

## Response Type

[`Task<Models.GetStaffAppointmentsResponse>`](../../doc/models/get-staff-appointments-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
List<int> requestAppointmentIds = new List<int>
{
    17,
    18,
};

string requestClientId = "request.clientId2";
DateTime? requestEndDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
int? requestLimit = 62;
List<int> requestLocationIds = new List<int>
{
    192,
};

int? requestOffset = 100;
List<long> requestStaffIds = new List<long>
{
    23L,
    24L,
    25L,
};

DateTime? requestStartDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
try
{
    GetStaffAppointmentsResponse result = await appointmentController.GetStaffAppointmentsAsync(
        version,
        siteId,
        authorization,
        requestAppointmentIds,
        requestClientId,
        requestEndDate,
        requestLimit,
        requestLocationIds,
        requestOffset,
        requestStaffIds,
        requestStartDate
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Unavailabilities

Returns a list of unavailabilities. Unavailabilities are the times at which appointments cannot be booked, for example, on holidays or after hours when the business is closed.

```csharp
GetUnavailabilitiesAsync(
    string version,
    string siteId,
    string authorization = null,
    DateTime? requestEndDate = null,
    int? requestLimit = null,
    int? requestOffset = null,
    List<long> requestStaffIds = null,
    DateTime? requestStartDate = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestEndDate` | `DateTime?` | Query, Optional | The end date of the requested date range.<br><br />Default: **today’s date** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestStaffIds` | `List<long>` | Query, Optional | A list of requested staff IDs. |
| `requestStartDate` | `DateTime?` | Query, Optional | The start date of the requested date range.<br><br />Default: **today’s date** |

## Response Type

[`Task<Models.GetUnavailabilitiesResponse>`](../../doc/models/get-unavailabilities-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
DateTime? requestEndDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
int? requestLimit = 62;
int? requestOffset = 100;
List<long> requestStaffIds = new List<long>
{
    23L,
    24L,
    25L,
};

DateTime? requestStartDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
try
{
    GetUnavailabilitiesResponse result = await appointmentController.GetUnavailabilitiesAsync(
        version,
        siteId,
        authorization,
        requestEndDate,
        requestLimit,
        requestOffset,
        requestStaffIds,
        requestStartDate
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Add Appointment

A user token is required for this endpoint. To book an appointment, you must use a location ID, staff ID, client ID, session type ID, and the StartDateTime of the appointment. You can get most of this information using GET BookableItems.

```csharp
AddAppointmentAsync(
    string version,
    Models.AddAppointmentRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`AddAppointmentRequest`](../../doc/models/add-appointment-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.AddAppointmentResponse>`](../../doc/models/add-appointment-response.md)

## Example Usage

```csharp
string version = "6";
AddAppointmentRequest request = new AddAppointmentRequest
{
    ClientId = "ClientId0",
    LocationId = 238,
    SessionTypeId = 82,
    StaffId = 188L,
    StartDateTime = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind),
    ApplyPayment = false,
    Duration = 224,
    Execute = "Execute2",
    EndDateTime = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind),
    GenderPreference = "GenderPreference6",
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    AddAppointmentResponse result = await appointmentController.AddAppointmentAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Add Appointment Add On

This endpoint books an add-on on top of an existing, regular appointment. To book an add-on, you must use an existing appointment ID and session type ID. You can get a session type ID using `GET AppointmentAddOns`.

```csharp
AddAppointmentAddOnAsync(
    string version,
    Models.AddAppointmentAddOnRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`AddAppointmentAddOnRequest`](../../doc/models/add-appointment-add-on-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.AddAppointmentAddOnResponse>`](../../doc/models/add-appointment-add-on-response.md)

## Example Usage

```csharp
string version = "6";
AddAppointmentAddOnRequest request = new AddAppointmentAddOnRequest
{
    ApplyPayment = false,
    AppointmentId = 246L,
    SessionTypeId = 82,
    StaffId = 188L,
    Test = false,
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    AddAppointmentAddOnResponse result = await appointmentController.AddAppointmentAddOnAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Add Multiple Appointments

A user token is required for this endpoint. To book appointments, you must provide a location ID, staff ID, client ID, session type ID, and the StartDateTime for each appointment.
You can retrieve most of this information using the GET BookableItems endpoint.
This endpoint will handle errors that occur during the appointment creation process and return a list of errors, as well as the request object that generated each outcome.
You can pass the AddAppointmentRequestId for each request, or it will be automatically filled. This is intended to facilitate matching each request with the corresponding outcome.

```csharp
AddMultipleAppointmentsAsync(
    string version,
    Models.AddMultipleAppointmentsRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`AddMultipleAppointmentsRequest`](../../doc/models/add-multiple-appointments-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.AddMultipleAppointmentsResponse>`](../../doc/models/add-multiple-appointments-response.md)

## Example Usage

```csharp
string version = "6";
AddMultipleAppointmentsRequest request = new AddMultipleAppointmentsRequest
{
    AddAppointmentRequests = new List<AddAppointmentRequest>
    {
        new AddAppointmentRequest
        {
            ClientId = "ClientId4",
            LocationId = 102,
            SessionTypeId = 202,
            StaffId = 52L,
            StartDateTime = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
                provider: CultureInfo.InvariantCulture,
                DateTimeStyles.RoundtripKind),
            ApplyPayment = false,
            Duration = 88,
            Execute = "Execute6",
            EndDateTime = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
                provider: CultureInfo.InvariantCulture,
                DateTimeStyles.RoundtripKind),
            GenderPreference = "GenderPreference0",
        },
        new AddAppointmentRequest
        {
            ClientId = "ClientId4",
            LocationId = 102,
            SessionTypeId = 202,
            StaffId = 52L,
            StartDateTime = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
                provider: CultureInfo.InvariantCulture,
                DateTimeStyles.RoundtripKind),
            ApplyPayment = false,
            Duration = 88,
            Execute = "Execute6",
            EndDateTime = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
                provider: CultureInfo.InvariantCulture,
                DateTimeStyles.RoundtripKind),
            GenderPreference = "GenderPreference0",
        },
    },
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    AddMultipleAppointmentsResponse result = await appointmentController.AddMultipleAppointmentsAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Update Availability

To update the information for a specific availability or unavailability of the staff.<br />
Note: You must have a staff user token with the required permissions.

```csharp
UpdateAvailabilityAsync(
    string version,
    string siteId,
    Models.UpdateAvailabilityRequest updateAvailabilityRequest,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `updateAvailabilityRequest` | [`UpdateAvailabilityRequest`](../../doc/models/update-availability-request.md) | Body, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.UpdateAvailabilityResponse>`](../../doc/models/update-availability-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
UpdateAvailabilityRequest updateAvailabilityRequest = new UpdateAvailabilityRequest
{
    AvailabilityIds = new List<int>
    {
        12,
        13,
    },
    PublicDisplay = PublicDisplayEnum.Hide,
    DaysOfWeek = new List<DaysOfWeekEnum>
    {
        DaysOfWeekEnum.Sunday,
        DaysOfWeekEnum.Monday,
    },
    ProgramIds = new List<int>
    {
        40,
        41,
    },
    StartDateTime = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind),
};

string authorization = "authorization6";
try
{
    UpdateAvailabilityResponse result = await appointmentController.UpdateAvailabilityAsync(
        version,
        siteId,
        updateAvailabilityRequest,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Add Availabilities

Add availabilities and unavailabilities for a staff member.<br />
Note: You must have a staff user token with the required permissions.

```csharp
AddAvailabilitiesAsync(
    string version,
    Models.AddAvailabilitiesRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`AddAvailabilitiesRequest`](../../doc/models/add-availabilities-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.AddAvailabilitiesResponse>`](../../doc/models/add-availabilities-response.md)

## Example Usage

```csharp
string version = "6";
AddAvailabilitiesRequest request = new AddAvailabilitiesRequest
{
    Test = false,
    LocationID = 38,
    StaffIDs = new List<long>
    {
        125L,
        126L,
    },
    ProgramIDs = new List<int>
    {
        144,
        145,
        146,
    },
    StartDateTime = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind),
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    AddAvailabilitiesResponse result = await appointmentController.AddAvailabilitiesAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Update Appointment

To update the information for a specific appointment, you must have a staff user token with the proper permissions. Note that you can only update the appointment’s `StartDateTime`, `EndDateTime`, `StaffId`, `Notes`, and `SessionTypeId`.

```csharp
UpdateAppointmentAsync(
    string version,
    Models.UpdateAppointmentRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`UpdateAppointmentRequest`](../../doc/models/update-appointment-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.UpdateAppointmentResponse>`](../../doc/models/update-appointment-response.md)

## Example Usage

```csharp
string version = "6";
UpdateAppointmentRequest request = new UpdateAppointmentRequest
{
    AppointmentId = 246L,
    EndDateTime = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind),
    Execute = "Execute2",
    GenderPreference = "GenderPreference6",
    Notes = "Notes8",
    PartnerExternalId = "PartnerExternalId0",
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    UpdateAppointmentResponse result = await appointmentController.UpdateAppointmentAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Remove From Waitlist

Remove an appointment from waitlist

```csharp
RemoveFromWaitlistAsync(
    string version,
    List<int> requestWaitlistEntryIds,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestWaitlistEntryIds` | `List<int>` | Query, Required | A list of `WaitlistEntryIds` to remove from the waiting list. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`Task`

## Example Usage

```csharp
string version = "6";
List<int> requestWaitlistEntryIds = new List<int>
{
    138,
    139,
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    await appointmentController.RemoveFromWaitlistAsync(
        version,
        requestWaitlistEntryIds,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Delete Availability

This endpoint deletes the availability or unavailability.
Note: You must have a staff user token with the required permissions.

```csharp
DeleteAvailabilityAsync(
    string version,
    string siteId,
    string authorization = null,
    int? deleteAvailabilityRequestAvailabilityId = null,
    bool? deleteAvailabilityRequestTest = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `deleteAvailabilityRequestAvailabilityId` | `int?` | Query, Optional | The ID of the availability or unavailability. |
| `deleteAvailabilityRequestTest` | `bool?` | Query, Optional | When `true`, indicates that this is a test request and no data is deleted from the subscriber’s database.<br>When `false`, the record will be deleted.<br>Default: **false** |

## Response Type

`Task`

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
int? deleteAvailabilityRequestAvailabilityId = 186;
bool? deleteAvailabilityRequestTest = false;
try
{
    await appointmentController.DeleteAvailabilityAsync(
        version,
        siteId,
        authorization,
        deleteAvailabilityRequestAvailabilityId,
        deleteAvailabilityRequestTest
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Delete Appointment Add On

This endpoint can be used to early-cancel a booked appointment add-on.

```csharp
DeleteAppointmentAddOnAsync(
    string version,
    long id,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `id` | `long` | Query, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`Task`

## Example Usage

```csharp
string version = "6";
long id = 112L;
string siteId = "-99";
string authorization = "authorization6";
try
{
    await appointmentController.DeleteAppointmentAddOnAsync(
        version,
        id,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

