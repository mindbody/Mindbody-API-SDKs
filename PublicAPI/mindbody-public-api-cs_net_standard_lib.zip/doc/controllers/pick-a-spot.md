# Pick a Spot

```csharp
PickASpotController pickASpotController = client.PickASpotController;
```

## Class Name

`PickASpotController`

## Methods

* [Get Class List](../../doc/controllers/pick-a-spot.md#get-class-list)
* [Get Class](../../doc/controllers/pick-a-spot.md#get-class)
* [Get Reservation](../../doc/controllers/pick-a-spot.md#get-reservation)
* [Update Reservation](../../doc/controllers/pick-a-spot.md#update-reservation)
* [Create Reservation](../../doc/controllers/pick-a-spot.md#create-reservation)
* [Delete Reservation](../../doc/controllers/pick-a-spot.md#delete-reservation)


# Get Class List

This endpoint supports pagination. See Pagination object for a description.

```csharp
GetClassListAsync(
    string version,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.GetPickASpotClassResponse>`](../../doc/models/get-pick-a-spot-class-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
try
{
    GetPickASpotClassResponse result = await pickASpotController.GetClassListAsync(
        version,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Class

Get a class filtered by classId.

```csharp
GetClassAsync(
    string version,
    string classId,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `classId` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.GetPickASpotClassResponse>`](../../doc/models/get-pick-a-spot-class-response.md)

## Example Usage

```csharp
string version = "6";
string classId = "classId0";
string siteId = "-99";
string authorization = "authorization6";
try
{
    GetPickASpotClassResponse result = await pickASpotController.GetClassAsync(
        version,
        classId,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Reservation

Retrieves reservation for Pick a Spot.

```csharp
GetReservationAsync(
    string version,
    string pathInfo,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `pathInfo` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.GetReservationResponse>`](../../doc/models/get-reservation-response.md)

## Example Usage

```csharp
string version = "6";
string pathInfo = "pathInfo8";
string siteId = "-99";
string authorization = "authorization6";
try
{
    GetReservationResponse result = await pickASpotController.GetReservationAsync(
        version,
        pathInfo,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Update Reservation

A user token is required for this endpoint.
This endpoint updates a single reservation.

```csharp
UpdateReservationAsync(
    string version,
    string pathInfo,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `pathInfo` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.UpdateReservationResponse>`](../../doc/models/update-reservation-response.md)

## Example Usage

```csharp
string version = "6";
string pathInfo = "pathInfo8";
string siteId = "-99";
string authorization = "authorization6";
try
{
    UpdateReservationResponse result = await pickASpotController.UpdateReservationAsync(
        version,
        pathInfo,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Create Reservation

Creates a spot reservation for a given pick-a-spot class. The actual class visit must be created prior to calling this endpoint.
A user token is required for this endpoint.

Sample request:

    POST /pickaspot/v1/reservation
    {
        "SiteId": -1147483363,
        "LocationId": 1,
        "ClassId": "64b14ac8c20ae8f0afd2d409",
        "ReservationExternalId": "44724", // this is a Visit.Id and should be linked to a specific class visit
        "MemberExternalId": "100000136", // this is Client's UniqueId
        "SpotNumber": "5",
        "ReservationDisplayName": "ReservationDisplayName", // optional
        "ReservationType": "Member", // optional. Can be Member, Guest, Instructor, FamilyMember,
        "AutoConfirm": false, // optional. Default: false
        "AutoAssignSpot": false // optional. It will override the "SpotNumber" passed and auto assign one. Default: false
    }

```csharp
CreateReservationAsync(
    string version,
    string pathInfo,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `pathInfo` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.CreateReservationResponse>`](../../doc/models/create-reservation-response.md)

## Example Usage

```csharp
string version = "6";
string pathInfo = "pathInfo8";
string siteId = "-99";
string authorization = "authorization6";
try
{
    CreateReservationResponse result = await pickASpotController.CreateReservationAsync(
        version,
        pathInfo,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Delete Reservation

A user token is required for this endpoint.
This endpoint deletes a single reservation.

```csharp
DeleteReservationAsync(
    string version,
    string pathInfo,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `pathInfo` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.HttpContent>`](../../doc/models/http-content.md)

## Example Usage

```csharp
string version = "6";
string pathInfo = "pathInfo8";
string siteId = "-99";
string authorization = "authorization6";
try
{
    HttpContent result = await pickASpotController.DeleteReservationAsync(
        version,
        pathInfo,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

