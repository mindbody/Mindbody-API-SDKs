# Client

```csharp
ClientController clientController = client.ClientController;
```

## Class Name

`ClientController`

## Methods

* [Get Active Client Memberships](../../doc/controllers/client.md#get-active-client-memberships)
* [Get Active Clients Memberships](../../doc/controllers/client.md#get-active-clients-memberships)
* [Get Client Account Balances](../../doc/controllers/client.md#get-client-account-balances)
* [Get Client Complete Info](../../doc/controllers/client.md#get-client-complete-info)
* [Get Client Contracts](../../doc/controllers/client.md#get-client-contracts)
* [Get Direct Debit Info](../../doc/controllers/client.md#get-direct-debit-info)
* [Delete Direct Debit Info](../../doc/controllers/client.md#delete-direct-debit-info)
* [Get Client Duplicates](../../doc/controllers/client.md#get-client-duplicates)
* [Get Client Formula Notes](../../doc/controllers/client.md#get-client-formula-notes)
* [Get Client Indexes](../../doc/controllers/client.md#get-client-indexes)
* [Get Client Purchases](../../doc/controllers/client.md#get-client-purchases)
* [Get Client Referral Types](../../doc/controllers/client.md#get-client-referral-types)
* [Get Client Rewards](../../doc/controllers/client.md#get-client-rewards)
* [Update Client Rewards](../../doc/controllers/client.md#update-client-rewards)
* [Get Clients](../../doc/controllers/client.md#get-clients)
* [Get Client Schedule](../../doc/controllers/client.md#get-client-schedule)
* [Get Client Services](../../doc/controllers/client.md#get-client-services)
* [Get Client Visits](../../doc/controllers/client.md#get-client-visits)
* [Get Contact Logs](../../doc/controllers/client.md#get-contact-logs)
* [Get Contact Log Types](../../doc/controllers/client.md#get-contact-log-types)
* [Get Cross Regional Client Associations](../../doc/controllers/client.md#get-cross-regional-client-associations)
* [Get Custom Client Fields](../../doc/controllers/client.md#get-custom-client-fields)
* [Get Required Client Fields](../../doc/controllers/client.md#get-required-client-fields)
* [Add Arrival](../../doc/controllers/client.md#add-arrival)
* [Add Client](../../doc/controllers/client.md#add-client)
* [Add Client Direct Debit Info](../../doc/controllers/client.md#add-client-direct-debit-info)
* [Add Formula Note](../../doc/controllers/client.md#add-formula-note)
* [Add Contact Log](../../doc/controllers/client.md#add-contact-log)
* [Merge Client](../../doc/controllers/client.md#merge-client)
* [Send Auto Email](../../doc/controllers/client.md#send-auto-email)
* [Send Password Reset Email](../../doc/controllers/client.md#send-password-reset-email)
* [Suspend Contract](../../doc/controllers/client.md#suspend-contract)
* [Terminate Contract](../../doc/controllers/client.md#terminate-contract)
* [Update Client](../../doc/controllers/client.md#update-client)
* [Update Client Contract Autopays](../../doc/controllers/client.md#update-client-contract-autopays)
* [Update Client Service](../../doc/controllers/client.md#update-client-service)
* [Update Client Visit](../../doc/controllers/client.md#update-client-visit)
* [Update Contact Log](../../doc/controllers/client.md#update-contact-log)
* [Upload Client Document](../../doc/controllers/client.md#upload-client-document)
* [Upload Client Photo](../../doc/controllers/client.md#upload-client-photo)
* [Delete Client Formula Note](../../doc/controllers/client.md#delete-client-formula-note)
* [Delete Contact Log](../../doc/controllers/client.md#delete-contact-log)


# Get Active Client Memberships

Please note that client memberships with location restrictions can only be used to pay for scheduled services at the site to which they belong. Memberships with location restrictions can not be used to pay for scheduled services at other sites within an organization.

```csharp
GetActiveClientMembershipsAsync(
    string version,
    string requestClientId,
    string siteId,
    string authorization = null,
    int? requestClientAssociatedSitesOffset = null,
    bool? requestCrossRegionalLookup = null,
    int? requestLimit = null,
    int? requestLocationId = null,
    int? requestOffset = null,
    long? requestUniqueClientId = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientId` | `string` | Query, Required | The ID of the client for whom memberships are returned. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestClientAssociatedSitesOffset` | `int?` | Query, Optional | Used to retrieve a client’s memberships from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br /><br>Default: **0**<br><br>For example, if a client is associated with 25 sites, you need to call GET `ActiveClientMemberships` three times, as follows:<br><br>* Use GET `CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.<br>* Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s memberships from sites 1-10<br>* Set `ClientAssociatedSitesOffset` to 10 to return the client’s memberships from sites 11-20<br>* Set `ClientAssociatedSitesOffset` to 20 to return the client’s memberships from sites 21-25 |
| `requestCrossRegionalLookup` | `bool?` | Query, Optional | Used to retrieve a client’s memberships from multiple sites within an organization. When included and set to `true`, it searches a maximum of ten sites with which this client is associated. When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.<br>Default: **false** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `int?` | Query, Optional | Filters results to memberships that can be used to pay for scheduled services at that location. This parameter can not be passed when `CrossRegionalLookup` is `true`. |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestUniqueClientId` | `long?` | Query, Optional | The Unique ID of the client for whom memberships are returned. Note that UniqueClientId takes precedence over ClientId if both are provided. |

## Response Type

[`Task<Models.GetActiveClientMembershipsResponse>`](../../doc/models/get-active-client-memberships-response.md)

## Example Usage

```csharp
string version = "6";
string requestClientId = "request.clientId2";
string siteId = "-99";
string authorization = "authorization6";
int? requestClientAssociatedSitesOffset = 146;
bool? requestCrossRegionalLookup = false;
int? requestLimit = 62;
int? requestLocationId = 90;
int? requestOffset = 100;
long? requestUniqueClientId = 226L;
try
{
    GetActiveClientMembershipsResponse result = await clientController.GetActiveClientMembershipsAsync(
        version,
        requestClientId,
        siteId,
        authorization,
        requestClientAssociatedSitesOffset,
        requestCrossRegionalLookup,
        requestLimit,
        requestLocationId,
        requestOffset,
        requestUniqueClientId
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Active Clients Memberships

The endpoint returns a list of memberships for multiple clients we pass in query parameter. Please note that clients memberships with location restrictions can only be used to pay for scheduled services at the site to which they belong. Memberships with location restrictions can not be used to pay for scheduled services at other sites within an organization.

```csharp
GetActiveClientsMembershipsAsync(
    string version,
    List<string> requestClientIds,
    string siteId,
    string authorization = null,
    int? requestClientAssociatedSitesOffset = null,
    bool? requestCrossRegionalLookup = null,
    int? requestLimit = null,
    int? requestLocationId = null,
    int? requestOffset = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientIds` | `List<string>` | Query, Required | The ID of the client for whom memberships are returned. Maximum allowed : 200. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestClientAssociatedSitesOffset` | `int?` | Query, Optional | Used to retrieve a client’s memberships from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br /><br>Default: **0**<br><br>For example, if a client is associated with 25 sites, you need to call `GetClientServices` three times, as follows:<br><br>* Use `GET CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.<br>* Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s services (pricing options) from sites 1-10.<br>* Set `ClientAssociatedSitesOffset` to 10 to return the client pricing options from sites 11-20<br>* Set `ClientAssociatedSitesOffset` to 20 to return the client pricing options from sites 21-25 |
| `requestCrossRegionalLookup` | `bool?` | Query, Optional | Used to retrieve a client’s memberships from multiple sites within an organization. When included and set to `true`, it searches a maximum of ten sites with which this client is associated. When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.<br>Default: **false** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `int?` | Query, Optional | Filters results to memberships that can be used to pay for scheduled services at that location. This parameter can not be passed when `CrossRegionalLookup` is `true`. |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`Task<Models.GetActiveClientsMembershipsResponse>`](../../doc/models/get-active-clients-memberships-response.md)

## Example Usage

```csharp
string version = "6";
List<string> requestClientIds = new List<string>
{
    "request.clientIds9",
    "request.clientIds0",
    "request.clientIds1",
};

string siteId = "-99";
string authorization = "authorization6";
int? requestClientAssociatedSitesOffset = 146;
bool? requestCrossRegionalLookup = false;
int? requestLimit = 62;
int? requestLocationId = 90;
int? requestOffset = 100;
try
{
    GetActiveClientsMembershipsResponse result = await clientController.GetActiveClientsMembershipsAsync(
        version,
        requestClientIds,
        siteId,
        authorization,
        requestClientAssociatedSitesOffset,
        requestCrossRegionalLookup,
        requestLimit,
        requestLocationId,
        requestOffset
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Client Account Balances

Get account balance information for one or more client(s).

```csharp
GetClientAccountBalancesAsync(
    string version,
    List<string> requestClientIds,
    string siteId,
    string authorization = null,
    DateTime? requestBalanceDate = null,
    int? requestClassId = null,
    int? requestLimit = null,
    int? requestOffset = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientIds` | `List<string>` | Query, Required | The list of clients IDs for which you want account balances. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestBalanceDate` | `DateTime?` | Query, Optional | The date you want a balance relative to.<br>Default: **the current date** |
| `requestClassId` | `int?` | Query, Optional | The class ID of the event for which you want a balance. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`Task<Models.GetClientAccountBalancesResponse>`](../../doc/models/get-client-account-balances-response.md)

## Example Usage

```csharp
string version = "6";
List<string> requestClientIds = new List<string>
{
    "request.clientIds9",
    "request.clientIds0",
    "request.clientIds1",
};

string siteId = "-99";
string authorization = "authorization6";
DateTime? requestBalanceDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
int? requestClassId = 206;
int? requestLimit = 62;
int? requestOffset = 100;
try
{
    GetClientAccountBalancesResponse result = await clientController.GetClientAccountBalancesAsync(
        version,
        requestClientIds,
        siteId,
        authorization,
        requestBalanceDate,
        requestClassId,
        requestLimit,
        requestOffset
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Client Complete Info

This endpoint returns complete client information along with list of purchased services, contract details, membership details and arrival programs for a specific client.

```csharp
GetClientCompleteInfoAsync(
    string version,
    string requestClientId,
    string siteId,
    string authorization = null,
    string consumerIdentityToken = null,
    int? requestClientAssociatedSitesOffset = null,
    bool? requestCrossRegionalLookup = null,
    DateTime? requestEndDate = null,
    bool? requestExcludeInactiveSites = null,
    List<string> requestRequiredClientData = null,
    bool? requestShowActiveOnly = null,
    DateTime? requestStartDate = null,
    long? requestUniqueClientId = null,
    bool? requestUseActivateDate = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientId` | `string` | Query, Required | Filters results to client with these ID. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `consumerIdentityToken` | `string` | Header, Optional | A consumers authorization token to replace the need of clientId in the request. |
| `requestClientAssociatedSitesOffset` | `int?` | Query, Optional | Used to retrieve a client’s pricing options from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br /><br>Default: **0**<br><br>For example, if a client is associated with 25 sites, you need to call `GetClientServices` three times, as follows:<br><br>* Use `GET CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.<br>* Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s services (pricing options) from sites 1-10.<br>* Set `ClientAssociatedSitesOffset` to 10 to return the client pricing options from sites 11-20<br>* Set `ClientAssociatedSitesOffset` to 20 to return the client pricing options from sites 21-25 |
| `requestCrossRegionalLookup` | `bool?` | Query, Optional | Used to retrieve a clients pricing options from multiple sites within an organization.When included and set to `true`,<br>it searches a maximum of ten sites with which this client is associated.When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated.<br>You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with.<br>Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.<br>Default: **false** |
| `requestEndDate` | `DateTime?` | Query, Optional | Filters results to pricing options that are purchased on or before this date.<br>Default: **today’s date**. |
| `requestExcludeInactiveSites` | `bool?` | Query, Optional | When this flag is set to `true`, will exclude inactive sites from the response<br>Default: **false** |
| `requestRequiredClientData` | `List<string>` | Query, Optional | Used to retrieve list of purchased services, contract details, membership details and arrival programs for a specific client.<br>Default `ClientServices`, `ClientContracts`, `ClientMemberships` and `ClientArrivals` will be returned when `RequiredClientDatais` not set.<br>When `RequiredClientData` is set to `Contracts` then only `ClientContracts` will be returned in the response.<br>When `RequiredClientData` is set to Services then only `ClientServices` will be returned in the response.<br>When `RequiredClientData` is set to `Memberships` then only `ClientMemberships` will be returned in the response.<br>When `RequiredClientData` is set to `ArrivalPrograms` then only `ClientArrivals` will be returned in the response. |
| `requestShowActiveOnly` | `bool?` | Query, Optional | When `true`, includes active services only. Set this field to `true` when trying to determine if a client has a<br>service that can pay for a class or appointment.<br>Default: **false** |
| `requestStartDate` | `DateTime?` | Query, Optional | Filters results to pricing options that are purchased on or after this date.<br>Default: **today’s date**. |
| `requestUniqueClientId` | `long?` | Query, Optional | The unique ID of the client who is viewing this class list. |
| `requestUseActivateDate` | `bool?` | Query, Optional | When this flag is set to `true`, the date filtering will use activate date to filter the pricing options.<br>When this flag is set to `false`, the date filtering will use purchase date to filter the pricing options.<br>Default: **false** |

## Response Type

[`Task<Models.GetClientCompleteInfoResponse>`](../../doc/models/get-client-complete-info-response.md)

## Example Usage

```csharp
string version = "6";
string requestClientId = "request.clientId2";
string siteId = "-99";
string authorization = "authorization6";
string consumerIdentityToken = "consumer-identity-token6";
int? requestClientAssociatedSitesOffset = 146;
bool? requestCrossRegionalLookup = false;
DateTime? requestEndDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
bool? requestExcludeInactiveSites = false;
List<string> requestRequiredClientData = new List<string>
{
    "request.requiredClientData4",
    "request.requiredClientData5",
};

bool? requestShowActiveOnly = false;
DateTime? requestStartDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
long? requestUniqueClientId = 226L;
bool? requestUseActivateDate = false;
try
{
    GetClientCompleteInfoResponse result = await clientController.GetClientCompleteInfoAsync(
        version,
        requestClientId,
        siteId,
        authorization,
        consumerIdentityToken,
        requestClientAssociatedSitesOffset,
        requestCrossRegionalLookup,
        requestEndDate,
        requestExcludeInactiveSites,
        requestRequiredClientData,
        requestShowActiveOnly,
        requestStartDate,
        requestUniqueClientId,
        requestUseActivateDate
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Client Contracts

Get contracts that a client has purchased.

```csharp
GetClientContractsAsync(
    string version,
    string requestClientId,
    string siteId,
    string authorization = null,
    int? requestClientAssociatedSitesOffset = null,
    bool? requestCrossRegionalLookup = null,
    int? requestLimit = null,
    int? requestOffset = null,
    long? requestUniqueClientId = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientId` | `string` | Query, Required | The ID of the client (RssId). |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestClientAssociatedSitesOffset` | `int?` | Query, Optional | Determines how many sites are skipped over when retrieving a client’s cross regional contracts. Used when a client ID is linked to more than ten sites in an organization. Only a maximum of ten site databases are queried when this call is made and `CrossRegionalLookup` is set to `true`. To change which sites are queried, change this offset value.<br>Default: **0** |
| `requestCrossRegionalLookup` | `bool?` | Query, Optional | When `true`, indicates that the requesting client’s cross regional contracts are returned, if any.<br /><br>When `false`, indicates that cross regional contracts are not returned. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestUniqueClientId` | `long?` | Query, Optional | The unique ID of the requested client. |

## Response Type

[`Task<Models.GetClientContractsResponse>`](../../doc/models/get-client-contracts-response.md)

## Example Usage

```csharp
string version = "6";
string requestClientId = "request.clientId2";
string siteId = "-99";
string authorization = "authorization6";
int? requestClientAssociatedSitesOffset = 146;
bool? requestCrossRegionalLookup = false;
int? requestLimit = 62;
int? requestOffset = 100;
long? requestUniqueClientId = 226L;
try
{
    GetClientContractsResponse result = await clientController.GetClientContractsAsync(
        version,
        requestClientId,
        siteId,
        authorization,
        requestClientAssociatedSitesOffset,
        requestCrossRegionalLookup,
        requestLimit,
        requestOffset,
        requestUniqueClientId
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Direct Debit Info

This endpoint returns direct debit info stored on a client's account. This endpoint requires staff user credentials.

A null response from this endpoint indicates that the client has no usable direct debit information on their account.Use the POST AddClientDirectDebitInfo endpoint to add direct debit information to a client’s account.

```csharp
GetDirectDebitInfoAsync(
    string version,
    string siteId,
    string authorization = null,
    string clientId = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `clientId` | `string` | Query, Optional | The ID of the client. |

## Response Type

[`Task<Models.DirectDebitInfo>`](../../doc/models/direct-debit-info.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
string clientId = "clientId6";
try
{
    DirectDebitInfo result = await clientController.GetDirectDebitInfoAsync(
        version,
        siteId,
        authorization,
        clientId
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Delete Direct Debit Info

This endpoint deletes direct debit info from a client’s account. This endpoint requires staff user credentials.

```csharp
DeleteDirectDebitInfoAsync(
    string version,
    string siteId,
    string authorization = null,
    string clientId = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `clientId` | `string` | Query, Optional | The ID of the client. |

## Response Type

`Task<object>`

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
string clientId = "clientId6";
try
{
    object result = await clientController.DeleteDirectDebitInfoAsync(
        version,
        siteId,
        authorization,
        clientId
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Client Duplicates

This endpoint gets client records that would be considered duplicates based on case-insensitive matching of the client's first name, last name, and email. For there to be results, all three parameters must match a client record. This endpoint requires staff user credentials.

An empty `ClientDuplicates` object in the response from this endpoint indicates that there were no client records found that match the first name, last name, and email fields passed in.

If one client record is returned, it is not a duplicate itself, but no other client record can be created or updated that would match this client's first name, last name, and email combination.

If more than one client record is returned, these clients are duplicates of each other.We recommend discussing with the business how they would like to resolve duplicate records in the event the response contains more than one client record.Businesses can use the Merge Duplicate Clients tool in the Core Business Mode software to resolve the duplicate client records.

```csharp
GetClientDuplicatesAsync(
    string version,
    string siteId,
    string authorization = null,
    string requestEmail = null,
    string requestFirstName = null,
    string requestLastName = null,
    int? requestLimit = null,
    int? requestOffset = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestEmail` | `string` | Query, Optional | The client email to match on when searching for duplicates. |
| `requestFirstName` | `string` | Query, Optional | The client first name to match on when searching for duplicates. |
| `requestLastName` | `string` | Query, Optional | The client last name to match on when searching for duplicates. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`Task<Models.GetClientDuplicatesResponse>`](../../doc/models/get-client-duplicates-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
string requestEmail = "request.email4";
string requestFirstName = "request.firstName8";
string requestLastName = "request.lastName8";
int? requestLimit = 62;
int? requestOffset = 100;
try
{
    GetClientDuplicatesResponse result = await clientController.GetClientDuplicatesAsync(
        version,
        siteId,
        authorization,
        requestEmail,
        requestFirstName,
        requestLastName,
        requestLimit,
        requestOffset
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Client Formula Notes

***QueryParams***: Enables to retrieve cross regional formula notes for a client, or for a specific appointment. The two parameters are optional, however at least one must be provided. This endpoint supports pagination.

```csharp
GetClientFormulaNotesAsync(
    string version,
    string siteId,
    string authorization = null,
    long? requestAppointmentId = null,
    string requestClientId = null,
    int? requestLimit = null,
    int? requestOffset = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestAppointmentId` | `long?` | Query, Optional | The appointment ID of an appointment in the studio specified in the header of the request. |
| `requestClientId` | `string` | Query, Optional | The client ID of the client whose formula notes are being requested. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`Task<Models.GetClientFormulaNotesResponse>`](../../doc/models/get-client-formula-notes-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
long? requestAppointmentId = 194L;
string requestClientId = "request.clientId2";
int? requestLimit = 62;
int? requestOffset = 100;
try
{
    GetClientFormulaNotesResponse result = await clientController.GetClientFormulaNotesAsync(
        version,
        siteId,
        authorization,
        requestAppointmentId,
        requestClientId,
        requestLimit,
        requestOffset
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Client Indexes

Client indexes are used to analyze client demographics. A business owner can set up different categories with sets of values which they can assign to each client. Client indexes are used in client searches, for tagging clients so that the owner can send mass emails to similar groups, and for many reports.

For more information, see Client Indexes and [Client Index Values (video tutorial)](https://support.mindbodyonline.com/s/article/203261653-Client-indexes-and-client-index-values-video-tutorial?language=en_USclient).

```csharp
GetClientIndexesAsync(
    string version,
    string siteId,
    string authorization = null,
    bool? requestRequiredOnly = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestRequiredOnly` | `bool?` | Query, Optional | When `true`, filters the results to only indexes that are required on creation.<br /><br>When `false` or omitted, returns all of the client indexes. |

## Response Type

[`Task<Models.GetClientIndexesResponse>`](../../doc/models/get-client-indexes-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
bool? requestRequiredOnly = false;
try
{
    GetClientIndexesResponse result = await clientController.GetClientIndexesAsync(
        version,
        siteId,
        authorization,
        requestRequiredOnly
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Client Purchases

Gets a list of purchases made by a specific client.

```csharp
GetClientPurchasesAsync(
    string version,
    string requestClientId,
    string siteId,
    string authorization = null,
    DateTime? requestEndDate = null,
    int? requestLimit = null,
    int? requestOffset = null,
    int? requestSaleId = null,
    DateTime? requestStartDate = null,
    long? requestUniqueClientId = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientId` | `string` | Query, Required | The ID of the client you are querying for purchases. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestEndDate` | `DateTime?` | Query, Optional | Filters results to purchases made before this timestamp.<br /><br>Default: **end of today** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestSaleId` | `int?` | Query, Optional | Filters results to the single record associated with this ID. |
| `requestStartDate` | `DateTime?` | Query, Optional | Filters results to purchases made on or after this timestamp.<br /><br>Default: **now** |
| `requestUniqueClientId` | `long?` | Query, Optional | The unique ID of the requested client. |

## Response Type

[`Task<Models.GetClientPurchasesResponse>`](../../doc/models/get-client-purchases-response.md)

## Example Usage

```csharp
string version = "6";
string requestClientId = "request.clientId2";
string siteId = "-99";
string authorization = "authorization6";
DateTime? requestEndDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
int? requestLimit = 62;
int? requestOffset = 100;
int? requestSaleId = 32;
DateTime? requestStartDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
long? requestUniqueClientId = 226L;
try
{
    GetClientPurchasesResponse result = await clientController.GetClientPurchasesAsync(
        version,
        requestClientId,
        siteId,
        authorization,
        requestEndDate,
        requestLimit,
        requestOffset,
        requestSaleId,
        requestStartDate,
        requestUniqueClientId
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Client Referral Types

Gets a list of referral types. Referral types are options that new clients can choose to identify how they learned about the business. Referral types are typically used for the sign-up process.

```csharp
GetClientReferralTypesAsync(
    string version,
    string siteId,
    string authorization = null,
    bool? requestIncludeInactive = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestIncludeInactive` | `bool?` | Query, Optional | When `true`, filters the results to include subtypes and inactive referral types.<br /><br>When `false`, includes no subtypes and only active types.<br>Default:**false** |

## Response Type

[`Task<Models.GetClientReferralTypesResponse>`](../../doc/models/get-client-referral-types-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
bool? requestIncludeInactive = false;
try
{
    GetClientReferralTypesResponse result = await clientController.GetClientReferralTypesAsync(
        version,
        siteId,
        authorization,
        requestIncludeInactive
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Client Rewards

Gets the client rewards.

```csharp
GetClientRewardsAsync(
    string version,
    string requestClientId,
    string siteId,
    string authorization = null,
    DateTime? requestEndDate = null,
    int? requestLimit = null,
    int? requestOffset = null,
    DateTime? requestStartDate = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientId` | `string` | Query, Required | The ID of the client. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestEndDate` | `DateTime?` | Query, Optional | The end date of transaction.<br>Default: **StartDate** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestStartDate` | `DateTime?` | Query, Optional | The start date of transaction.<br>Default: **today** |

## Response Type

[`Task<Models.GetClientRewardsResponse>`](../../doc/models/get-client-rewards-response.md)

## Example Usage

```csharp
string version = "6";
string requestClientId = "request.clientId2";
string siteId = "-99";
string authorization = "authorization6";
DateTime? requestEndDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
int? requestLimit = 62;
int? requestOffset = 100;
DateTime? requestStartDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
try
{
    GetClientRewardsResponse result = await clientController.GetClientRewardsAsync(
        version,
        requestClientId,
        siteId,
        authorization,
        requestEndDate,
        requestLimit,
        requestOffset,
        requestStartDate
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Update Client Rewards

Earns or redeems rewards points for a given client, based on site settings. Cross regional rewards are not supported at this time.

```csharp
UpdateClientRewardsAsync(
    string version,
    Models.UpdateClientRewardsRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`UpdateClientRewardsRequest`](../../doc/models/update-client-rewards-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.GetClientRewardsResponse>`](../../doc/models/get-client-rewards-response.md)

## Example Usage

```csharp
string version = "6";
UpdateClientRewardsRequest request = new UpdateClientRewardsRequest
{
    ClientId = "ClientId0",
    Points = 10L,
    Action = "Action6",
    Source = "Source6",
    SourceId = 112L,
    ActionDateTime = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind),
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    GetClientRewardsResponse result = await clientController.UpdateClientRewardsAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Clients

This endpoint requires staff user credentials. This endpoint supports pagination. See Pagination for a description of the Pagination information.

```csharp
GetClientsAsync(
    string version,
    string siteId,
    string authorization = null,
    List<string> requestClientIDs = null,
    bool? requestIncludeInactive = null,
    bool? requestIsProspect = null,
    DateTime? requestLastModifiedDate = null,
    int? requestLimit = null,
    int? requestOffset = null,
    string requestSearchText = null,
    List<long> requestUniqueIds = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestClientIDs` | `List<string>` | Query, Optional | The requested client IDs.<br>Default: **all IDs** that the authenticated user’s access level allows.<br /><br>Note: You can fetch information for maximum 20 clients at once. |
| `requestIncludeInactive` | `bool?` | Query, Optional | When `true`, indicates the results to include active and inactive clients.<br /><br>When `false`, indicates that only those clients who are marked as active should be returned.<br>Default: **false** |
| `requestIsProspect` | `bool?` | Query, Optional | When `true`, filters the results to include only those clients marked as prospects for the business.<br /><br>When `false`, indicates that only those clients who are not marked prospects should be returned. |
| `requestLastModifiedDate` | `DateTime?` | Query, Optional | Filters the results to include only the clients that have been modified on or after this date. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestSearchText` | `string` | Query, Optional | Text to use in the search. Can include FirstName, LastName, and Email. Note that user credentials must be provided. |
| `requestUniqueIds` | `List<long>` | Query, Optional | Filters results to clients with these `UniqueIDs`. This parameter cannot be used with `ClientIDs` or `SearchText`.<br>Default: **all UniqueIDs** that the authenticated user’s access level allows. |

## Response Type

[`Task<Models.GetClientsResponse>`](../../doc/models/get-clients-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
List<string> requestClientIDs = new List<string>
{
    "request.clientIDs9",
    "request.clientIDs0",
    "request.clientIDs1",
};

bool? requestIncludeInactive = false;
bool? requestIsProspect = false;
DateTime? requestLastModifiedDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
int? requestLimit = 62;
int? requestOffset = 100;
string requestSearchText = "request.searchText0";
List<long> requestUniqueIds = new List<long>
{
    123L,
    124L,
    125L,
};

try
{
    GetClientsResponse result = await clientController.GetClientsAsync(
        version,
        siteId,
        authorization,
        requestClientIDs,
        requestIncludeInactive,
        requestIsProspect,
        requestLastModifiedDate,
        requestLimit,
        requestOffset,
        requestSearchText,
        requestUniqueIds
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Client Schedule

This endpoint can be utilized to retrieve scheduled visits which is associated with the requested client.

```csharp
GetClientScheduleAsync(
    string version,
    string siteId,
    string authorization = null,
    int? requestClientAssociatedSitesOffset = null,
    string requestClientId = null,
    bool? requestCrossRegionalLookup = null,
    DateTime? requestEndDate = null,
    bool? requestIncludeWaitlistEntries = null,
    int? requestLimit = null,
    int? requestOffset = null,
    DateTime? requestStartDate = null,
    long? requestUniqueClientId = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestClientAssociatedSitesOffset` | `int?` | Query, Optional | The number of sites to skip when returning the site associated with a client. |
| `requestClientId` | `string` | Query, Optional | The ID of the requested client. |
| `requestCrossRegionalLookup` | `bool?` | Query, Optional | When `true`, indicates that past and scheduled client visits across all sites in the region are returned.<br>When `false`, indicates that only visits at the current site are returned. |
| `requestEndDate` | `DateTime?` | Query, Optional | The date past which class visits are not returned.<br>Default is today’s date |
| `requestIncludeWaitlistEntries` | `bool?` | Query, Optional | When `true`, waitlist entries are included in the response.<br>When `false`, waitlist entries are removed from the response.<br>Default: **false** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestStartDate` | `DateTime?` | Query, Optional | The date before which class visits are not returned.<br>Default is the end date |
| `requestUniqueClientId` | `long?` | Query, Optional | The unique ID of the requested client.<br>Note: you need to provide the 'UniqueClientId' OR the 'ClientId'. If both are provided, the 'UniqueClientId' takes precedence. |

## Response Type

[`Task<Models.GetClientScheduleResponse>`](../../doc/models/get-client-schedule-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
int? requestClientAssociatedSitesOffset = 146;
string requestClientId = "request.clientId2";
bool? requestCrossRegionalLookup = false;
DateTime? requestEndDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
bool? requestIncludeWaitlistEntries = false;
int? requestLimit = 62;
int? requestOffset = 100;
DateTime? requestStartDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
long? requestUniqueClientId = 226L;
try
{
    GetClientScheduleResponse result = await clientController.GetClientScheduleAsync(
        version,
        siteId,
        authorization,
        requestClientAssociatedSitesOffset,
        requestClientId,
        requestCrossRegionalLookup,
        requestEndDate,
        requestIncludeWaitlistEntries,
        requestLimit,
        requestOffset,
        requestStartDate,
        requestUniqueClientId
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Client Services

Get pricing options that a client has purchased.

```csharp
GetClientServicesAsync(
    string version,
    string siteId,
    string authorization = null,
    int? requestClassId = null,
    List<int> requestClassScheduleID = null,
    int? requestClientAssociatedSitesOffset = null,
    string requestClientId = null,
    List<string> requestClientIds = null,
    bool? requestCrossRegionalLookup = null,
    DateTime? requestEndDate = null,
    bool? requestExcludeInactiveSites = null,
    bool? requestIgnoreCrossRegionalSiteLimit = null,
    int? requestLimit = null,
    List<int> requestLocationIds = null,
    int? requestOffset = null,
    List<int> requestProgramIds = null,
    int? requestSessionTypeId = null,
    bool? requestShowActiveOnly = null,
    DateTime? requestStartDate = null,
    long? requestUniqueClientId = null,
    List<long> requestUniqueClientIds = null,
    bool? requestUseActivateDate = null,
    int? requestVisitCount = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestClassId` | `int?` | Query, Optional | Filters results to only those pricing options that can be used to pay for this class. |
| `requestClassScheduleID` | `List<int>` | Query, Optional | Filters results to pricing options which are associated with one of the ClassScheduleIDs |
| `requestClientAssociatedSitesOffset` | `int?` | Query, Optional | Used to retrieve a client’s pricing options from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br /><br>Default: **0**<br><br>For example, if a client is associated with 25 sites, you need to call `GetClientServices` three times, as follows:<br><br>* Use `GET CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.<br>* Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s services (pricing options) from sites 1-10.<br>* Set `ClientAssociatedSitesOffset` to 10 to return the client pricing options from sites 11-20<br>* Set `ClientAssociatedSitesOffset` to 20 to return the client pricing options from sites 21-25 |
| `requestClientId` | `string` | Query, Optional | The ID of the client to query. The results are a list of pricing options that the client has purchased. Note that “service” and “pricing option” are synonymous in this section of the documentation. |
| `requestClientIds` | `List<string>` | Query, Optional | The IDs of the clients to query. The results are a list of pricing options that the clients have purchased.<br>ClientId parameter takes priority over ClientIds due to backward compatibility.<br>So if you want to use ClientIds, then ClientId needs to be empty.<br>Either of ClientId or ClientIds need to be specified |
| `requestCrossRegionalLookup` | `bool?` | Query, Optional | Used to retrieve a client’s pricing options from multiple sites within an organization. When included and set to `true`, it searches a maximum of ten sites with which this client is associated. When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.<br>Default: **false** |
| `requestEndDate` | `DateTime?` | Query, Optional | Filters results to pricing options that are purchased on or before this date.<br>Default: **today’s date** |
| `requestExcludeInactiveSites` | `bool?` | Query, Optional | When this flag is set to `true`, will exclude inactive sites from the response.<br>Default: **false** |
| `requestIgnoreCrossRegionalSiteLimit` | `bool?` | Query, Optional | Used to specify if the number of cross regional sites used to search for client’s pricing options should be ignored.<br>Default: **false** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationIds` | `List<int>` | Query, Optional | Filters results to pricing options that can be used at the listed location IDs. |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestProgramIds` | `List<int>` | Query, Optional | Filters results to pricing options that belong to one of the given program IDs. |
| `requestSessionTypeId` | `int?` | Query, Optional | Filters results to pricing options that will pay for the given session type ID. Use this to find pricing options that will pay for a specific appointment type. |
| `requestShowActiveOnly` | `bool?` | Query, Optional | When `true`, includes active services only.<br>Default: **false** |
| `requestStartDate` | `DateTime?` | Query, Optional | Filters results to pricing options that are purchased on or after this date.<br>Default: **today’s date** |
| `requestUniqueClientId` | `long?` | Query, Optional | The unique ID of the client to query. Note that UniqueClientId takes precedence over ClientId. |
| `requestUniqueClientIds` | `List<long>` | Query, Optional | The Unique IDs of the clients to query. Note that UniqueClientIds collection takes precedence over ClientIds collection. |
| `requestUseActivateDate` | `bool?` | Query, Optional | When this flag is set to `true`, the date filtering will use activate date to filter the pricing options.<br>When this flag is set to `false`, the date filtering will use purchase date to filter the pricing options.<br>Default: **false** |
| `requestVisitCount` | `int?` | Query, Optional | A filter on the minimum number of visits a service can pay for. |

## Response Type

[`Task<Models.GetClientServicesResponse>`](../../doc/models/get-client-services-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
int? requestClassId = 206;
List<int> requestClassScheduleID = new List<int>
{
    118,
    119,
};

int? requestClientAssociatedSitesOffset = 146;
string requestClientId = "request.clientId2";
List<string> requestClientIds = new List<string>
{
    "request.clientIds9",
    "request.clientIds0",
    "request.clientIds1",
};

bool? requestCrossRegionalLookup = false;
DateTime? requestEndDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
bool? requestExcludeInactiveSites = false;
bool? requestIgnoreCrossRegionalSiteLimit = false;
int? requestLimit = 62;
List<int> requestLocationIds = new List<int>
{
    192,
};

int? requestOffset = 100;
List<int> requestProgramIds = new List<int>
{
    91,
    92,
    93,
};

int? requestSessionTypeId = 100;
bool? requestShowActiveOnly = false;
DateTime? requestStartDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
long? requestUniqueClientId = 226L;
List<long> requestUniqueClientIds = new List<long>
{
    219L,
    220L,
};

bool? requestUseActivateDate = false;
int? requestVisitCount = 18;
try
{
    GetClientServicesResponse result = await clientController.GetClientServicesAsync(
        version,
        siteId,
        authorization,
        requestClassId,
        requestClassScheduleID,
        requestClientAssociatedSitesOffset,
        requestClientId,
        requestClientIds,
        requestCrossRegionalLookup,
        requestEndDate,
        requestExcludeInactiveSites,
        requestIgnoreCrossRegionalSiteLimit,
        requestLimit,
        requestLocationIds,
        requestOffset,
        requestProgramIds,
        requestSessionTypeId,
        requestShowActiveOnly,
        requestStartDate,
        requestUniqueClientId,
        requestUniqueClientIds,
        requestUseActivateDate,
        requestVisitCount
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Client Visits

Gets the Client Visits for a specific client.

```csharp
GetClientVisitsAsync(
    string version,
    string siteId,
    string authorization = null,
    int? requestClientAssociatedSitesOffset = null,
    string requestClientId = null,
    bool? requestCrossRegionalLookup = null,
    DateTime? requestEndDate = null,
    int? requestLimit = null,
    int? requestOffset = null,
    DateTime? requestStartDate = null,
    long? requestUniqueClientId = null,
    bool? requestUnpaidsOnly = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestClientAssociatedSitesOffset` | `int?` | Query, Optional | The number of sites to skip when returning the site associated with a client. |
| `requestClientId` | `string` | Query, Optional | The ID of the requested client. |
| `requestCrossRegionalLookup` | `bool?` | Query, Optional | When `true`, indicates that past and scheduled client visits across all sites in the region are returned.<br /><br>When `false`, indicates that only visits at the current site are returned. |
| `requestEndDate` | `DateTime?` | Query, Optional | The date past which class visits are not returned.<br>Default: **today's date** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestStartDate` | `DateTime?` | Query, Optional | The date before which class visits are not returned.<br>Default: **the end date** |
| `requestUniqueClientId` | `long?` | Query, Optional | The unique ID of the requested client.<br>Note: you need to provide the 'UniqueClientId' OR the 'ClientId'. If both are provided, the 'UniqueClientId' takes precedence. |
| `requestUnpaidsOnly` | `bool?` | Query, Optional | When `true`, indicates that only visits that have not been paid for are returned.<br /><br>When `false`, indicates that all visits are returned, regardless of whether they have been paid for.<br /><br>Default: **false** |

## Response Type

[`Task<Models.GetClientVisitsResponse>`](../../doc/models/get-client-visits-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
int? requestClientAssociatedSitesOffset = 146;
string requestClientId = "request.clientId2";
bool? requestCrossRegionalLookup = false;
DateTime? requestEndDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
int? requestLimit = 62;
int? requestOffset = 100;
DateTime? requestStartDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
long? requestUniqueClientId = 226L;
bool? requestUnpaidsOnly = false;
try
{
    GetClientVisitsResponse result = await clientController.GetClientVisitsAsync(
        version,
        siteId,
        authorization,
        requestClientAssociatedSitesOffset,
        requestClientId,
        requestCrossRegionalLookup,
        requestEndDate,
        requestLimit,
        requestOffset,
        requestStartDate,
        requestUniqueClientId,
        requestUnpaidsOnly
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Contact Logs

This endpoint contains a variety of filters that can return not just all contact logs, but also system-generated contact logs, contact logs assigned to specific staff members, and contact logs of specific types or subtypes.

```csharp
GetContactLogsAsync(
    string version,
    string requestClientId,
    string siteId,
    string authorization = null,
    DateTime? requestEndDate = null,
    int? requestLimit = null,
    int? requestOffset = null,
    bool? requestShowSystemGenerated = null,
    List<long> requestStaffIds = null,
    DateTime? requestStartDate = null,
    List<int> requestSubtypeIds = null,
    List<int> requestTypeIds = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientId` | `string` | Query, Required | The ID of the client whose contact logs are being requested. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestEndDate` | `DateTime?` | Query, Optional | Filters the results to contact logs created before this date.<br /><br>Default: **the start date** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestShowSystemGenerated` | `bool?` | Query, Optional | When `true`, system-generated contact logs are returned in the results.<br /><br>Default: **false** |
| `requestStaffIds` | `List<long>` | Query, Optional | Filters the results to return contact logs assigned to one or more staff IDs. |
| `requestStartDate` | `DateTime?` | Query, Optional | Filters the results to contact logs created on or after this date.<br /><br>Default: **the current date** |
| `requestSubtypeIds` | `List<int>` | Query, Optional | Filters the results to contact logs assigned one or more of these subtype IDs. |
| `requestTypeIds` | `List<int>` | Query, Optional | Filters the results to contact logs assigned one or more of these type IDs. |

## Response Type

[`Task<Models.GetContactLogsResponse>`](../../doc/models/get-contact-logs-response.md)

## Example Usage

```csharp
string version = "6";
string requestClientId = "request.clientId2";
string siteId = "-99";
string authorization = "authorization6";
DateTime? requestEndDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
int? requestLimit = 62;
int? requestOffset = 100;
bool? requestShowSystemGenerated = false;
List<long> requestStaffIds = new List<long>
{
    23L,
    24L,
    25L,
};

DateTime? requestStartDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
List<int> requestSubtypeIds = new List<int>
{
    141,
};

List<int> requestTypeIds = new List<int>
{
    63,
};

try
{
    GetContactLogsResponse result = await clientController.GetContactLogsAsync(
        version,
        requestClientId,
        siteId,
        authorization,
        requestEndDate,
        requestLimit,
        requestOffset,
        requestShowSystemGenerated,
        requestStaffIds,
        requestStartDate,
        requestSubtypeIds,
        requestTypeIds
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Contact Log Types

This endpoint contains a variety of filters that can return not just all contact logs, but also system-generated contact logs, contact logs assigned to specific staff members, and contact logs of specific types or subtypes.

```csharp
GetContactLogTypesAsync(
    string version,
    string siteId,
    string authorization = null,
    int? requestContactLogTypeId = null,
    int? requestLimit = null,
    int? requestOffset = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestContactLogTypeId` | `int?` | Query, Optional | The requested ContactLogType ID.<br>Default: **all** IDs that the authenticated user’s access level allows. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`Task<Models.GetContactLogTypesResponse>`](../../doc/models/get-contact-log-types-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
int? requestContactLogTypeId = 24;
int? requestLimit = 62;
int? requestOffset = 100;
try
{
    GetContactLogTypesResponse result = await clientController.GetContactLogTypesAsync(
        version,
        siteId,
        authorization,
        requestContactLogTypeId,
        requestLimit,
        requestOffset
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Cross Regional Client Associations

Returns a list of sites that a particular client ID (also referred to as an RSSID) or a client email address is associated with in a cross-regional organization. Either the `ClientID` or `Email` parameter is required. If both are provided, the `ClientID` is used.

Use this endpoint to retrieve information for other Public API endpoints, about the same client at multiple sites within an organization. To use this endpoint, your developer account must have been granted permission to the site's entire organization.

Note that this endpoint does not work on the Developer Sandbox site, as it is not set up for cross-regional use cases.

```csharp
GetCrossRegionalClientAssociationsAsync(
    string version,
    string siteId,
    string authorization = null,
    string requestClientId = null,
    string requestEmail = null,
    bool? requestExcludeInactiveSites = null,
    string requestFirstName = null,
    string requestLastName = null,
    int? requestLimit = null,
    int? requestOffset = null,
    long? requestUniqueClientId = null,
    bool? requestV2 = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestClientId` | `string` | Query, Optional | Looks up the cross regional associations by the client’s ID. |
| `requestEmail` | `string` | Query, Optional | Looks up the cross regional associations by the client’s email address. |
| `requestExcludeInactiveSites` | `bool?` | Query, Optional | Used to exclude inactive and deleted sites from the results.<br>When this flag is set to `true`, client profiles associated with inactive and deleted sites are not getting returned.<br>When this flag is set to `false`,client profiles associated with inactive and deleted sites are getting returned.<br>Default: **true** |
| `requestFirstName` | `string` | Query, Optional | First name (used for email queries) |
| `requestLastName` | `string` | Query, Optional | Last name (used for email queries) |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestUniqueClientId` | `long?` | Query, Optional | Looks up the cross regional associations by the unique client’s ID.<br>Note: you need to provide the 'UniqueClientId' OR the 'ClientId' OR the 'Email'.<br>'UniqueClientId' takes precedence when provided. If not, but both 'ClientId' and 'Email' are provided, 'ClientId' is used by default. |
| `requestV2` | `bool?` | Query, Optional | Use newer method |

## Response Type

[`Task<Models.GetCrossRegionalClientAssociationsResponse>`](../../doc/models/get-cross-regional-client-associations-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
string requestClientId = "request.clientId2";
string requestEmail = "request.email4";
bool? requestExcludeInactiveSites = false;
string requestFirstName = "request.firstName8";
string requestLastName = "request.lastName8";
int? requestLimit = 62;
int? requestOffset = 100;
long? requestUniqueClientId = 226L;
bool? requestV2 = false;
try
{
    GetCrossRegionalClientAssociationsResponse result = await clientController.GetCrossRegionalClientAssociationsAsync(
        version,
        siteId,
        authorization,
        requestClientId,
        requestEmail,
        requestExcludeInactiveSites,
        requestFirstName,
        requestLastName,
        requestLimit,
        requestOffset,
        requestUniqueClientId,
        requestV2
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Custom Client Fields

Get a site's configured custom client fields.

```csharp
GetCustomClientFieldsAsync(
    string version,
    string siteId,
    string authorization = null,
    int? requestLimit = null,
    int? requestOffset = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`Task<Models.GetCustomClientFieldsResponse>`](../../doc/models/get-custom-client-fields-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
int? requestLimit = 62;
int? requestOffset = 100;
try
{
    GetCustomClientFieldsResponse result = await clientController.GetCustomClientFieldsAsync(
        version,
        siteId,
        authorization,
        requestLimit,
        requestOffset
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Required Client Fields

Gets the list of fields that a new client has to fill out in business mode, specifically for the sign-up process. `AddClient` and `UpdateClient` validate against these fields.

This endpoint has no query parameters.

```csharp
GetRequiredClientFieldsAsync(
    string version,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.GetRequiredClientFieldsResponse>`](../../doc/models/get-required-client-fields-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
try
{
    GetRequiredClientFieldsResponse result = await clientController.GetRequiredClientFieldsAsync(
        version,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Add Arrival

Marks a client as arrived for a specified location. A staff user token must be included with staff assigned the LaunchSignInScreen permission.

When used on a site that is part of a region, the following additional logic will apply:

* When a client exists within the region but not at the studio where the arrival is being logged, a local client record will be automatically created.
* If the local client does not have an applicable local membership or pricing option, a membership or pricing option will be automatically used if it exists elsewhere within the region.

```csharp
AddArrivalAsync(
    string version,
    Models.AddArrivalRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`AddArrivalRequest`](../../doc/models/add-arrival-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.AddArrivalResponse>`](../../doc/models/add-arrival-response.md)

## Example Usage

```csharp
string version = "6";
AddArrivalRequest request = new AddArrivalRequest
{
    ClientId = "ClientId0",
    LocationId = 238,
    ArrivalTypeId = 120,
    LeadChannelId = 216,
    Test = false,
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    AddArrivalResponse result = await clientController.AddArrivalAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Add Client

Starting the week of May 11th, 2020 all versions of the Public API will no longer allow duplicate clients to be created. This applies to both adding a client and updating a client record. A duplicate client is created when two profiles have the same first name, last name and email.<br />
Creates a new client record at the specified business.Passing a User Token as Authorization will create a client and respect Business Mode required fields.Omitting the token will create a client and respect Consumer Mode required fi elds. To make sure you are collecting all required pieces of information, first run GetRequired ClientFields.<br />
If you have purchased an Ultimate tier then this endpoint will automatically start showing new opportunity on Sales Pipeline.

```csharp
AddClientAsync(
    string version,
    Models.AddClientRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`AddClientRequest`](../../doc/models/add-client-request.md) | Body, Required | The `FirstName` and `LastName` parameters are always required in this request.<br>All other parameters are optional, but note that any of the optional parameters could be required by a particular business,<br>depending on how the business has configured the site settings. If `GetRequiredClientFields` returns `EmergContact` in the list of required fields,<br>then all emergency contact parameters are required, which includes `EmergencyContactInfoEmail`, `EmergencyContactInfoName`, `EmergencyContactInfoPhone`, and `EmergencyContactInfoRelationship`. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.AddClientResponse>`](../../doc/models/add-client-response.md)

## Example Usage

```csharp
string version = "6";
AddClientRequest request = new AddClientRequest
{
    FirstName = "FirstName8",
    LastName = "LastName8",
    AccountBalance = 60.74,
    Action = Action1Enum.Added,
    Active = false,
    AddressLine1 = "AddressLine12",
    AddressLine2 = "AddressLine26",
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    AddClientResponse result = await clientController.AddClientAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Add Client Direct Debit Info

This endpoint adds direct debit info to a client’s account. This endpoint requires staff user credentials.

```csharp
AddClientDirectDebitInfoAsync(
    string version,
    Models.AddClientDirectDebitInfoRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`AddClientDirectDebitInfoRequest`](../../doc/models/add-client-direct-debit-info-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.AddClientDirectDebitInfoResponse>`](../../doc/models/add-client-direct-debit-info-response.md)

## Example Usage

```csharp
string version = "6";
AddClientDirectDebitInfoRequest request = new AddClientDirectDebitInfoRequest
{
    Test = false,
    ClientId = "ClientId0",
    NameOnAccount = "NameOnAccount0",
    RoutingNumber = "RoutingNumber6",
    AccountNumber = "AccountNumber0",
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    AddClientDirectDebitInfoResponse result = await clientController.AddClientDirectDebitInfoAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Add Formula Note

This endpoint adds a formula note for a specified client or specified client appointment. A staff user token must be included with staff assigned permission to view client profile or have both ViewAppointmentDetails and ModifyAppointment permissions.

```csharp
AddFormulaNoteAsync(
    string version,
    Models.AddFormulaNoteRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`AddFormulaNoteRequest`](../../doc/models/add-formula-note-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.FormulaNoteResponse>`](../../doc/models/formula-note-response.md)

## Example Usage

```csharp
string version = "6";
AddFormulaNoteRequest request = new AddFormulaNoteRequest
{
    ClientId = "ClientId0",
    Note = "Note6",
    AppointmentId = 246L,
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    FormulaNoteResponse result = await clientController.AddFormulaNoteAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Add Contact Log

Add a contact log to a client's account.

```csharp
AddContactLogAsync(
    string version,
    Models.AddContactLogRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`AddContactLogRequest`](../../doc/models/add-contact-log-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.ContactLog>`](../../doc/models/contact-log.md)

## Example Usage

```csharp
string version = "6";
AddContactLogRequest request = new AddContactLogRequest
{
    ClientId = "ClientId0",
    ContactMethod = "ContactMethod0",
    AssignedToStaffId = 202L,
    Text = "Text8",
    FollowupByDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind),
    ContactName = "ContactName6",
    IsComplete = false,
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    ContactLog result = await clientController.AddContactLogAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Merge Client

This endpoint helps to merge clients.

```csharp
MergeClientAsync(
    string version,
    Models.MergeClientsRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MergeClientsRequest`](../../doc/models/merge-clients-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`Task<object>`

## Example Usage

```csharp
string version = "6";
MergeClientsRequest request = new MergeClientsRequest
{
    SourceClientId = 120L,
    TargetClientId = 110L,
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    object result = await clientController.MergeClientAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Send Auto Email

This endpoint requires staff user credentials.

```csharp
SendAutoEmailAsync(
    string version,
    Models.SendAutoEmailRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`SendAutoEmailRequest`](../../doc/models/send-auto-email-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`Task<object>`

## Example Usage

```csharp
string version = "6";
SendAutoEmailRequest request = new SendAutoEmailRequest
{
    ClientId = "ClientId0",
    EmailType = "EmailType4",
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    object result = await clientController.SendAutoEmailAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Send Password Reset Email

Send a password reset email to a client.

```csharp
SendPasswordResetEmailAsync(
    string version,
    Models.SendPasswordResetEmailRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`SendPasswordResetEmailRequest`](../../doc/models/send-password-reset-email-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`Task<object>`

## Example Usage

```csharp
string version = "6";
SendPasswordResetEmailRequest request = new SendPasswordResetEmailRequest
{
    UserEmail = "UserEmail2",
    UserFirstName = "UserFirstName2",
    UserLastName = "UserLastName8",
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    object result = await clientController.SendPasswordResetEmailAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Suspend Contract

Suspend client contract

```csharp
SuspendContractAsync(
    string version,
    Models.SuspendContractRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`SuspendContractRequest`](../../doc/models/suspend-contract-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.SuspendContractResponse>`](../../doc/models/suspend-contract-response.md)

## Example Usage

```csharp
string version = "6";
SuspendContractRequest request = new SuspendContractRequest
{
    ClientId = "ClientId0",
    ClientContractId = 118,
    SuspensionType = "SuspensionType0",
    SuspensionStart = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind),
    Duration = 224,
    DurationUnit = 102,
    OpenEnded = false,
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    SuspendContractResponse result = await clientController.SuspendContractAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Terminate Contract

This endpoint terminates a client contract. This endpoint requires staff user credentials with TerminateClientContract permission.

```csharp
TerminateContractAsync(
    string version,
    Models.TerminateContractRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`TerminateContractRequest`](../../doc/models/terminate-contract-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.TerminateContractResponse>`](../../doc/models/terminate-contract-response.md)

## Example Usage

```csharp
string version = "6";
TerminateContractRequest request = new TerminateContractRequest
{
    ClientId = "ClientId0",
    ClientContractId = 118,
    TerminationDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind),
    TerminationCode = "TerminationCode0",
    TerminationComments = "TerminationComments8",
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    TerminateContractResponse result = await clientController.TerminateContractAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Update Client

Starting the week of May 11th, 2020 all versions of the Public API will no longer allow duplicate clients to be created. This applies to both adding a client and updating a client record. A duplicate client is created when two profiles have the same first name, last name and email.<br />
Updates an existing client for a specific subscriber.Passing a User Token as Authorization respects Business Mode required fields.Omitting the token respects Consumer Mode required fields.To make sure you are collecting all required pieces of information, first run GetRequiredClientFields.
<br />.
Use this endpoint as follows:

* If you need to update the `ReferredBy` parameter, use this endpoint after calling `GET ClientReferralTypes`.
* When updating a client's home location, use after calling `GET Locations`.
* If you are updating a client's stored credit card, use after calling `GET AcceptedCardTypes` so that you can make sure the card is a type that is accepted at the subscriber.
* If this endpoint is used on a cross-regional site, passing in a client's RSSID and email address creates a cross-regional link. This means that the client is created in cross-regional sites where the client does not exist and `GET CrossRegionalClientAssociations` returns all appropriate cross-regional sites.
* When `CrossRegionalUpdate` is omitted or set to `true`, the client's updated information is propagated to all of the region's sites. If `CrossRegionalUpdate` is set to `false`, only the local client is updated.
* Important: Starting in June 2025, the fields RSSID, Prefix, Name, Email, Birthday, Phone, and Address will automatically update cross-regionally when changed, regardless of the CrossRegionalUpdate setting. The update is rolling out on a per customer basis and is expected to complete to all customers by September 2025.

Note that the following items cannot be updated for a cross-regional client:

* `ClientIndexes`
* `ClientRelationships`
* `CustomClientFields`
* `SalesReps`
* `SendAccountEmails`
* `SendAccountTexts`
* `SendPromotionalEmails`
* `SendPromotionalTexts`
* `SendScheduleEmails`
* `SendScheduleTexts`
* `Gender` (for site custom values)

Custom client Gender options can only be created with non-cross-regional requests.

If you have purchased an Ultimate tier then this endpoint will automatically start showing a new opportunity on Sales Pipeline.It will create a new opportunity if the current request modify the contact as follows::

* You need to update the `IsProspect` parameter, to `true`.
* You need to update the `ProspectStage`.`Description parameter`, to `New Lead`.<br />

Updates made to any inactive clients will automatically reactivate the client unless the `Acive` property is explicitly set to `false` in the request body.

```csharp
UpdateClientAsync(
    string version,
    Models.UpdateClientRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`UpdateClientRequest`](../../doc/models/update-client-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.UpdateClientResponse>`](../../doc/models/update-client-response.md)

## Example Usage

```csharp
string version = "6";
UpdateClientRequest request = new UpdateClientRequest
{
    Client = new ClientWithSuspensionInfo
    {
        SuspensionInfo = new ClientSuspensionInfo
        {
            BookingSuspended = false,
            SuspensionStartDate = "SuspensionStartDate8",
            SuspensionEndDate = "SuspensionEndDate2",
        },
        AppointmentGenderPreference = AppointmentGenderPreference1Enum.None,
        BirthDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
            provider: CultureInfo.InvariantCulture,
            DateTimeStyles.RoundtripKind),
        Country = "Country8",
        CreationDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
            provider: CultureInfo.InvariantCulture,
            DateTimeStyles.RoundtripKind),
    },
    Test = false,
    CrossRegionalUpdate = false,
    NewId = "NewId2",
    LeadChannelId = 216,
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    UpdateClientResponse result = await clientController.UpdateClientAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Update Client Contract Autopays

This endpoint can be used to update the amount and/or the item of a client’s autopay schedule.

```csharp
UpdateClientContractAutopaysAsync(
    string version,
    Models.UpdateClientContractAutopaysRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`UpdateClientContractAutopaysRequest`](../../doc/models/update-client-contract-autopays-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.Contract>`](../../doc/models/contract.md)

## Example Usage

```csharp
string version = "6";
UpdateClientContractAutopaysRequest request = new UpdateClientContractAutopaysRequest
{
    ClientContractId = 118,
    AutopayStartDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind),
    AutopayEndDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind),
    ProductId = 136,
    ReplaceWithProductId = 56,
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    Contract result = await clientController.UpdateClientContractAutopaysAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Update Client Service

Updates the active date and/or expiration date of a client pricing option. This request requires staff user credentials. If the active date is modified, the expiration date is also modified accordingly. If the expiration date is modified, the active date is unchanged.

```csharp
UpdateClientServiceAsync(
    string version,
    Models.UpdateClientServiceRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`UpdateClientServiceRequest`](../../doc/models/update-client-service-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.UpdateClientServiceResponse>`](../../doc/models/update-client-service-response.md)

## Example Usage

```csharp
string version = "6";
UpdateClientServiceRequest request = new UpdateClientServiceRequest
{
    ServiceId = 130,
    ActiveDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind),
    ExpirationDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind),
    Count = 242,
    Test = false,
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    UpdateClientServiceResponse result = await clientController.UpdateClientServiceAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Update Client Visit

Updates the status of the specified visit.

```csharp
UpdateClientVisitAsync(
    string version,
    Models.UpdateClientVisitRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`UpdateClientVisitRequest`](../../doc/models/update-client-visit-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.UpdateClientVisitResponse>`](../../doc/models/update-client-visit-response.md)

## Example Usage

```csharp
string version = "6";
UpdateClientVisitRequest request = new UpdateClientVisitRequest
{
    VisitId = 92,
    Makeup = false,
    SignedIn = false,
    ClientServiceId = 244,
    Execute = "Execute2",
    Test = false,
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    UpdateClientVisitResponse result = await clientController.UpdateClientVisitAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Update Contact Log

Update a contact log on a client's account.

```csharp
UpdateContactLogAsync(
    string version,
    Models.UpdateContactLogRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`UpdateContactLogRequest`](../../doc/models/update-contact-log-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.ContactLog>`](../../doc/models/contact-log.md)

## Example Usage

```csharp
string version = "6";
UpdateContactLogRequest request = new UpdateContactLogRequest
{
    Id = 178,
    Test = false,
    AssignedToStaffId = 202L,
    Text = "Text8",
    ContactName = "ContactName6",
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    ContactLog result = await clientController.UpdateContactLogAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Upload Client Document

Uploads a document file for a specific client. Returns a string representation of the image byte array. The maximum size file that can be uploaded is **4MB**.

```csharp
UploadClientDocumentAsync(
    string version,
    Models.UploadClientDocumentRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`UploadClientDocumentRequest`](../../doc/models/upload-client-document-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.UploadClientDocumentResponse>`](../../doc/models/upload-client-document-response.md)

## Example Usage

```csharp
string version = "6";
UploadClientDocumentRequest request = new UploadClientDocumentRequest
{
    ClientId = "ClientId0",
    File = new ClientDocument
    {
        FileName = "FileName6",
        MediaType = "MediaType6",
        Buffer = "Buffer8",
    },
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    UploadClientDocumentResponse result = await clientController.UploadClientDocumentAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Upload Client Photo

Uploads a client’s profile photo. The maximum file size is 4 MB and acceptable file types are:

* bmp
* jpeg
* gif
* tiff
* png

```csharp
UploadClientPhotoAsync(
    string version,
    Models.UploadClientPhotoRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`UploadClientPhotoRequest`](../../doc/models/upload-client-photo-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.UploadClientPhotoResponse>`](../../doc/models/upload-client-photo-response.md)

## Example Usage

```csharp
string version = "6";
UploadClientPhotoRequest request = new UploadClientPhotoRequest
{
    Bytes = "Bytes6",
    ClientId = "ClientId0",
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    UploadClientPhotoResponse result = await clientController.UploadClientPhotoAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Delete Client Formula Note

This endpoint deletes an existing formula note. A staff user token must be included with staff assigned permission to view client profile or have both ViewAppointmentDetails and ModifyAppointment permissions.

```csharp
DeleteClientFormulaNoteAsync(
    string version,
    string requestClientId,
    long requestFormulaNoteId,
    string siteId,
    string authorization = null,
    int? requestLimit = null,
    int? requestOffset = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientId` | `string` | Query, Required | The client ID of the client whose formula note needs to be deleted. |
| `requestFormulaNoteId` | `long` | Query, Required | The formula note ID for the note to be deleted. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |

## Response Type

`Task`

## Example Usage

```csharp
string version = "6";
string requestClientId = "request.clientId2";
long requestFormulaNoteId = 72L;
string siteId = "-99";
string authorization = "authorization6";
int? requestLimit = 62;
int? requestOffset = 100;
try
{
    await clientController.DeleteClientFormulaNoteAsync(
        version,
        requestClientId,
        requestFormulaNoteId,
        siteId,
        authorization,
        requestLimit,
        requestOffset
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Delete Contact Log

This endpoint deletes contactlog of client. This endpoint requires staff user credentials.

```csharp
DeleteContactLogAsync(
    string version,
    string requestClientId,
    long requestContactLogId,
    string siteId,
    string authorization = null,
    bool? requestTest = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientId` | `string` | Query, Required | The client ID of the client whose Contact Log is being deleted. |
| `requestContactLogId` | `long` | Query, Required | The Contact Log ID. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestTest` | `bool?` | Query, Optional | When `true`, indicates that this is a test request and no data is inserted into the subscriber’s database.<br>When `false`, the database is updated. |

## Response Type

`Task<object>`

## Example Usage

```csharp
string version = "6";
string requestClientId = "request.clientId2";
long requestContactLogId = 90L;
string siteId = "-99";
string authorization = "authorization6";
bool? requestTest = false;
try
{
    object result = await clientController.DeleteContactLogAsync(
        version,
        requestClientId,
        requestContactLogId,
        siteId,
        authorization,
        requestTest
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

