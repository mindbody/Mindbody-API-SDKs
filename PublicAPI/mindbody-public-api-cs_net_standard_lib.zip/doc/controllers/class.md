# Class

```csharp
ClassController classController = client.ClassController;
```

## Class Name

`ClassController`

## Methods

* [Get Class Descriptions](../../doc/controllers/class.md#get-class-descriptions)
* [Get Classes](../../doc/controllers/class.md#get-classes)
* [Get Class Schedules](../../doc/controllers/class.md#get-class-schedules)
* [Get Class Visits](../../doc/controllers/class.md#get-class-visits)
* [Get Courses](../../doc/controllers/class.md#get-courses)
* [Get Semesters](../../doc/controllers/class.md#get-semesters)
* [Get Waitlist Entries](../../doc/controllers/class.md#get-waitlist-entries)
* [Add Class Schedule](../../doc/controllers/class.md#add-class-schedule)
* [Add Client to Class](../../doc/controllers/class.md#add-client-to-class)
* [Cancel Single Class](../../doc/controllers/class.md#cancel-single-class)
* [Remove Client From Class](../../doc/controllers/class.md#remove-client-from-class)
* [Remove Clients From Classes](../../doc/controllers/class.md#remove-clients-from-classes)
* [Remove From Waitlist](../../doc/controllers/class.md#remove-from-waitlist)
* [Substitute Class Teacher](../../doc/controllers/class.md#substitute-class-teacher)
* [Update Class Schedule](../../doc/controllers/class.md#update-class-schedule)


# Get Class Descriptions

To find class descriptions associated with **scheduled classes**, pass `StaffId`, `StartClassDateTime`, `EndClassDateTime`, or `LocationId` in the request.

```csharp
GetClassDescriptionsAsync(
    string version,
    string siteId,
    string authorization = null,
    int? requestClassDescriptionId = null,
    DateTime? requestEndClassDateTime = null,
    bool? requestIncludeInactive = null,
    int? requestLimit = null,
    int? requestLocationId = null,
    int? requestOffset = null,
    List<int> requestProgramIds = null,
    long? requestStaffId = null,
    DateTime? requestStartClassDateTime = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestClassDescriptionId` | `int?` | Query, Optional | The ID of the requested client. |
| `requestEndClassDateTime` | `DateTime?` | Query, Optional | Filters the results to class descriptions for scheduled classes that happen before the given date and time. |
| `requestIncludeInactive` | `bool?` | Query, Optional | Includes inactive class descriptions, defaulting to true. When set to false, it filters out inactive class descriptions. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `int?` | Query, Optional | Filters results to classes descriptions for schedule classes as the given location. |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestProgramIds` | `List<int>` | Query, Optional | A list of requested program IDs. |
| `requestStaffId` | `long?` | Query, Optional | Filters results to class descriptions for scheduled classes taught by the given staff member. |
| `requestStartClassDateTime` | `DateTime?` | Query, Optional | Filters the results to class descriptions for scheduled classes that happen on or after the given date and time. |

## Response Type

[`Task<Models.GetClassDescriptionsResponse>`](../../doc/models/get-class-descriptions-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
int? requestClassDescriptionId = 62;
DateTime? requestEndClassDateTime = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
bool? requestIncludeInactive = false;
int? requestLimit = 62;
int? requestLocationId = 90;
int? requestOffset = 100;
List<int> requestProgramIds = new List<int>
{
    91,
    92,
    93,
};

long? requestStaffId = 180L;
DateTime? requestStartClassDateTime = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
try
{
    GetClassDescriptionsResponse result = await classController.GetClassDescriptionsAsync(
        version,
        siteId,
        authorization,
        requestClassDescriptionId,
        requestEndClassDateTime,
        requestIncludeInactive,
        requestLimit,
        requestLocationId,
        requestOffset,
        requestProgramIds,
        requestStaffId,
        requestStartClassDateTime
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Classes

Get scheduled classes.

```csharp
GetClassesAsync(
    string version,
    string siteId,
    string authorization = null,
    List<int> requestClassDescriptionIds = null,
    List<int> requestClassIds = null,
    List<int> requestClassScheduleIds = null,
    string requestClientId = null,
    DateTime? requestEndDateTime = null,
    bool? requestHideCanceledClasses = null,
    DateTime? requestLastModifiedDate = null,
    int? requestLimit = null,
    List<int> requestLocationIds = null,
    int? requestOffset = null,
    List<int> requestProgramIds = null,
    bool? requestSchedulingWindow = null,
    List<int> requestSemesterIds = null,
    List<int> requestSessionTypeIds = null,
    List<long> requestStaffIds = null,
    DateTime? requestStartDateTime = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestClassDescriptionIds` | `List<int>` | Query, Optional | The requested class description IDs. |
| `requestClassIds` | `List<int>` | Query, Optional | The requested class IDs. |
| `requestClassScheduleIds` | `List<int>` | Query, Optional | The requested classSchedule Ids. |
| `requestClientId` | `string` | Query, Optional | The client ID of the client who is viewing this class list. Based on identity, the client may be able to see additional information, such as membership specials. |
| `requestEndDateTime` | `DateTime?` | Query, Optional | The requested end date for filtering.<br><br />Default: **today’s date** |
| `requestHideCanceledClasses` | `bool?` | Query, Optional | When `true`, canceled classes are removed from the response.<br /><br>When `false`, canceled classes are included in the response.<br /><br>Default: **false** |
| `requestLastModifiedDate` | `DateTime?` | Query, Optional | When included in the request, only records modified on or after the `LastModifiedDate` specified are included in the response. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationIds` | `List<int>` | Query, Optional | A list of location IDs on which to base the search. |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestProgramIds` | `List<int>` | Query, Optional | A list of program IDs on which to base the search. |
| `requestSchedulingWindow` | `bool?` | Query, Optional | When `true`, classes outside scheduling window are removed from the response.<br /><br>When `false`, classes are included in the response, regardless of the scheduling window.<br /><br>Default: **false** |
| `requestSemesterIds` | `List<int>` | Query, Optional | A list of semester IDs on which to base the search. |
| `requestSessionTypeIds` | `List<int>` | Query, Optional | A list of session type IDs on which to base the search. |
| `requestStaffIds` | `List<long>` | Query, Optional | The requested IDs of the teaching staff members. |
| `requestStartDateTime` | `DateTime?` | Query, Optional | The requested start date for filtering. This also determines what you will see for the ‘BookingWindow’ StartDateTime in the response. For example, if you pass a StartDateTime that is on OR before the BookingWindow ‘Open’ days of the class, you will retrieve the actual ‘StartDateTime’ for the Booking Window. If you pass a StartDateTime that is after the BookingWindow ‘date’, then you will receive results based on that start date. |

## Response Type

[`Task<Models.GetClassesResponse>`](../../doc/models/get-classes-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
List<int> requestClassDescriptionIds = new List<int>
{
    107,
    108,
};

List<int> requestClassIds = new List<int>
{
    87,
    88,
    89,
};

List<int> requestClassScheduleIds = new List<int>
{
    149,
    150,
    151,
};

string requestClientId = "request.clientId2";
DateTime? requestEndDateTime = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
bool? requestHideCanceledClasses = false;
DateTime? requestLastModifiedDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
int? requestLimit = 62;
List<int> requestLocationIds = new List<int>
{
    192,
};

int? requestOffset = 100;
List<int> requestProgramIds = new List<int>
{
    91,
    92,
    93,
};

bool? requestSchedulingWindow = false;
List<int> requestSemesterIds = new List<int>
{
    251,
    252,
};

List<int> requestSessionTypeIds = new List<int>
{
    228,
    229,
};

List<long> requestStaffIds = new List<long>
{
    23L,
    24L,
    25L,
};

DateTime? requestStartDateTime = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
try
{
    GetClassesResponse result = await classController.GetClassesAsync(
        version,
        siteId,
        authorization,
        requestClassDescriptionIds,
        requestClassIds,
        requestClassScheduleIds,
        requestClientId,
        requestEndDateTime,
        requestHideCanceledClasses,
        requestLastModifiedDate,
        requestLimit,
        requestLocationIds,
        requestOffset,
        requestProgramIds,
        requestSchedulingWindow,
        requestSemesterIds,
        requestSessionTypeIds,
        requestStaffIds,
        requestStartDateTime
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Class Schedules

Get class schedules.

```csharp
GetClassSchedulesAsync(
    string version,
    string siteId,
    string authorization = null,
    List<int> requestClassScheduleIds = null,
    DateTime? requestEndDate = null,
    int? requestLimit = null,
    List<int> requestLocationIds = null,
    int? requestOffset = null,
    List<int> requestProgramIds = null,
    List<int> requestSessionTypeIds = null,
    List<long> requestStaffIds = null,
    DateTime? requestStartDate = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestClassScheduleIds` | `List<int>` | Query, Optional | The class schedule IDs.<br><br />Default: **all** |
| `requestEndDate` | `DateTime?` | Query, Optional | The end date of the range. Return any active enrollments that occur on or before this day.<br><br />Default: **StartDate** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationIds` | `List<int>` | Query, Optional | The location IDs.<br><br />Default: **all** |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestProgramIds` | `List<int>` | Query, Optional | The program IDs.<br><br />Default: **all** |
| `requestSessionTypeIds` | `List<int>` | Query, Optional | The session type IDs.<br><br />Default: **all** |
| `requestStaffIds` | `List<long>` | Query, Optional | The staff IDs.<br><br />Default: **all** |
| `requestStartDate` | `DateTime?` | Query, Optional | The start date of the range. Return any active enrollments that occur on or after this day.<br><br />Default: **today’s date** |

## Response Type

[`Task<Models.GetClassSchedulesResponse>`](../../doc/models/get-class-schedules-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
List<int> requestClassScheduleIds = new List<int>
{
    149,
    150,
    151,
};

DateTime? requestEndDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
int? requestLimit = 62;
List<int> requestLocationIds = new List<int>
{
    192,
};

int? requestOffset = 100;
List<int> requestProgramIds = new List<int>
{
    91,
    92,
    93,
};

List<int> requestSessionTypeIds = new List<int>
{
    228,
    229,
};

List<long> requestStaffIds = new List<long>
{
    23L,
    24L,
    25L,
};

DateTime? requestStartDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
try
{
    GetClassSchedulesResponse result = await classController.GetClassSchedulesAsync(
        version,
        siteId,
        authorization,
        requestClassScheduleIds,
        requestEndDate,
        requestLimit,
        requestLocationIds,
        requestOffset,
        requestProgramIds,
        requestSessionTypeIds,
        requestStaffIds,
        requestStartDate
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Class Visits

Returns a list of visits that contain information for a specified class. On success, this request returns the class object in the response with a list of visits.

```csharp
GetClassVisitsAsync(
    string version,
    long requestClassID,
    string siteId,
    string authorization = null,
    DateTime? requestLastModifiedDate = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClassID` | `long` | Query, Required | The class ID. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestLastModifiedDate` | `DateTime?` | Query, Optional | When included in the request, only records modified on or after the `LastModifiedDate` specified are included in the response. |

## Response Type

[`Task<Models.GetClassVisitsResponse>`](../../doc/models/get-class-visits-response.md)

## Example Usage

```csharp
string version = "6";
long requestClassID = 222L;
string siteId = "-99";
string authorization = "authorization6";
DateTime? requestLastModifiedDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
try
{
    GetClassVisitsResponse result = await classController.GetClassVisitsAsync(
        version,
        requestClassID,
        siteId,
        authorization,
        requestLastModifiedDate
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Courses

This endpoint will provide all the data related to courses depending on the access level.<br />
Note: The Authorization is an optional header.If Authorization header is not passed, the response will be masked else full response will be provided.

```csharp
GetCoursesAsync(
    string version,
    string siteId,
    string authorization = null,
    List<long> getCoursesRequestCourseIDs = null,
    DateTime? getCoursesRequestEndDate = null,
    int? getCoursesRequestLimit = null,
    List<int> getCoursesRequestLocationIDs = null,
    int? getCoursesRequestOffset = null,
    List<int> getCoursesRequestProgramIDs = null,
    List<int> getCoursesRequestSemesterIDs = null,
    List<long> getCoursesRequestStaffIDs = null,
    DateTime? getCoursesRequestStartDate = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `getCoursesRequestCourseIDs` | `List<long>` | Query, Optional | Return only courses that are available for the specified CourseIds. |
| `getCoursesRequestEndDate` | `DateTime?` | Query, Optional | The end date range. Any active courses that are on or before this day.<br><br />(optional) Defaults to StartDate. |
| `getCoursesRequestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `getCoursesRequestLocationIDs` | `List<int>` | Query, Optional | Return only courses that are available for the specified LocationIds. |
| `getCoursesRequestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `getCoursesRequestProgramIDs` | `List<int>` | Query, Optional | Return only courses that are available for the specified ProgramIds. |
| `getCoursesRequestSemesterIDs` | `List<int>` | Query, Optional | Return only courses that are available for the specified SemesterIds. |
| `getCoursesRequestStaffIDs` | `List<long>` | Query, Optional | Return only courses that are available for the specified StaffIds. |
| `getCoursesRequestStartDate` | `DateTime?` | Query, Optional | The start date range. Any active courses that are on or after this day.<br><br />(optional) Defaults to today. |

## Response Type

[`Task<Models.GetCoursesReponse>`](../../doc/models/get-courses-reponse.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
List<long> getCoursesRequestCourseIDs = new List<long>
{
    11L,
    12L,
    13L,
};

DateTime? getCoursesRequestEndDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
int? getCoursesRequestLimit = 158;
List<int> getCoursesRequestLocationIDs = new List<int>
{
    175,
    176,
};

int? getCoursesRequestOffset = 92;
List<int> getCoursesRequestProgramIDs = new List<int>
{
    250,
};

List<int> getCoursesRequestSemesterIDs = new List<int>
{
    73,
    74,
    75,
};

List<long> getCoursesRequestStaffIDs = new List<long>
{
    73L,
};

DateTime? getCoursesRequestStartDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
try
{
    GetCoursesReponse result = await classController.GetCoursesAsync(
        version,
        siteId,
        authorization,
        getCoursesRequestCourseIDs,
        getCoursesRequestEndDate,
        getCoursesRequestLimit,
        getCoursesRequestLocationIDs,
        getCoursesRequestOffset,
        getCoursesRequestProgramIDs,
        getCoursesRequestSemesterIDs,
        getCoursesRequestStaffIDs,
        getCoursesRequestStartDate
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Semesters

This endpoint retrieves the business class semesters.

```csharp
GetSemestersAsync(
    string version,
    string siteId,
    string authorization = null,
    bool? requestActive = null,
    DateTime? requestEndDate = null,
    int? requestLimit = null,
    int? requestOffset = null,
    List<int> requestSemesterIDs = null,
    DateTime? requestStartDate = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestActive` | `bool?` | Query, Optional | When true, the response only contains semesters which are activated. When false, only deactivated semesters are returned.<br>Default: **All semesters** |
| `requestEndDate` | `DateTime?` | Query, Optional | The end date for the range. All semesters that are on or before this day.<br>Default: **StartDate** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestSemesterIDs` | `List<int>` | Query, Optional | The requested semester IDs. |
| `requestStartDate` | `DateTime?` | Query, Optional | The start date for the range. All semesters that are on or after this day.<br>Default: **today’s date** |

## Response Type

[`Task<Models.GetSemestersResponse>`](../../doc/models/get-semesters-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
bool? requestActive = false;
DateTime? requestEndDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
int? requestLimit = 62;
int? requestOffset = 100;
List<int> requestSemesterIDs = new List<int>
{
    126,
};

DateTime? requestStartDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
try
{
    GetSemestersResponse result = await classController.GetSemestersAsync(
        version,
        siteId,
        authorization,
        requestActive,
        requestEndDate,
        requestLimit,
        requestOffset,
        requestSemesterIDs,
        requestStartDate
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Waitlist Entries

Returns a list of waiting list entries for a specified class schedule or class. The request requires staff credentials and either a class schedule ID or class ID.

```csharp
GetWaitlistEntriesAsync(
    string version,
    string siteId,
    string authorization = null,
    List<int> requestClassIds = null,
    List<int> requestClassScheduleIds = null,
    List<string> requestClientIds = null,
    bool? requestHidePastEntries = null,
    int? requestLimit = null,
    int? requestOffset = null,
    List<int> requestWaitlistEntryIds = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestClassIds` | `List<int>` | Query, Optional | The requested class IDs. If a class ID is present, the request automatically disregards any class schedule IDs in the request. <br /><br>Either `ClassScheduleIds`, `ClientIds`, `WaitlistEntryIds`, or `ClassIds` is required; the others become optional.<br /><br>Default: **all ClassIds** |
| `requestClassScheduleIds` | `List<int>` | Query, Optional | The requested class schedule IDs. If a class ID is present, the request automatically disregards any class schedule IDs in the request.<br /><br>Either `ClassScheduleIds`, `ClientIds`, `WaitlistEntryIds`, or `ClassIds` is required; the others become optional.<br /><br>Default: **all ClassScheduleIds** |
| `requestClientIds` | `List<string>` | Query, Optional | The requested client IDs.<br /><br>Either `ClassScheduleIds`, `ClientIds`, `WaitlistEntryIds`, or `ClassIds` is required; the others become optional.<br /><br>Default: **all ClientIds** |
| `requestHidePastEntries` | `bool?` | Query, Optional | When `true`, indicates that past waiting list entries are hidden from clients.<br /><br>When `false`, indicates that past entries are not hidden from clients.<br /><br>Default: **false** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestWaitlistEntryIds` | `List<int>` | Query, Optional | The requested waiting list entry IDs.<br /><br>Either `ClassScheduleIds`, `ClientIds`, `WaitlistEntryIds`, or `ClassIds` is required; the others become optional.<br /><br>Default: **all WaitlistEntryIds** |

## Response Type

[`Task<Models.GetWaitlistEntriesResponse>`](../../doc/models/get-waitlist-entries-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
List<int> requestClassIds = new List<int>
{
    87,
    88,
    89,
};

List<int> requestClassScheduleIds = new List<int>
{
    149,
    150,
    151,
};

List<string> requestClientIds = new List<string>
{
    "request.clientIds9",
    "request.clientIds0",
    "request.clientIds1",
};

bool? requestHidePastEntries = false;
int? requestLimit = 62;
int? requestOffset = 100;
List<int> requestWaitlistEntryIds = new List<int>
{
    138,
    139,
};

try
{
    GetWaitlistEntriesResponse result = await classController.GetWaitlistEntriesAsync(
        version,
        siteId,
        authorization,
        requestClassIds,
        requestClassScheduleIds,
        requestClientIds,
        requestHidePastEntries,
        requestLimit,
        requestOffset,
        requestWaitlistEntryIds
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Add Class Schedule

This endpoint adds a class schedule. For a single day schedule, the EndDate parameter can be omitted.

```csharp
AddClassScheduleAsync(
    string version,
    Models.AddClassEnrollmentScheduleRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`AddClassEnrollmentScheduleRequest`](../../doc/models/add-class-enrollment-schedule-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.WrittenClassSchedulesInfo>`](../../doc/models/written-class-schedules-info.md)

## Example Usage

```csharp
string version = "6";
AddClassEnrollmentScheduleRequest request = new AddClassEnrollmentScheduleRequest
{
    ClassDescriptionId = 66,
    LocationId = 238,
    StartDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind),
    EndDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind),
    StartTime = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind),
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    WrittenClassSchedulesInfo result = await classController.AddClassScheduleAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Add Client to Class

This endpoint adds a client to a class or to a class waiting list. To prevent overbooking a class or booking outside the schedule windows set forth by the business, it is necessary to first check the capacity level of the class (‘MaxCapacity’ and 'TotalBooked’) and the 'IsAvailable’ parameter by running the GetClasses REQUEST. It is helpful to use this endpoint in the following situations:

* Use after calling `GET Clients` and `GET Classes` so that you are sure which client to book in which class.
* If adding a client to a class from a waiting list, use this call after you call `GET WaitlistEntries` and determine the ID of the waiting list from which you are moving the client.
* If adding a client to a class and using a pricing option that the client has already purchased, use this call after you call `GET ClientServices` to determine the ID of the pricing option that the client wants to use.

If you add a client to a class and the client purchases a new pricing option, use `GET Services`, `GET Classes`, and then `POST CheckoutShoppingCart` in place of this call.

This endpoint also supports cross-regional class bookings. If you want to perform a cross-regional class booking, set `CrossRegionalBooking` to `true`. This endpoint does not support adding a user to a waiting list using a cross-regional client pricing option(service). Cross-regional booking workflows do not support client service scheduling restrictions.

When performing a cross-regional class booking, this endpoint loops through the first ten sites that the client is associated with, looks for client pricing options at each of those sites, and then uses the oldest client pricing option found.It is important to note that this endpoint only loops through a maximum of ten associated client sites. If a `ClientID` is associated with more than ten sites in an organization, this endpoint only loops through the first ten.If you know that a client has a client service at another site, you can specify that site using the `CrossRegionalBookingClientServiceSiteId` query parameter.

If you perform a cross-regional booking, two additional fields are included in the `SessionType` object of the response:

* `SiteID`, which specifies where the client service is coming from
* `CrossRegionalBookingPerformed`, a Boolean field that is set to `true`

As a prerequisite to using this endpoint, your `SourceName` must have been granted access to the organization to which the site belongs.

```csharp
AddClientToClassAsync(
    string version,
    Models.AddClientToClassRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`AddClientToClassRequest`](../../doc/models/add-client-to-class-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.AddClientToClassResponse>`](../../doc/models/add-client-to-class-response.md)

## Example Usage

```csharp
string version = "6";
AddClientToClassRequest request = new AddClientToClassRequest
{
    ClientId = "ClientId0",
    ClassId = 90,
    Test = false,
    RequirePayment = false,
    Waitlist = false,
    SendEmail = false,
    WaitlistEntryId = 54,
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    AddClientToClassResponse result = await classController.AddClientToClassAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Cancel Single Class

This endpoint will cancel a single class from studio.

```csharp
CancelSingleClassAsync(
    string version,
    Models.CancelSingleClassRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`CancelSingleClassRequest`](../../doc/models/cancel-single-class-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.CancelSingleClassResponse>`](../../doc/models/cancel-single-class-response.md)

## Example Usage

```csharp
string version = "6";
CancelSingleClassRequest request = new CancelSingleClassRequest
{
    ClassID = 30L,
    HideCancel = false,
    SendClientEmail = false,
    SendStaffEmail = false,
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    CancelSingleClassResponse result = await classController.CancelSingleClassAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Remove Client From Class

Remove a client from a class.

```csharp
RemoveClientFromClassAsync(
    string version,
    Models.RemoveClientFromClassRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`RemoveClientFromClassRequest`](../../doc/models/remove-client-from-class-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.RemoveClientFromClassResponse>`](../../doc/models/remove-client-from-class-response.md)

## Example Usage

```csharp
string version = "6";
RemoveClientFromClassRequest request = new RemoveClientFromClassRequest
{
    ClientId = "ClientId0",
    ClassId = 90,
    Test = false,
    SendEmail = false,
    LateCancel = false,
    VisitId = 92,
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    RemoveClientFromClassResponse result = await classController.RemoveClientFromClassAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Remove Clients From Classes

This endpoint can be utilized for removing multiple clients from multiple classes in one request.

```csharp
RemoveClientsFromClassesAsync(
    string version,
    Models.RemoveClientsFromClassesRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`RemoveClientsFromClassesRequest`](../../doc/models/remove-clients-from-classes-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.RemoveClientsFromClassesResponse>`](../../doc/models/remove-clients-from-classes-response.md)

## Example Usage

```csharp
string version = "6";
RemoveClientsFromClassesRequest request = new RemoveClientsFromClassesRequest
{
    Details = new List<ClassClientDetail>
    {
        new ClassClientDetail
        {
            ClientIds = new List<string>
            {
                "ClientIds5",
            },
            ClassId = 190,
        },
        new ClassClientDetail
        {
            ClientIds = new List<string>
            {
                "ClientIds5",
            },
            ClassId = 190,
        },
    },
    Test = false,
    SendEmail = false,
    LateCancel = false,
    Limit = 32,
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    RemoveClientsFromClassesResponse result = await classController.RemoveClientsFromClassesAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Remove From Waitlist

This endpoint does not return a response. If a call to this endpoint results in a 200 OK HTTP status code, then the call was successful.

```csharp
RemoveFromWaitlistAsync(
    string version,
    List<int> requestWaitlistEntryIds,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestWaitlistEntryIds` | `List<int>` | Query, Required | A list of `WaitlistEntryIds` to remove from the waiting list. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`Task<object>`

## Example Usage

```csharp
string version = "6";
List<int> requestWaitlistEntryIds = new List<int>
{
    138,
    139,
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    object result = await classController.RemoveFromWaitlistAsync(
        version,
        requestWaitlistEntryIds,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Substitute Class Teacher

Substitute a class teacher.

```csharp
SubstituteClassTeacherAsync(
    string version,
    Models.SubstituteClassTeacherRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`SubstituteClassTeacherRequest`](../../doc/models/substitute-class-teacher-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.SubstituteClassTeacherResponse>`](../../doc/models/substitute-class-teacher-response.md)

## Example Usage

```csharp
string version = "6";
SubstituteClassTeacherRequest request = new SubstituteClassTeacherRequest
{
    ClassId = 90,
    StaffId = 188L,
    OverrideConflicts = false,
    SendClientEmail = false,
    SendOriginalTeacherEmail = false,
    SendSubstituteTeacherEmail = false,
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    SubstituteClassTeacherResponse result = await classController.SubstituteClassTeacherAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Update Class Schedule

This endpoint updates a class schedule.

```csharp
UpdateClassScheduleAsync(
    string version,
    Models.UpdateClassEnrollmentScheduleRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`UpdateClassEnrollmentScheduleRequest`](../../doc/models/update-class-enrollment-schedule-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.WrittenClassSchedulesInfo>`](../../doc/models/written-class-schedules-info.md)

## Example Usage

```csharp
string version = "6";
UpdateClassEnrollmentScheduleRequest request = new UpdateClassEnrollmentScheduleRequest
{
    ClassId = 90,
    ClassDescriptionId = 66,
    LocationId = 238,
    StartDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind),
    EndDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind),
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    WrittenClassSchedulesInfo result = await classController.UpdateClassScheduleAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

