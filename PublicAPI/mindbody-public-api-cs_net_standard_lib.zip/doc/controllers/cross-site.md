# Cross Site

```csharp
CrossSiteController crossSiteController = client.CrossSiteController;
```

## Class Name

`CrossSiteController`


# Copy Credit Card

Copies the credit card information from one client to another, regardless of site.
The source and target clients must have the same email address.

```csharp
CopyCreditCardAsync(
    string version,
    Models.CopyCreditCardRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`CopyCreditCardRequest`](../../doc/models/copy-credit-card-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.CopyCreditCardResponse>`](../../doc/models/copy-credit-card-response.md)

## Example Usage

```csharp
string version = "6";
CopyCreditCardRequest request = new CopyCreditCardRequest
{
    SourceSiteId = 42,
    SourceClientId = "SourceClientId8",
    TargetSiteId = 26,
    TargetClientId = "TargetClientId8",
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    CopyCreditCardResponse result = await crossSiteController.CopyCreditCardAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

