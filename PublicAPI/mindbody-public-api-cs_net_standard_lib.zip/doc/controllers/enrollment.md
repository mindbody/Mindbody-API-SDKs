# Enrollment

```csharp
EnrollmentController enrollmentController = client.EnrollmentController;
```

## Class Name

`EnrollmentController`

## Methods

* [Get Enrollments](../../doc/controllers/enrollment.md#get-enrollments)
* [Add Client to Enrollment](../../doc/controllers/enrollment.md#add-client-to-enrollment)
* [Add Enrollment Schedule](../../doc/controllers/enrollment.md#add-enrollment-schedule)
* [Update Enrollment Schedule](../../doc/controllers/enrollment.md#update-enrollment-schedule)


# Get Enrollments

Returns a list of enrollments. An enrollment is a service, such as a workshop or an event, that a staff member offers to multiple students, who commit to coming to all or most of the scheduled sessions. Enrollments typically run for a limited time only.

When a user token is not passed with the request or the passed user token has insufficient viewing permissions, only the following staff data is returned in the response:

* FirstName
* LastName
* Id
* Bio
* DisplayName
* ImageUrl

```csharp
GetEnrollmentsAsync(
    string version,
    string siteId,
    string authorization = null,
    List<int> requestClassScheduleIds = null,
    DateTime? requestEndDate = null,
    int? requestLimit = null,
    List<int> requestLocationIds = null,
    int? requestOffset = null,
    List<int> requestProgramIds = null,
    List<int> requestSessionTypeIds = null,
    List<long> requestStaffIds = null,
    DateTime? requestStartDate = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestClassScheduleIds` | `List<int>` | Query, Optional | A list of the requested class schedule IDs. If omitted, all class schedule IDs return. |
| `requestEndDate` | `DateTime?` | Query, Optional | The end of the date range. The response returns any active enrollments that occur on or before this day.<br /><br>Default: **StartDate** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationIds` | `List<int>` | Query, Optional | List of the IDs for the requested locations. If omitted, all location IDs return. |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestProgramIds` | `List<int>` | Query, Optional | List of the IDs for the requested programs. If omitted, all program IDs return. |
| `requestSessionTypeIds` | `List<int>` | Query, Optional | List of the IDs for the requested session types. If omitted, all session types IDs return. |
| `requestStaffIds` | `List<long>` | Query, Optional | List of the IDs for the requested staff IDs. If omitted, all staff IDs return. |
| `requestStartDate` | `DateTime?` | Query, Optional | The start of the date range. The response returns any active enrollments that occur on or after this day.<br /><br>Default: **today’s date** |

## Response Type

[`Task<Models.GetEnrollmentsResponse>`](../../doc/models/get-enrollments-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
List<int> requestClassScheduleIds = new List<int>
{
    149,
    150,
    151,
};

DateTime? requestEndDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
int? requestLimit = 62;
List<int> requestLocationIds = new List<int>
{
    192,
};

int? requestOffset = 100;
List<int> requestProgramIds = new List<int>
{
    91,
    92,
    93,
};

List<int> requestSessionTypeIds = new List<int>
{
    228,
    229,
};

List<long> requestStaffIds = new List<long>
{
    23L,
    24L,
    25L,
};

DateTime? requestStartDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
try
{
    GetEnrollmentsResponse result = await enrollmentController.GetEnrollmentsAsync(
        version,
        siteId,
        authorization,
        requestClassScheduleIds,
        requestEndDate,
        requestLimit,
        requestLocationIds,
        requestOffset,
        requestProgramIds,
        requestSessionTypeIds,
        requestStaffIds,
        requestStartDate
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Add Client to Enrollment

Book a client into an enrollment.

```csharp
AddClientToEnrollmentAsync(
    string version,
    Models.AddClientToEnrollmentRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`AddClientToEnrollmentRequest`](../../doc/models/add-client-to-enrollment-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.ClassSchedule>`](../../doc/models/class-schedule.md)

## Example Usage

```csharp
string version = "6";
AddClientToEnrollmentRequest request = new AddClientToEnrollmentRequest
{
    ClientId = "ClientId0",
    ClassScheduleId = 36,
    EnrollDateForward = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind),
    EnrollOpen = new List<DateTime>
    {
        DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
            provider: CultureInfo.InvariantCulture,
            DateTimeStyles.RoundtripKind),
    },
    Test = false,
    SendEmail = false,
    Waitlist = false,
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    ClassSchedule result = await enrollmentController.AddClientToEnrollmentAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Add Enrollment Schedule

This endpoint adds a enrollment schedule. You can require clients to sign up for the entire enrollment schedule or allow them to pick specific sessions using the AllowOpenEnrollment parameter.

```csharp
AddEnrollmentScheduleAsync(
    string version,
    Models.AddClassEnrollmentScheduleRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`AddClassEnrollmentScheduleRequest`](../../doc/models/add-class-enrollment-schedule-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.WrittenClassSchedulesInfo>`](../../doc/models/written-class-schedules-info.md)

## Example Usage

```csharp
string version = "6";
AddClassEnrollmentScheduleRequest request = new AddClassEnrollmentScheduleRequest
{
    ClassDescriptionId = 66,
    LocationId = 238,
    StartDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind),
    EndDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind),
    StartTime = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind),
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    WrittenClassSchedulesInfo result = await enrollmentController.AddEnrollmentScheduleAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Update Enrollment Schedule

This endpoint update a enrollment schedule.

```csharp
UpdateEnrollmentScheduleAsync(
    string version,
    Models.UpdateClassEnrollmentScheduleRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`UpdateClassEnrollmentScheduleRequest`](../../doc/models/update-class-enrollment-schedule-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.WrittenClassSchedulesInfo>`](../../doc/models/written-class-schedules-info.md)

## Example Usage

```csharp
string version = "6";
UpdateClassEnrollmentScheduleRequest request = new UpdateClassEnrollmentScheduleRequest
{
    ClassId = 90,
    ClassDescriptionId = 66,
    LocationId = 238,
    StartDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind),
    EndDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind),
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    WrittenClassSchedulesInfo result = await enrollmentController.UpdateEnrollmentScheduleAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

