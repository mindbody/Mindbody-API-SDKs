
# Copy Credit Card Request

crosssite/copycreditcard

## Structure

`CopyCreditCardRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SourceSiteId` | `int?` | Optional | The siteId of the source clientId. |
| `SourceClientId` | `string` | Optional | The clientId at the source siteId. |
| `TargetSiteId` | `int?` | Optional | The siteId of the target clientId. |
| `TargetClientId` | `string` | Optional | The clientId at the target siteId. |

## Example (as JSON)

```json
{
  "SourceSiteId": 96,
  "SourceClientId": "SourceClientId8",
  "TargetSiteId": 228,
  "TargetClientId": "TargetClientId2"
}
```

