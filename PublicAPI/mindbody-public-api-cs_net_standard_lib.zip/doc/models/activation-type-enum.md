
# Activation Type Enum

Specifies how this pricing option is configured to activate.
<para>
This value reflects the activation behavior defined in the Core system when the pricing option was created.
Use this field to determine whether the {Mindbody.PublicApi.Dto.Models.V6.ClientService.ActiveDate} represents the purchase date
or a future date pending the client's first visit.
</para><para>
Possible values:
<list type="bullet"><item><term>OnFirstVisit</term><description>
The pricing option activates on the client's first visit (check-in) after purchase.
The {Mindbody.PublicApi.Dto.Models.V6.ClientService.ActiveDate} is set to the date of that first visit.
Until the client checks in, the {Mindbody.PublicApi.Dto.Models.V6.ClientService.ActiveDate} may be null or set to a future/placeholder date.
</description></item><item><term>OnPurchase</term><description>
The pricing option activates immediately upon purchase.
The {Mindbody.PublicApi.Dto.Models.V6.ClientService.ActiveDate} is set to the purchase date.
</description></item></list></para>

## Enumeration

`ActivationTypeEnum`

## Fields

| Name |
|  --- |
| `OnFirstVisit` |
| `OnPurchase` |

