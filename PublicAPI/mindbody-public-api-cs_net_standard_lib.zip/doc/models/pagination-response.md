
# Pagination Response

Contains information about the pagination to use.

## Structure

`PaginationResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `RequestedLimit` | `int?` | Optional | Limit from pagination request |
| `RequestedOffset` | `int?` | Optional | Offset from pagination request |
| `PageSize` | `int?` | Optional | Number of results returned in this response |
| `TotalResults` | `int?` | Optional | Total number of results in dataset |

## Example (as JSON)

```json
{
  "RequestedLimit": 22,
  "RequestedOffset": 0,
  "PageSize": 172,
  "TotalResults": 112
}
```

