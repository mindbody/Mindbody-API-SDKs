
# Checkout Item Wrapper

## Structure

`CheckoutItemWrapper`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Item` | [`CheckoutItem`](../../doc/models/checkout-item.md) | Optional | - |
| `SalesNotes` | `string` | Optional | Sales Notes for the product |
| `DiscountAmount` | `double?` | Optional | The amount the item is discounted. This parameter is ignored for packages. |
| `AppointmentBookingRequests` | [`List<CheckoutAppointmentBookingRequest>`](../../doc/models/checkout-appointment-booking-request.md) | Optional | A list of appointments to be booked then paid for by this item. This parameter applies only to pricing option items. |
| `EnrollmentIds` | `List<int>` | Optional | A list of enrollment IDs that this item is to pay for. This parameter applies only to pricing option items. |
| `ClassIds` | `List<int>` | Optional | A list of class IDs that this item is to pay for. This parameter applies only to pricing option items. |
| `CourseIds` | `List<long>` | Optional | A list of course IDs that this item is to pay for. This parameter applies only to pricing option items. |
| `VisitIds` | `List<long>` | Optional | A list of visit IDs that this item is to pay for. This parameter applies only to pricing option items. |
| `AppointmentIds` | `List<long>` | Optional | A list of appointment IDs that this item is to reconcile. |
| `Id` | `int?` | Optional | The item’s unique ID within the cart. |
| `Quantity` | `int?` | Optional | The number of this item to be purchased. |

## Example (as JSON)

```json
{
  "Item": {
    "Type": "Type2",
    "Metadata": {
      "key0": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  },
  "SalesNotes": "SalesNotes8",
  "DiscountAmount": 177.3,
  "AppointmentBookingRequests": [
    {
      "StaffId": 16,
      "LocationId": 66,
      "SessionTypeId": 166,
      "Resources": [
        {
          "Id": 216,
          "Name": "Name6"
        },
        {
          "Id": 216,
          "Name": "Name6"
        },
        {
          "Id": 216,
          "Name": "Name6"
        }
      ],
      "StartDateTime": "2016-03-13T12:52:32.123Z"
    },
    {
      "StaffId": 16,
      "LocationId": 66,
      "SessionTypeId": 166,
      "Resources": [
        {
          "Id": 216,
          "Name": "Name6"
        },
        {
          "Id": 216,
          "Name": "Name6"
        },
        {
          "Id": 216,
          "Name": "Name6"
        }
      ],
      "StartDateTime": "2016-03-13T12:52:32.123Z"
    },
    {
      "StaffId": 16,
      "LocationId": 66,
      "SessionTypeId": 166,
      "Resources": [
        {
          "Id": 216,
          "Name": "Name6"
        },
        {
          "Id": 216,
          "Name": "Name6"
        },
        {
          "Id": 216,
          "Name": "Name6"
        }
      ],
      "StartDateTime": "2016-03-13T12:52:32.123Z"
    }
  ],
  "EnrollmentIds": [
    19
  ]
}
```

