
# Location 1

## Structure

`Location1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BusinessId` | `int?` | Optional | - |
| `SiteId` | `int?` | Optional | - |
| `BusinessDescription` | `string` | Optional | - |
| `AdditionalImageURLs` | `List<string>` | Optional | - |
| `FacilitySquareFeet` | `int?` | Optional | - |
| `ProSpaFinderSite` | `bool?` | Optional | - |
| `HasClasses` | `bool?` | Optional | - |
| `PhoneExtension` | `string` | Optional | - |
| `Action` | [`ActionEnum?`](../../doc/models/action-enum.md) | Optional | - |
| `Id` | `int?` | Optional | - |
| `Name` | `string` | Optional | - |
| `Address` | `string` | Optional | - |
| `Address2` | `string` | Optional | - |
| `Tax1` | `double?` | Optional | - |
| `Tax2` | `double?` | Optional | - |
| `Tax3` | `double?` | Optional | - |
| `Tax4` | `double?` | Optional | - |
| `Tax5` | `double?` | Optional | - |
| `Phone` | `string` | Optional | - |
| `City` | `string` | Optional | - |
| `StateProvCode` | `string` | Optional | - |
| `PostalCode` | `string` | Optional | - |
| `Latitude` | `double?` | Optional | - |
| `Longitude` | `double?` | Optional | - |
| `DistanceInMiles` | `double?` | Optional | - |
| `ImageURL` | `string` | Optional | - |
| `Description` | `string` | Optional | - |
| `HasSite` | `bool?` | Optional | - |
| `CanBook` | `bool?` | Optional | - |
| `NumberTreatmentRooms` | `int?` | Optional | - |
| `Active` | `bool?` | Optional | - |
| `InvActive` | `bool?` | Optional | - |
| `WsShow` | `bool?` | Optional | - |
| `Email` | `string` | Optional | - |
| `ContactName` | `string` | Optional | - |
| `ShipAddress` | `string` | Optional | - |
| `ShipState` | `string` | Optional | - |
| `ShipPostal` | `string` | Optional | - |
| `ShipPhone` | `string` | Optional | - |
| `ShipPOC` | `string` | Optional | - |
| `TaxGrouping` | `bool?` | Optional | - |
| `LabelTax1` | `string` | Optional | - |
| `LabelTax2` | `string` | Optional | - |
| `LabelTax3` | `string` | Optional | - |
| `LabelTax4` | `string` | Optional | - |
| `LabelTax5` | `string` | Optional | - |
| `WAC` | `bool?` | Optional | - |
| `ShipAddress2` | `string` | Optional | - |
| `MasterLocId` | `int?` | Optional | - |
| `StreetAddress` | `string` | Optional | - |
| `Country` | `string` | Optional | - |
| `Ext` | `string` | Optional | - |
| `Amenities` | [`List<Amenity1>`](../../doc/models/amenity-1.md) | Optional | - |
| `TotalNumberOfDeals` | `long?` | Optional | - |
| `TotalNumberOfRatings` | `int?` | Optional | - |
| `AverageRating` | `double?` | Optional | - |

## Example (as JSON)

```json
{
  "BusinessId": 192,
  "SiteId": 116,
  "BusinessDescription": "BusinessDescription4",
  "AdditionalImageURLs": [
    "AdditionalImageURLs6"
  ],
  "FacilitySquareFeet": 46
}
```

