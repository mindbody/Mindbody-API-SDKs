
# Payment Method Enum

The payment method.

## Enumeration

`PaymentMethodEnum`

## Fields

| Name |
|  --- |
| `Other` |
| `CreditCard` |
| `DebitAccount` |
| `ACH` |

