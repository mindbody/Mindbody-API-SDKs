
# Unavailability

## Structure

`Unavailability`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | The ID of the unavailability. |
| `StartDateTime` | `DateTime?` | Optional | The date and time the unavailability starts. |
| `EndDateTime` | `DateTime?` | Optional | The date and time the unavailability ends. |
| `Description` | `string` | Optional | A description of the unavailability. |

## Example (as JSON)

```json
{
  "Id": 248,
  "StartDateTime": "2016-03-13T12:52:32.123Z",
  "EndDateTime": "2016-03-13T12:52:32.123Z",
  "Description": "Description4"
}
```

