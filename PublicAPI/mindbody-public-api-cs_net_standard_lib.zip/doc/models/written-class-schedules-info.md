
# Written Class Schedules Info

## Structure

`WrittenClassSchedulesInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClassId` | `int?` | Optional | The ClassScheduleId. |
| `ClassInstanceIds` | `List<int>` | Optional | The individual ClassIds of the enrollment schedule. |

## Example (as JSON)

```json
{
  "ClassId": 220,
  "ClassInstanceIds": [
    95
  ]
}
```

