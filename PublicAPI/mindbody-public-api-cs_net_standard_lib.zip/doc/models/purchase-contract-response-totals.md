
# Purchase Contract Response Totals

Totals for the purchase

## Structure

`PurchaseContractResponseTotals`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Total` | `double?` | Optional | Total payment amount |
| `SubTotal` | `double?` | Optional | Sub total. For VAT, sum of asking prices (include taxes, excludes discounts). For non vat, excludes taxes and discounts. |
| `Discount` | `double?` | Optional | Discount |
| `Tax` | `double?` | Optional | Tax |

## Example (as JSON)

```json
{
  "Total": 58.52,
  "SubTotal": 16.62,
  "Discount": 230.64,
  "Tax": 195.98
}
```

