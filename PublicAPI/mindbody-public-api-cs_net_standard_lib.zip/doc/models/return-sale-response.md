
# Return Sale Response

ReturnSaleResponse

## Structure

`ReturnSaleResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ReturnSaleID` | `long?` | Optional | The returned sale ID |
| `TrainerID` | `long?` | Optional | The trainer ID who returned the sale |
| `Amount` | `double?` | Optional | The returned amount |

## Example (as JSON)

```json
{
  "ReturnSaleID": 144,
  "TrainerID": 120,
  "Amount": 181.0
}
```

