
# Appointment Status Enum

The status of the appointment.

## Enumeration

`AppointmentStatusEnum`

## Fields

| Name |
|  --- |
| `None` |
| `Requested` |
| `Booked` |
| `Completed` |
| `Confirmed` |
| `Arrived` |
| `NoShow` |
| `Cancelled` |
| `LateCancelled` |

