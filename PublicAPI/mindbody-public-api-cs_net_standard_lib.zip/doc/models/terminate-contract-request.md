
# Terminate Contract Request

## Structure

`TerminateContractRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClientId` | `string` | Required | The ID of the client. |
| `ClientContractId` | `int` | Required | The unique ID of the sale of the contract |
| `TerminationDate` | `DateTime` | Required | The contract termination date. |
| `TerminationCode` | `string` | Optional | ex. Illness, Injury, Moving, BreakingContract (Note this can be customized by each studio). |
| `TerminationComments` | `string` | Optional | The comments for terminating a contract. |

## Example (as JSON)

```json
{
  "ClientId": "ClientId2",
  "ClientContractId": 242,
  "TerminationDate": "2016-03-13T12:52:32.123Z",
  "TerminationCode": "TerminationCode8",
  "TerminationComments": "TerminationComments0"
}
```

