
# Initiate Purchase Contract Request

Request to initiate a purchase contract.

## Structure

`InitiatePurchaseContractRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Test` | `bool?` | Optional | When `true`, the Public API validates input information, but does not commit it, so no client data is affected.<br /><br>When `false` or omitted, the transaction is committed, and client data is affected.<br /><br>This endpoint DOES NOT support the `Test` parameter.<br /><br>Default: **false** |
| `LocationId` | `int` | Required | The ID of the location where the client is purchasing the contract; used for AutoPays. |
| `ClientId` | `string` | Required | The ID of the client. Note that this is not the same as the client’s unique ID. |
| `ContractId` | `int` | Required | The ID of the contract being purchased. |
| `PromotionCode` | `string` | Optional | A promotion code, if one applies. Promotion codes are applied to items that are both marked as pay now in a contract and are discounted by the promotion code. If a pay now item is an autopay item, its autopay price is the price at the time of checkout, so, if a promotion code was applied, all autopays are scheduled using that discounted price. |
| `PromotionCodes` | `List<string>` | Optional | Promotion codes, if they apply. Promotion codes are applied to items that are both marked as pay now in a contract and are discounted by the promotion code. If a pay now item is an autopay item, its autopay price is the price at the time of checkout, so, if a promotion code was applied, all autopays are scheduled using that discounted price. |
| `SendNotifications` | `bool?` | Optional | When `true`, indicates that email and SMS notifications should be sent to the client after purchase.<br /><br>Default: **true** |
| `SalesRepId` | `long?` | Optional | The ID of the staff member to be marked as the sales rep for this contract sale. |
| `PaymentAuthenticationCallbackUrl` | `string` | Optional | The URL consumer is redirected to after the payment. |
| `PaymentMethodId` | `int` | Required | The type of alternative payment. Possible values are:<br><br>* 997 - Indicates that the payment method is iDEAL.<br>* 801 - Indicates that the payment method is Apple Pay. |

## Example (as JSON)

```json
{
  "Test": false,
  "LocationId": 176,
  "ClientId": "ClientId8",
  "ContractId": 10,
  "PromotionCode": "PromotionCode4",
  "PromotionCodes": [
    "PromotionCodes3",
    "PromotionCodes4"
  ],
  "SendNotifications": false,
  "SalesRepId": 182,
  "PaymentMethodId": 222
}
```

