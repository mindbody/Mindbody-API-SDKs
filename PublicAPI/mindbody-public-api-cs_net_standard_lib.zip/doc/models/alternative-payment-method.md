
# Alternative Payment Method

DTO object for alternative payment methods.

## Structure

`AlternativePaymentMethod`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | The ID of the alternative payment method. |
| `Name` | `string` | Optional | The name of the alternative payment method. |

## Example (as JSON)

```json
{
  "Id": 24,
  "Name": "Name4"
}
```

