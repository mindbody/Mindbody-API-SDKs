
# Promo Code

## Structure

`PromoCode`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PromotionID` | `int?` | Optional | ID of the promo code |
| `Name` | `string` | Optional | Name of the promo code |
| `Code` | `string` | Optional | The code of the promocode. |
| `Active` | `bool?` | Optional | Indicates that promocode is active. |
| `Discount` | [`Discount`](../../doc/models/discount.md) | Optional | Discount for a promo code |
| `ActivationDate` | `DateTime?` | Optional | The promocode activation date. |
| `ExpirationDate` | `DateTime?` | Optional | The promocode expiration date. |
| `MaxUses` | `int?` | Optional | The maximun number of uses. |
| `NumberOfAutopays` | `int?` | Optional | Number of Autopays |
| `DaysAfterCloseDate` | `int?` | Optional | The number of days a client has to use a promocode after they are no longer a prospect. |
| `AllowOnline` | `bool?` | Optional | Indicates if promocode to be redeemed online in consumer mode. |
| `LastModifiedDateTime` | `DateTime?` | Optional | Promo code last modified date and time |
| `DaysValid` | [`List<DaysValidEnum>`](../../doc/models/days-valid-enum.md) | Optional | What days the promo code can be used |
| `ApplicableItems` | [`List<ApplicableItem>`](../../doc/models/applicable-item.md) | Optional | Contains information about a promocode applicable items. |

## Example (as JSON)

```json
{
  "PromotionID": 0,
  "Name": "Name4",
  "Code": "Code4",
  "Active": false,
  "Discount": {
    "Type": "Type6",
    "Amount": 80.68
  }
}
```

