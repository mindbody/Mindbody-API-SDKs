
# Resource Availability

An availability of a resource

## Structure

`ResourceAvailability`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ResourceId` | `int?` | Optional | Id |
| `StartDateTime` | `DateTime?` | Optional | Starts |
| `EndDateTime` | `DateTime?` | Optional | Ends |

## Example (as JSON)

```json
{
  "ResourceId": 170,
  "StartDateTime": "2016-03-13T12:52:32.123Z",
  "EndDateTime": "2016-03-13T12:52:32.123Z"
}
```

