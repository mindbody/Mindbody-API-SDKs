
# Visit Waitlist Info

A Visit DTO with Waitlist Informatoin

## Structure

`VisitWaitlistInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `WaitlistId` | `int?` | Optional | waitlist entry Id |
| `WaitlistOrderNumber` | `int?` | Optional | order of the waitlist entry |

## Example (as JSON)

```json
{
  "WaitlistId": 6,
  "WaitlistOrderNumber": 74
}
```

