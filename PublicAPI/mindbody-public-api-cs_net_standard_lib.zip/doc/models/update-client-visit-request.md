
# Update Client Visit Request

## Structure

`UpdateClientVisitRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `VisitId` | `int` | Required | The ID of the visit to be updated. |
| `Makeup` | `bool?` | Optional | When `true`, indicates that the visit is eligible to be made up. |
| `SignedIn` | `bool?` | Optional | When `true`, indicates that the client has signed in for the visit. |
| `ClientServiceId` | `int?` | Optional | The ID of the service to assign to the visit. |
| `Execute` | `string` | Optional | The execute code used to update this visit. Possible values are:<br><br>* Cancel<br>* Latecancel<br>* Unlatecancel |
| `Test` | `bool?` | Optional | When `true`, indicates that test mode is enabled. When test mode is enabled, input information is validated, but not committed.<br /><br>Default: **false** |
| `SendEmail` | `bool?` | Optional | When `true`, indicates that the client should be sent an email for cancellations. Note that email is not sent unless the client has an email address and automatic emails have been set up correctly.<br /><br>Default: **false** |

## Example (as JSON)

```json
{
  "VisitId": 154,
  "Makeup": false,
  "SignedIn": false,
  "ClientServiceId": 50,
  "Execute": "Execute8",
  "Test": false
}
```

