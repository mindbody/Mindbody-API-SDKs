
# Checkout Alternative Payment Info

Request object to capture Alternative Payment information.

## Structure

`CheckoutAlternativePaymentInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaymentMethodType` | `string` | Required | The type of alterntive payment. Possible values are:<br><br>* Ideal |
| `Amount` | `double` | Required | The amount to be paid |

## Example (as JSON)

```json
{
  "PaymentMethodType": "PaymentMethodType2",
  "Amount": 128.28
}
```

