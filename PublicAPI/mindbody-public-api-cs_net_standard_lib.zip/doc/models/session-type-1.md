
# Session Type 1

## Structure

`SessionType1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Type` | [`Type1Enum?`](../../doc/models/type-1-enum.md) | Optional | - |
| `DefaultTimeLength` | `int?` | Optional | - |
| `StaffTimeLength` | `int?` | Optional | - |
| `ProgramId` | `int?` | Optional | - |
| `NumDeducted` | `int?` | Optional | - |
| `Id` | `int?` | Optional | - |
| `Name` | `string` | Optional | - |
| `Active` | `bool?` | Optional | - |
| `Capacity` | `int?` | Optional | - |
| `ResourceRequired` | `bool?` | Optional | - |
| `Category` | [`ServiceTag`](../../doc/models/service-tag.md) | Optional | - |
| `Subcategory` | [`ServiceTag`](../../doc/models/service-tag.md) | Optional | - |
| `OnlineDescription` | `string` | Optional | - |
| `AvailableForAddOn` | `bool?` | Optional | - |

## Example (as JSON)

```json
{
  "Type": "Arrival",
  "DefaultTimeLength": 152,
  "StaffTimeLength": 130,
  "ProgramId": 134,
  "NumDeducted": 246
}
```

