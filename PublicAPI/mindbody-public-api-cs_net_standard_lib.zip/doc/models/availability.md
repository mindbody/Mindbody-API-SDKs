
# Availability

A staff availability entry

## Structure

`Availability`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | The ID of the availability. |
| `Staff` | [`Staff`](../../doc/models/staff.md) | Optional | The Staff |
| `SessionType` | [`SessionType`](../../doc/models/session-type.md) | Optional | SessionType contains information about the session types in a business. |
| `Programs` | [`List<Program>`](../../doc/models/program.md) | Optional | Contains information about the programs. |
| `StartDateTime` | `DateTime?` | Optional | The date and time the availability starts. |
| `EndDateTime` | `DateTime?` | Optional | The date and time the availability ends. |
| `BookableEndDateTime` | `DateTime?` | Optional | The time of day that the last appointment can start. |
| `Location` | [`Location`](../../doc/models/location.md) | Optional | - |
| `PrepTime` | `int?` | Optional | Prep time in minutes |
| `FinishTime` | `int?` | Optional | Finish time in minutes |
| `IsMasked` | `bool?` | Optional | When `true`, indicates that the staff member's name for availabilty is masked.<br>When `false`, indicates that the staff member's name for availabilty is not masked. |
| `ShowPublic` | `bool?` | Optional | When `true`, indicates that the schedule is shown to the clients.<br>When `false`, indicates that the schedule is hidden from the clients. |

## Example (as JSON)

```json
{
  "Id": 158,
  "Staff": {
    "Address": "Address8",
    "AppointmentInstructor": false,
    "AlwaysAllowDoubleBooking": false,
    "Bio": "Bio2",
    "City": "City8"
  },
  "SessionType": {
    "Type": "Class",
    "DefaultTimeLength": 30,
    "StaffTimeLength": 52,
    "Id": 52,
    "Name": "Name8"
  },
  "Programs": [
    {
      "Id": 192,
      "Name": "Name8",
      "ScheduleType": "Appointment",
      "CancelOffset": 182,
      "ContentFormats": [
        "ContentFormats9"
      ]
    },
    {
      "Id": 192,
      "Name": "Name8",
      "ScheduleType": "Appointment",
      "CancelOffset": 182,
      "ContentFormats": [
        "ContentFormats9"
      ]
    },
    {
      "Id": 192,
      "Name": "Name8",
      "ScheduleType": "Appointment",
      "CancelOffset": 182,
      "ContentFormats": [
        "ContentFormats9"
      ]
    }
  ],
  "StartDateTime": "2016-03-13T12:52:32.123Z"
}
```

