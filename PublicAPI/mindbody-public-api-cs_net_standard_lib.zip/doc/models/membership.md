
# Membership

## Structure

`Membership`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `MembershipId` | `int?` | Optional | The membership id. |
| `MembershipName` | `string` | Optional | The membership name. |
| `Priority` | `int?` | Optional | The priority/sort order. |
| `MemberRetailDiscount` | `double?` | Optional | The membership discount for retail as a percentage. |
| `MemberServiceDiscount` | `double?` | Optional | The membership discount for services as a percentage. |
| `AllowClientsToScheduleUnpaid` | `bool?` | Optional | Allow clients in this membership to schedule unpaid. |
| `OnlineBookingRestrictedToMembersOnly` | [`List<ProgramMembership>`](../../doc/models/program-membership.md) | Optional | List of programs that are restricted to clients in this membership only. |
| `DayOfMonthSchedulingOpensForNextMonth` | `int?` | Optional | Day of month scheduling opens for next month.  Unrestricted is a null value. |
| `RestrictSelfSignInToMembersOnly` | `bool?` | Optional | Restrict self sign in to members only. |
| `AllowMembersToBookAppointmentsWithoutPaying` | `bool?` | Optional | Allow members to book appointments without paying. |
| `AllowMembersToPurchaseNonMembersServices` | `bool?` | Optional | Allow members to purchase non-members services. |
| `AllowMembersToPurchaseNonMembersProducts` | `bool?` | Optional | Allow members to purchase non-members products. |
| `IsActive` | `bool?` | Optional | Indicates if the membership is active. |
| `EarlyAccessDaysBeforeSchedulingWindow` | `int?` | Optional | Number of days before the scheduling window that members with this membership get early access. |

## Example (as JSON)

```json
{
  "MembershipId": 228,
  "MembershipName": "MembershipName0",
  "Priority": 178,
  "MemberRetailDiscount": 155.74,
  "MemberServiceDiscount": 84.46
}
```

