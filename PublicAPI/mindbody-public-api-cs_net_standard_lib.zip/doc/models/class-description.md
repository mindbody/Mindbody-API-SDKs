
# Class Description

Represents a class definition. The class meets at the start time, goes until the end time.

## Structure

`ClassDescription`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Active` | `bool?` | Optional | When `true`, indicates that the business can assign this class description to new class schedules.<br /><br>When `false`, indicates that the business cannot assign this class description to new class schedules. |
| `Description` | `string` | Optional | The long version of the class description. |
| `Id` | `int?` | Optional | The class description's ID. |
| `ImageURL` | `string` | Optional | The class description's image URL, if any. If it does not exist, nothing is returned. |
| `LastUpdated` | `DateTime?` | Optional | The date this class description was last modified. |
| `Level` | [`Level`](../../doc/models/level.md) | Optional | The level information about this class. |
| `Name` | `string` | Optional | The name of this class description. |
| `Notes` | `string` | Optional | Any notes about the class description. |
| `Prereq` | `string` | Optional | Any prerequisites for the class. |
| `Program` | [`Program`](../../doc/models/program.md) | Optional | Contains information about the class description's program. |
| `SessionType` | [`SessionType`](../../doc/models/session-type.md) | Optional | Contains information about the class description's session type. |
| `Category` | `string` | Optional | The category of this class description. |
| `CategoryId` | `int?` | Optional | The category ID of this class description. |
| `Subcategory` | `string` | Optional | The subcategory of this class description. |
| `SubcategoryId` | `int?` | Optional | The subcategory ID of this class description. |

## Example (as JSON)

```json
{
  "Active": false,
  "Description": "Description6",
  "Id": 110,
  "ImageURL": "ImageURL2",
  "LastUpdated": "2016-03-13T12:52:32.123Z"
}
```

