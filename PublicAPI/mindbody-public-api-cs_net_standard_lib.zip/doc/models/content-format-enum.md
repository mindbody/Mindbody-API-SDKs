
# Content Format Enum

## Enumeration

`ContentFormatEnum`

## Fields

| Name |
|  --- |
| `InPerson` |
| `Mindbody` |
| `Other` |

