
# Add Appointment Request

Represents a request to add a new appointment, including details such as client information, appointment timing, location, and additional preferences.

## Structure

`AddAppointmentRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ApplyPayment` | `bool?` | Optional | When `true`, indicates that a payment should be applied to the appointment.<br><br />Default: **true** |
| `ClientId` | `string` | Required | The RRSID of the client for whom the new appointment is being made. |
| `Duration` | `int?` | Optional | The duration of the appointment. This parameter is used to change the default duration of an appointment. |
| `Execute` | `string` | Optional | The action taken to add this appointment. Possible values are: confirm, unconfirm, arrive, unarrive, cancel, latecancel, complete. |
| `EndDateTime` | `DateTime?` | Optional | The end date and time of the new appointment. <br /><br>Default: **StartDateTime**, offset by the staff member’s default appointment duration. |
| `GenderPreference` | `string` | Optional | The client’s service provider gender preference. |
| `LocationId` | `int` | Required | The ID of the location where the new appointment is to take place. |
| `Notes` | `string` | Optional | Any general notes about this appointment. |
| `ProviderId` | `string` | Optional | If a user has Complementary and Alternative Medicine features enabled, this parameter assigns a provider ID to the appointment. |
| `ResourceIds` | `List<int>` | Optional | A list of resource IDs to associate with the new appointment. |
| `SendEmail` | `bool?` | Optional | Whether to send client an email for cancellations. An email is sent only if the client has an email address and automatic emails have been set up.<br><br />Default: **false** |
| `SessionTypeId` | `int` | Required | The session type associated with the new appointment. |
| `StaffId` | `long` | Required | The ID of the staff member who is adding the new appointment. |
| `StaffRequested` | `bool?` | Optional | When `true`, indicates that the staff member was requested specifically by the client. |
| `StartDateTime` | `DateTime` | Required | The start date and time of the new appointment. |
| `Test` | `bool?` | Optional | When true, indicates that the method is to be validated, but no new appointment data is added.<br><br />Default: **false** |
| `IsWaitlist` | `bool?` | Optional | When `true`, indicates that the client should be added to a specific appointment waiting list.<br>When `false`, the client should not be added to the waiting list.<br>Default: **false** |
| `IsRequest` | `bool?` | Optional | Indicates whether to add an appointment request for review.<br>If `true`, the appointment will be added as a request, bypassing the `IsWaitlist` parameter and two validations:<br><br>1. If a consumer is adding the appointment for another person.<br>2. If a staff member without permission to add appointments for other staff members is adding the appointment for another staff member.<br><br>This also allows anonymous calls (without an authentication token) to this endpoint.<br>The `AllowClientsToBookAppointments` option must be disabled. If it is enabled and the `IsRequest` parameter is `true`, it will return an error.<br><br>For the appointment to be created as a request, one of the following conditions must also be met:<br><br>- The call is anonymous (no authentication token provided).<br>- The call is authenticated with a consumer token.<br>- The authenticated user lacks permission to book appointments for other staff (`BookAppointmentsForAllStaff`) and is attempting to book for a different staff member.<br>  - In this last case, if the `IsRequest` parameter is `true` and the authenticated user has the `BookAppointmentsForAllStaff` permission or is attempting to book the appointment for themselves,<br>    the appointment will be created, but not as an appointment request.<br><br>If `false`, the appointment will follow the standard creation process, respecting the `IsWaitlist` parameter.<br><br>Default: `false` |
| `PartnerExternalId` | `string` | Optional | Optional external key for api partners. |
| `AddAppointmentRequestId` | `int?` | Optional | A unique identifier for tracking the AddAppointmentRequest. This ID is not stored and is used to match each request with its corresponding response.<br>The request object will also be returned in the response, with the same ID value.<br><br>- For single requests, this value will be ignored.<br>- For multiple requests, if no value is provided, the system will generate an identifier ranging from 0 to (number of requests - 1). |

## Example (as JSON)

```json
{
  "ApplyPayment": false,
  "ClientId": "ClientId6",
  "Duration": 252,
  "Execute": "Execute8",
  "EndDateTime": "2016-03-13T12:52:32.123Z",
  "GenderPreference": "GenderPreference2",
  "LocationId": 10,
  "SessionTypeId": 110,
  "StaffId": 216,
  "StartDateTime": "2016-03-13T12:52:32.123Z"
}
```

