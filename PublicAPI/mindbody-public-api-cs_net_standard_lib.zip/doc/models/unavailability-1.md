
# Unavailability 1

## Structure

`Unavailability1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | Unavailabiltity ID. |
| `StartDateTime` | `DateTime?` | Optional | Start of the unavailability. |
| `EndDateTime` | `DateTime?` | Optional | End of the unavailability. |
| `Description` | `string` | Optional | Description of the unavailability. |

## Example (as JSON)

```json
{
  "Id": 74,
  "StartDateTime": "2016-03-13T12:52:32.123Z",
  "EndDateTime": "2016-03-13T12:52:32.123Z",
  "Description": "Description6"
}
```

