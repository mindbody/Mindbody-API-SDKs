
# Days Valid Enum

## Enumeration

`DaysValidEnum`

## Fields

| Name |
|  --- |
| `Sunday` |
| `Monday` |
| `Tuesday` |
| `Wednesday` |
| `Thursday` |
| `Friday` |
| `Saturday` |

