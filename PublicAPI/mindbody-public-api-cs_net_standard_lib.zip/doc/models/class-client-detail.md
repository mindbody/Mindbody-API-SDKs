
# Class Client Detail

Class Client Detail Object

## Structure

`ClassClientDetail`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClientIds` | `List<string>` | Required | The RSSID of the clients to remove from the specified classes. |
| `ClassId` | `int` | Required | The ID of the classes that you want to remove the clients from. |

## Example (as JSON)

```json
{
  "ClientIds": [
    "ClientIds1"
  ],
  "ClassId": 120
}
```

