
# Visit

Represents a specific visit to a class

## Structure

`Visit`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AppointmentId` | `int?` | Optional | The appointment’s ID. |
| `AppointmentGenderPreference` | [`AppointmentGenderPreferenceEnum?`](../../doc/models/appointment-gender-preference-enum.md) | Optional | The gender of staff member with whom the client prefers to book appointments.<br><br>Possible values are:<br><br>* Female - Indicates that the client prefers to book appointments with female staff members.<br>* Male - Indicates that the client prefers to book appointments with male staff members.<br>* None - Indicates that the client does not have a staff member gender preference. |
| `AppointmentStatus` | [`AppointmentStatusEnum?`](../../doc/models/appointment-status-enum.md) | Optional | The status of the appointment. |
| `ClassId` | `int?` | Optional | The class ID that was used to retrieve the visits. |
| `ClientId` | `string` | Optional | The ID of the client associated with the visit. |
| `ClientPhotoUrl` | `string` | Optional | PhotoUrl for the client |
| `ClientUniqueId` | `long?` | Optional | The unique ID of the client associated with the visit. |
| `StartDateTime` | `DateTime?` | Optional | The time this class is scheduled to start. |
| `EndDateTime` | `DateTime?` | Optional | The date and time the visit ends. The Public API returns UTC dates and times. For example, a class that occurs on June 25th, 2018 at 2:15PM (EST) appears as “2018-06-25T19:15:00Z” because EST is five hours behind UTC. Date time pairs always return in the format YYYY-MM-DDTHH:mm:ssZ. |
| `Id` | `long?` | Optional | The ID of the visit. |
| `LastModifiedDateTime` | `DateTime?` | Optional | When included in the request, only records modified on or after the specified `LastModifiedDate` are included in the response. The Public API returns UTC dates and times. For example, a class that occurs on June 25th, 2018 at 2:15PM (EST) appears as “2018-06-25T19:15:00Z” because EST is five hours behind UTC. Date time pairs always return in the format YYYY-MM-DDTHH:mm:ssZ. |
| `LateCancelled` | `bool?` | Optional | When `true`, indicates that the class has been `LateCancelled`.<br /><br>When `false`, indicates that the class has not been `LateCancelled`. |
| `SiteId` | `int?` | Optional | The ID of the business where the visit is booked. |
| `LocationId` | `int?` | Optional | The ID of the location where the visit took place or is to take place. |
| `MakeUp` | `bool?` | Optional | When `true`, the client can make up this session and a session is not deducted from the pricing option that was used to sign the client into the enrollment. When the client has the make-up session, a session is automatically removed from a pricing option that matches the service category of the enrollment and is within the same date range of the missed session.<br /><br>When `false`, the client cannot make up this session. See [Enrollments: Make-ups](https://support.mindbodyonline.com/s/article/203259433-Enrollments-Make-ups?language=en_US) for more information. |
| `Name` | `string` | Optional | The name of the class. |
| `ServiceId` | `long?` | Optional | The unique ID assigned to this pricing option when it was purchased by the client. |
| `ServiceName` | `string` | Optional | The name of the pricing option at the site where it was purchased. |
| `Service` | [`ClientService`](../../doc/models/client-service.md) | Optional | A service that is on a client's account. |
| `ProductId` | `long?` | Optional | The ID of the pricing option at the site where it was purchased. |
| `SignedIn` | `bool?` | Optional | When `true`, indicates that the client has been signed in.<br /><br>When `false`, indicates that the client has not been signed in. |
| `StaffId` | `long?` | Optional | The ID of the staff member who is teaching the class. |
| `WebSignup` | `bool?` | Optional | When `true`, indicates that the client signed up online.<br /><br>When `false`, indicates that the client was signed up by a staff member. |
| `Action` | [`Action1Enum?`](../../doc/models/action-1-enum.md) | Optional | The action taken. |
| `Missed` | `bool?` | Optional | When `true`, indicates that the class has been `Missed`.<br /><br>When `false`, indicates that the class has not been `Missed`. |
| `VisitType` | `int?` | Optional | Indicates the Id of visit type. |
| `TypeGroup` | `int?` | Optional | Indicates the Id of type group. |
| `TypeTaken` | `string` | Optional | Indicates the service type taken. |

## Example (as JSON)

```json
{
  "AppointmentId": 166,
  "AppointmentGenderPreference": "None",
  "AppointmentStatus": "LateCancelled",
  "ClassId": 246,
  "ClientId": "ClientId6"
}
```

