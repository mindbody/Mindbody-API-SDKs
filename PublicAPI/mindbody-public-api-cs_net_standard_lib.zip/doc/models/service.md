
# Service

## Structure

`Service`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Price` | `double?` | Optional | The cost of the pricing option when sold at a physical location. |
| `OnlinePrice` | `double?` | Optional | The cost of the pricing option when sold online. |
| `TaxIncluded` | `double?` | Optional | The amount of tax included in the price, if inclusive pricing is enabled. |
| `ProgramId` | `int?` | Optional | The ID of the program that this pricing option applies to. |
| `TaxRate` | `double?` | Optional | The tax rate applied to the pricing option. This field is populated only when you include a `LocationID` in the request. |
| `ProductId` | `int?` | Optional | The unique ID of this pricing option. This is the `PurchasedItems[].Id` returned from GET Sales. |
| `Id` | `string` | Optional | The barcode ID of the pricing option. This is the `PurchasedItems[].BarcodeId` returned from GET Sales. |
| `Name` | `string` | Optional | The name of the pricing option. |
| `Count` | `int?` | Optional | The initial count of usages available for the pricing option. |
| `SellOnline` | `bool?` | Optional | When true, filters to the pricing options that can be sold online.<br>Default: *false* |
| `SaleInContractOnly` | `bool?` | Optional | When `true`, indicates that the pricing option is allowed to be purchased in a contract or package.<br>When `false`, indicates that the pricing option is not allowed to be purchased in a contract or package. |
| `Type` | `string` | Optional | The type of the pricing option, either Drop-in, Series, or Unlimited. |
| `ExpirationType` | `string` | Optional | The date the pricing option begins its activation, either the date of sale or the date the client first used it for a visit. |
| `ExpirationUnit` | `string` | Optional | The unit, either days or months, of `ExpirationLength`, indicating how long the pricing option is active for. |
| `ExpirationLength` | `int?` | Optional | The number of days or months that the pricing option is active for. |
| `RevenueCategory` | `string` | Optional | The revenue category of the pricing option. |
| `MembershipId` | `int?` | Optional | The ID that this pricing option grants membership to. |
| `SellAtLocationIds` | `List<int>` | Optional | The location IDs where this pricing option is sold. |
| `UseAtLocationIds` | `List<int>` | Optional | The location IDs where this pricing option may be used. |
| `Priority` | `string` | Optional | The priority of the pricing option, either High, Medium, or Low. |
| `IsIntroOffer` | `bool?` | Optional | Indicates if this pricing option is an introductory offer. |
| `IntroOfferType` | `string` | Optional | When `IsIntroOffer` is true, this indicates if this introductory offer may be purchased by new clients or new and existing clients. |
| `IsThirdPartyDiscountPricing` | `bool?` | Optional | Indicates whether this pricing option is sold at discounted rates by third-party services, such as ClassPass. |
| `Program` | `string` | Optional | The name of the service category the pricing option belongs to. |
| `Discontinued` | `bool?` | Optional | If the pricing option has been marked discontinued. |
| `RestrictToMembershipIds` | `List<int>` | Optional | Restricted to members of these membership ids. |
| `ApplyMemberDiscountsOfMembershipIds` | `List<int>` | Optional | Discounts applied of these membership ids. |

## Example (as JSON)

```json
{
  "Price": 104.72,
  "OnlinePrice": 139.24,
  "TaxIncluded": 212.26,
  "ProgramId": 22,
  "TaxRate": 72.76
}
```

