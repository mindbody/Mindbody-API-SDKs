
# Gender Preference Enum

The prefered gender of the appointment provider.
Possible values are:

* None
* Female
* Male

## Enumeration

`GenderPreferenceEnum`

## Fields

| Name |
|  --- |
| `None` |
| `Female` |
| `Male` |

