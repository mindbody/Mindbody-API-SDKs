
# Get Liability Waiver Response

## Structure

`GetLiabilityWaiverResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `LiabilityWaiver` | `string` | Optional | Contains Liability Waiver text for a site |

## Example (as JSON)

```json
{
  "LiabilityWaiver": "LiabilityWaiver0"
}
```

