
# Client Contract

A client contract.

## Structure

`ClientContract`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PayerClientId` | `long?` | Optional | The ID of the client who holds the contract. |
| `AgreementDate` | `DateTime?` | Optional | The date on which the contract was signed. |
| `AutopayStatus` | [`AutopayStatusEnum?`](../../doc/models/autopay-status-enum.md) | Optional | The status of the client’s autopay. |
| `AutoRenewing` | `bool?` | Optional | Determines if the contract is auto-renewing. |
| `FirstAutoPay` | `double?` | Optional | The amount of the first autopay transaction. |
| `LastAutoPay` | `double?` | Optional | The amount of the last autopay transaction. |
| `NormalAutoPay` | `double?` | Optional | The amount of the normal recurring autopay transaction. |
| `IsMonthToMonth` | `bool?` | Optional | Indicates if the contract renews on a month-to-month basis. |
| `AutoRenewClientContractID` | `int?` | Optional | The ID of the contract that this one auto-renews from. |
| `ContractText` | `string` | Optional | The full text of the contract. |
| `ContractAutoRenewed` | `bool?` | Optional | Indicates whether the contract was auto-renewed from a previous one. |
| `ContractName` | `string` | Optional | The name of the contract. |
| `EndDate` | `DateTime?` | Optional | The date that the contract expires. |
| `Id` | `int?` | Optional | The unique ID of the sale of the contract. Each time a contract is sold, this ID increases sequentially. |
| `OriginationLocationId` | `int?` | Optional | The ID of the location where the contract was issued. |
| `StartDate` | `DateTime?` | Optional | The date that the contract became active. |
| `SiteId` | `int?` | Optional | The ID of the site where the contract was issued. |
| `UpcomingAutopayEvents` | [`List<UpcomingAutopayEvent>`](../../doc/models/upcoming-autopay-event.md) | Optional | Contains details of the autopay events. |
| `ContractID` | `int?` | Optional | The ID of the contract. |
| `TerminationDate` | `DateTime?` | Optional | The date that the contract was terminated. |
| `MinimumCommitmentValue` | `int?` | Optional | Minimum commitment value. |
| `MinimumCommitmentUnit` | [`MinimumCommitmentUnitEnum?`](../../doc/models/minimum-commitment-unit-enum.md) | Optional | Minimum commitment unit type. |
| `MinimumCommitmentEndDate` | `DateTime?` | Optional | The earliest date a contract termination can take effect if a minimum commitment applies.<br>This represents the last day the client is obligated to remain on the contract.<br>Returned even if the commitment has already been fulfilled. |

## Example (as JSON)

```json
{
  "PayerClientId": 182,
  "AgreementDate": "2016-03-13T12:52:32.123Z",
  "AutopayStatus": "Suspended",
  "AutoRenewing": false,
  "FirstAutoPay": 152.34
}
```

