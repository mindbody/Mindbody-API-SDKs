
# Add Multiple Appointments Response

Represents the response for adding multiple appointments.

## Structure

`AddMultipleAppointmentsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AddAppointmentOutcomes` | [`List<AddAppointmentOutcome>`](../../doc/models/add-appointment-outcome.md) | Optional | Contains information about the created appointments. |

## Example (as JSON)

```json
{
  "AddAppointmentOutcomes": [
    {
      "Appointment": {
        "GenderPreference": "None",
        "Duration": 182,
        "ProviderId": "ProviderId6",
        "Id": 136,
        "Status": "None"
      },
      "Error": {
        "Message": "Message0",
        "Code": "Code4"
      },
      "Request": {
        "ApplyPayment": false,
        "ClientId": "ClientId6",
        "Duration": 150,
        "Execute": "Execute8",
        "EndDateTime": "2016-03-13T12:52:32.123Z",
        "GenderPreference": "GenderPreference2",
        "LocationId": 164,
        "SessionTypeId": 8,
        "StaffId": 114,
        "StartDateTime": "2016-03-13T12:52:32.123Z"
      }
    }
  ]
}
```

