
# Gift Card Layout

Gift card layout

## Structure

`GiftCardLayout`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `LayoutId` | `int?` | Optional | The ID of the layout. |
| `LayoutName` | `string` | Optional | The name of the layout. |
| `LayoutUrl` | `string` | Optional | The URL of the layout. |

## Example (as JSON)

```json
{
  "LayoutId": 178,
  "LayoutName": "LayoutName4",
  "LayoutUrl": "LayoutUrl0"
}
```

