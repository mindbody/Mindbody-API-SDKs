
# Add Staff Request

## Structure

`AddStaffRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FirstName` | `string` | Required | The staff member first name. You must specify a first name when you add a staff member. |
| `LastName` | `string` | Required | The staff member last name. You must specify a last name when you add a staff member. |
| `Email` | `string` | Optional | The staff member’s email address. |
| `IsMale` | `bool?` | Optional | When `true`, indicates that the staff member is male.<br>When `false`, indicates that the staff member is female. |
| `HomePhone` | `string` | Optional | The staff member’s home phone number. |
| `WorkPhone` | `string` | Optional | The staff member’s work phone number. |
| `MobilePhone` | `string` | Optional | The staff member’s mobile phone number. |
| `Bio` | `string` | Optional | The staff member’s biography. This string contains HTML. |
| `Address` | `string` | Optional | The first line of the staff member street address. |
| `Address2` | `string` | Optional | The second line of the staff member street address, if needed. |
| `City` | `string` | Optional | The staff member’s city. |
| `State` | `string` | Optional | The staff member’s state. |
| `Country` | `string` | Optional | The staff member’s country. |
| `PostalCode` | `string` | Optional | The staff member’s postal code. |
| `ClassAssistant` | `bool?` | Optional | Is the staff an assistant |
| `ClassAssistant2` | `bool?` | Optional | Is the staff an assistant2 |
| `IndependentContractor` | `bool?` | Optional | When `true`, indicates that the staff member is an independent contractor.<br>When `false`, indicates that the staff member is not an independent contractor. |
| `AppointmentInstructor` | `bool?` | Optional | When `true`, indicates that the staff member offers appointments.<br /><br>When `false`, indicates that the staff member does not offer appointments. |
| `AlwaysAllowDoubleBooking` | `bool?` | Optional | When `true`, indicates that the staff member can be scheduled for overlapping services.<br /><br>When `false`, indicates that the staff can only be scheduled for one service at a time in any given time-frame. |
| `ClassTeacher` | `bool?` | Optional | When `true`, indicates that the staff member can teach classes.<br>When `false`, indicates that the staff member cannot teach classes. |
| `EmploymentStart` | `DateTime?` | Optional | The start date of employment |
| `EmploymentEnd` | `DateTime?` | Optional | The end date of employment |
| `SortOrder` | `int?` | Optional | If configured by the business owner, this field determines a staff member’s weight when sorting. Use this field to sort staff members on your interface. |
| `ProviderIDs` | `List<string>` | Optional | A list of providerIDs for the staff.  In the US it is one per staff and is numeric, otherwise it can be a list and is alpha-numeric<br>for more information see <a href=" https://support.mindbodyonline.com/s/article/204075743-Provider-IDs?language=en_US" target="blank">Provider IDs</a> |
| `Notes` | `string` | Optional | The staff member private notes. |
| `EmpID` | `string` | Optional | The custom staff ID assigned to the staff member. |

## Example (as JSON)

```json
{
  "FirstName": "FirstName2",
  "LastName": "LastName2",
  "Email": "Email2",
  "IsMale": false,
  "HomePhone": "HomePhone6",
  "WorkPhone": "WorkPhone8",
  "MobilePhone": "MobilePhone2"
}
```

