
# Autopay Status Enum

The status of the client’s autopay.

## Enumeration

`AutopayStatusEnum`

## Fields

| Name |
|  --- |
| `Active` |
| `Inactive` |
| `Suspended` |

