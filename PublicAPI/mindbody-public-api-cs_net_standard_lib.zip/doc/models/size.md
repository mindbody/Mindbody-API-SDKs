
# Size

## Structure

`Size`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | The unique ID of the product size. |
| `Name` | `string` | Optional | The name of the size of product. |

## Example (as JSON)

```json
{
  "Id": 112,
  "Name": "Name8"
}
```

