// <copyright file="CrossSiteController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using APIMatic.Core;
using APIMatic.Core.Types;
using APIMatic.Core.Utilities;
using APIMatic.Core.Utilities.Date.Xml;
using MINDBODYPublicAPI.Standard;
using MINDBODYPublicAPI.Standard.Http.Client;
using MINDBODYPublicAPI.Standard.Utilities;
using Newtonsoft.Json.Converters;
using System.Net.Http;

namespace MINDBODYPublicAPI.Standard.Controllers
{
    /// <summary>
    /// CrossSiteController.
    /// </summary>
    public class CrossSiteController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CrossSiteController"/> class.
        /// </summary>
        internal CrossSiteController(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// Copies the credit card information from one client to another, regardless of site.
        /// The source and target clients must have the same email address.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.CopyCreditCardResponse response from the API call.</returns>
        public Models.CopyCreditCardResponse CopyCreditCard(
                string version,
                Models.CopyCreditCardRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(CopyCreditCardAsync(version, request, siteId, authorization));

        /// <summary>
        /// Copies the credit card information from one client to another, regardless of site.
        /// The source and target clients must have the same email address.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.CopyCreditCardResponse response from the API call.</returns>
        public async Task<Models.CopyCreditCardResponse> CopyCreditCardAsync(
                string version,
                Models.CopyCreditCardRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.CopyCreditCardResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/crossSite/copycreditcard")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);
    }
}