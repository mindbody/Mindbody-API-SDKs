// <copyright file="Action9Enum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using APIMatic.Core.Utilities.Converters;
using MINDBODYPublicAPI.Standard;
using MINDBODYPublicAPI.Standard.Utilities;
using Newtonsoft.Json;

namespace MINDBODYPublicAPI.Standard.Models
{
    /// <summary>
    /// Action9Enum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum Action9Enum
    {
        /// <summary>
        /// Earned.
        /// </summary>
        [EnumMember(Value = "Earned")]
        Earned,

        /// <summary>
        /// Redeemed.
        /// </summary>
        [EnumMember(Value = "Redeemed")]
        Redeemed,

        /// <summary>
        /// Returned.
        /// </summary>
        [EnumMember(Value = "Returned")]
        Returned,

        /// <summary>
        /// Removed.
        /// </summary>
        [EnumMember(Value = "Removed")]
        Removed,

        /// <summary>
        /// LateCanceled.
        /// </summary>
        [EnumMember(Value = "LateCanceled")]
        LateCanceled
    }
}