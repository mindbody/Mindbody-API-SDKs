// <copyright file="DeactivatePromoCodeRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using MINDBODYPublicAPI.Standard;
using MINDBODYPublicAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace MINDBODYPublicAPI.Standard.Models
{
    /// <summary>
    /// DeactivatePromoCodeRequest.
    /// </summary>
    public class DeactivatePromoCodeRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DeactivatePromoCodeRequest"/> class.
        /// </summary>
        public DeactivatePromoCodeRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DeactivatePromoCodeRequest"/> class.
        /// </summary>
        /// <param name="promotionId">PromotionId.</param>
        public DeactivatePromoCodeRequest(
            int promotionId)
        {
            this.PromotionId = promotionId;
        }

        /// <summary>
        /// The promocodeID
        /// </summary>
        [JsonProperty("PromotionId")]
        public int PromotionId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"DeactivatePromoCodeRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is DeactivatePromoCodeRequest other &&                this.PromotionId.Equals(other.PromotionId);
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PromotionId = {this.PromotionId}");
        }
    }
}