// <copyright file="AppointmentStatusEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using APIMatic.Core.Utilities.Converters;
using MINDBODYPublicAPI.Standard;
using MINDBODYPublicAPI.Standard.Utilities;
using Newtonsoft.Json;

namespace MINDBODYPublicAPI.Standard.Models
{
    /// <summary>
    /// AppointmentStatusEnum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum AppointmentStatusEnum
    {
        /// <summary>
        /// None.
        /// </summary>
        [EnumMember(Value = "None")]
        None,

        /// <summary>
        /// Requested.
        /// </summary>
        [EnumMember(Value = "Requested")]
        Requested,

        /// <summary>
        /// Booked.
        /// </summary>
        [EnumMember(Value = "Booked")]
        Booked,

        /// <summary>
        /// Completed.
        /// </summary>
        [EnumMember(Value = "Completed")]
        Completed,

        /// <summary>
        /// Confirmed.
        /// </summary>
        [EnumMember(Value = "Confirmed")]
        Confirmed,

        /// <summary>
        /// Arrived.
        /// </summary>
        [EnumMember(Value = "Arrived")]
        Arrived,

        /// <summary>
        /// NoShow.
        /// </summary>
        [EnumMember(Value = "NoShow")]
        NoShow,

        /// <summary>
        /// Cancelled.
        /// </summary>
        [EnumMember(Value = "Cancelled")]
        Cancelled,

        /// <summary>
        /// LateCancelled.
        /// </summary>
        [EnumMember(Value = "LateCancelled")]
        LateCancelled
    }
}