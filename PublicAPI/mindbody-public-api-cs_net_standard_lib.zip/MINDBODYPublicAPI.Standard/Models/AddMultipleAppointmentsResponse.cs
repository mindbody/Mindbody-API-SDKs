// <copyright file="AddMultipleAppointmentsResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using MINDBODYPublicAPI.Standard;
using MINDBODYPublicAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace MINDBODYPublicAPI.Standard.Models
{
    /// <summary>
    /// AddMultipleAppointmentsResponse.
    /// </summary>
    public class AddMultipleAppointmentsResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AddMultipleAppointmentsResponse"/> class.
        /// </summary>
        public AddMultipleAppointmentsResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AddMultipleAppointmentsResponse"/> class.
        /// </summary>
        /// <param name="addAppointmentOutcomes">AddAppointmentOutcomes.</param>
        public AddMultipleAppointmentsResponse(
            List<Models.AddAppointmentOutcome> addAppointmentOutcomes = null)
        {
            this.AddAppointmentOutcomes = addAppointmentOutcomes;
        }

        /// <summary>
        /// Contains information about the created appointments.
        /// </summary>
        [JsonProperty("AddAppointmentOutcomes", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.AddAppointmentOutcome> AddAppointmentOutcomes { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"AddMultipleAppointmentsResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is AddMultipleAppointmentsResponse other &&                ((this.AddAppointmentOutcomes == null && other.AddAppointmentOutcomes == null) || (this.AddAppointmentOutcomes?.Equals(other.AddAppointmentOutcomes) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AddAppointmentOutcomes = {(this.AddAppointmentOutcomes == null ? "null" : $"[{string.Join(", ", this.AddAppointmentOutcomes)} ]")}");
        }
    }
}