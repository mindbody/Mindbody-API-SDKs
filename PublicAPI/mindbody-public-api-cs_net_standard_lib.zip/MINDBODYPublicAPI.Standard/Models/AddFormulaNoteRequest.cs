// <copyright file="AddFormulaNoteRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using MINDBODYPublicAPI.Standard;
using MINDBODYPublicAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace MINDBODYPublicAPI.Standard.Models
{
    /// <summary>
    /// AddFormulaNoteRequest.
    /// </summary>
    public class AddFormulaNoteRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AddFormulaNoteRequest"/> class.
        /// </summary>
        public AddFormulaNoteRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AddFormulaNoteRequest"/> class.
        /// </summary>
        /// <param name="clientId">ClientId.</param>
        /// <param name="note">Note.</param>
        /// <param name="appointmentId">AppointmentId.</param>
        public AddFormulaNoteRequest(
            string clientId,
            string note,
            long? appointmentId = null)
        {
            this.ClientId = clientId;
            this.AppointmentId = appointmentId;
            this.Note = note;
        }

        /// <summary>
        /// The ID of the client who needs to have a formula note added.
        /// </summary>
        [JsonProperty("ClientId")]
        public string ClientId { get; set; }

        /// <summary>
        /// The appointment ID that the formula note is related to.
        /// </summary>
        [JsonProperty("AppointmentId", NullValueHandling = NullValueHandling.Ignore)]
        public long? AppointmentId { get; set; }

        /// <summary>
        /// The new formula note text.
        /// </summary>
        [JsonProperty("Note")]
        public string Note { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"AddFormulaNoteRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is AddFormulaNoteRequest other &&                ((this.ClientId == null && other.ClientId == null) || (this.ClientId?.Equals(other.ClientId) == true)) &&
                ((this.AppointmentId == null && other.AppointmentId == null) || (this.AppointmentId?.Equals(other.AppointmentId) == true)) &&
                ((this.Note == null && other.Note == null) || (this.Note?.Equals(other.Note) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ClientId = {(this.ClientId == null ? "null" : this.ClientId)}");
            toStringOutput.Add($"this.AppointmentId = {(this.AppointmentId == null ? "null" : this.AppointmentId.ToString())}");
            toStringOutput.Add($"this.Note = {(this.Note == null ? "null" : this.Note)}");
        }
    }
}