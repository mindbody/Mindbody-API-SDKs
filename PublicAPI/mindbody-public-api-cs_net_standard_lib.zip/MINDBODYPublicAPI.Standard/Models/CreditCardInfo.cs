// <copyright file="CreditCardInfo.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using MINDBODYPublicAPI.Standard;
using MINDBODYPublicAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace MINDBODYPublicAPI.Standard.Models
{
    /// <summary>
    /// CreditCardInfo.
    /// </summary>
    public class CreditCardInfo
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CreditCardInfo"/> class.
        /// </summary>
        public CreditCardInfo()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CreditCardInfo"/> class.
        /// </summary>
        /// <param name="creditCardNumber">CreditCardNumber.</param>
        /// <param name="expMonth">ExpMonth.</param>
        /// <param name="expYear">ExpYear.</param>
        /// <param name="billingName">BillingName.</param>
        /// <param name="billingAddress">BillingAddress.</param>
        /// <param name="billingCity">BillingCity.</param>
        /// <param name="billingState">BillingState.</param>
        /// <param name="billingPostalCode">BillingPostalCode.</param>
        /// <param name="saveInfo">SaveInfo.</param>
        /// <param name="cardId">CardId.</param>
        /// <param name="cVV">CVV.</param>
        public CreditCardInfo(
            string creditCardNumber = null,
            string expMonth = null,
            string expYear = null,
            string billingName = null,
            string billingAddress = null,
            string billingCity = null,
            string billingState = null,
            string billingPostalCode = null,
            bool? saveInfo = null,
            string cardId = null,
            string cVV = null)
        {
            this.CreditCardNumber = creditCardNumber;
            this.ExpMonth = expMonth;
            this.ExpYear = expYear;
            this.BillingName = billingName;
            this.BillingAddress = billingAddress;
            this.BillingCity = billingCity;
            this.BillingState = billingState;
            this.BillingPostalCode = billingPostalCode;
            this.SaveInfo = saveInfo;
            this.CardId = cardId;
            this.CVV = cVV;
        }

        /// <summary>
        /// Gets or sets CreditCardNumber.
        /// </summary>
        [JsonProperty("CreditCardNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string CreditCardNumber { get; set; }

        /// <summary>
        /// Gets or sets ExpMonth.
        /// </summary>
        [JsonProperty("ExpMonth", NullValueHandling = NullValueHandling.Ignore)]
        public string ExpMonth { get; set; }

        /// <summary>
        /// Gets or sets ExpYear.
        /// </summary>
        [JsonProperty("ExpYear", NullValueHandling = NullValueHandling.Ignore)]
        public string ExpYear { get; set; }

        /// <summary>
        /// Gets or sets BillingName.
        /// </summary>
        [JsonProperty("BillingName", NullValueHandling = NullValueHandling.Ignore)]
        public string BillingName { get; set; }

        /// <summary>
        /// Gets or sets BillingAddress.
        /// </summary>
        [JsonProperty("BillingAddress", NullValueHandling = NullValueHandling.Ignore)]
        public string BillingAddress { get; set; }

        /// <summary>
        /// Gets or sets BillingCity.
        /// </summary>
        [JsonProperty("BillingCity", NullValueHandling = NullValueHandling.Ignore)]
        public string BillingCity { get; set; }

        /// <summary>
        /// Gets or sets BillingState.
        /// </summary>
        [JsonProperty("BillingState", NullValueHandling = NullValueHandling.Ignore)]
        public string BillingState { get; set; }

        /// <summary>
        /// Gets or sets BillingPostalCode.
        /// </summary>
        [JsonProperty("BillingPostalCode", NullValueHandling = NullValueHandling.Ignore)]
        public string BillingPostalCode { get; set; }

        /// <summary>
        /// Gets or sets SaveInfo.
        /// </summary>
        [JsonProperty("SaveInfo", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SaveInfo { get; set; }

        /// <summary>
        /// Card Id of a stored instruments card
        /// </summary>
        [JsonProperty("CardId", NullValueHandling = NullValueHandling.Ignore)]
        public string CardId { get; set; }

        /// <summary>
        /// CVV of the card
        /// </summary>
        [JsonProperty("CVV", NullValueHandling = NullValueHandling.Ignore)]
        public string CVV { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"CreditCardInfo : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is CreditCardInfo other &&
                (this.CreditCardNumber == null && other.CreditCardNumber == null ||
                 this.CreditCardNumber?.Equals(other.CreditCardNumber) == true) &&
                (this.ExpMonth == null && other.ExpMonth == null ||
                 this.ExpMonth?.Equals(other.ExpMonth) == true) &&
                (this.ExpYear == null && other.ExpYear == null ||
                 this.ExpYear?.Equals(other.ExpYear) == true) &&
                (this.BillingName == null && other.BillingName == null ||
                 this.BillingName?.Equals(other.BillingName) == true) &&
                (this.BillingAddress == null && other.BillingAddress == null ||
                 this.BillingAddress?.Equals(other.BillingAddress) == true) &&
                (this.BillingCity == null && other.BillingCity == null ||
                 this.BillingCity?.Equals(other.BillingCity) == true) &&
                (this.BillingState == null && other.BillingState == null ||
                 this.BillingState?.Equals(other.BillingState) == true) &&
                (this.BillingPostalCode == null && other.BillingPostalCode == null ||
                 this.BillingPostalCode?.Equals(other.BillingPostalCode) == true) &&
                (this.SaveInfo == null && other.SaveInfo == null ||
                 this.SaveInfo?.Equals(other.SaveInfo) == true) &&
                (this.CardId == null && other.CardId == null ||
                 this.CardId?.Equals(other.CardId) == true) &&
                (this.CVV == null && other.CVV == null ||
                 this.CVV?.Equals(other.CVV) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"CreditCardNumber = {this.CreditCardNumber ?? "null"}");
            toStringOutput.Add($"ExpMonth = {this.ExpMonth ?? "null"}");
            toStringOutput.Add($"ExpYear = {this.ExpYear ?? "null"}");
            toStringOutput.Add($"BillingName = {this.BillingName ?? "null"}");
            toStringOutput.Add($"BillingAddress = {this.BillingAddress ?? "null"}");
            toStringOutput.Add($"BillingCity = {this.BillingCity ?? "null"}");
            toStringOutput.Add($"BillingState = {this.BillingState ?? "null"}");
            toStringOutput.Add($"BillingPostalCode = {this.BillingPostalCode ?? "null"}");
            toStringOutput.Add($"SaveInfo = {(this.SaveInfo == null ? "null" : this.SaveInfo.ToString())}");
            toStringOutput.Add($"CardId = {this.CardId ?? "null"}");
            toStringOutput.Add($"CVV = {this.CVV ?? "null"}");
        }
    }
}