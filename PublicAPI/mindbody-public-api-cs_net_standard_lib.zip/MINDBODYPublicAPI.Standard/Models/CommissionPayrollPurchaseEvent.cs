// <copyright file="CommissionPayrollPurchaseEvent.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using MINDBODYPublicAPI.Standard;
using MINDBODYPublicAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace MINDBODYPublicAPI.Standard.Models
{
    /// <summary>
    /// CommissionPayrollPurchaseEvent.
    /// </summary>
    public class CommissionPayrollPurchaseEvent
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CommissionPayrollPurchaseEvent"/> class.
        /// </summary>
        public CommissionPayrollPurchaseEvent()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CommissionPayrollPurchaseEvent"/> class.
        /// </summary>
        /// <param name="staffId">StaffId.</param>
        /// <param name="saleDateTime">SaleDateTime.</param>
        /// <param name="saleId">SaleId.</param>
        /// <param name="saleType">SaleType.</param>
        /// <param name="productId">ProductId.</param>
        /// <param name="earningsDetails">EarningsDetails.</param>
        /// <param name="earnings">Earnings.</param>
        public CommissionPayrollPurchaseEvent(
            long? staffId = null,
            DateTime? saleDateTime = null,
            long? saleId = null,
            string saleType = null,
            long? productId = null,
            List<Models.CommissionDetail> earningsDetails = null,
            double? earnings = null)
        {
            this.StaffId = staffId;
            this.SaleDateTime = saleDateTime;
            this.SaleId = saleId;
            this.SaleType = saleType;
            this.ProductId = productId;
            this.EarningsDetails = earningsDetails;
            this.Earnings = earnings;
        }

        /// <summary>
        /// The ID of the staff member who earned commissions.
        /// </summary>
        [JsonProperty("StaffId", NullValueHandling = NullValueHandling.Ignore)]
        public long? StaffId { get; set; }

        /// <summary>
        /// The date and time when the sale occurred.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("SaleDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? SaleDateTime { get; set; }

        /// <summary>
        /// The sale’s ID.
        /// </summary>
        [JsonProperty("SaleId", NullValueHandling = NullValueHandling.Ignore)]
        public long? SaleId { get; set; }

        /// <summary>
        /// The Sales type. When this is "Purchase" indicates that this sale paid commission to a staff. When this is "Return"
        /// </summary>
        [JsonProperty("SaleType", NullValueHandling = NullValueHandling.Ignore)]
        public string SaleType { get; set; }

        /// <summary>
        /// The product ID of the item for which the staff earned commissions.
        /// </summary>
        [JsonProperty("ProductId", NullValueHandling = NullValueHandling.Ignore)]
        public long? ProductId { get; set; }

        /// <summary>
        /// Contains information about which commissions the staff earned for this item.
        /// </summary>
        [JsonProperty("EarningsDetails", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.CommissionDetail> EarningsDetails { get; set; }

        /// <summary>
        /// The total commissions earned by the staff for this item.
        /// </summary>
        [JsonProperty("Earnings", NullValueHandling = NullValueHandling.Ignore)]
        public double? Earnings { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"CommissionPayrollPurchaseEvent : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is CommissionPayrollPurchaseEvent other &&
                (this.StaffId == null && other.StaffId == null ||
                 this.StaffId?.Equals(other.StaffId) == true) &&
                (this.SaleDateTime == null && other.SaleDateTime == null ||
                 this.SaleDateTime?.Equals(other.SaleDateTime) == true) &&
                (this.SaleId == null && other.SaleId == null ||
                 this.SaleId?.Equals(other.SaleId) == true) &&
                (this.SaleType == null && other.SaleType == null ||
                 this.SaleType?.Equals(other.SaleType) == true) &&
                (this.ProductId == null && other.ProductId == null ||
                 this.ProductId?.Equals(other.ProductId) == true) &&
                (this.EarningsDetails == null && other.EarningsDetails == null ||
                 this.EarningsDetails?.Equals(other.EarningsDetails) == true) &&
                (this.Earnings == null && other.Earnings == null ||
                 this.Earnings?.Equals(other.Earnings) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"StaffId = {(this.StaffId == null ? "null" : this.StaffId.ToString())}");
            toStringOutput.Add($"SaleDateTime = {(this.SaleDateTime == null ? "null" : this.SaleDateTime.ToString())}");
            toStringOutput.Add($"SaleId = {(this.SaleId == null ? "null" : this.SaleId.ToString())}");
            toStringOutput.Add($"SaleType = {this.SaleType ?? "null"}");
            toStringOutput.Add($"ProductId = {(this.ProductId == null ? "null" : this.ProductId.ToString())}");
            toStringOutput.Add($"EarningsDetails = {(this.EarningsDetails == null ? "null" : $"[{string.Join(", ", this.EarningsDetails)} ]")}");
            toStringOutput.Add($"Earnings = {(this.Earnings == null ? "null" : this.Earnings.ToString())}");
        }
    }
}