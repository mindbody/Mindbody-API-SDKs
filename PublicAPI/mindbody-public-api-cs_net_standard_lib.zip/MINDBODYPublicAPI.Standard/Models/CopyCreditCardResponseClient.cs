// <copyright file="CopyCreditCardResponseClient.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using MINDBODYPublicAPI.Standard;
using MINDBODYPublicAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace MINDBODYPublicAPI.Standard.Models
{
    /// <summary>
    /// CopyCreditCardResponseClient.
    /// </summary>
    public class CopyCreditCardResponseClient
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CopyCreditCardResponseClient"/> class.
        /// </summary>
        public CopyCreditCardResponseClient()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CopyCreditCardResponseClient"/> class.
        /// </summary>
        /// <param name="clientId">ClientId.</param>
        /// <param name="siteId">SiteId.</param>
        /// <param name="firstName">FirstName.</param>
        /// <param name="lastName">LastName.</param>
        public CopyCreditCardResponseClient(
            string clientId = null,
            int? siteId = null,
            string firstName = null,
            string lastName = null)
        {
            this.ClientId = clientId;
            this.SiteId = siteId;
            this.FirstName = firstName;
            this.LastName = lastName;
        }

        /// <summary>
        /// ClientId
        /// </summary>
        [JsonProperty("ClientId", NullValueHandling = NullValueHandling.Ignore)]
        public string ClientId { get; set; }

        /// <summary>
        /// SiteId
        /// </summary>
        [JsonProperty("SiteId", NullValueHandling = NullValueHandling.Ignore)]
        public int? SiteId { get; set; }

        /// <summary>
        /// First name of ClientId
        /// </summary>
        [JsonProperty("FirstName", NullValueHandling = NullValueHandling.Ignore)]
        public string FirstName { get; set; }

        /// <summary>
        /// Last name of ClientId
        /// </summary>
        [JsonProperty("LastName", NullValueHandling = NullValueHandling.Ignore)]
        public string LastName { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"CopyCreditCardResponseClient : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is CopyCreditCardResponseClient other &&
                (this.ClientId == null && other.ClientId == null ||
                 this.ClientId?.Equals(other.ClientId) == true) &&
                (this.SiteId == null && other.SiteId == null ||
                 this.SiteId?.Equals(other.SiteId) == true) &&
                (this.FirstName == null && other.FirstName == null ||
                 this.FirstName?.Equals(other.FirstName) == true) &&
                (this.LastName == null && other.LastName == null ||
                 this.LastName?.Equals(other.LastName) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"ClientId = {this.ClientId ?? "null"}");
            toStringOutput.Add($"SiteId = {(this.SiteId == null ? "null" : this.SiteId.ToString())}");
            toStringOutput.Add($"FirstName = {this.FirstName ?? "null"}");
            toStringOutput.Add($"LastName = {this.LastName ?? "null"}");
        }
    }
}