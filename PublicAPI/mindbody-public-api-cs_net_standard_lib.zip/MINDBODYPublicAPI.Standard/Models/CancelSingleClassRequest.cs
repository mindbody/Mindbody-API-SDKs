// <copyright file="CancelSingleClassRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using MINDBODYPublicAPI.Standard;
using MINDBODYPublicAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace MINDBODYPublicAPI.Standard.Models
{
    /// <summary>
    /// CancelSingleClassRequest.
    /// </summary>
    public class CancelSingleClassRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CancelSingleClassRequest"/> class.
        /// </summary>
        public CancelSingleClassRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CancelSingleClassRequest"/> class.
        /// </summary>
        /// <param name="classID">ClassID.</param>
        /// <param name="hideCancel">HideCancel.</param>
        /// <param name="sendClientEmail">SendClientEmail.</param>
        /// <param name="sendStaffEmail">SendStaffEmail.</param>
        public CancelSingleClassRequest(
            long? classID = null,
            bool? hideCancel = null,
            bool? sendClientEmail = null,
            bool? sendStaffEmail = null)
        {
            this.ClassID = classID;
            this.HideCancel = hideCancel;
            this.SendClientEmail = sendClientEmail;
            this.SendStaffEmail = sendStaffEmail;
        }

        /// <summary>
        /// Class ID to lookup.
        /// </summary>
        [JsonProperty("ClassID", NullValueHandling = NullValueHandling.Ignore)]
        public long? ClassID { get; set; }

        /// <summary>
        /// When `true`, indicates that this class is hidden when cancelled.
        /// When `false`, indicates that this class is not hidden when cancelled.
        /// </summary>
        [JsonProperty("HideCancel", NullValueHandling = NullValueHandling.Ignore)]
        public bool? HideCancel { get; set; }

        /// <summary>
        /// When `true`, sends the client an automatic email about the cancellation, if the client has opted to receive email.
        /// </summary>
        [JsonProperty("SendClientEmail", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SendClientEmail { get; set; }

        /// <summary>
        /// When `true`, sends the staff an automatic email about the cancellation, if the staff has opted to receive email.
        /// </summary>
        [JsonProperty("SendStaffEmail", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SendStaffEmail { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"CancelSingleClassRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is CancelSingleClassRequest other &&
                (this.ClassID == null && other.ClassID == null ||
                 this.ClassID?.Equals(other.ClassID) == true) &&
                (this.HideCancel == null && other.HideCancel == null ||
                 this.HideCancel?.Equals(other.HideCancel) == true) &&
                (this.SendClientEmail == null && other.SendClientEmail == null ||
                 this.SendClientEmail?.Equals(other.SendClientEmail) == true) &&
                (this.SendStaffEmail == null && other.SendStaffEmail == null ||
                 this.SendStaffEmail?.Equals(other.SendStaffEmail) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"ClassID = {(this.ClassID == null ? "null" : this.ClassID.ToString())}");
            toStringOutput.Add($"HideCancel = {(this.HideCancel == null ? "null" : this.HideCancel.ToString())}");
            toStringOutput.Add($"SendClientEmail = {(this.SendClientEmail == null ? "null" : this.SendClientEmail.ToString())}");
            toStringOutput.Add($"SendStaffEmail = {(this.SendStaffEmail == null ? "null" : this.SendStaffEmail.ToString())}");
        }
    }
}