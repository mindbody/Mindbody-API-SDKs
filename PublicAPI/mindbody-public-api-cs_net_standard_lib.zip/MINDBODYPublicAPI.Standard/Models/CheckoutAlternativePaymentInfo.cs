// <copyright file="CheckoutAlternativePaymentInfo.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using MINDBODYPublicAPI.Standard;
using MINDBODYPublicAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace MINDBODYPublicAPI.Standard.Models
{
    /// <summary>
    /// CheckoutAlternativePaymentInfo.
    /// </summary>
    public class CheckoutAlternativePaymentInfo
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CheckoutAlternativePaymentInfo"/> class.
        /// </summary>
        public CheckoutAlternativePaymentInfo()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CheckoutAlternativePaymentInfo"/> class.
        /// </summary>
        /// <param name="paymentMethodId">PaymentMethodId.</param>
        /// <param name="amount">Amount.</param>
        public CheckoutAlternativePaymentInfo(
            int paymentMethodId,
            double amount)
        {
            this.PaymentMethodId = paymentMethodId;
            this.Amount = amount;
        }

        /// <summary>
        /// The type of alternative payment. Possible values are:
        /// * 997 - Indicates that this payment item is iDEAL.
        /// * 801 - Indicates that this payment item is Apple Pay.
        /// </summary>
        [JsonProperty("PaymentMethodId")]
        public int PaymentMethodId { get; set; }

        /// <summary>
        /// The amount to be paid
        /// </summary>
        [JsonProperty("Amount")]
        public double Amount { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"CheckoutAlternativePaymentInfo : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is CheckoutAlternativePaymentInfo other &&
                (this.PaymentMethodId.Equals(other.PaymentMethodId)) &&
                (this.Amount.Equals(other.Amount));
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"PaymentMethodId = {this.PaymentMethodId}");
            toStringOutput.Add($"Amount = {this.Amount}");
        }
    }
}