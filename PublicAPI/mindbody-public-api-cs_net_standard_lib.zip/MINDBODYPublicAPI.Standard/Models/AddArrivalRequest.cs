// <copyright file="AddArrivalRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using MINDBODYPublicAPI.Standard;
using MINDBODYPublicAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace MINDBODYPublicAPI.Standard.Models
{
    /// <summary>
    /// AddArrivalRequest.
    /// </summary>
    public class AddArrivalRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AddArrivalRequest"/> class.
        /// </summary>
        public AddArrivalRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AddArrivalRequest"/> class.
        /// </summary>
        /// <param name="clientId">ClientId.</param>
        /// <param name="locationId">LocationId.</param>
        /// <param name="arrivalTypeId">ArrivalTypeId.</param>
        /// <param name="leadChannelId">LeadChannelId.</param>
        /// <param name="test">Test.</param>
        public AddArrivalRequest(
            string clientId,
            int locationId,
            int? arrivalTypeId = null,
            int? leadChannelId = null,
            bool? test = null)
        {
            this.ClientId = clientId;
            this.LocationId = locationId;
            this.ArrivalTypeId = arrivalTypeId;
            this.LeadChannelId = leadChannelId;
            this.Test = test;
        }

        /// <summary>
        /// The ID of the requested client.
        /// </summary>
        [JsonProperty("ClientId")]
        public string ClientId { get; set; }

        /// <summary>
        /// The ID of the location for the requested arrival.
        /// </summary>
        [JsonProperty("LocationId")]
        public int LocationId { get; set; }

        /// <summary>
        /// The ID of the arrival program (service category) under which this arrival is to be logged. If this is not provided, the program ID of the first arrival pricing option found will be used.
        /// OPTIONAL: will take first payment found if not provided
        /// Default: **null**
        /// </summary>
        [JsonProperty("ArrivalTypeId", NullValueHandling = NullValueHandling.Ignore)]
        public int? ArrivalTypeId { get; set; }

        /// <summary>
        /// The ID of the Lead Channel ID from lead management. If this is supplied then it will map lead channel on the lead management.
        /// If this is not supplied then it wont save anything.
        /// This parameters required to track the lead channel if new client added while adding arrival of client on non home location.
        /// </summary>
        [JsonProperty("LeadChannelId", NullValueHandling = NullValueHandling.Ignore)]
        public int? LeadChannelId { get; set; }

        /// <summary>
        /// When `true`, indicates that the arrival log is to be validated, but no new arrival data is added. When `false`, the arrival is logged and the database is affected.
        /// Default: **false**
        /// </summary>
        [JsonProperty("Test", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Test { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"AddArrivalRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is AddArrivalRequest other &&                ((this.ClientId == null && other.ClientId == null) || (this.ClientId?.Equals(other.ClientId) == true)) &&
                this.LocationId.Equals(other.LocationId) &&
                ((this.ArrivalTypeId == null && other.ArrivalTypeId == null) || (this.ArrivalTypeId?.Equals(other.ArrivalTypeId) == true)) &&
                ((this.LeadChannelId == null && other.LeadChannelId == null) || (this.LeadChannelId?.Equals(other.LeadChannelId) == true)) &&
                ((this.Test == null && other.Test == null) || (this.Test?.Equals(other.Test) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ClientId = {(this.ClientId == null ? "null" : this.ClientId)}");
            toStringOutput.Add($"this.LocationId = {this.LocationId}");
            toStringOutput.Add($"this.ArrivalTypeId = {(this.ArrivalTypeId == null ? "null" : this.ArrivalTypeId.ToString())}");
            toStringOutput.Add($"this.LeadChannelId = {(this.LeadChannelId == null ? "null" : this.LeadChannelId.ToString())}");
            toStringOutput.Add($"this.Test = {(this.Test == null ? "null" : this.Test.ToString())}");
        }
    }
}