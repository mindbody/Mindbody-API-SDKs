// <copyright file="AddMultipleAppointmentsRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using MINDBODYPublicAPI.Standard;
using MINDBODYPublicAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace MINDBODYPublicAPI.Standard.Models
{
    /// <summary>
    /// AddMultipleAppointmentsRequest.
    /// </summary>
    public class AddMultipleAppointmentsRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AddMultipleAppointmentsRequest"/> class.
        /// </summary>
        public AddMultipleAppointmentsRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AddMultipleAppointmentsRequest"/> class.
        /// </summary>
        /// <param name="addAppointmentRequests">AddAppointmentRequests.</param>
        public AddMultipleAppointmentsRequest(
            List<Models.AddAppointmentRequest> addAppointmentRequests = null)
        {
            this.AddAppointmentRequests = addAppointmentRequests;
        }

        /// <summary>
        /// List of appointment requests to be added.
        /// </summary>
        [JsonProperty("AddAppointmentRequests", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.AddAppointmentRequest> AddAppointmentRequests { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"AddMultipleAppointmentsRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is AddMultipleAppointmentsRequest other &&                ((this.AddAppointmentRequests == null && other.AddAppointmentRequests == null) || (this.AddAppointmentRequests?.Equals(other.AddAppointmentRequests) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AddAppointmentRequests = {(this.AddAppointmentRequests == null ? "null" : $"[{string.Join(", ", this.AddAppointmentRequests)} ]")}");
        }
    }
}