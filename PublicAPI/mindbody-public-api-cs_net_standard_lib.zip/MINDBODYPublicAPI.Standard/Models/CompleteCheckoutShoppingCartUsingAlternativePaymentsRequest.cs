// <copyright file="CompleteCheckoutShoppingCartUsingAlternativePaymentsRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using MINDBODYPublicAPI.Standard;
using MINDBODYPublicAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace MINDBODYPublicAPI.Standard.Models
{
    /// <summary>
    /// CompleteCheckoutShoppingCartUsingAlternativePaymentsRequest.
    /// </summary>
    public class CompleteCheckoutShoppingCartUsingAlternativePaymentsRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CompleteCheckoutShoppingCartUsingAlternativePaymentsRequest"/> class.
        /// </summary>
        public CompleteCheckoutShoppingCartUsingAlternativePaymentsRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CompleteCheckoutShoppingCartUsingAlternativePaymentsRequest"/> class.
        /// </summary>
        /// <param name="accessToken">AccessToken.</param>
        /// <param name="clientId">ClientId.</param>
        /// <param name="test">Test.</param>
        public CompleteCheckoutShoppingCartUsingAlternativePaymentsRequest(
            string accessToken,
            string clientId,
            bool? test = null)
        {
            this.AccessToken = accessToken;
            this.ClientId = clientId;
            this.Test = test;
        }

        /// <summary>
        /// The Access Token generated during Pre-Payment step.
        /// </summary>
        [JsonProperty("AccessToken")]
        public string AccessToken { get; set; }

        /// <summary>
        /// The RSSID of the client making the purchase. A cart can be validated without a client ID, but a client ID must be specified to complete a sale.
        /// </summary>
        [JsonProperty("ClientId")]
        public string ClientId { get; set; }

        /// <summary>
        /// When `true`, indicates that the contents of the cart are validated, but the transaction does not take place. You should use this parameter during testing and when checking the calculated totals of the items in the cart.<br />
        /// When `false`, the transaction takes place and the database is affected.<br />
        /// Default: **false**
        /// </summary>
        [JsonProperty("Test", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Test { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"CompleteCheckoutShoppingCartUsingAlternativePaymentsRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is CompleteCheckoutShoppingCartUsingAlternativePaymentsRequest other &&
                (this.AccessToken == null && other.AccessToken == null ||
                 this.AccessToken?.Equals(other.AccessToken) == true) &&
                (this.ClientId == null && other.ClientId == null ||
                 this.ClientId?.Equals(other.ClientId) == true) &&
                (this.Test == null && other.Test == null ||
                 this.Test?.Equals(other.Test) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"AccessToken = {this.AccessToken ?? "null"}");
            toStringOutput.Add($"ClientId = {this.ClientId ?? "null"}");
            toStringOutput.Add($"Test = {(this.Test == null ? "null" : this.Test.ToString())}");
        }
    }
}