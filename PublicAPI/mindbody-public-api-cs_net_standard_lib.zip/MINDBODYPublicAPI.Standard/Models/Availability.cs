// <copyright file="Availability.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using MINDBODYPublicAPI.Standard;
using MINDBODYPublicAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace MINDBODYPublicAPI.Standard.Models
{
    /// <summary>
    /// Availability.
    /// </summary>
    public class Availability
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Availability"/> class.
        /// </summary>
        public Availability()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Availability"/> class.
        /// </summary>
        /// <param name="id">Id.</param>
        /// <param name="staff">Staff.</param>
        /// <param name="sessionType">SessionType.</param>
        /// <param name="programs">Programs.</param>
        /// <param name="startDateTime">StartDateTime.</param>
        /// <param name="endDateTime">EndDateTime.</param>
        /// <param name="bookableEndDateTime">BookableEndDateTime.</param>
        /// <param name="location">Location.</param>
        /// <param name="prepTime">PrepTime.</param>
        /// <param name="finishTime">FinishTime.</param>
        /// <param name="isMasked">IsMasked.</param>
        /// <param name="showPublic">ShowPublic.</param>
        /// <param name="resourceAvailabilities">ResourceAvailabilities.</param>
        public Availability(
            int? id = null,
            Models.Staff staff = null,
            Models.SessionType sessionType = null,
            List<Models.Program> programs = null,
            DateTime? startDateTime = null,
            DateTime? endDateTime = null,
            DateTime? bookableEndDateTime = null,
            Models.Location location = null,
            int? prepTime = null,
            int? finishTime = null,
            bool? isMasked = null,
            bool? showPublic = null,
            List<Models.ResourceAvailability> resourceAvailabilities = null)
        {
            this.Id = id;
            this.Staff = staff;
            this.SessionType = sessionType;
            this.Programs = programs;
            this.StartDateTime = startDateTime;
            this.EndDateTime = endDateTime;
            this.BookableEndDateTime = bookableEndDateTime;
            this.Location = location;
            this.PrepTime = prepTime;
            this.FinishTime = finishTime;
            this.IsMasked = isMasked;
            this.ShowPublic = showPublic;
            this.ResourceAvailabilities = resourceAvailabilities;
        }

        /// <summary>
        /// The ID of the availability.
        /// </summary>
        [JsonProperty("Id", NullValueHandling = NullValueHandling.Ignore)]
        public int? Id { get; set; }

        /// <summary>
        /// The Staff
        /// </summary>
        [JsonProperty("Staff", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Staff Staff { get; set; }

        /// <summary>
        /// SessionType contains information about the session types in a business.
        /// </summary>
        [JsonProperty("SessionType", NullValueHandling = NullValueHandling.Ignore)]
        public Models.SessionType SessionType { get; set; }

        /// <summary>
        /// Contains information about the programs.
        /// </summary>
        [JsonProperty("Programs", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.Program> Programs { get; set; }

        /// <summary>
        /// The date and time the availability starts.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("StartDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? StartDateTime { get; set; }

        /// <summary>
        /// The date and time the availability ends.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("EndDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? EndDateTime { get; set; }

        /// <summary>
        /// The time of day that the last appointment can start.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("BookableEndDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? BookableEndDateTime { get; set; }

        /// <summary>
        /// Gets or sets Location.
        /// </summary>
        [JsonProperty("Location", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Location Location { get; set; }

        /// <summary>
        /// Prep time in minutes
        /// </summary>
        [JsonProperty("PrepTime", NullValueHandling = NullValueHandling.Ignore)]
        public int? PrepTime { get; set; }

        /// <summary>
        /// Finish time in minutes
        /// </summary>
        [JsonProperty("FinishTime", NullValueHandling = NullValueHandling.Ignore)]
        public int? FinishTime { get; set; }

        /// <summary>
        /// When `true`, indicates that the staff member's name for availabilty is masked.
        /// When `false`, indicates that the staff member's name for availabilty is not masked.
        /// </summary>
        [JsonProperty("IsMasked", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IsMasked { get; set; }

        /// <summary>
        /// When `true`, indicates that the schedule is shown to the clients.
        /// When `false`, indicates that the schedule is hidden from the clients.
        /// </summary>
        [JsonProperty("ShowPublic", NullValueHandling = NullValueHandling.Ignore)]
        public bool? ShowPublic { get; set; }

        /// <summary>
        /// Contains information about resources availability for the specified session type.
        /// </summary>
        [JsonProperty("ResourceAvailabilities", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ResourceAvailability> ResourceAvailabilities { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"Availability : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is Availability other &&
                (this.Id == null && other.Id == null ||
                 this.Id?.Equals(other.Id) == true) &&
                (this.Staff == null && other.Staff == null ||
                 this.Staff?.Equals(other.Staff) == true) &&
                (this.SessionType == null && other.SessionType == null ||
                 this.SessionType?.Equals(other.SessionType) == true) &&
                (this.Programs == null && other.Programs == null ||
                 this.Programs?.Equals(other.Programs) == true) &&
                (this.StartDateTime == null && other.StartDateTime == null ||
                 this.StartDateTime?.Equals(other.StartDateTime) == true) &&
                (this.EndDateTime == null && other.EndDateTime == null ||
                 this.EndDateTime?.Equals(other.EndDateTime) == true) &&
                (this.BookableEndDateTime == null && other.BookableEndDateTime == null ||
                 this.BookableEndDateTime?.Equals(other.BookableEndDateTime) == true) &&
                (this.Location == null && other.Location == null ||
                 this.Location?.Equals(other.Location) == true) &&
                (this.PrepTime == null && other.PrepTime == null ||
                 this.PrepTime?.Equals(other.PrepTime) == true) &&
                (this.FinishTime == null && other.FinishTime == null ||
                 this.FinishTime?.Equals(other.FinishTime) == true) &&
                (this.IsMasked == null && other.IsMasked == null ||
                 this.IsMasked?.Equals(other.IsMasked) == true) &&
                (this.ShowPublic == null && other.ShowPublic == null ||
                 this.ShowPublic?.Equals(other.ShowPublic) == true) &&
                (this.ResourceAvailabilities == null && other.ResourceAvailabilities == null ||
                 this.ResourceAvailabilities?.Equals(other.ResourceAvailabilities) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"Id = {(this.Id == null ? "null" : this.Id.ToString())}");
            toStringOutput.Add($"Staff = {(this.Staff == null ? "null" : this.Staff.ToString())}");
            toStringOutput.Add($"SessionType = {(this.SessionType == null ? "null" : this.SessionType.ToString())}");
            toStringOutput.Add($"Programs = {(this.Programs == null ? "null" : $"[{string.Join(", ", this.Programs)} ]")}");
            toStringOutput.Add($"StartDateTime = {(this.StartDateTime == null ? "null" : this.StartDateTime.ToString())}");
            toStringOutput.Add($"EndDateTime = {(this.EndDateTime == null ? "null" : this.EndDateTime.ToString())}");
            toStringOutput.Add($"BookableEndDateTime = {(this.BookableEndDateTime == null ? "null" : this.BookableEndDateTime.ToString())}");
            toStringOutput.Add($"Location = {(this.Location == null ? "null" : this.Location.ToString())}");
            toStringOutput.Add($"PrepTime = {(this.PrepTime == null ? "null" : this.PrepTime.ToString())}");
            toStringOutput.Add($"FinishTime = {(this.FinishTime == null ? "null" : this.FinishTime.ToString())}");
            toStringOutput.Add($"IsMasked = {(this.IsMasked == null ? "null" : this.IsMasked.ToString())}");
            toStringOutput.Add($"ShowPublic = {(this.ShowPublic == null ? "null" : this.ShowPublic.ToString())}");
            toStringOutput.Add($"ResourceAvailabilities = {(this.ResourceAvailabilities == null ? "null" : $"[{string.Join(", ", this.ResourceAvailabilities)} ]")}");
        }
    }
}