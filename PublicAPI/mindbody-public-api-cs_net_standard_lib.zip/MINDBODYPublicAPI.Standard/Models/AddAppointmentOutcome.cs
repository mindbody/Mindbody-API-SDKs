// <copyright file="AddAppointmentOutcome.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using MINDBODYPublicAPI.Standard;
using MINDBODYPublicAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace MINDBODYPublicAPI.Standard.Models
{
    /// <summary>
    /// AddAppointmentOutcome.
    /// </summary>
    public class AddAppointmentOutcome
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AddAppointmentOutcome"/> class.
        /// </summary>
        public AddAppointmentOutcome()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AddAppointmentOutcome"/> class.
        /// </summary>
        /// <param name="appointment">Appointment.</param>
        /// <param name="error">Error.</param>
        /// <param name="request">Request.</param>
        public AddAppointmentOutcome(
            Models.Appointment appointment = null,
            Models.ApiError error = null,
            Models.AddAppointmentRequest request = null)
        {
            this.Appointment = appointment;
            this.Error = error;
            this.Request = request;
        }

        /// <summary>
        /// Contains information about an appointment.
        /// </summary>
        [JsonProperty("Appointment", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Appointment Appointment { get; set; }

        /// <summary>
        /// Gets or sets Error.
        /// </summary>
        [JsonProperty("Error", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ApiError Error { get; set; }

        /// <summary>
        /// Represents a request to add a new appointment, including details such as client information, appointment timing, location, and additional preferences.
        /// </summary>
        [JsonProperty("Request", NullValueHandling = NullValueHandling.Ignore)]
        public Models.AddAppointmentRequest Request { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"AddAppointmentOutcome : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is AddAppointmentOutcome other &&
                (this.Appointment == null && other.Appointment == null ||
                 this.Appointment?.Equals(other.Appointment) == true) &&
                (this.Error == null && other.Error == null ||
                 this.Error?.Equals(other.Error) == true) &&
                (this.Request == null && other.Request == null ||
                 this.Request?.Equals(other.Request) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"Appointment = {(this.Appointment == null ? "null" : this.Appointment.ToString())}");
            toStringOutput.Add($"Error = {(this.Error == null ? "null" : this.Error.ToString())}");
            toStringOutput.Add($"Request = {(this.Request == null ? "null" : this.Request.ToString())}");
        }
    }
}