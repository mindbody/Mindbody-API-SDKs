// <copyright file="AddClientRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using MINDBODYPublicAPI.Standard;
using MINDBODYPublicAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace MINDBODYPublicAPI.Standard.Models
{
    /// <summary>
    /// AddClientRequest.
    /// </summary>
    public class AddClientRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AddClientRequest"/> class.
        /// </summary>
        public AddClientRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AddClientRequest"/> class.
        /// </summary>
        /// <param name="firstName">FirstName.</param>
        /// <param name="lastName">LastName.</param>
        /// <param name="accountBalance">AccountBalance.</param>
        /// <param name="action">Action.</param>
        /// <param name="active">Active.</param>
        /// <param name="addressLine1">AddressLine1.</param>
        /// <param name="addressLine2">AddressLine2.</param>
        /// <param name="apptGenderPrefMale">ApptGenderPrefMale.</param>
        /// <param name="birthDate">BirthDate.</param>
        /// <param name="city">City.</param>
        /// <param name="clientCreditCard">ClientCreditCard.</param>
        /// <param name="clientIndexes">ClientIndexes.</param>
        /// <param name="clientRelationships">ClientRelationships.</param>
        /// <param name="country">Country.</param>
        /// <param name="creationDate">CreationDate.</param>
        /// <param name="customClientFields">CustomClientFields.</param>
        /// <param name="email">Email.</param>
        /// <param name="emergencyContactInfoEmail">EmergencyContactInfoEmail.</param>
        /// <param name="emergencyContactInfoName">EmergencyContactInfoName.</param>
        /// <param name="emergencyContactInfoPhone">EmergencyContactInfoPhone.</param>
        /// <param name="emergencyContactInfoRelationship">EmergencyContactInfoRelationship.</param>
        /// <param name="firstAppointmentDate">FirstAppointmentDate.</param>
        /// <param name="gender">Gender.</param>
        /// <param name="homeLocation">HomeLocation.</param>
        /// <param name="homePhone">HomePhone.</param>
        /// <param name="isCompany">IsCompany.</param>
        /// <param name="isProspect">IsProspect.</param>
        /// <param name="lastFormulaNotes">LastFormulaNotes.</param>
        /// <param name="lastModifiedDateTime">LastModifiedDateTime.</param>
        /// <param name="liability">Liability.</param>
        /// <param name="liabilityRelease">LiabilityRelease.</param>
        /// <param name="membershipIcon">MembershipIcon.</param>
        /// <param name="middleName">MiddleName.</param>
        /// <param name="mobilePhone">MobilePhone.</param>
        /// <param name="mobileProvider">MobileProvider.</param>
        /// <param name="newId">NewId.</param>
        /// <param name="notes">Notes.</param>
        /// <param name="photoUrl">PhotoUrl.</param>
        /// <param name="postalCode">PostalCode.</param>
        /// <param name="prospectStage">ProspectStage.</param>
        /// <param name="redAlert">RedAlert.</param>
        /// <param name="referredBy">ReferredBy.</param>
        /// <param name="salesReps">SalesReps.</param>
        /// <param name="siteId">SiteId.</param>
        /// <param name="state">State.</param>
        /// <param name="status">Status.</param>
        /// <param name="test">Test.</param>
        /// <param name="uniqueId">UniqueId.</param>
        /// <param name="workExtension">WorkExtension.</param>
        /// <param name="workPhone">WorkPhone.</param>
        /// <param name="yellowAlert">YellowAlert.</param>
        /// <param name="sendScheduleEmails">SendScheduleEmails.</param>
        /// <param name="sendAccountEmails">SendAccountEmails.</param>
        /// <param name="sendPromotionalEmails">SendPromotionalEmails.</param>
        /// <param name="sendScheduleTexts">SendScheduleTexts.</param>
        /// <param name="sendAccountTexts">SendAccountTexts.</param>
        /// <param name="sendPromotionalTexts">SendPromotionalTexts.</param>
        /// <param name="lockerNumber">LockerNumber.</param>
        /// <param name="reactivateInactiveClient">ReactivateInactiveClient.</param>
        /// <param name="leadChannelId">LeadChannelId.</param>
        public AddClientRequest(
            string firstName,
            string lastName,
            double? accountBalance = null,
            Models.Action1Enum? action = null,
            bool? active = null,
            string addressLine1 = null,
            string addressLine2 = null,
            bool? apptGenderPrefMale = null,
            DateTime? birthDate = null,
            string city = null,
            Models.ClientCreditCard clientCreditCard = null,
            List<Models.AssignedClientIndex> clientIndexes = null,
            List<Models.ClientRelationship> clientRelationships = null,
            string country = null,
            DateTime? creationDate = null,
            List<Models.CustomClientFieldValue> customClientFields = null,
            string email = null,
            string emergencyContactInfoEmail = null,
            string emergencyContactInfoName = null,
            string emergencyContactInfoPhone = null,
            string emergencyContactInfoRelationship = null,
            DateTime? firstAppointmentDate = null,
            string gender = null,
            Models.Location homeLocation = null,
            string homePhone = null,
            bool? isCompany = null,
            bool? isProspect = null,
            string lastFormulaNotes = null,
            DateTime? lastModifiedDateTime = null,
            Models.Liability liability = null,
            bool? liabilityRelease = null,
            int? membershipIcon = null,
            string middleName = null,
            string mobilePhone = null,
            int? mobileProvider = null,
            string newId = null,
            string notes = null,
            string photoUrl = null,
            string postalCode = null,
            Models.ProspectStage prospectStage = null,
            string redAlert = null,
            string referredBy = null,
            List<Models.SalesRep> salesReps = null,
            int? siteId = null,
            string state = null,
            string status = null,
            bool? test = null,
            long? uniqueId = null,
            string workExtension = null,
            string workPhone = null,
            string yellowAlert = null,
            bool? sendScheduleEmails = null,
            bool? sendAccountEmails = null,
            bool? sendPromotionalEmails = null,
            bool? sendScheduleTexts = null,
            bool? sendAccountTexts = null,
            bool? sendPromotionalTexts = null,
            string lockerNumber = null,
            bool? reactivateInactiveClient = null,
            int? leadChannelId = null)
        {
            this.AccountBalance = accountBalance;
            this.Action = action;
            this.Active = active;
            this.AddressLine1 = addressLine1;
            this.AddressLine2 = addressLine2;
            this.ApptGenderPrefMale = apptGenderPrefMale;
            this.BirthDate = birthDate;
            this.City = city;
            this.ClientCreditCard = clientCreditCard;
            this.ClientIndexes = clientIndexes;
            this.ClientRelationships = clientRelationships;
            this.Country = country;
            this.CreationDate = creationDate;
            this.CustomClientFields = customClientFields;
            this.Email = email;
            this.EmergencyContactInfoEmail = emergencyContactInfoEmail;
            this.EmergencyContactInfoName = emergencyContactInfoName;
            this.EmergencyContactInfoPhone = emergencyContactInfoPhone;
            this.EmergencyContactInfoRelationship = emergencyContactInfoRelationship;
            this.FirstAppointmentDate = firstAppointmentDate;
            this.FirstName = firstName;
            this.Gender = gender;
            this.HomeLocation = homeLocation;
            this.HomePhone = homePhone;
            this.IsCompany = isCompany;
            this.IsProspect = isProspect;
            this.LastFormulaNotes = lastFormulaNotes;
            this.LastModifiedDateTime = lastModifiedDateTime;
            this.LastName = lastName;
            this.Liability = liability;
            this.LiabilityRelease = liabilityRelease;
            this.MembershipIcon = membershipIcon;
            this.MiddleName = middleName;
            this.MobilePhone = mobilePhone;
            this.MobileProvider = mobileProvider;
            this.NewId = newId;
            this.Notes = notes;
            this.PhotoUrl = photoUrl;
            this.PostalCode = postalCode;
            this.ProspectStage = prospectStage;
            this.RedAlert = redAlert;
            this.ReferredBy = referredBy;
            this.SalesReps = salesReps;
            this.SiteId = siteId;
            this.State = state;
            this.Status = status;
            this.Test = test;
            this.UniqueId = uniqueId;
            this.WorkExtension = workExtension;
            this.WorkPhone = workPhone;
            this.YellowAlert = yellowAlert;
            this.SendScheduleEmails = sendScheduleEmails;
            this.SendAccountEmails = sendAccountEmails;
            this.SendPromotionalEmails = sendPromotionalEmails;
            this.SendScheduleTexts = sendScheduleTexts;
            this.SendAccountTexts = sendAccountTexts;
            this.SendPromotionalTexts = sendPromotionalTexts;
            this.LockerNumber = lockerNumber;
            this.ReactivateInactiveClient = reactivateInactiveClient;
            this.LeadChannelId = leadChannelId;
        }

        /// <summary>
        /// The client’s current [account balance](https://mindbody-online-support.force.com/support/s/article/203262013-Adding-account-payments-video-tutorial?language=en_US).
        /// </summary>
        [JsonProperty("AccountBalance", NullValueHandling = NullValueHandling.Ignore)]
        public double? AccountBalance { get; set; }

        /// <summary>
        /// The action taken.
        /// </summary>
        [JsonProperty("Action", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Action1Enum? Action { get; set; }

        /// <summary>
        /// When `true`, indicates that the client is active at the site.<br />
        /// When `false`, indicates that the client is not active at the site.
        /// </summary>
        [JsonProperty("Active", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Active { get; set; }

        /// <summary>
        /// The first line of the client’s street address.
        /// </summary>
        [JsonProperty("AddressLine1", NullValueHandling = NullValueHandling.Ignore)]
        public string AddressLine1 { get; set; }

        /// <summary>
        /// The second line of the client’s street address, if needed.
        /// </summary>
        [JsonProperty("AddressLine2", NullValueHandling = NullValueHandling.Ignore)]
        public string AddressLine2 { get; set; }

        /// <summary>
        /// When `true`, indicates that the client prefers services to be provided by a male service provider.<br />
        /// When `false`, indicates that the client prefers services to be provided by a female service provider.<br />
        /// When `null`, indicates that the client has no preference.
        /// Default: **null**
        /// </summary>
        [JsonProperty("ApptGenderPrefMale", NullValueHandling = NullValueHandling.Ignore)]
        public bool? ApptGenderPrefMale { get; set; }

        /// <summary>
        /// The client’s date of birth.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("BirthDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? BirthDate { get; set; }

        /// <summary>
        /// The client’s city.
        /// </summary>
        [JsonProperty("City", NullValueHandling = NullValueHandling.Ignore)]
        public string City { get; set; }

        /// <summary>
        /// A client credit card.
        /// </summary>
        [JsonProperty("ClientCreditCard", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ClientCreditCard ClientCreditCard { get; set; }

        /// <summary>
        /// Contains a list of the indexes and client index values to be assigned to the client.
        /// If an index is already assigned to the client, it is overwritten with the passed index value. You cannot currently remove client indexes using the Public API. Only the indexes passed in the request are returned in the response.
        /// </summary>
        [JsonProperty("ClientIndexes", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.AssignedClientIndex> ClientIndexes { get; set; }

        /// <summary>
        /// Contains information about client relationships that were added or updated for the client. This parameter does not include all of the relationships assigned to the client, only the ones passed in the request.
        /// </summary>
        [JsonProperty("ClientRelationships", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ClientRelationship> ClientRelationships { get; set; }

        /// <summary>
        /// The country in which the client is located.
        /// </summary>
        [JsonProperty("Country", NullValueHandling = NullValueHandling.Ignore)]
        public string Country { get; set; }

        /// <summary>
        /// The date when the client was added to the business, either by the client from the online store or by a staff member at the subscriber’s business. This value always returns in the format yyyy-mm-ddThh:mm:ss:ms.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("CreationDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? CreationDate { get; set; }

        /// <summary>
        /// Contains information about the custom fields used for clients in the business.
        /// </summary>
        [JsonProperty("CustomClientFields", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.CustomClientFieldValue> CustomClientFields { get; set; }

        /// <summary>
        /// The client’s email address.
        /// </summary>
        [JsonProperty("Email", NullValueHandling = NullValueHandling.Ignore)]
        public string Email { get; set; }

        /// <summary>
        /// The email address of the client’s emergency contact.<br />
        /// For more information, see [Children’s program features(emergency contact information)](https://support.mindbodyonline.com/s/article/203259283-Children-s-program-features-emergency-contact-information?language=en_US).
        /// </summary>
        [JsonProperty("EmergencyContactInfoEmail", NullValueHandling = NullValueHandling.Ignore)]
        public string EmergencyContactInfoEmail { get; set; }

        /// <summary>
        /// The name of the client’s emergency contact.
        /// </summary>
        [JsonProperty("EmergencyContactInfoName", NullValueHandling = NullValueHandling.Ignore)]
        public string EmergencyContactInfoName { get; set; }

        /// <summary>
        /// The phone number of the client’s emergency contact.
        /// </summary>
        [JsonProperty("EmergencyContactInfoPhone", NullValueHandling = NullValueHandling.Ignore)]
        public string EmergencyContactInfoPhone { get; set; }

        /// <summary>
        /// The client’s relationship with the emergency contact, for example, mother or spouse.
        /// </summary>
        [JsonProperty("EmergencyContactInfoRelationship", NullValueHandling = NullValueHandling.Ignore)]
        public string EmergencyContactInfoRelationship { get; set; }

        /// <summary>
        /// The date of the client’s first booked appointment at the business.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("FirstAppointmentDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? FirstAppointmentDate { get; set; }

        /// <summary>
        /// The client’s first name. You must specify a first name when you add a client.
        /// </summary>
        [JsonProperty("FirstName")]
        public string FirstName { get; set; }

        /// <summary>
        /// The client’s gender.
        /// </summary>
        [JsonProperty("Gender", NullValueHandling = NullValueHandling.Ignore)]
        public string Gender { get; set; }

        /// <summary>
        /// Gets or sets HomeLocation.
        /// </summary>
        [JsonProperty("HomeLocation", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Location HomeLocation { get; set; }

        /// <summary>
        /// The client’s home phone number.
        /// </summary>
        [JsonProperty("HomePhone", NullValueHandling = NullValueHandling.Ignore)]
        public string HomePhone { get; set; }

        /// <summary>
        /// When `true`, indicates that the client should be marked as a company at the business.<br />
        /// When `false`, indicates the client is an individual and does not represent a company.
        /// </summary>
        [JsonProperty("IsCompany", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IsCompany { get; set; }

        /// <summary>
        /// This value is set only if the business owner allows individuals to be prospects.<br />
        /// If the business owner has enabled the setting to default new client as a Prospect, the isProspect value will always be true. Otherwise,<br />
        /// When `true`, indicates that the client should be marked as a prospect for the business.<br />
        /// When `false`, indicates that the client should not be marked as a prospect for the business.
        /// </summary>
        [JsonProperty("IsProspect", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IsProspect { get; set; }

        /// <summary>
        /// The last [formula note](https://support.mindbodyonline.com/s/article/203259903-Appointments-Formula-notes?language=en_US) entered for the client.
        /// </summary>
        [JsonProperty("LastFormulaNotes", NullValueHandling = NullValueHandling.Ignore)]
        public string LastFormulaNotes { get; set; }

        /// <summary>
        /// The UTC date and time when the client’s information was last modified.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("LastModifiedDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? LastModifiedDateTime { get; set; }

        /// <summary>
        /// The client’s last name. You must specify a last name when you add a client.
        /// </summary>
        [JsonProperty("LastName")]
        public string LastName { get; set; }

        /// <summary>
        /// Gets or sets Liability.
        /// </summary>
        [JsonProperty("Liability", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Liability Liability { get; set; }

        /// <summary>
        /// When `true`, sets the client’s liability information as follows:
        /// * `IsReleased` is set to true.
        /// * `AgreementDate` is set to the time zone of the business when the call was processed.
        /// * `ReleasedBy` is set to `null` if the call is made by the client, `0` if the call was made by the business owner, or to a specific staff member’s ID if a staff member made the call.
        /// When `false`, sets the client’s liability information as follows:
        /// * `IsReleased` is set to `false`.
        /// * `AgreementDate` is set to `null`.
        /// * `ReleasedBy` is set to `null`.
        /// </summary>
        [JsonProperty("LiabilityRelease", NullValueHandling = NullValueHandling.Ignore)]
        public bool? LiabilityRelease { get; set; }

        /// <summary>
        /// The ID of the membership icon displayed next to the client’s name, if the client has a membership on their account.
        /// </summary>
        [JsonProperty("MembershipIcon", NullValueHandling = NullValueHandling.Ignore)]
        public int? MembershipIcon { get; set; }

        /// <summary>
        /// The client’s middle name.
        /// </summary>
        [JsonProperty("MiddleName", NullValueHandling = NullValueHandling.Ignore)]
        public string MiddleName { get; set; }

        /// <summary>
        /// The client’s mobile phone number.
        /// </summary>
        [JsonProperty("MobilePhone", NullValueHandling = NullValueHandling.Ignore)]
        public string MobilePhone { get; set; }

        /// <summary>
        /// The client's mobile provider.
        /// </summary>
        [JsonProperty("MobileProvider", NullValueHandling = NullValueHandling.Ignore)]
        public int? MobileProvider { get; set; }

        /// <summary>
        /// The new RSSID to be used for the client. Use `NewId` to assign a specific alphanumeric value to be a client’s ID. This RSSID must be unique within the subscriber’s site. If this is a cross-regional update, the RSSID must be unique across the region. If the requested value is already in use, the call returns an error.
        /// </summary>
        [JsonProperty("NewId", NullValueHandling = NullValueHandling.Ignore)]
        public string NewId { get; set; }

        /// <summary>
        /// Any notes entered on the client’s account by staff members. This value should never be shown to clients unless the business owner has a specific reason for showing them.
        /// </summary>
        [JsonProperty("Notes", NullValueHandling = NullValueHandling.Ignore)]
        public string Notes { get; set; }

        /// <summary>
        /// The URL for the client’s photo, if one has been uploaded.
        /// </summary>
        [JsonProperty("PhotoUrl", NullValueHandling = NullValueHandling.Ignore)]
        public string PhotoUrl { get; set; }

        /// <summary>
        /// The client’s postal code.
        /// </summary>
        [JsonProperty("PostalCode", NullValueHandling = NullValueHandling.Ignore)]
        public string PostalCode { get; set; }

        /// <summary>
        /// Gets or sets ProspectStage.
        /// </summary>
        [JsonProperty("ProspectStage", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ProspectStage ProspectStage { get; set; }

        /// <summary>
        /// Contains any red alert information entered by the business owner for the client.
        /// </summary>
        [JsonProperty("RedAlert", NullValueHandling = NullValueHandling.Ignore)]
        public string RedAlert { get; set; }

        /// <summary>
        /// Specifies how the client was referred to the business. You can get a list of possible strings using the `GET ClientReferralTypes` endpoint.<br />
        /// For more information, see [Referral types and referral subtypes](https://support.mindbodyonline.com/s/article/203259393-Referral-types-and-referral-subtypes?language=en_US).
        /// </summary>
        [JsonProperty("ReferredBy", NullValueHandling = NullValueHandling.Ignore)]
        public string ReferredBy { get; set; }

        /// <summary>
        /// Contains information about the sales representatives to be assigned to the new client.
        /// </summary>
        [JsonProperty("SalesReps", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.SalesRep> SalesReps { get; set; }

        /// <summary>
        /// The ID of the site.
        /// </summary>
        [JsonProperty("SiteId", NullValueHandling = NullValueHandling.Ignore)]
        public int? SiteId { get; set; }

        /// <summary>
        /// The client’s state.
        /// </summary>
        [JsonProperty("State", NullValueHandling = NullValueHandling.Ignore)]
        public string State { get; set; }

        /// <summary>
        /// The client’s status.
        /// </summary>
        [JsonProperty("Status", NullValueHandling = NullValueHandling.Ignore)]
        public string Status { get; set; }

        /// <summary>
        /// When `true`, indicates that test mode is enabled. The method is validated, but no client data is added or updated.<br />
        /// Default: **false**
        /// </summary>
        [JsonProperty("Test", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Test { get; set; }

        /// <summary>
        /// The client’s system-generated ID at the business. This value cannot be changed by business owners and is always unique across all clients at the business. This ID is not widely used in the Public API, but can be used by your application to uniquely identify clients.
        /// </summary>
        [JsonProperty("UniqueId", NullValueHandling = NullValueHandling.Ignore)]
        public long? UniqueId { get; set; }

        /// <summary>
        /// The client’s work phone extension number.
        /// </summary>
        [JsonProperty("WorkExtension", NullValueHandling = NullValueHandling.Ignore)]
        public string WorkExtension { get; set; }

        /// <summary>
        /// The client’s work phone number.
        /// </summary>
        [JsonProperty("WorkPhone", NullValueHandling = NullValueHandling.Ignore)]
        public string WorkPhone { get; set; }

        /// <summary>
        /// Contains any yellow alert information entered by the business owner for the client.
        /// </summary>
        [JsonProperty("YellowAlert", NullValueHandling = NullValueHandling.Ignore)]
        public string YellowAlert { get; set; }

        /// <summary>
        /// When `true`, indicates that the client opts to receive schedule emails.
        /// Default : **false**
        /// </summary>
        [JsonProperty("SendScheduleEmails", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SendScheduleEmails { get; set; }

        /// <summary>
        /// When `true`, indicates that the client opts to receive account emails.
        /// Default : **false**
        /// </summary>
        [JsonProperty("SendAccountEmails", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SendAccountEmails { get; set; }

        /// <summary>
        /// When `true`, indicates that the client opts to receive promotional emails.
        /// Default : **false**
        /// </summary>
        [JsonProperty("SendPromotionalEmails", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SendPromotionalEmails { get; set; }

        /// <summary>
        /// When `true`, indicates that the client opts to receive schedule texts.
        /// </summary>
        [JsonProperty("SendScheduleTexts", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SendScheduleTexts { get; set; }

        /// <summary>
        /// When `true`, indicates that the client opts to receive account texts.
        /// </summary>
        [JsonProperty("SendAccountTexts", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SendAccountTexts { get; set; }

        /// <summary>
        /// When `true`, indicates that the client opts to receive promotional texts.
        /// </summary>
        [JsonProperty("SendPromotionalTexts", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SendPromotionalTexts { get; set; }

        /// <summary>
        /// The clients locker number.
        /// </summary>
        [JsonProperty("LockerNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string LockerNumber { get; set; }

        /// <summary>
        /// When `true`, indicates that the client opts to reactive existing Inactive client.
        /// </summary>
        [JsonProperty("ReactivateInactiveClient", NullValueHandling = NullValueHandling.Ignore)]
        public bool? ReactivateInactiveClient { get; set; }

        /// <summary>
        /// The ID of the LeadChannel from LeadManagement. This parameter is required by LeadManagement to track the LeadChannel from where the new client is added.
        /// If this value is not supplied then it won't save anything.
        /// </summary>
        [JsonProperty("LeadChannelId", NullValueHandling = NullValueHandling.Ignore)]
        public int? LeadChannelId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"AddClientRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is AddClientRequest other &&                ((this.AccountBalance == null && other.AccountBalance == null) || (this.AccountBalance?.Equals(other.AccountBalance) == true)) &&
                ((this.Action == null && other.Action == null) || (this.Action?.Equals(other.Action) == true)) &&
                ((this.Active == null && other.Active == null) || (this.Active?.Equals(other.Active) == true)) &&
                ((this.AddressLine1 == null && other.AddressLine1 == null) || (this.AddressLine1?.Equals(other.AddressLine1) == true)) &&
                ((this.AddressLine2 == null && other.AddressLine2 == null) || (this.AddressLine2?.Equals(other.AddressLine2) == true)) &&
                ((this.ApptGenderPrefMale == null && other.ApptGenderPrefMale == null) || (this.ApptGenderPrefMale?.Equals(other.ApptGenderPrefMale) == true)) &&
                ((this.BirthDate == null && other.BirthDate == null) || (this.BirthDate?.Equals(other.BirthDate) == true)) &&
                ((this.City == null && other.City == null) || (this.City?.Equals(other.City) == true)) &&
                ((this.ClientCreditCard == null && other.ClientCreditCard == null) || (this.ClientCreditCard?.Equals(other.ClientCreditCard) == true)) &&
                ((this.ClientIndexes == null && other.ClientIndexes == null) || (this.ClientIndexes?.Equals(other.ClientIndexes) == true)) &&
                ((this.ClientRelationships == null && other.ClientRelationships == null) || (this.ClientRelationships?.Equals(other.ClientRelationships) == true)) &&
                ((this.Country == null && other.Country == null) || (this.Country?.Equals(other.Country) == true)) &&
                ((this.CreationDate == null && other.CreationDate == null) || (this.CreationDate?.Equals(other.CreationDate) == true)) &&
                ((this.CustomClientFields == null && other.CustomClientFields == null) || (this.CustomClientFields?.Equals(other.CustomClientFields) == true)) &&
                ((this.Email == null && other.Email == null) || (this.Email?.Equals(other.Email) == true)) &&
                ((this.EmergencyContactInfoEmail == null && other.EmergencyContactInfoEmail == null) || (this.EmergencyContactInfoEmail?.Equals(other.EmergencyContactInfoEmail) == true)) &&
                ((this.EmergencyContactInfoName == null && other.EmergencyContactInfoName == null) || (this.EmergencyContactInfoName?.Equals(other.EmergencyContactInfoName) == true)) &&
                ((this.EmergencyContactInfoPhone == null && other.EmergencyContactInfoPhone == null) || (this.EmergencyContactInfoPhone?.Equals(other.EmergencyContactInfoPhone) == true)) &&
                ((this.EmergencyContactInfoRelationship == null && other.EmergencyContactInfoRelationship == null) || (this.EmergencyContactInfoRelationship?.Equals(other.EmergencyContactInfoRelationship) == true)) &&
                ((this.FirstAppointmentDate == null && other.FirstAppointmentDate == null) || (this.FirstAppointmentDate?.Equals(other.FirstAppointmentDate) == true)) &&
                ((this.FirstName == null && other.FirstName == null) || (this.FirstName?.Equals(other.FirstName) == true)) &&
                ((this.Gender == null && other.Gender == null) || (this.Gender?.Equals(other.Gender) == true)) &&
                ((this.HomeLocation == null && other.HomeLocation == null) || (this.HomeLocation?.Equals(other.HomeLocation) == true)) &&
                ((this.HomePhone == null && other.HomePhone == null) || (this.HomePhone?.Equals(other.HomePhone) == true)) &&
                ((this.IsCompany == null && other.IsCompany == null) || (this.IsCompany?.Equals(other.IsCompany) == true)) &&
                ((this.IsProspect == null && other.IsProspect == null) || (this.IsProspect?.Equals(other.IsProspect) == true)) &&
                ((this.LastFormulaNotes == null && other.LastFormulaNotes == null) || (this.LastFormulaNotes?.Equals(other.LastFormulaNotes) == true)) &&
                ((this.LastModifiedDateTime == null && other.LastModifiedDateTime == null) || (this.LastModifiedDateTime?.Equals(other.LastModifiedDateTime) == true)) &&
                ((this.LastName == null && other.LastName == null) || (this.LastName?.Equals(other.LastName) == true)) &&
                ((this.Liability == null && other.Liability == null) || (this.Liability?.Equals(other.Liability) == true)) &&
                ((this.LiabilityRelease == null && other.LiabilityRelease == null) || (this.LiabilityRelease?.Equals(other.LiabilityRelease) == true)) &&
                ((this.MembershipIcon == null && other.MembershipIcon == null) || (this.MembershipIcon?.Equals(other.MembershipIcon) == true)) &&
                ((this.MiddleName == null && other.MiddleName == null) || (this.MiddleName?.Equals(other.MiddleName) == true)) &&
                ((this.MobilePhone == null && other.MobilePhone == null) || (this.MobilePhone?.Equals(other.MobilePhone) == true)) &&
                ((this.MobileProvider == null && other.MobileProvider == null) || (this.MobileProvider?.Equals(other.MobileProvider) == true)) &&
                ((this.NewId == null && other.NewId == null) || (this.NewId?.Equals(other.NewId) == true)) &&
                ((this.Notes == null && other.Notes == null) || (this.Notes?.Equals(other.Notes) == true)) &&
                ((this.PhotoUrl == null && other.PhotoUrl == null) || (this.PhotoUrl?.Equals(other.PhotoUrl) == true)) &&
                ((this.PostalCode == null && other.PostalCode == null) || (this.PostalCode?.Equals(other.PostalCode) == true)) &&
                ((this.ProspectStage == null && other.ProspectStage == null) || (this.ProspectStage?.Equals(other.ProspectStage) == true)) &&
                ((this.RedAlert == null && other.RedAlert == null) || (this.RedAlert?.Equals(other.RedAlert) == true)) &&
                ((this.ReferredBy == null && other.ReferredBy == null) || (this.ReferredBy?.Equals(other.ReferredBy) == true)) &&
                ((this.SalesReps == null && other.SalesReps == null) || (this.SalesReps?.Equals(other.SalesReps) == true)) &&
                ((this.SiteId == null && other.SiteId == null) || (this.SiteId?.Equals(other.SiteId) == true)) &&
                ((this.State == null && other.State == null) || (this.State?.Equals(other.State) == true)) &&
                ((this.Status == null && other.Status == null) || (this.Status?.Equals(other.Status) == true)) &&
                ((this.Test == null && other.Test == null) || (this.Test?.Equals(other.Test) == true)) &&
                ((this.UniqueId == null && other.UniqueId == null) || (this.UniqueId?.Equals(other.UniqueId) == true)) &&
                ((this.WorkExtension == null && other.WorkExtension == null) || (this.WorkExtension?.Equals(other.WorkExtension) == true)) &&
                ((this.WorkPhone == null && other.WorkPhone == null) || (this.WorkPhone?.Equals(other.WorkPhone) == true)) &&
                ((this.YellowAlert == null && other.YellowAlert == null) || (this.YellowAlert?.Equals(other.YellowAlert) == true)) &&
                ((this.SendScheduleEmails == null && other.SendScheduleEmails == null) || (this.SendScheduleEmails?.Equals(other.SendScheduleEmails) == true)) &&
                ((this.SendAccountEmails == null && other.SendAccountEmails == null) || (this.SendAccountEmails?.Equals(other.SendAccountEmails) == true)) &&
                ((this.SendPromotionalEmails == null && other.SendPromotionalEmails == null) || (this.SendPromotionalEmails?.Equals(other.SendPromotionalEmails) == true)) &&
                ((this.SendScheduleTexts == null && other.SendScheduleTexts == null) || (this.SendScheduleTexts?.Equals(other.SendScheduleTexts) == true)) &&
                ((this.SendAccountTexts == null && other.SendAccountTexts == null) || (this.SendAccountTexts?.Equals(other.SendAccountTexts) == true)) &&
                ((this.SendPromotionalTexts == null && other.SendPromotionalTexts == null) || (this.SendPromotionalTexts?.Equals(other.SendPromotionalTexts) == true)) &&
                ((this.LockerNumber == null && other.LockerNumber == null) || (this.LockerNumber?.Equals(other.LockerNumber) == true)) &&
                ((this.ReactivateInactiveClient == null && other.ReactivateInactiveClient == null) || (this.ReactivateInactiveClient?.Equals(other.ReactivateInactiveClient) == true)) &&
                ((this.LeadChannelId == null && other.LeadChannelId == null) || (this.LeadChannelId?.Equals(other.LeadChannelId) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AccountBalance = {(this.AccountBalance == null ? "null" : this.AccountBalance.ToString())}");
            toStringOutput.Add($"this.Action = {(this.Action == null ? "null" : this.Action.ToString())}");
            toStringOutput.Add($"this.Active = {(this.Active == null ? "null" : this.Active.ToString())}");
            toStringOutput.Add($"this.AddressLine1 = {(this.AddressLine1 == null ? "null" : this.AddressLine1)}");
            toStringOutput.Add($"this.AddressLine2 = {(this.AddressLine2 == null ? "null" : this.AddressLine2)}");
            toStringOutput.Add($"this.ApptGenderPrefMale = {(this.ApptGenderPrefMale == null ? "null" : this.ApptGenderPrefMale.ToString())}");
            toStringOutput.Add($"this.BirthDate = {(this.BirthDate == null ? "null" : this.BirthDate.ToString())}");
            toStringOutput.Add($"this.City = {(this.City == null ? "null" : this.City)}");
            toStringOutput.Add($"this.ClientCreditCard = {(this.ClientCreditCard == null ? "null" : this.ClientCreditCard.ToString())}");
            toStringOutput.Add($"this.ClientIndexes = {(this.ClientIndexes == null ? "null" : $"[{string.Join(", ", this.ClientIndexes)} ]")}");
            toStringOutput.Add($"this.ClientRelationships = {(this.ClientRelationships == null ? "null" : $"[{string.Join(", ", this.ClientRelationships)} ]")}");
            toStringOutput.Add($"this.Country = {(this.Country == null ? "null" : this.Country)}");
            toStringOutput.Add($"this.CreationDate = {(this.CreationDate == null ? "null" : this.CreationDate.ToString())}");
            toStringOutput.Add($"this.CustomClientFields = {(this.CustomClientFields == null ? "null" : $"[{string.Join(", ", this.CustomClientFields)} ]")}");
            toStringOutput.Add($"this.Email = {(this.Email == null ? "null" : this.Email)}");
            toStringOutput.Add($"this.EmergencyContactInfoEmail = {(this.EmergencyContactInfoEmail == null ? "null" : this.EmergencyContactInfoEmail)}");
            toStringOutput.Add($"this.EmergencyContactInfoName = {(this.EmergencyContactInfoName == null ? "null" : this.EmergencyContactInfoName)}");
            toStringOutput.Add($"this.EmergencyContactInfoPhone = {(this.EmergencyContactInfoPhone == null ? "null" : this.EmergencyContactInfoPhone)}");
            toStringOutput.Add($"this.EmergencyContactInfoRelationship = {(this.EmergencyContactInfoRelationship == null ? "null" : this.EmergencyContactInfoRelationship)}");
            toStringOutput.Add($"this.FirstAppointmentDate = {(this.FirstAppointmentDate == null ? "null" : this.FirstAppointmentDate.ToString())}");
            toStringOutput.Add($"this.FirstName = {(this.FirstName == null ? "null" : this.FirstName)}");
            toStringOutput.Add($"this.Gender = {(this.Gender == null ? "null" : this.Gender)}");
            toStringOutput.Add($"this.HomeLocation = {(this.HomeLocation == null ? "null" : this.HomeLocation.ToString())}");
            toStringOutput.Add($"this.HomePhone = {(this.HomePhone == null ? "null" : this.HomePhone)}");
            toStringOutput.Add($"this.IsCompany = {(this.IsCompany == null ? "null" : this.IsCompany.ToString())}");
            toStringOutput.Add($"this.IsProspect = {(this.IsProspect == null ? "null" : this.IsProspect.ToString())}");
            toStringOutput.Add($"this.LastFormulaNotes = {(this.LastFormulaNotes == null ? "null" : this.LastFormulaNotes)}");
            toStringOutput.Add($"this.LastModifiedDateTime = {(this.LastModifiedDateTime == null ? "null" : this.LastModifiedDateTime.ToString())}");
            toStringOutput.Add($"this.LastName = {(this.LastName == null ? "null" : this.LastName)}");
            toStringOutput.Add($"this.Liability = {(this.Liability == null ? "null" : this.Liability.ToString())}");
            toStringOutput.Add($"this.LiabilityRelease = {(this.LiabilityRelease == null ? "null" : this.LiabilityRelease.ToString())}");
            toStringOutput.Add($"this.MembershipIcon = {(this.MembershipIcon == null ? "null" : this.MembershipIcon.ToString())}");
            toStringOutput.Add($"this.MiddleName = {(this.MiddleName == null ? "null" : this.MiddleName)}");
            toStringOutput.Add($"this.MobilePhone = {(this.MobilePhone == null ? "null" : this.MobilePhone)}");
            toStringOutput.Add($"this.MobileProvider = {(this.MobileProvider == null ? "null" : this.MobileProvider.ToString())}");
            toStringOutput.Add($"this.NewId = {(this.NewId == null ? "null" : this.NewId)}");
            toStringOutput.Add($"this.Notes = {(this.Notes == null ? "null" : this.Notes)}");
            toStringOutput.Add($"this.PhotoUrl = {(this.PhotoUrl == null ? "null" : this.PhotoUrl)}");
            toStringOutput.Add($"this.PostalCode = {(this.PostalCode == null ? "null" : this.PostalCode)}");
            toStringOutput.Add($"this.ProspectStage = {(this.ProspectStage == null ? "null" : this.ProspectStage.ToString())}");
            toStringOutput.Add($"this.RedAlert = {(this.RedAlert == null ? "null" : this.RedAlert)}");
            toStringOutput.Add($"this.ReferredBy = {(this.ReferredBy == null ? "null" : this.ReferredBy)}");
            toStringOutput.Add($"this.SalesReps = {(this.SalesReps == null ? "null" : $"[{string.Join(", ", this.SalesReps)} ]")}");
            toStringOutput.Add($"this.SiteId = {(this.SiteId == null ? "null" : this.SiteId.ToString())}");
            toStringOutput.Add($"this.State = {(this.State == null ? "null" : this.State)}");
            toStringOutput.Add($"this.Status = {(this.Status == null ? "null" : this.Status)}");
            toStringOutput.Add($"this.Test = {(this.Test == null ? "null" : this.Test.ToString())}");
            toStringOutput.Add($"this.UniqueId = {(this.UniqueId == null ? "null" : this.UniqueId.ToString())}");
            toStringOutput.Add($"this.WorkExtension = {(this.WorkExtension == null ? "null" : this.WorkExtension)}");
            toStringOutput.Add($"this.WorkPhone = {(this.WorkPhone == null ? "null" : this.WorkPhone)}");
            toStringOutput.Add($"this.YellowAlert = {(this.YellowAlert == null ? "null" : this.YellowAlert)}");
            toStringOutput.Add($"this.SendScheduleEmails = {(this.SendScheduleEmails == null ? "null" : this.SendScheduleEmails.ToString())}");
            toStringOutput.Add($"this.SendAccountEmails = {(this.SendAccountEmails == null ? "null" : this.SendAccountEmails.ToString())}");
            toStringOutput.Add($"this.SendPromotionalEmails = {(this.SendPromotionalEmails == null ? "null" : this.SendPromotionalEmails.ToString())}");
            toStringOutput.Add($"this.SendScheduleTexts = {(this.SendScheduleTexts == null ? "null" : this.SendScheduleTexts.ToString())}");
            toStringOutput.Add($"this.SendAccountTexts = {(this.SendAccountTexts == null ? "null" : this.SendAccountTexts.ToString())}");
            toStringOutput.Add($"this.SendPromotionalTexts = {(this.SendPromotionalTexts == null ? "null" : this.SendPromotionalTexts.ToString())}");
            toStringOutput.Add($"this.LockerNumber = {(this.LockerNumber == null ? "null" : this.LockerNumber)}");
            toStringOutput.Add($"this.ReactivateInactiveClient = {(this.ReactivateInactiveClient == null ? "null" : this.ReactivateInactiveClient.ToString())}");
            toStringOutput.Add($"this.LeadChannelId = {(this.LeadChannelId == null ? "null" : this.LeadChannelId.ToString())}");
        }
    }
}