// <copyright file="CommissionDetail.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using MINDBODYPublicAPI.Standard;
using MINDBODYPublicAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace MINDBODYPublicAPI.Standard.Models
{
    /// <summary>
    /// CommissionDetail.
    /// </summary>
    public class CommissionDetail
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CommissionDetail"/> class.
        /// </summary>
        public CommissionDetail()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CommissionDetail"/> class.
        /// </summary>
        /// <param name="commissionType">CommissionType.</param>
        /// <param name="commissionEarnings">CommissionEarnings.</param>
        public CommissionDetail(
            string commissionType = null,
            double? commissionEarnings = null)
        {
            this.CommissionType = commissionType;
            this.CommissionEarnings = commissionEarnings;
        }

        /// <summary>
        /// The type of commission earned. Possible values are:
        /// * ItemStandardPercentageCommission
        /// * ItemStandardFlatCommission
        /// * ItemPromotionalPercentageCommission
        /// * ItemPromotionalFlatCommission
        /// * StaffStandardPercentageCommission
        /// * StaffStandardFlatCommission
        /// * StaffPromotionalPercentageCommission
        /// * StaffPromotionalFlatCommission
        /// </summary>
        [JsonProperty("CommissionType", NullValueHandling = NullValueHandling.Ignore)]
        public string CommissionType { get; set; }

        /// <summary>
        /// The portion of `Earnings` earned by this `CommissionType`.
        /// </summary>
        [JsonProperty("CommissionEarnings", NullValueHandling = NullValueHandling.Ignore)]
        public double? CommissionEarnings { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CommissionDetail : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is CommissionDetail other &&                ((this.CommissionType == null && other.CommissionType == null) || (this.CommissionType?.Equals(other.CommissionType) == true)) &&
                ((this.CommissionEarnings == null && other.CommissionEarnings == null) || (this.CommissionEarnings?.Equals(other.CommissionEarnings) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.CommissionType = {(this.CommissionType == null ? "null" : this.CommissionType)}");
            toStringOutput.Add($"this.CommissionEarnings = {(this.CommissionEarnings == null ? "null" : this.CommissionEarnings.ToString())}");
        }
    }
}