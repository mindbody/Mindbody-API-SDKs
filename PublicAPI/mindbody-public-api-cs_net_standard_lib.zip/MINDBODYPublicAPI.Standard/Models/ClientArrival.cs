// <copyright file="ClientArrival.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using MINDBODYPublicAPI.Standard;
using MINDBODYPublicAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace MINDBODYPublicAPI.Standard.Models
{
    /// <summary>
    /// ClientArrival.
    /// </summary>
    public class ClientArrival
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ClientArrival"/> class.
        /// </summary>
        public ClientArrival()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ClientArrival"/> class.
        /// </summary>
        /// <param name="arrivalProgramID">ArrivalProgramID.</param>
        /// <param name="arrivalProgramName">ArrivalProgramName.</param>
        /// <param name="canAccess">CanAccess.</param>
        /// <param name="locationsIDs">LocationsIDs.</param>
        public ClientArrival(
            int? arrivalProgramID = null,
            string arrivalProgramName = null,
            bool? canAccess = null,
            List<int> locationsIDs = null)
        {
            this.ArrivalProgramID = arrivalProgramID;
            this.ArrivalProgramName = arrivalProgramName;
            this.CanAccess = canAccess;
            this.LocationsIDs = locationsIDs;
        }

        /// <summary>
        /// Arrival program id
        /// </summary>
        [JsonProperty("ArrivalProgramID", NullValueHandling = NullValueHandling.Ignore)]
        public int? ArrivalProgramID { get; set; }

        /// <summary>
        /// Arrival program name
        /// </summary>
        [JsonProperty("ArrivalProgramName", NullValueHandling = NullValueHandling.Ignore)]
        public string ArrivalProgramName { get; set; }

        /// <summary>
        /// Property to check client can access arrival service.
        /// </summary>
        [JsonProperty("CanAccess", NullValueHandling = NullValueHandling.Ignore)]
        public bool? CanAccess { get; set; }

        /// <summary>
        /// List of locations where arrival service can availed
        /// </summary>
        [JsonProperty("LocationsIDs", NullValueHandling = NullValueHandling.Ignore)]
        public List<int> LocationsIDs { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ClientArrival : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is ClientArrival other &&                ((this.ArrivalProgramID == null && other.ArrivalProgramID == null) || (this.ArrivalProgramID?.Equals(other.ArrivalProgramID) == true)) &&
                ((this.ArrivalProgramName == null && other.ArrivalProgramName == null) || (this.ArrivalProgramName?.Equals(other.ArrivalProgramName) == true)) &&
                ((this.CanAccess == null && other.CanAccess == null) || (this.CanAccess?.Equals(other.CanAccess) == true)) &&
                ((this.LocationsIDs == null && other.LocationsIDs == null) || (this.LocationsIDs?.Equals(other.LocationsIDs) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ArrivalProgramID = {(this.ArrivalProgramID == null ? "null" : this.ArrivalProgramID.ToString())}");
            toStringOutput.Add($"this.ArrivalProgramName = {(this.ArrivalProgramName == null ? "null" : this.ArrivalProgramName)}");
            toStringOutput.Add($"this.CanAccess = {(this.CanAccess == null ? "null" : this.CanAccess.ToString())}");
            toStringOutput.Add($"this.LocationsIDs = {(this.LocationsIDs == null ? "null" : $"[{string.Join(", ", this.LocationsIDs)} ]")}");
        }
    }
}