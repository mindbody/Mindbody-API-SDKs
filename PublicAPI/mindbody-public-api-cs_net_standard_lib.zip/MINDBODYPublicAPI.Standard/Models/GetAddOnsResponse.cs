// <copyright file="GetAddOnsResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using MINDBODYPublicAPI.Standard;
using MINDBODYPublicAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace MINDBODYPublicAPI.Standard.Models
{
    /// <summary>
    /// GetAddOnsResponse.
    /// </summary>
    public class GetAddOnsResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GetAddOnsResponse"/> class.
        /// </summary>
        public GetAddOnsResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GetAddOnsResponse"/> class.
        /// </summary>
        /// <param name="paginationResponse">PaginationResponse.</param>
        /// <param name="addOns">AddOns.</param>
        public GetAddOnsResponse(
            Models.PaginationResponse paginationResponse = null,
            List<Models.AppointmentAddOn> addOns = null)
        {
            this.PaginationResponse = paginationResponse;
            this.AddOns = addOns;
        }

        /// <summary>
        /// Contains information about the pagination to use.
        /// </summary>
        [JsonProperty("PaginationResponse", NullValueHandling = NullValueHandling.Ignore)]
        public Models.PaginationResponse PaginationResponse { get; set; }

        /// <summary>
        /// A list of available add-ons.
        /// </summary>
        [JsonProperty("AddOns", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.AppointmentAddOn> AddOns { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"GetAddOnsResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is GetAddOnsResponse other &&                ((this.PaginationResponse == null && other.PaginationResponse == null) || (this.PaginationResponse?.Equals(other.PaginationResponse) == true)) &&
                ((this.AddOns == null && other.AddOns == null) || (this.AddOns?.Equals(other.AddOns) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PaginationResponse = {(this.PaginationResponse == null ? "null" : this.PaginationResponse.ToString())}");
            toStringOutput.Add($"this.AddOns = {(this.AddOns == null ? "null" : $"[{string.Join(", ", this.AddOns)} ]")}");
        }
    }
}