// <copyright file="ContactLogType.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using MINDBODYPublicAPI.Standard;
using MINDBODYPublicAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace MINDBODYPublicAPI.Standard.Models
{
    /// <summary>
    /// ContactLogType.
    /// </summary>
    public class ContactLogType
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ContactLogType"/> class.
        /// </summary>
        public ContactLogType()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ContactLogType"/> class.
        /// </summary>
        /// <param name="id">Id.</param>
        /// <param name="name">Name.</param>
        /// <param name="subTypes">SubTypes.</param>
        public ContactLogType(
            int? id = null,
            string name = null,
            List<Models.ContactLogSubType> subTypes = null)
        {
            this.Id = id;
            this.Name = name;
            this.SubTypes = subTypes;
        }

        /// <summary>
        /// The Id of the contactlog Type.
        /// </summary>
        [JsonProperty("Id", NullValueHandling = NullValueHandling.Ignore)]
        public int? Id { get; set; }

        /// <summary>
        /// The name of the contactlog Type.
        /// </summary>
        [JsonProperty("Name", NullValueHandling = NullValueHandling.Ignore)]
        public string Name { get; set; }

        /// <summary>
        /// Contains the SubType objects, each of which describes the subtypes for a contactlog Type.
        /// </summary>
        [JsonProperty("SubTypes", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ContactLogSubType> SubTypes { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"ContactLogType : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is ContactLogType other &&
                (this.Id == null && other.Id == null ||
                 this.Id?.Equals(other.Id) == true) &&
                (this.Name == null && other.Name == null ||
                 this.Name?.Equals(other.Name) == true) &&
                (this.SubTypes == null && other.SubTypes == null ||
                 this.SubTypes?.Equals(other.SubTypes) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"Id = {(this.Id == null ? "null" : this.Id.ToString())}");
            toStringOutput.Add($"Name = {this.Name ?? "null"}");
            toStringOutput.Add($"SubTypes = {(this.SubTypes == null ? "null" : $"[{string.Join(", ", this.SubTypes)} ]")}");
        }
    }
}