// <copyright file="DirectDebitInfo.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using MINDBODYPublicAPI.Standard;
using MINDBODYPublicAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace MINDBODYPublicAPI.Standard.Models
{
    /// <summary>
    /// DirectDebitInfo.
    /// </summary>
    public class DirectDebitInfo
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DirectDebitInfo"/> class.
        /// </summary>
        public DirectDebitInfo()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DirectDebitInfo"/> class.
        /// </summary>
        /// <param name="nameOnAccount">NameOnAccount.</param>
        /// <param name="routingNumber">RoutingNumber.</param>
        /// <param name="accountNumber">AccountNumber.</param>
        /// <param name="accountType">AccountType.</param>
        public DirectDebitInfo(
            string nameOnAccount = null,
            string routingNumber = null,
            string accountNumber = null,
            string accountType = null)
        {
            this.NameOnAccount = nameOnAccount;
            this.RoutingNumber = routingNumber;
            this.AccountNumber = accountNumber;
            this.AccountType = accountType;
        }

        /// <summary>
        /// The name on the bank account.
        /// </summary>
        [JsonProperty("NameOnAccount", NullValueHandling = NullValueHandling.Ignore)]
        public string NameOnAccount { get; set; }

        /// <summary>
        /// The routing number for the bank.
        /// </summary>
        [JsonProperty("RoutingNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string RoutingNumber { get; set; }

        /// <summary>
        /// The last four of the bank account number.
        /// </summary>
        [JsonProperty("AccountNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string AccountNumber { get; set; }

        /// <summary>
        /// The account type.
        /// Possible values:
        /// * Checking
        /// * Savings
        /// </summary>
        [JsonProperty("AccountType", NullValueHandling = NullValueHandling.Ignore)]
        public string AccountType { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();
            this.ToString(toStringOutput);
            return $"DirectDebitInfo : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (ReferenceEquals(this, obj)) return true;

            return obj is DirectDebitInfo other &&
                (this.NameOnAccount == null && other.NameOnAccount == null ||
                 this.NameOnAccount?.Equals(other.NameOnAccount) == true) &&
                (this.RoutingNumber == null && other.RoutingNumber == null ||
                 this.RoutingNumber?.Equals(other.RoutingNumber) == true) &&
                (this.AccountNumber == null && other.AccountNumber == null ||
                 this.AccountNumber?.Equals(other.AccountNumber) == true) &&
                (this.AccountType == null && other.AccountType == null ||
                 this.AccountType?.Equals(other.AccountType) == true);
        }

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"NameOnAccount = {this.NameOnAccount ?? "null"}");
            toStringOutput.Add($"RoutingNumber = {this.RoutingNumber ?? "null"}");
            toStringOutput.Add($"AccountNumber = {this.AccountNumber ?? "null"}");
            toStringOutput.Add($"AccountType = {this.AccountType ?? "null"}");
        }
    }
}