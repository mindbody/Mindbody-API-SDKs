// <copyright file="ContentFormatEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using APIMatic.Core.Utilities.Converters;
using MINDBODYPublicAPI.Standard;
using MINDBODYPublicAPI.Standard.Utilities;
using Newtonsoft.Json;

namespace MINDBODYPublicAPI.Standard.Models
{
    /// <summary>
    /// ContentFormatEnum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum ContentFormatEnum
    {
        /// <summary>
        /// InPerson.
        /// </summary>
        [EnumMember(Value = "InPerson")]
        InPerson,

        /// <summary>
        /// Mindbody.
        /// </summary>
        [EnumMember(Value = "Mindbody")]
        Mindbody,

        /// <summary>
        /// Other.
        /// </summary>
        [EnumMember(Value = "Other")]
        Other
    }
}