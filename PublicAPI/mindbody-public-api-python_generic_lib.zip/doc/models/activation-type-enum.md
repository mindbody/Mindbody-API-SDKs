
# Activation Type Enum

Specifies how this pricing option is configured to activate.
This value reflects the activation behavior defined in the Core system when the pricing option was created.
Use this field to determine whether the ActiveDate represents the purchase date
or a future date pending the client's first visit.
Possible values:

- OnFirstVisit: The pricing option activates on the client's first visit (check-in) after purchase.
  The ActiveDate is set to the date of that first visit.
  Until the client checks in, the ActiveDate may be null or set to a future/placeholder date.
- OnPurchase: The pricing option activates immediately upon purchase.
  The ActiveDate is set to the purchase date.

## Enumeration

`ActivationTypeEnum`

## Fields

| Name |
|  --- |
| `ONFIRSTVISIT` |
| `ONPURCHASE` |

