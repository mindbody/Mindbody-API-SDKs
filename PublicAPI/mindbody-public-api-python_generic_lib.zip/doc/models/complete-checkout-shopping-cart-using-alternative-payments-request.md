
# Complete Checkout Shopping Cart Using Alternative Payments Request

The API Request model for Complete Checkout Shopping Cart API.

## Structure

`CompleteCheckoutShoppingCartUsingAlternativePaymentsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `access_token` | `str` | Required | The Access Token generated during Pre-Payment step. |
| `client_id` | `str` | Required | The RSSID of the client making the purchase. A cart can be validated without a client ID, but a client ID must be specified to complete a sale. |
| `test` | `bool` | Optional | When `true`, indicates that the contents of the cart are validated, but the transaction does not take place. You should use this parameter during testing and when checking the calculated totals of the items in the cart.<br /><br>When `false`, the transaction takes place and the database is affected.<br /><br>Default: **false** |

## Example (as JSON)

```json
{
  "AccessToken": "AccessToken2",
  "ClientId": "ClientId8",
  "Test": false
}
```

