
# Resource

## Structure

`Resource`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | - |
| `name` | `str` | Optional | - |

## Example (as JSON)

```json
{
  "Id": 22,
  "Name": "Name6"
}
```

