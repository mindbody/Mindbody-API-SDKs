
# Add Multiple Appointments Request

Request to add multiple appointments.

## Structure

`AddMultipleAppointmentsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `add_appointment_requests` | [`List[AddAppointmentRequest]`](../../doc/models/add-appointment-request.md) | Optional | List of appointment requests to be added. |

## Example (as JSON)

```json
{
  "AddAppointmentRequests": [
    {
      "ApplyPayment": false,
      "ClientId": "ClientId4",
      "Duration": 88,
      "Execute": "Execute6",
      "EndDateTime": "2016-03-13T12:52:32.123Z",
      "GenderPreference": "GenderPreference0",
      "LocationId": 102,
      "SessionTypeId": 202,
      "StaffId": 52,
      "StartDateTime": "2016-03-13T12:52:32.123Z"
    },
    {
      "ApplyPayment": false,
      "ClientId": "ClientId4",
      "Duration": 88,
      "Execute": "Execute6",
      "EndDateTime": "2016-03-13T12:52:32.123Z",
      "GenderPreference": "GenderPreference0",
      "LocationId": 102,
      "SessionTypeId": 202,
      "StaffId": 52,
      "StartDateTime": "2016-03-13T12:52:32.123Z"
    }
  ]
}
```

