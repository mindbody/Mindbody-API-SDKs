
# Frequency Type Enum

The class schedule recurrence type.

## Enumeration

`FrequencyTypeEnum`

## Fields

| Name |
|  --- |
| `DAILY` |
| `WEEKLY` |
| `MONTHLY` |

