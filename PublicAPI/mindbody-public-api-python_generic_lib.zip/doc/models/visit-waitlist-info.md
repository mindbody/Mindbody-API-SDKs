
# Visit Waitlist Info

A Visit DTO with Waitlist Informatoin

## Structure

`VisitWaitlistInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `waitlist_id` | `int` | Optional | waitlist entry Id |
| `waitlist_order_number` | `int` | Optional | order of the waitlist entry |

## Example (as JSON)

```json
{
  "WaitlistId": 6,
  "WaitlistOrderNumber": 74
}
```

