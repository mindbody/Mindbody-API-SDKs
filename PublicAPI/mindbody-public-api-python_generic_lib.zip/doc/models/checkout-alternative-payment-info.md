
# Checkout Alternative Payment Info

Request object to capture Alternative Payment information.

## Structure

`CheckoutAlternativePaymentInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payment_method_id` | `int` | Required | The type of alternative payment. Possible values are:<br><br>* 997 - Indicates that this payment item is iDEAL.<br>* 801 - Indicates that this payment item is Apple Pay. |
| `amount` | `float` | Required | The amount to be paid |

## Example (as JSON)

```json
{
  "PaymentMethodId": 88,
  "Amount": 128.28
}
```

