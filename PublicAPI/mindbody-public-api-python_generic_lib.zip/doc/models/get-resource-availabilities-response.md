
# Get Resource Availabilities Response

## Structure

`GetResourceAvailabilitiesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `resource_availabilities` | [`List[ResourceAvailability]`](../../doc/models/resource-availability.md) | Optional | Contains information about resources as the business. |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "ResourceAvailabilities": [
    {
      "ResourceId": 202,
      "StartDateTime": "2016-03-13T12:52:32.123Z",
      "EndDateTime": "2016-03-13T12:52:32.123Z"
    },
    {
      "ResourceId": 202,
      "StartDateTime": "2016-03-13T12:52:32.123Z",
      "EndDateTime": "2016-03-13T12:52:32.123Z"
    }
  ]
}
```

