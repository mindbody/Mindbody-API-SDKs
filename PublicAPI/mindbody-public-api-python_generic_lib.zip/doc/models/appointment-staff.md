
# Appointment Staff

## Structure

`AppointmentStaff`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `long\|int` | Optional | - |
| `first_name` | `str` | Optional | - |
| `last_name` | `str` | Optional | - |
| `display_name` | `str` | Optional | - |

## Example (as JSON)

```json
{
  "Id": 130,
  "FirstName": "FirstName2",
  "LastName": "LastName2",
  "DisplayName": "DisplayName4"
}
```

