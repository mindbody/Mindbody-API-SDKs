
# Resource Availability 1

An availability of a resource

## Structure

`ResourceAvailability1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `resource_id` | `int` | Optional | Id |
| `start_date_time` | `datetime` | Optional | Starts |
| `end_date_time` | `datetime` | Optional | Ends |
| `session_type_ids` | `List[int]` | Optional | List of SessionTypeIds that this availability is restricted to. If empty, no restrictions. |
| `program_ids` | `List[int]` | Optional | List of ProgramIds that this availability is restricted to. If empty, no restrictions. |

## Example (as JSON)

```json
{
  "ResourceId": 172,
  "StartDateTime": "2016-03-13T12:52:32.123Z",
  "EndDateTime": "2016-03-13T12:52:32.123Z",
  "SessionTypeIds": [
    106,
    107
  ],
  "ProgramIds": [
    16,
    17,
    18
  ]
}
```

