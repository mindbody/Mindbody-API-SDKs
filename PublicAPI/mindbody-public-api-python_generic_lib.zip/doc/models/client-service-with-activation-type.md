
# Client Service With Activation Type

Represents a pricing option (service) on a client's account, including activation behavior details.
<para>
This model extends {Mindbody.PublicApi.Dto.Models.V6.ClientService} to include additional fields that describe
how and when the pricing option becomes active for use.
</para><para>
For more information about pricing option activation, see the following support articles:
<list type="bullet"><item><description><see href="https://support.mindbodyonline.com/s/article/203268693-How-do-I-adjust-a-pricing-option-that-activates-on-the-date-of-client-s-first-visit-to-cover-a-visit-before-its-activation-date">How to change a pricing option activation date set to begin on the client's first visit</see></description></item><item><description><see href="https://support.mindbodyonline.com/s/article/Offset-Activation">How to set offset activation dates for contracts</see></description></item><item><description><see href="https://support.mindbodyonline.com/s/article/How-do-I-expire-terminate-an-unused-pricing-option-that-activates-on-date-of-first-visit">How do I expire or terminate an unused pricing option that activates on the date of the first visit?</see></description></item><item><description><see href="https://support.mindbodyonline.com/s/article/203257593-What-are-the-differences-between-the-different-pricing-option-activation-dates">Pricing option activation date options</see></description></item></list></para>

## Structure

`ClientServiceWithActivationType`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `activation_type` | [`ActivationTypeEnum`](../../doc/models/activation-type-enum.md) | Optional | Specifies how this pricing option is configured to activate.<br><para><br>This value reflects the activation behavior defined in the Core system when the pricing option was created.<br>Use this field to determine whether the {Mindbody.PublicApi.Dto.Models.V6.ClientService.ActiveDate} represents the purchase date<br>or a future date pending the client's first visit.<br></para><para><br>Possible values:<br><list type="bullet"><item><term>OnFirstVisit</term><description><br>The pricing option activates on the client's first visit (check-in) after purchase.<br>The {Mindbody.PublicApi.Dto.Models.V6.ClientService.ActiveDate} is set to the date of that first visit.<br>Until the client checks in, the {Mindbody.PublicApi.Dto.Models.V6.ClientService.ActiveDate} may be null or set to a future/placeholder date.<br></description></item><item><term>OnPurchase</term><description><br>The pricing option activates immediately upon purchase.<br>The {Mindbody.PublicApi.Dto.Models.V6.ClientService.ActiveDate} is set to the purchase date.<br></description></item></list></para> |
| `cannot_pay_for_classes_before_activation` | `bool` | Optional | Indicates whether the site enforces activation date restrictions for booking.<br><para><br>This value reflects the site-level setting EnforceActivationDates (also known as "Check Activation Dates")<br>for the subscriber identified by {Mindbody.PublicApi.Dto.Models.V6.ClientService.SiteId}.<br></para><para><br>When integrating with booking workflows, use this field in conjunction with {Mindbody.PublicApi.Dto.Models.V6.ClientServiceWithActivationType.ActivationType}<br>to determine if a pricing option can be applied for a booking:<br><list type="bullet"><item><term>true</term><description><br>The site enforces activation dates. The client cannot use this pricing option to pay for<br>classes or appointments scheduled before the {Mindbody.PublicApi.Dto.Models.V6.ClientService.ActiveDate}.<br></description></item><item><term>false</term><description><br>The site allows booking before activation. The client can use this pricing option to pay for<br>classes or appointments scheduled before the {Mindbody.PublicApi.Dto.Models.V6.ClientService.ActiveDate}.<br>This is commonly used with "Activate on First Visit" pricing options to allow immediate booking.<br></description></item></list></para> |
| `active_date` | `datetime` | Optional | The date that this pricing option became active and could be used to pay for services. |
| `count` | `int` | Optional | The number of service sessions this pricing option contained when first purchased. |
| `current` | `bool` | Optional | When `true`, there are service sessions remaining on the pricing option that can be used pay for the current session.<br /><br>When `false`, the client cannot use this pricing option to pay for other services. |
| `expiration_date` | `datetime` | Optional | The date when the pricing option expires and can no longer be used to pay for services, even if unused service sessions remain on the option; expressed as UTC. |
| `id` | `int` | Optional | The unique ID assigned to this pricing option, specific to when it was purchased by the client. |
| `product_id` | `int` | Optional | The unique ID of this pricing option, not specific to any client's purchase of it. |
| `name` | `str` | Optional | The name of this pricing option. |
| `payment_date` | `datetime` | Optional | The date on which the client paid for this pricing option. |
| `program` | [`Program`](../../doc/models/program.md) | Optional | Contains information about the service category this service falls under. |
| `remaining` | `int` | Optional | The number of service sessions remaining in the pricing option that can still be used. |
| `site_id` | `int` | Optional | The ID of the subscriber site associated with this pricing option. |
| `action` | [`Action1Enum`](../../doc/models/action-1-enum.md) | Optional | The action taken. |
| `client_id` | `str` | Optional | The Client ID assigned to this pricing option, specific to when it was purchased by the client. |
| `returned` | `bool` | Optional | Identification for purchased service is returned or not. |

## Example (as JSON)

```json
{
  "ActivationType": "OnFirstVisit",
  "CannotPayForClassesBeforeActivation": false,
  "ActiveDate": "2016-03-13T12:52:32.123Z",
  "Count": 210,
  "Current": false
}
```

