
# Initiate Purchase Contract Request

Request to initiate a purchase contract.

## Structure

`InitiatePurchaseContractRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `test` | `bool` | Optional | When `true`, the Public API validates input information, but does not commit it, so no client data is affected.<br /><br>When `false` or omitted, the transaction is committed, and client data is affected.<br /><br>Default: **false** |
| `location_id` | `int` | Required | The ID of the location where the client is purchasing the contract; used for AutoPays. |
| `client_id` | `str` | Required | The ID of the client. Note that this is not the same as the client’s unique ID. |
| `contract_id` | `int` | Required | The ID of the contract being purchased. |
| `promotion_code` | `str` | Optional | A promotion code, if one applies. Promotion codes are applied to items that are both marked as pay now in a contract and are discounted by the promotion code. If a pay now item is an autopay item, its autopay price is the price at the time of checkout, so, if a promotion code was applied, all autopays are scheduled using that discounted price. |
| `promotion_codes` | `List[str]` | Optional | Promotion codes, if they apply. Promotion codes are applied to items that are both marked as pay now in a contract and are discounted by the promotion code. If a pay now item is an autopay item, its autopay price is the price at the time of checkout, so, if a promotion code was applied, all autopays are scheduled using that discounted price. |
| `send_notifications` | `bool` | Optional | When `true`, indicates that email and SMS notifications should be sent to the client after purchase.<br /><br>Default: **true** |
| `sales_rep_id` | `int` | Optional | The ID of the staff member to be marked as the sales rep for this contract sale. |
| `payment_authentication_callback_url` | `str` | Optional | The URL consumer is redirected to if the bank requests SCA. This field is only needed if ConsumerPresent is true. |
| `payment_method_id` | `int` | Required | Name of the alternative payment method |

## Example (as JSON)

```json
{
  "Test": false,
  "LocationId": 176,
  "ClientId": "ClientId8",
  "ContractId": 10,
  "PromotionCode": "PromotionCode4",
  "PromotionCodes": [
    "PromotionCodes3",
    "PromotionCodes4"
  ],
  "SendNotifications": false,
  "SalesRepId": 182,
  "PaymentMethodId": 222
}
```

