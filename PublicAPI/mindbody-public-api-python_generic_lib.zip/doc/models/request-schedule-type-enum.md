
# Request Schedule Type Enum

## Enumeration

`RequestScheduleTypeEnum`

## Fields

| Name |
|  --- |
| `ALL` |
| `CLASS` |
| `ENROLLMENT` |
| `APPOINTMENT` |
| `RESOURCE` |
| `MEDIA` |
| `ARRIVAL` |

