
# Initiate Checkout Shopping Cart Using Alternative Payments Request

The API Request model for Initiate Checkout Shopping Cart API.

## Structure

`InitiateCheckoutShoppingCartUsingAlternativePaymentsRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `cartId` | `?string` | Optional | The unique ID of the shopping cart to be processed. You can use this value to maintain a persistent cart. If you do not specify a cart ID, the MINDBODY software generates one. | getCartId(): ?string | setCartId(?string cartId): void |
| `clientId` | `string` | Required | The RSSID of the client making the purchase. A cart can be validated without a client ID, but a client ID must be specified to complete a sale. | getClientId(): string | setClientId(string clientId): void |
| `payerClientId` | `?string` | Optional | The RSSID of the client paying for the purchase. This client needs to have a relationship of type "Pays for" with the client specified in the "ClientId" field. | getPayerClientId(): ?string | setPayerClientId(?string payerClientId): void |
| `test` | `?bool` | Optional | When `true`, indicates that the contents of the cart are validated, but the transaction does not take place. You should use this parameter during testing and when checking the calculated totals of the items in the cart.<br /><br>When `false`, the transaction takes place and the database is affected.<br /><br>Default: **false** | getTest(): ?bool | setTest(?bool test): void |
| `items` | [`CheckoutItemWrapper[]`](../../doc/models/checkout-item-wrapper.md) | Required | A list of the items in the cart. | getItems(): array | setItems(array items): void |
| `inStore` | `?bool` | Optional | When `true`, indicates that the cart is to be completed by a staff member and is to take place at one of the business’ physical locations.<br /><br>When `false`, indicates that the cart is to be completed by a client from the business’ online store.<br /><br>Default: **false** | getInStore(): ?bool | setInStore(?bool inStore): void |
| `calculateTax` | `?bool` | Optional | When `true`, indicates that the tax should be calculated.<br>When `false`, indicates that the tax should not be calculated.<br>Default: **true** | getCalculateTax(): ?bool | setCalculateTax(?bool calculateTax): void |
| `promotionCode` | `?string` | Optional | Promotion code to be applied to the cart. | getPromotionCode(): ?string | setPromotionCode(?string promotionCode): void |
| `payments` | [`CheckoutAlternativePaymentInfo[]`](../../doc/models/checkout-alternative-payment-info.md) | Required | A list of payment information objects to be applied to payment against the items in the cart. | getPayments(): array | setPayments(array payments): void |
| `sendEmail` | `?bool` | Optional | When `true`, sends a purchase receipt email to the client. Note that all appropriate permissions and settings must be enabled for the client to receive an email.<br /><br>Default: **false** | getSendEmail(): ?bool | setSendEmail(?bool sendEmail): void |
| `locationId` | `?int` | Optional | The location ID to be used for pulling business mode prices and taxes. If no location ID is supplied, it defaults to the online store, represented by a null value.<br>Default: **null** (the online store) | getLocationId(): ?int | setLocationId(?int locationId): void |
| `paymentAuthenticationCallbackUrl` | `string` | Required | The URL consumer is redirected to after the payment. | getPaymentAuthenticationCallbackUrl(): string | setPaymentAuthenticationCallbackUrl(string paymentAuthenticationCallbackUrl): void |
| `transactionIds` | `?(int[])` | Optional | The list of TransactionIds provided with initial response containing SCA Challenge URLs for ConsumerPresent transactions | getTransactionIds(): ?array | setTransactionIds(?array transactionIds): void |
| `isBillingPostalCodeRequired` | `?bool` | Optional | the flag to check billing post code is required or not. | getIsBillingPostalCodeRequired(): ?bool | setIsBillingPostalCodeRequired(?bool isBillingPostalCodeRequired): void |
| `enforceLocationRestrictions` | `?bool` | Optional | When `true`, enforces "sell at" location restrictions on the cart items.<br>When `false`, "sell at" location restrictions are not enforced.<br>Default: **false** | getEnforceLocationRestrictions(): ?bool | setEnforceLocationRestrictions(?bool enforceLocationRestrictions): void |

## Example (as JSON)

```json
{
  "CartId": "CartId6",
  "ClientId": "ClientId6",
  "PayerClientId": "PayerClientId8",
  "Test": false,
  "Items": [
    {
      "Item": {
        "Type": "Type2",
        "Metadata": {
          "key0": {
            "key1": "val1",
            "key2": "val2"
          }
        }
      },
      "SalesNotes": "SalesNotes6",
      "DiscountAmount": 41.36,
      "AppointmentBookingRequests": [
        {
          "StaffId": 16,
          "LocationId": 66,
          "SessionTypeId": 166,
          "Resources": [
            {
              "Id": 216,
              "Name": "Name6"
            },
            {
              "Id": 216,
              "Name": "Name6"
            },
            {
              "Id": 216,
              "Name": "Name6"
            }
          ],
          "StartDateTime": "2016-03-13T12:52:32.123Z"
        }
      ],
      "EnrollmentIds": [
        249,
        250
      ]
    },
    {
      "Item": {
        "Type": "Type2",
        "Metadata": {
          "key0": {
            "key1": "val1",
            "key2": "val2"
          }
        }
      },
      "SalesNotes": "SalesNotes6",
      "DiscountAmount": 41.36,
      "AppointmentBookingRequests": [
        {
          "StaffId": 16,
          "LocationId": 66,
          "SessionTypeId": 166,
          "Resources": [
            {
              "Id": 216,
              "Name": "Name6"
            },
            {
              "Id": 216,
              "Name": "Name6"
            },
            {
              "Id": 216,
              "Name": "Name6"
            }
          ],
          "StartDateTime": "2016-03-13T12:52:32.123Z"
        }
      ],
      "EnrollmentIds": [
        249,
        250
      ]
    }
  ],
  "InStore": false,
  "CalculateTax": false,
  "Payments": [
    {
      "PaymentMethodId": 20,
      "Amount": 24.8
    },
    {
      "PaymentMethodId": 20,
      "Amount": 24.8
    }
  ],
  "PaymentAuthenticationCallbackUrl": "PaymentAuthenticationCallbackUrl4"
}
```

