
# Cart Item

## Structure

`CartItem`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `item` | `?array` | Optional | - | getItem(): ?array | setItem(?array item): void |
| `salesNotes` | `?string` | Optional | Sales Notes for the Product Purcahsed | getSalesNotes(): ?string | setSalesNotes(?string salesNotes): void |
| `discountAmount` | `?float` | Optional | The amount of the discount applied to the item. | getDiscountAmount(): ?float | setDiscountAmount(?float discountAmount): void |
| `visitIds` | `?(int[])` | Optional | The IDs of the booked classes, enrollments, or courses that were reconciled by this cart item. This list is only returned if a valid visit ID was passed in the request’s `VisitIds` list. | getVisitIds(): ?array | setVisitIds(?array visitIds): void |
| `appointmentIds` | `?(int[])` | Optional | Gets or sets the item. | getAppointmentIds(): ?array | setAppointmentIds(?array appointmentIds): void |
| `appointments` | [`?(Appointment[])`](../../doc/models/appointment.md) | Optional | The IDs of the appointments that were reconciled by this cart item. This list is only returned if a valid appointment ID was passed in the request’s `AppointmentIds` list. | getAppointments(): ?array | setAppointments(?array appointments): void |
| `id` | `?int` | Optional | The item’s ID in the current cart. | getId(): ?int | setId(?int id): void |
| `quantity` | `?int` | Optional | The quantity of the item being purchased. | getQuantity(): ?int | setQuantity(?int quantity): void |

## Example (as JSON)

```json
{
  "Item": {
    "key1": "val1",
    "key2": "val2"
  },
  "SalesNotes": "SalesNotes0",
  "DiscountAmount": 228.72,
  "VisitIds": [
    128
  ],
  "AppointmentIds": [
    170,
    169,
    168
  ]
}
```

