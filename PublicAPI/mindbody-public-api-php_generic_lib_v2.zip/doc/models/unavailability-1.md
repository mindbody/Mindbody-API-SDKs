
# Unavailability 1

## Structure

`Unavailability1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | Unavailabiltity ID. | getId(): ?int | setId(?int id): void |
| `startDateTime` | `?DateTime` | Optional | Start of the unavailability. | getStartDateTime(): ?\DateTime | setStartDateTime(?\DateTime startDateTime): void |
| `endDateTime` | `?DateTime` | Optional | End of the unavailability. | getEndDateTime(): ?\DateTime | setEndDateTime(?\DateTime endDateTime): void |
| `description` | `?string` | Optional | Description of the unavailability. | getDescription(): ?string | setDescription(?string description): void |

## Example (as JSON)

```json
{
  "Id": 74,
  "StartDateTime": "2016-03-13T12:52:32.123Z",
  "EndDateTime": "2016-03-13T12:52:32.123Z",
  "Description": "Description6"
}
```

