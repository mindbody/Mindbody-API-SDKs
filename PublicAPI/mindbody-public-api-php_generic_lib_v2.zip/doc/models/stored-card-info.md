
# Stored Card Info

## Structure

`StoredCardInfo`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `lastFour` | `?string` | Optional | - | getLastFour(): ?string | setLastFour(?string lastFour): void |

## Example (as JSON)

```json
{
  "LastFour": "LastFour6"
}
```

