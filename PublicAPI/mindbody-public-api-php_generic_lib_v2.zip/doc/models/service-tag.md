
# Service Tag

ServiceTag refers to Category and Subcategory fields for classes and appointments

## Structure

`ServiceTag`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | - | getName(): ?string | setName(?string name): void |

## Example (as JSON)

```json
{
  "Id": 100,
  "Name": "Name2"
}
```

