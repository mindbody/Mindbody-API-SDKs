
# Update Product Price Response

Update Product Price Response Model

## Structure

`UpdateProductPriceResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `product` | [`?Product`](../../doc/models/product.md) | Optional | Represents a product. | getProduct(): ?Product | setProduct(?Product product): void |

## Example (as JSON)

```json
{
  "Product": {
    "ProductId": 172,
    "Id": "Id0",
    "CategoryId": 128,
    "SubCategoryId": 164,
    "SecondaryCategoryId": 118
  }
}
```

