
# Update Product Request

Update Product Request Model

## Structure

`UpdateProductRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `barcodeId` | `?string` | Optional | The unique ID of the product variant, for example, a particular size and color combination. | getBarcodeId(): ?string | setBarcodeId(?string barcodeId): void |
| `price` | `?float` | Optional | The price of the product.<br>**Constraints**: `>= 0` | getPrice(): ?float | setPrice(?float price): void |
| `onlinePrice` | `?float` | Optional | The online price of the product.<br>**Constraints**: `>= 0` | getOnlinePrice(): ?float | setOnlinePrice(?float onlinePrice): void |

## Example (as JSON)

```json
{
  "BarcodeId": "BarcodeId8",
  "Price": 24.38,
  "OnlinePrice": 58.9
}
```

