
# Applicable Item

Item that will be applied to a promo code

## Structure

`ApplicableItem`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | `?string` | Optional | Type of a promo code<br>The promotional item type.<br>Possible values are:<br><br>* ServiceCategory<br>* RevenueCategory<br>* Supplier<br>* Item | getType(): ?string | setType(?string type): void |
| `id` | `?int` | Optional | The promotional item ID. | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | The promotional item name. | getName(): ?string | setName(?string name): void |

## Example (as JSON)

```json
{
  "Type": "Type4",
  "Id": 154,
  "Name": "Name4"
}
```

