
# Shopping Cart

Represents a shopping cart.

## Structure

`ShoppingCart`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?string` | Optional | The shopping cart ID. | getId(): ?string | setId(?string id): void |
| `cartItems` | [`?(CartItem[])`](../../doc/models/cart-item.md) | Optional | Contains information about the items in the shopping cart. | getCartItems(): ?array | setCartItems(?array cartItems): void |
| `subTotal` | `?float` | Optional | The cart’s total cost before taxes and discounts were applied. | getSubTotal(): ?float | setSubTotal(?float subTotal): void |
| `discountTotal` | `?float` | Optional | The monetary amount removed from the cart’s total cost by applied discounts. | getDiscountTotal(): ?float | setDiscountTotal(?float discountTotal): void |
| `taxTotal` | `?float` | Optional | The monetary amount paid in taxes, included in the cart’s `GrandTotal`. | getTaxTotal(): ?float | setTaxTotal(?float taxTotal): void |
| `grandTotal` | `?float` | Optional | The cart’s total cost, including taxes and discounts. | getGrandTotal(): ?float | setGrandTotal(?float grandTotal): void |
| `transactions` | [`?(TransactionResponse[])`](../../doc/models/transaction-response.md) | Optional | Contains information returned from the first call to CheckoutShoppingCart. | getTransactions(): ?array | setTransactions(?array transactions): void |
| `saleId` | `?int` | Optional | The ID of the sale associated with the shopping cart. | getSaleId(): ?int | setSaleId(?int saleId): void |

## Example (as JSON)

```json
{
  "Id": "Id0",
  "CartItems": [
    {
      "Item": {
        "key1": "val1",
        "key2": "val2"
      },
      "SalesNotes": "SalesNotes8",
      "DiscountAmount": 4.36,
      "VisitIds": [
        232,
        233
      ],
      "AppointmentIds": [
        98
      ]
    },
    {
      "Item": {
        "key1": "val1",
        "key2": "val2"
      },
      "SalesNotes": "SalesNotes8",
      "DiscountAmount": 4.36,
      "VisitIds": [
        232,
        233
      ],
      "AppointmentIds": [
        98
      ]
    },
    {
      "Item": {
        "key1": "val1",
        "key2": "val2"
      },
      "SalesNotes": "SalesNotes8",
      "DiscountAmount": 4.36,
      "VisitIds": [
        232,
        233
      ],
      "AppointmentIds": [
        98
      ]
    }
  ],
  "SubTotal": 108.54,
  "DiscountTotal": 99.92,
  "TaxTotal": 136.36
}
```

