
# Get Transactions Response

Get transactions response properties

## Structure

`GetTransactionsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `transactions` | [`?(Transaction[])`](../../doc/models/transaction.md) | Optional | Contains the transaction objects, each of which describes the transaction details for a purchase event. | getTransactions(): ?array | setTransactions(?array transactions): void |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "Transactions": [
    {
      "TransactionId": 34,
      "SaleId": 160,
      "ClientId": 92,
      "Amount": 30.14,
      "Settled": false
    }
  ]
}
```

