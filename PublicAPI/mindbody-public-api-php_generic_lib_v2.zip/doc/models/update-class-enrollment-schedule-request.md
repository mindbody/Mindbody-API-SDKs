
# Update Class Enrollment Schedule Request

## Structure

`UpdateClassEnrollmentScheduleRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `classId` | `?int` | Optional | The class id, a block of schedules | getClassId(): ?int | setClassId(?int classId): void |
| `classDescriptionId` | `?int` | Optional | Used only internally, overridden if sent | getClassDescriptionId(): ?int | setClassDescriptionId(?int classDescriptionId): void |
| `locationId` | `?int` | Optional | The location where the class is taking place | getLocationId(): ?int | setLocationId(?int locationId): void |
| `startDate` | `?DateTime` | Optional | Class start time (use null for TBD) | getStartDate(): ?\DateTime | setStartDate(?\DateTime startDate): void |
| `endDate` | `?DateTime` | Optional | Class end time (ignored if StartTime is null) | getEndDate(): ?\DateTime | setEndDate(?\DateTime endDate): void |
| `startTime` | `?DateTime` | Optional | Class start time (use null for TBD) | getStartTime(): ?\DateTime | setStartTime(?\DateTime startTime): void |
| `endTime` | `?DateTime` | Optional | Class end time (ignored if StartTime is null) | getEndTime(): ?\DateTime | setEndTime(?\DateTime endTime): void |
| `daySunday` | `?bool` | Optional | (optional) - If the class occurs on Sunday (ignored if EndDate is null) | getDaySunday(): ?bool | setDaySunday(?bool daySunday): void |
| `dayMonday` | `?bool` | Optional | (optional) - If the class occurs on Monday (ignored if EndDate is null) | getDayMonday(): ?bool | setDayMonday(?bool dayMonday): void |
| `dayTuesday` | `?bool` | Optional | (optional) - If the class occurs on Tuesday (ignored if EndDate is null) | getDayTuesday(): ?bool | setDayTuesday(?bool dayTuesday): void |
| `dayWednesday` | `?bool` | Optional | (optional) - If the class occurs on Wednesday (ignored if EndDate is null) | getDayWednesday(): ?bool | setDayWednesday(?bool dayWednesday): void |
| `dayThursday` | `?bool` | Optional | (optional) - If the class occurs on Thursday (ignored if EndDate is null) | getDayThursday(): ?bool | setDayThursday(?bool dayThursday): void |
| `dayFriday` | `?bool` | Optional | (optional) - If the class occurs on Friday (ignored if EndDate is null) | getDayFriday(): ?bool | setDayFriday(?bool dayFriday): void |
| `daySaturday` | `?bool` | Optional | (optional) - If the class occurs on Saturday (ignored if EndDate is null | getDaySaturday(): ?bool | setDaySaturday(?bool daySaturday): void |
| `staffId` | `?int` | Optional | The staff member teaching the class | getStaffId(): ?int | setStaffId(?int staffId): void |
| `staffPayRate` | `?int` | Optional | The staff pay rate | getStaffPayRate(): ?int | setStaffPayRate(?int staffPayRate): void |
| `resourceId` | `?int` | Optional | (optional) - The room where the class is taking place | getResourceId(): ?int | setResourceId(?int resourceId): void |
| `maxCapacity` | `?int` | Optional | How many people can attend | getMaxCapacity(): ?int | setMaxCapacity(?int maxCapacity): void |
| `webCapacity` | `?int` | Optional | How many people can signup online (if 0 clients cannot signup online) | getWebCapacity(): ?int | setWebCapacity(?int webCapacity): void |
| `waitlistCapacity` | `?int` | Optional | One of: PaymentRequired, BookAndPayLater, Free | getWaitlistCapacity(): ?int | setWaitlistCapacity(?int waitlistCapacity): void |
| `bookingStatus` | `?string` | Optional | One of: PaymentRequired, BookAndPayLater, Free | getBookingStatus(): ?string | setBookingStatus(?string bookingStatus): void |
| `allowOpenEnrollment` | `?bool` | Optional | Allow clients to choose which sessions they'd like to sign up for | getAllowOpenEnrollment(): ?bool | setAllowOpenEnrollment(?bool allowOpenEnrollment): void |
| `allowDateForwardEnrollment` | `?bool` | Optional | Allow booking after the enrollment has started | getAllowDateForwardEnrollment(): ?bool | setAllowDateForwardEnrollment(?bool allowDateForwardEnrollment): void |
| `retainScheduleChanges` | `?bool` | Optional | Whether or not to retain manual schedule changes within the date range | getRetainScheduleChanges(): ?bool | setRetainScheduleChanges(?bool retainScheduleChanges): void |

## Example (as JSON)

```json
{
  "ClassId": 200,
  "ClassDescriptionId": 176,
  "LocationId": 92,
  "StartDate": "2016-03-13T12:52:32.123Z",
  "EndDate": "2016-03-13T12:52:32.123Z"
}
```

