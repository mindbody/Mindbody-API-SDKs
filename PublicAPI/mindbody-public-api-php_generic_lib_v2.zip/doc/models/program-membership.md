
# Program Membership

## Structure

`ProgramMembership`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The service category’s ID. | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | The name of this service category. | getName(): ?string | setName(?string name): void |

## Example (as JSON)

```json
{
  "Id": 48,
  "Name": "Name0"
}
```

