
# Category

## Structure

`Category`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The category Id used for api calls. | getId(): ?int | setId(?int id): void |
| `categoryName` | `?string` | Optional | Category Name | getCategoryName(): ?string | setCategoryName(?string categoryName): void |
| `description` | `?string` | Optional | Category Description | getDescription(): ?string | setDescription(?string description): void |
| `service` | `?bool` | Optional | Category service | getService(): ?bool | setService(?bool service): void |
| `active` | `?bool` | Optional | Check if Category is active. | getActive(): ?bool | setActive(?bool active): void |
| `isPrimary` | `?bool` | Optional | Check if Category is of primary type. | getIsPrimary(): ?bool | setIsPrimary(?bool isPrimary): void |
| `isSecondary` | `?bool` | Optional | Check if Category is of secondary type. | getIsSecondary(): ?bool | setIsSecondary(?bool isSecondary): void |
| `createdDateTimeUTC` | `?DateTime` | Optional | Category Created DateTime UTC | getCreatedDateTimeUTC(): ?\DateTime | setCreatedDateTimeUTC(?\DateTime createdDateTimeUTC): void |
| `modifiedDateTimeUTC` | `?DateTime` | Optional | Category Modified DateTime UTC | getModifiedDateTimeUTC(): ?\DateTime | setModifiedDateTimeUTC(?\DateTime modifiedDateTimeUTC): void |
| `subCategories` | [`?(SubCategory[])`](../../doc/models/sub-category.md) | Optional | Contains the SubCategory objects, each of which describes the subcategories for a category. | getSubCategories(): ?array | setSubCategories(?array subCategories): void |
| `totalCount` | `?int` | Optional | Get total number of rows | getTotalCount(): ?int | setTotalCount(?int totalCount): void |

## Example (as JSON)

```json
{
  "Id": 30,
  "CategoryName": "CategoryName0",
  "Description": "Description8",
  "Service": false,
  "Active": false
}
```

