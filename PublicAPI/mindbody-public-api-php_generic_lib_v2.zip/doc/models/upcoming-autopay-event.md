
# Upcoming Autopay Event

## Structure

`UpcomingAutopayEvent`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `clientContractId` | `?int` | Optional | The ID of the contract. | getClientContractId(): ?int | setClientContractId(?int clientContractId): void |
| `chargeAmount` | `?float` | Optional | The amount charged. | getChargeAmount(): ?float | setChargeAmount(?float chargeAmount): void |
| `subtotal` | `?float` | Optional | Subtotal before tax. | getSubtotal(): ?float | setSubtotal(?float subtotal): void |
| `tax` | `?float` | Optional | Tax amount. | getTax(): ?float | setTax(?float tax): void |
| `paymentMethod` | [`?string(PaymentMethodEnum)`](../../doc/models/payment-method-enum.md) | Optional | The payment method. | getPaymentMethod(): ?string | setPaymentMethod(?string paymentMethod): void |
| `scheduleDate` | `?DateTime` | Optional | The date and time of the next payment. | getScheduleDate(): ?\DateTime | setScheduleDate(?\DateTime scheduleDate): void |
| `productId` | `?int` | Optional | The product id. | getProductId(): ?int | setProductId(?int productId): void |

## Example (as JSON)

```json
{
  "ClientContractId": 28,
  "ChargeAmount": 36.94,
  "Subtotal": 66.48,
  "Tax": 77.72,
  "PaymentMethod": "DebitAccount"
}
```

