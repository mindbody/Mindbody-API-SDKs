
# Get Session Types Response

## Structure

`GetSessionTypesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination properties used. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `sessionTypes` | [`?(SessionType[])`](../../doc/models/session-type.md) | Optional | Contains information about sessions. | getSessionTypes(): ?array | setSessionTypes(?array sessionTypes): void |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "SessionTypes": [
    {
      "Type": "Media",
      "DefaultTimeLength": 254,
      "StaffTimeLength": 232,
      "Id": 24,
      "Name": "Name6"
    },
    {
      "Type": "Media",
      "DefaultTimeLength": 254,
      "StaffTimeLength": 232,
      "Id": 24,
      "Name": "Name6"
    },
    {
      "Type": "Media",
      "DefaultTimeLength": 254,
      "StaffTimeLength": 232,
      "Id": 24,
      "Name": "Name6"
    }
  ]
}
```

