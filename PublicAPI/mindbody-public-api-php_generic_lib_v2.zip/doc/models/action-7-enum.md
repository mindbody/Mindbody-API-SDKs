
# Action 7 Enum

The action performed on this object.

## Enumeration

`Action7Enum`

## Fields

| Name |
|  --- |
| `NONE` |
| `ADDED` |
| `UPDATED` |
| `FAILED` |
| `REMOVED` |

