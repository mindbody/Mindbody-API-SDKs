
# Copy Credit Card Request

crosssite/copycreditcard

## Structure

`CopyCreditCardRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `sourceSiteId` | `?int` | Optional | The siteId of the source clientId. | getSourceSiteId(): ?int | setSourceSiteId(?int sourceSiteId): void |
| `sourceClientId` | `?string` | Optional | The clientId at the source siteId. | getSourceClientId(): ?string | setSourceClientId(?string sourceClientId): void |
| `sourceUniqueClientId` | `?int` | Optional | The unique clidnetId at the source siteId. | getSourceUniqueClientId(): ?int | setSourceUniqueClientId(?int sourceUniqueClientId): void |
| `targetSiteId` | `?int` | Optional | The siteId of the target clientId. | getTargetSiteId(): ?int | setTargetSiteId(?int targetSiteId): void |
| `targetClientId` | `?string` | Optional | The clientId at the target siteId. | getTargetClientId(): ?string | setTargetClientId(?string targetClientId): void |
| `targetUniqueClientId` | `?int` | Optional | The unique clidnetId at the target siteId. | getTargetUniqueClientId(): ?int | setTargetUniqueClientId(?int targetUniqueClientId): void |

## Example (as JSON)

```json
{
  "SourceSiteId": 96,
  "SourceClientId": "SourceClientId8",
  "SourceUniqueClientId": 172,
  "TargetSiteId": 228,
  "TargetClientId": "TargetClientId2"
}
```

