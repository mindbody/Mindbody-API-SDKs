
# Get Client Referral Types Response

## Structure

`GetClientReferralTypesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `referralTypes` | `?(string[])` | Optional | The list of available referral types. | getReferralTypes(): ?array | setReferralTypes(?array referralTypes): void |

## Example (as JSON)

```json
{
  "ReferralTypes": [
    "ReferralTypes1",
    "ReferralTypes0",
    "ReferralTypes9"
  ]
}
```

