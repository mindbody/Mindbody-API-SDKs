
# Client Index

A client index.

## Structure

`ClientIndex`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The unique ID of the client index. | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | The name of the client index. | getName(): ?string | setName(?string name): void |
| `requiredBusinessMode` | `?bool` | Optional | When `true`, indicates that the index is required when creating profiles in business mode. | getRequiredBusinessMode(): ?bool | setRequiredBusinessMode(?bool requiredBusinessMode): void |
| `requiredConsumerMode` | `?bool` | Optional | When `true`, indicates that the index is required when creating profiles in consumer mode. | getRequiredConsumerMode(): ?bool | setRequiredConsumerMode(?bool requiredConsumerMode): void |
| `values` | [`?(ClientIndexValue[])`](../../doc/models/client-index-value.md) | Optional | Contains a list with a single object representing the index value assigned to the client index. | getValues(): ?array | setValues(?array values): void |
| `action` | [`?string(Action7Enum)`](../../doc/models/action-7-enum.md) | Optional | The action performed on this object. | getAction(): ?string | setAction(?string action): void |

## Example (as JSON)

```json
{
  "Id": 214,
  "Name": "Name4",
  "RequiredBusinessMode": false,
  "RequiredConsumerMode": false,
  "Values": [
    {
      "Active": false,
      "Id": 34,
      "Name": "Name4"
    },
    {
      "Active": false,
      "Id": 34,
      "Name": "Name4"
    }
  ]
}
```

