
# Get Sites Response

## Structure

`GetSitesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `sites` | [`?(Site[])`](../../doc/models/site.md) | Optional | Contains information about the sites. | getSites(): ?array | setSites(?array sites): void |

## Example (as JSON)

```json
{
  "Sites": [
    {
      "LeadChannels": [
        {
          "UniversalCustomerId": "00000000-0000-0000-0000-000000000000"
        }
      ],
      "AcceptsAmericanExpress": false,
      "AcceptsDiscover": false,
      "AcceptsMasterCard": false,
      "AcceptsVisa": false,
      "AllowsDashboardAccess": false
    }
  ],
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  }
}
```

