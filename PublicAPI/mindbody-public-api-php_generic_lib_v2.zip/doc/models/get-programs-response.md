
# Get Programs Response

## Structure

`GetProgramsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `programs` | [`?(Program[])`](../../doc/models/program.md) | Optional | Contains information about the programs. | getPrograms(): ?array | setPrograms(?array programs): void |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "Programs": [
    {
      "Id": 192,
      "Name": "Name8",
      "ScheduleType": "Appointment",
      "CancelOffset": 182,
      "ContentFormats": [
        "ContentFormats9"
      ]
    },
    {
      "Id": 192,
      "Name": "Name8",
      "ScheduleType": "Appointment",
      "CancelOffset": 182,
      "ContentFormats": [
        "ContentFormats9"
      ]
    }
  ]
}
```

