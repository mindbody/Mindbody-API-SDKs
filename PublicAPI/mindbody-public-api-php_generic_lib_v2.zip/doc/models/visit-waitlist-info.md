
# Visit Waitlist Info

A Visit DTO with Waitlist Informatoin

## Structure

`VisitWaitlistInfo`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `waitlistId` | `?int` | Optional | waitlist entry Id | getWaitlistId(): ?int | setWaitlistId(?int waitlistId): void |
| `waitlistOrderNumber` | `?int` | Optional | order of the waitlist entry | getWaitlistOrderNumber(): ?int | setWaitlistOrderNumber(?int waitlistOrderNumber): void |

## Example (as JSON)

```json
{
  "WaitlistId": 6,
  "WaitlistOrderNumber": 74
}
```

