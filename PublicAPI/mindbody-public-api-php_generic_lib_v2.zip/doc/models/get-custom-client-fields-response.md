
# Get Custom Client Fields Response

## Structure

`GetCustomClientFieldsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `customClientFields` | [`?(CustomClientField[])`](../../doc/models/custom-client-field.md) | Optional | Contains information about the available custom client fields. | getCustomClientFields(): ?array | setCustomClientFields(?array customClientFields): void |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "CustomClientFields": [
    {
      "Id": 112,
      "DataType": "DataType2",
      "Name": "Name8"
    },
    {
      "Id": 112,
      "DataType": "DataType2",
      "Name": "Name8"
    },
    {
      "Id": 112,
      "DataType": "DataType2",
      "Name": "Name8"
    }
  ]
}
```

