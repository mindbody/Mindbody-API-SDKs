
# Program 1

## Structure

`Program1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `cancelOffset` | `?int` | Optional | - | getCancelOffset(): ?int | setCancelOffset(?int cancelOffset): void |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | - | getName(): ?string | setName(?string name): void |
| `scheduleType` | [`?string(ScheduleType2Enum)`](../../doc/models/schedule-type-2-enum.md) | Optional | - | getScheduleType(): ?string | setScheduleType(?string scheduleType): void |
| `contentFormat` | [`?string(ContentFormatEnum)`](../../doc/models/content-format-enum.md) | Optional | - | getContentFormat(): ?string | setContentFormat(?string contentFormat): void |
| `onlineBookingDisabled` | `?bool` | Optional | - | getOnlineBookingDisabled(): ?bool | setOnlineBookingDisabled(?bool onlineBookingDisabled): void |
| `scheduleOffset` | `?int` | Optional | - | getScheduleOffset(): ?int | setScheduleOffset(?int scheduleOffset): void |
| `scheduleOffsetEnd` | `?int` | Optional | - | getScheduleOffsetEnd(): ?int | setScheduleOffsetEnd(?int scheduleOffsetEnd): void |
| `pricingRelationships` | [`?PricingRelationships`](../../doc/models/pricing-relationships.md) | Optional | - | getPricingRelationships(): ?PricingRelationships | setPricingRelationships(?PricingRelationships pricingRelationships): void |

## Example (as JSON)

```json
{
  "CancelOffset": 146,
  "Id": 156,
  "Name": "Name4",
  "ScheduleType": "Resource",
  "ContentFormat": "Other"
}
```

