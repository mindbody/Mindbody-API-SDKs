
# Checkout Alternative Payment Info

Request object to capture Alternative Payment information.

## Structure

`CheckoutAlternativePaymentInfo`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paymentMethodType` | `string` | Required | The type of alterntive payment. Possible values are:<br><br>* Ideal | getPaymentMethodType(): string | setPaymentMethodType(string paymentMethodType): void |
| `amount` | `float` | Required | The amount to be paid | getAmount(): float | setAmount(float amount): void |

## Example (as JSON)

```json
{
  "PaymentMethodType": "PaymentMethodType2",
  "Amount": 128.28
}
```

