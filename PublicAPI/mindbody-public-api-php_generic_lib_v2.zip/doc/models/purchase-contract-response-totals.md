
# Purchase Contract Response Totals

Totals for the purchase

## Structure

`PurchaseContractResponseTotals`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `total` | `?float` | Optional | Total payment amount | getTotal(): ?float | setTotal(?float total): void |
| `subTotal` | `?float` | Optional | Sub total. For VAT, sum of asking prices (include taxes, excludes discounts). For non vat, excludes taxes and discounts. | getSubTotal(): ?float | setSubTotal(?float subTotal): void |
| `discount` | `?float` | Optional | Discount | getDiscount(): ?float | setDiscount(?float discount): void |
| `tax` | `?float` | Optional | Tax | getTax(): ?float | setTax(?float tax): void |

## Example (as JSON)

```json
{
  "Total": 58.52,
  "SubTotal": 16.62,
  "Discount": 230.64,
  "Tax": 195.98
}
```

