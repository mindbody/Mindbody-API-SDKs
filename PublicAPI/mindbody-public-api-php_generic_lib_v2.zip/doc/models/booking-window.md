
# Booking Window

The booking window for registration

## Structure

`BookingWindow`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `startDateTime` | `?DateTime` | Optional | Date and time that the booking window opens; that is, the first day of sales. | getStartDateTime(): ?\DateTime | setStartDateTime(?\DateTime startDateTime): void |
| `endDateTime` | `?DateTime` | Optional | Date and time that the booking window closes; that is, the last day of sales. | getEndDateTime(): ?\DateTime | setEndDateTime(?\DateTime endDateTime): void |
| `dailyStartTime` | `?DateTime` | Optional | The time that the booking window opens; that is, the time that the store opens. | getDailyStartTime(): ?\DateTime | setDailyStartTime(?\DateTime dailyStartTime): void |
| `dailyEndTime` | `?DateTime` | Optional | The time that the booking window closes; that is, the time that the store closes. | getDailyEndTime(): ?\DateTime | setDailyEndTime(?\DateTime dailyEndTime): void |

## Example (as JSON)

```json
{
  "StartDateTime": "2016-03-13T12:52:32.123Z",
  "EndDateTime": "2016-03-13T12:52:32.123Z",
  "DailyStartTime": "2016-03-13T12:52:32.123Z",
  "DailyEndTime": "2016-03-13T12:52:32.123Z"
}
```

