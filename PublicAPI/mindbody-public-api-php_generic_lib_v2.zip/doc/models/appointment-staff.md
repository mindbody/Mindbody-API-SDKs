
# Appointment Staff

## Structure

`AppointmentStaff`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `firstName` | `?string` | Optional | - | getFirstName(): ?string | setFirstName(?string firstName): void |
| `lastName` | `?string` | Optional | - | getLastName(): ?string | setLastName(?string lastName): void |
| `displayName` | `?string` | Optional | - | getDisplayName(): ?string | setDisplayName(?string displayName): void |

## Example (as JSON)

```json
{
  "Id": 130,
  "FirstName": "FirstName2",
  "LastName": "LastName2",
  "DisplayName": "DisplayName4"
}
```

