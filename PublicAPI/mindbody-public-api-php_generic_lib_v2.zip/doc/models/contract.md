
# Contract

## Structure

`Contract`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The contract’s ID at the subscriber’s business. | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | The name of the contract. | getName(): ?string | setName(?string name): void |
| `description` | `?string` | Optional | A description of the contract. | getDescription(): ?string | setDescription(?string description): void |
| `assignsMembershipId` | `?int` | Optional | The ID of the membership that was assigned to the client when the client signed up for a contract. | getAssignsMembershipId(): ?int | setAssignsMembershipId(?int assignsMembershipId): void |
| `assignsMembershipName` | `?string` | Optional | The name of the membership that was assigned to the client when the client signed up for this contract. | getAssignsMembershipName(): ?string | setAssignsMembershipName(?string assignsMembershipName): void |
| `soldOnline` | `?bool` | Optional | When `true`, indicates that this membership is intended to be shown to clients in client experiences.<br /><br>When `false`, this contract should only be shown to staff members. | getSoldOnline(): ?bool | setSoldOnline(?bool soldOnline): void |
| `contractItems` | [`?(ContractItem[])`](../../doc/models/contract-item.md) | Optional | Contains information about the items in the contract. | getContractItems(): ?array | setContractItems(?array contractItems): void |
| `introOffer` | `?string` | Optional | Defines whether this contract is treated as an introductory offer. If this is an introductory offer, then clients are always charged a set number of times rather than month to month, using their AutoPays. Possible values are:<br><br>* None<br>* NewConsumer<br>* NewAndReturningConsumer | getIntroOffer(): ?string | setIntroOffer(?string introOffer): void |
| `autopaySchedule` | [`?AutopaySchedule`](../../doc/models/autopay-schedule.md) | Optional | - | getAutopaySchedule(): ?AutopaySchedule | setAutopaySchedule(?AutopaySchedule autopaySchedule): void |
| `numberOfAutopays` | `?int` | Optional | The number of times that the AutoPay is to be run. This value is null if `FrequencyType` is `MonthToMonth`. | getNumberOfAutopays(): ?int | setNumberOfAutopays(?int numberOfAutopays): void |
| `autopayTriggerType` | `?string` | Optional | Defines whether the AutoPay, if applicable to this contract, runs on a set schedule or when the pricing option runs out or expires. Possible values are:<br><br>* OnSetSchedule<br>* PricingOptionRunsOutOrExpires | getAutopayTriggerType(): ?string | setAutopayTriggerType(?string autopayTriggerType): void |
| `actionUponCompletionOfAutopays` | `?string` | Optional | The renewal action to be taken when this AutoPay is completed. Possible values are:<br><br>* ContractExpires<br>* ContractAutomaticallyRenews | getActionUponCompletionOfAutopays(): ?string | setActionUponCompletionOfAutopays(?string actionUponCompletionOfAutopays): void |
| `clientsChargedOn` | `?string` | Optional | The value that indicates when clients are charged. Possible values are:<br><br>* OnSaleDate<br>* FirstOfTheMonth<br>* FifteenthOfTheMonth<br>* LastDayOfTheMonth<br>* FirstOrFifteenthOfTheMonth<br>* FirstOrSixteenthOfTheMonth<br>* FifteenthOrEndOfTheMonth<br>* SpecificDate | getClientsChargedOn(): ?string | setClientsChargedOn(?string clientsChargedOn): void |
| `clientsChargedOnSpecificDate` | `?DateTime` | Optional | If `ClientsChargedOn` is defined as a specific date, this property holds the value of that date. Otherwise, this property is null. | getClientsChargedOnSpecificDate(): ?\DateTime | setClientsChargedOnSpecificDate(?\DateTime clientsChargedOnSpecificDate): void |
| `discountAmount` | `?float` | Optional | The calculated discount applied to the items in this contract. | getDiscountAmount(): ?float | setDiscountAmount(?float discountAmount): void |
| `depositAmount` | `?float` | Optional | The amount of the deposit required for this contract. | getDepositAmount(): ?float | setDepositAmount(?float depositAmount): void |
| `firstAutopayFree` | `?bool` | Optional | When `true`, indicates that the first payment for the AutoPay is free. | getFirstAutopayFree(): ?bool | setFirstAutopayFree(?bool firstAutopayFree): void |
| `lastAutopayFree` | `?bool` | Optional | When `true`, indicates that the last payment for the AutoPay is free. | getLastAutopayFree(): ?bool | setLastAutopayFree(?bool lastAutopayFree): void |
| `clientTerminateOnline` | `?bool` | Optional | When `true`, indicates that the client can terminate this contract on the Internet. | getClientTerminateOnline(): ?bool | setClientTerminateOnline(?bool clientTerminateOnline): void |
| `membershipTypeRestrictions` | [`?(MembershipTypeRestriction[])`](../../doc/models/membership-type-restriction.md) | Optional | Contains information about the memberships that can purchase this contract. If null, then no membership restrictions exist, and anyone can purchase the contract. | getMembershipTypeRestrictions(): ?array | setMembershipTypeRestrictions(?array membershipTypeRestrictions): void |
| `locationPurchaseRestrictionIds` | `?(int[])` | Optional | The IDs of the locations where this contract may be sold. If there are no restrictions, this value is null. | getLocationPurchaseRestrictionIds(): ?array | setLocationPurchaseRestrictionIds(?array locationPurchaseRestrictionIds): void |
| `locationPurchaseRestrictionNames` | `?(string[])` | Optional | Location names where the contract may be purchased. If this value is null, there are no restrictions. | getLocationPurchaseRestrictionNames(): ?array | setLocationPurchaseRestrictionNames(?array locationPurchaseRestrictionNames): void |
| `agreementTerms` | `?string` | Optional | Business-defined terms and conditions for the contract. | getAgreementTerms(): ?string | setAgreementTerms(?string agreementTerms): void |
| `requiresElectronicConfirmation` | `?bool` | Optional | When `true`, clients who purchase the contract are prompted to agree to the terms of the contract the next time that they log in. | getRequiresElectronicConfirmation(): ?bool | setRequiresElectronicConfirmation(?bool requiresElectronicConfirmation): void |
| `autopayEnabled` | `?bool` | Optional | When `true`, this contract establishes an AutoPay on the client’s account. | getAutopayEnabled(): ?bool | setAutopayEnabled(?bool autopayEnabled): void |
| `firstPaymentAmountSubtotal` | `?float` | Optional | The subtotal of the amount that the client is to be charged when signing up for the contract. | getFirstPaymentAmountSubtotal(): ?float | setFirstPaymentAmountSubtotal(?float firstPaymentAmountSubtotal): void |
| `firstPaymentAmountTax` | `?float` | Optional | The amount of tax that the client is to be charged when signing up for the contract. | getFirstPaymentAmountTax(): ?float | setFirstPaymentAmountTax(?float firstPaymentAmountTax): void |
| `firstPaymentAmountTotal` | `?float` | Optional | The total amount that the client is to be charged when signing up for the contract. | getFirstPaymentAmountTotal(): ?float | setFirstPaymentAmountTotal(?float firstPaymentAmountTotal): void |
| `recurringPaymentAmountSubtotal` | `?float` | Optional | The subtotal amount that the client is to be charged on an ongoing basis. | getRecurringPaymentAmountSubtotal(): ?float | setRecurringPaymentAmountSubtotal(?float recurringPaymentAmountSubtotal): void |
| `recurringPaymentAmountTax` | `?float` | Optional | The amount of tax the client is to be charged on an ongoing basis. | getRecurringPaymentAmountTax(): ?float | setRecurringPaymentAmountTax(?float recurringPaymentAmountTax): void |
| `recurringPaymentAmountTotal` | `?float` | Optional | The total amount that the client is to be charged on an ongoing basis. | getRecurringPaymentAmountTotal(): ?float | setRecurringPaymentAmountTotal(?float recurringPaymentAmountTotal): void |
| `totalContractAmountSubtotal` | `?float` | Optional | The subtotal amount that the client is to be charged over the lifespan of the contract. | getTotalContractAmountSubtotal(): ?float | setTotalContractAmountSubtotal(?float totalContractAmountSubtotal): void |
| `totalContractAmountTax` | `?float` | Optional | The total amount of tax the client is to be charged over the lifespan of the contract. | getTotalContractAmountTax(): ?float | setTotalContractAmountTax(?float totalContractAmountTax): void |
| `totalContractAmountTotal` | `?float` | Optional | The total amount the client is to be charged over the lifespan of the contract. | getTotalContractAmountTotal(): ?float | setTotalContractAmountTotal(?float totalContractAmountTotal): void |
| `promoPaymentAmountSubtotal` | `?float` | Optional | Subtotal promotional period | getPromoPaymentAmountSubtotal(): ?float | setPromoPaymentAmountSubtotal(?float promoPaymentAmountSubtotal): void |
| `promoPaymentAmountTax` | `?float` | Optional | Taxes of promotional period | getPromoPaymentAmountTax(): ?float | setPromoPaymentAmountTax(?float promoPaymentAmountTax): void |
| `promoPaymentAmountTotal` | `?float` | Optional | Total of promotional period | getPromoPaymentAmountTotal(): ?float | setPromoPaymentAmountTotal(?float promoPaymentAmountTotal): void |
| `numberOfPromoAutopays` | `?int` | Optional | Number of times that the AutoPay runs under the promotional period | getNumberOfPromoAutopays(): ?int | setNumberOfPromoAutopays(?int numberOfPromoAutopays): void |

## Example (as JSON)

```json
{
  "Id": 170,
  "Name": "Name8",
  "Description": "Description2",
  "AssignsMembershipId": 46,
  "AssignsMembershipName": "AssignsMembershipName8"
}
```

