
# Get Liability Waiver Response

## Structure

`GetLiabilityWaiverResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `liabilityWaiver` | `?string` | Optional | Contains Liability Waiver text for a site | getLiabilityWaiver(): ?string | setLiabilityWaiver(?string liabilityWaiver): void |

## Example (as JSON)

```json
{
  "LiabilityWaiver": "LiabilityWaiver0"
}
```

