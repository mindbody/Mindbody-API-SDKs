
# Substitute Class Teacher Request

## Structure

`SubstituteClassTeacherRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `classId` | `int` | Required | The ID of the class to which a substitute teacher needs to be assigned. | getClassId(): int | setClassId(int classId): void |
| `staffId` | `int` | Required | The staff ID of the teacher to substitute. | getStaffId(): int | setStaffId(int staffId): void |
| `overrideConflicts` | `?bool` | Optional | When `true`, overrides any conflicts in the schedule. | getOverrideConflicts(): ?bool | setOverrideConflicts(?bool overrideConflicts): void |
| `sendClientEmail` | `?bool` | Optional | When `true`, sends the client an automatic email about the substitution, if the client has opted to receive email. | getSendClientEmail(): ?bool | setSendClientEmail(?bool sendClientEmail): void |
| `sendOriginalTeacherEmail` | `?bool` | Optional | When `true`, sends the originally scheduled teacher an automatic email about the substitution. | getSendOriginalTeacherEmail(): ?bool | setSendOriginalTeacherEmail(?bool sendOriginalTeacherEmail): void |
| `sendSubstituteTeacherEmail` | `?bool` | Optional | When `true`, sends the substituted teacher an automatic email about the substitution. | getSendSubstituteTeacherEmail(): ?bool | setSendSubstituteTeacherEmail(?bool sendSubstituteTeacherEmail): void |

## Example (as JSON)

```json
{
  "ClassId": 242,
  "StaffId": 84,
  "OverrideConflicts": false,
  "SendClientEmail": false,
  "SendOriginalTeacherEmail": false,
  "SendSubstituteTeacherEmail": false
}
```

