
# Discount

Discount for a promo code

## Structure

`Discount`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | `?string` | Optional | Type of discount percentage/amount | getType(): ?string | setType(?string type): void |
| `amount` | `?float` | Optional | Amount of discount | getAmount(): ?float | setAmount(?float amount): void |

## Example (as JSON)

```json
{
  "Type": "Type6",
  "Amount": 80.68
}
```

