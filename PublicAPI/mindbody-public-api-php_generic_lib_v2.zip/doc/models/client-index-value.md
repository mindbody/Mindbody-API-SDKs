
# Client Index Value

A client index value.

## Structure

`ClientIndexValue`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `active` | `?bool` | Optional | For this call, this value is always `false` and can be ignored.<br>When `false`, indicates that the index value has been deactivated and cannot be assigned to its parent index. | getActive(): ?bool | setActive(?bool active): void |
| `id` | `?int` | Optional | The index value’s ID. | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | The name of the client index value. | getName(): ?string | setName(?string name): void |

## Example (as JSON)

```json
{
  "Active": false,
  "Id": 242,
  "Name": "Name8"
}
```

