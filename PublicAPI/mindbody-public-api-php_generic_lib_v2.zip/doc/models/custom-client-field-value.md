
# Custom Client Field Value

The value of a custom client field

## Structure

`CustomClientFieldValue`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `value` | `?string` | Optional | The value of a specific custom field for a client. | getValue(): ?string | setValue(?string value): void |
| `id` | `?int` | Optional | The ID of the custom client field. | getId(): ?int | setId(?int id): void |
| `dataType` | `?string` | Optional | The data type of the field. | getDataType(): ?string | setDataType(?string dataType): void |
| `name` | `?string` | Optional | The name of the field. | getName(): ?string | setName(?string name): void |

## Example (as JSON)

```json
{
  "Value": "Value4",
  "Id": 8,
  "DataType": "DataType2",
  "Name": "Name8"
}
```

