
# Update Class Schedule Notes Request

A model for requesting the updates of notes of a class schedule.

## Structure

`UpdateClassScheduleNotesRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `notes` | `?string` | Optional | Gets the class notes. | getNotes(): ?string | setNotes(?string notes): void |

## Example (as JSON)

```json
{
  "Notes": "Notes8"
}
```

