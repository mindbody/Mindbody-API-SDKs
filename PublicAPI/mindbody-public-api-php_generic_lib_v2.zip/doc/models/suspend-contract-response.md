
# Suspend Contract Response

## Structure

`SuspendContractResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `contract` | [`?ClientContract`](../../doc/models/client-contract.md) | Optional | Contains information about client contract. | getContract(): ?ClientContract | setContract(?ClientContract contract): void |

## Example (as JSON)

```json
{
  "Contract": {
    "PayerClientId": 104,
    "AgreementDate": "2016-03-13T12:52:32.123Z",
    "AutopayStatus": "Active",
    "AutoRenewing": false,
    "FirstAutoPay": 184.84
  }
}
```

