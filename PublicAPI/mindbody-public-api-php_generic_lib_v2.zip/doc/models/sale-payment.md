
# Sale Payment

## Structure

`SalePayment`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | A unique identifier for this payment. | getId(): ?int | setId(?int id): void |
| `amount` | `?float` | Optional | The total amount of sales that were made on the sale date, including all payment methods that were used and taxes that were collected. | getAmount(): ?float | setAmount(?float amount): void |
| `method` | `?int` | Optional | The method used to make this payment. | getMethod(): ?int | setMethod(?int method): void |
| `type` | `?string` | Optional | The payment method type used for the client’s purchase. | getType(): ?string | setType(?string type): void |
| `notes` | `?string` | Optional | Payment notes that are entered under the selected payment method in the Retail screen before completing the sale. | getNotes(): ?string | setNotes(?string notes): void |
| `transactionId` | `?int` | Optional | The ID of transaction. Use this ID when calling the GET Transactions endpoint. | getTransactionId(): ?int | setTransactionId(?int transactionId): void |

## Example (as JSON)

```json
{
  "Id": 138,
  "Amount": 228.76,
  "Method": 144,
  "Type": "Type4",
  "Notes": "Notes4"
}
```

