
# Get Cross Regional Client Associations Response

## Structure

`GetCrossRegionalClientAssociationsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `crossRegionalClientAssociations` | [`?(CrossRegionalClientAssociation[])`](../../doc/models/cross-regional-client-association.md) | Optional | Contains information about the client’s cross regional associations. | getCrossRegionalClientAssociations(): ?array | setCrossRegionalClientAssociations(?array crossRegionalClientAssociations): void |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "CrossRegionalClientAssociations": [
    {
      "SiteId": 80,
      "ClientId": "ClientId0",
      "UniqueId": 202,
      "SiteIsActive": false
    },
    {
      "SiteId": 80,
      "ClientId": "ClientId0",
      "UniqueId": 202,
      "SiteIsActive": false
    }
  ]
}
```

