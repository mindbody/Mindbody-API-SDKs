
# Response Details

Contains information about the response message detail.

## Structure

`ResponseDetails`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `status` | `?string` | Optional | Contains information about the response status. | getStatus(): ?string | setStatus(?string status): void |
| `transactionId` | `?string` | Optional | The unique transaction ID. | getTransactionId(): ?string | setTransactionId(?string transactionId): void |
| `message` | `?string` | Optional | Contains information about the response message detail. | getMessage(): ?string | setMessage(?string message): void |

## Example (as JSON)

```json
{
  "Status": "Status2",
  "TransactionId": "TransactionId4",
  "Message": "Message0"
}
```

