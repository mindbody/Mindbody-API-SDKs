
# Availability 1

The availability of a specific staff

## Structure

`Availability1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | Id of the availability | getId(): ?int | setId(?int id): void |
| `staff` | [`?Staff1`](../../doc/models/staff-1.md) | Optional | - | getStaff(): ?Staff1 | setStaff(?Staff1 staff): void |
| `sessionType` | [`?SessionType1`](../../doc/models/session-type-1.md) | Optional | - | getSessionType(): ?SessionType1 | setSessionType(?SessionType1 sessionType): void |
| `programs` | [`?(Program1[])`](../../doc/models/program-1.md) | Optional | Availabilities program list. | getPrograms(): ?array | setPrograms(?array programs): void |
| `startDateTime` | `?DateTime` | Optional | Availabilities start date and time. | getStartDateTime(): ?\DateTime | setStartDateTime(?\DateTime startDateTime): void |
| `endDateTime` | `?DateTime` | Optional | Availabilities end date and time. | getEndDateTime(): ?\DateTime | setEndDateTime(?\DateTime endDateTime): void |
| `bookableEndDateTime` | `?DateTime` | Optional | Availabilities bookable end date and time. | getBookableEndDateTime(): ?\DateTime | setBookableEndDateTime(?\DateTime bookableEndDateTime): void |
| `location` | [`?Location1`](../../doc/models/location-1.md) | Optional | - | getLocation(): ?Location1 | setLocation(?Location1 location): void |
| `prepTime` | `?int` | Optional | Appointment prep time | getPrepTime(): ?int | setPrepTime(?int prepTime): void |
| `finishTime` | `?int` | Optional | Appointment finish time | getFinishTime(): ?int | setFinishTime(?int finishTime): void |
| `isMasked` | `?bool` | Optional | - | getIsMasked(): ?bool | setIsMasked(?bool isMasked): void |
| `showPublic` | `?bool` | Optional | - | getShowPublic(): ?bool | setShowPublic(?bool showPublic): void |
| `resourceAvailabilities` | [`?(ResourceAvailability1[])`](../../doc/models/resource-availability-1.md) | Optional | List of resource availabilities that can be booked with this session type. | getResourceAvailabilities(): ?array | setResourceAvailabilities(?array resourceAvailabilities): void |

## Example (as JSON)

```json
{
  "Id": 176,
  "Staff": {
    "Id": 176,
    "FirstName": "FirstName6",
    "LastName": "LastName6",
    "DisplayName": "DisplayName4",
    "Email": "Email6"
  },
  "SessionType": {
    "Type": "DropIn",
    "DefaultTimeLength": 30,
    "StaffTimeLength": 52,
    "ProgramId": 60,
    "NumDeducted": 64
  },
  "Programs": [
    {
      "CancelOffset": 182,
      "Id": 192,
      "Name": "Name8",
      "ScheduleType": "Appointment",
      "ContentFormat": "Mindbody"
    }
  ],
  "StartDateTime": "2016-03-13T12:52:32.123Z"
}
```

