
# Package

## Structure

`Package`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The ID of the package. | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | The name of the package. | getName(): ?string | setName(?string name): void |
| `discountPercentage` | `?float` | Optional | The discount percentage applied to the package. | getDiscountPercentage(): ?float | setDiscountPercentage(?float discountPercentage): void |
| `sellOnline` | `?bool` | Optional | When `true`, only products that can be sold online are returned.<br /><br>When `false`, all products are returned. | getSellOnline(): ?bool | setSellOnline(?bool sellOnline): void |
| `services` | [`?(Service[])`](../../doc/models/service.md) | Optional | Information about the services in the packages. | getServices(): ?array | setServices(?array services): void |
| `products` | [`?(Product[])`](../../doc/models/product.md) | Optional | Information about the products in the packages. | getProducts(): ?array | setProducts(?array products): void |

## Example (as JSON)

```json
{
  "Id": 82,
  "Name": "Name4",
  "DiscountPercentage": 6.46,
  "SellOnline": false,
  "Services": [
    {
      "Price": 224.3,
      "OnlinePrice": 2.82,
      "TaxIncluded": 75.84,
      "ProgramId": 204,
      "TaxRate": 192.34
    }
  ]
}
```

