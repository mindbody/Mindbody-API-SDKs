
# Add Class Enrollment Schedule Request

## Structure

`AddClassEnrollmentScheduleRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `classDescriptionId` | `?int` | Optional | The Id of the class/enrollment description. This can be found in GetClassDescriptions. | getClassDescriptionId(): ?int | setClassDescriptionId(?int classDescriptionId): void |
| `locationId` | `?int` | Optional | The Location Id of the enrollment schedule. | getLocationId(): ?int | setLocationId(?int locationId): void |
| `startDate` | `?DateTime` | Optional | The start date of the enrollment schedule. | getStartDate(): ?\DateTime | setStartDate(?\DateTime startDate): void |
| `endDate` | `?DateTime` | Optional | The end date of the enrollment schedule. | getEndDate(): ?\DateTime | setEndDate(?\DateTime endDate): void |
| `startTime` | `?DateTime` | Optional | Enrollment start time (use null or omit for TBD). | getStartTime(): ?\DateTime | setStartTime(?\DateTime startTime): void |
| `endTime` | `?DateTime` | Optional | Enrollment end time (ignored if StartTime is null or omitted). | getEndTime(): ?\DateTime | setEndTime(?\DateTime endTime): void |
| `daySunday` | `?bool` | Optional | If the enrollment occurs on Sunday(s). | getDaySunday(): ?bool | setDaySunday(?bool daySunday): void |
| `dayMonday` | `?bool` | Optional | If the enrollment occurs on Monday(s). | getDayMonday(): ?bool | setDayMonday(?bool dayMonday): void |
| `dayTuesday` | `?bool` | Optional | If the enrollment occurs on Tuesday(s). | getDayTuesday(): ?bool | setDayTuesday(?bool dayTuesday): void |
| `dayWednesday` | `?bool` | Optional | If the enrollment occurs on Wednesday(s). | getDayWednesday(): ?bool | setDayWednesday(?bool dayWednesday): void |
| `dayThursday` | `?bool` | Optional | If the enrollment occurs on Thursday(s). | getDayThursday(): ?bool | setDayThursday(?bool dayThursday): void |
| `dayFriday` | `?bool` | Optional | If the enrollment occurs on Friday(s). | getDayFriday(): ?bool | setDayFriday(?bool dayFriday): void |
| `daySaturday` | `?bool` | Optional | If the enrollment occurs on Saturday(s). | getDaySaturday(): ?bool | setDaySaturday(?bool daySaturday): void |
| `staffId` | `?int` | Optional | The staff member teaching the enrollment. | getStaffId(): ?int | setStaffId(?int staffId): void |
| `staffPayRate` | `?int` | Optional | The staff pay rate. Must be between 1-21. | getStaffPayRate(): ?int | setStaffPayRate(?int staffPayRate): void |
| `resourceId` | `?int` | Optional | The room where the enrollment is taking place. | getResourceId(): ?int | setResourceId(?int resourceId): void |
| `maxCapacity` | `?int` | Optional | How many people can attend. | getMaxCapacity(): ?int | setMaxCapacity(?int maxCapacity): void |
| `webCapacity` | `?int` | Optional | How many people can signup online.<br>Default: **0** | getWebCapacity(): ?int | setWebCapacity(?int webCapacity): void |
| `waitlistCapacity` | `?int` | Optional | How many people can waitlist.<br>Default:**0** | getWaitlistCapacity(): ?int | setWaitlistCapacity(?int waitlistCapacity): void |
| `bookingStatus` | `?string` | Optional | One of: PaymentRequired, BookAndPayLater, Free | getBookingStatus(): ?string | setBookingStatus(?string bookingStatus): void |
| `allowOpenEnrollment` | `?bool` | Optional | Allow clients to choose which sessions they’d like to sign up for.<br>Default: **false** | getAllowOpenEnrollment(): ?bool | setAllowOpenEnrollment(?bool allowOpenEnrollment): void |
| `allowDateForwardEnrollment` | `?bool` | Optional | Allow booking after the enrollment has started.<br>Default: **false** | getAllowDateForwardEnrollment(): ?bool | setAllowDateForwardEnrollment(?bool allowDateForwardEnrollment): void |
| `pricingOptionsProductIds` | `?(int[])` | Optional | Pricing Options for this schedule | getPricingOptionsProductIds(): ?array | setPricingOptionsProductIds(?array pricingOptionsProductIds): void |
| `showToPublic` | `?bool` | Optional | Allow clients to see this schedule<br>Default: **true** | getShowToPublic(): ?bool | setShowToPublic(?bool showToPublic): void |

## Example (as JSON)

```json
{
  "ClassDescriptionId": 176,
  "LocationId": 4,
  "StartDate": "2016-03-13T12:52:32.123Z",
  "EndDate": "2016-03-13T12:52:32.123Z",
  "StartTime": "2016-03-13T12:52:32.123Z"
}
```

