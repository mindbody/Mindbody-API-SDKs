
# Client Contract

A client contract.

## Structure

`ClientContract`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `agreementDate` | `?DateTime` | Optional | The date on which the contract was signed. | getAgreementDate(): ?\DateTime | setAgreementDate(?\DateTime agreementDate): void |
| `autopayStatus` | [`?string(AutopayStatusEnum)`](../../doc/models/autopay-status-enum.md) | Optional | The status of the client’s autopay. | getAutopayStatus(): ?string | setAutopayStatus(?string autopayStatus): void |
| `autoRenewing` | `?bool` | Optional | Determines if the contract is auto-renewing. | getAutoRenewing(): ?bool | setAutoRenewing(?bool autoRenewing): void |
| `firstAutoPay` | `?float` | Optional | The amount of the first autopay transaction. | getFirstAutoPay(): ?float | setFirstAutoPay(?float firstAutoPay): void |
| `lastAutoPay` | `?float` | Optional | The amount of the last autopay transaction. | getLastAutoPay(): ?float | setLastAutoPay(?float lastAutoPay): void |
| `normalAutoPay` | `?float` | Optional | The amount of the normal recurring autopay transaction. | getNormalAutoPay(): ?float | setNormalAutoPay(?float normalAutoPay): void |
| `isMonthToMonth` | `?bool` | Optional | Indicates if the contract renews on a month-to-month basis. | getIsMonthToMonth(): ?bool | setIsMonthToMonth(?bool isMonthToMonth): void |
| `autoRenewClientContractID` | `?int` | Optional | The ID of the contract that this one auto-renews from. | getAutoRenewClientContractID(): ?int | setAutoRenewClientContractID(?int autoRenewClientContractID): void |
| `contractText` | `?string` | Optional | The full text of the contract. | getContractText(): ?string | setContractText(?string contractText): void |
| `contractAutoRenewed` | `?bool` | Optional | Indicates whether the contract was auto-renewed from a previous one. | getContractAutoRenewed(): ?bool | setContractAutoRenewed(?bool contractAutoRenewed): void |
| `contractName` | `?string` | Optional | The name of the contract. | getContractName(): ?string | setContractName(?string contractName): void |
| `endDate` | `?DateTime` | Optional | The date that the contract expires. | getEndDate(): ?\DateTime | setEndDate(?\DateTime endDate): void |
| `id` | `?int` | Optional | The unique ID of the sale of the contract. Each time a contract is sold, this ID increases sequentially. | getId(): ?int | setId(?int id): void |
| `originationLocationId` | `?int` | Optional | The ID of the location where the contract was issued. | getOriginationLocationId(): ?int | setOriginationLocationId(?int originationLocationId): void |
| `startDate` | `?DateTime` | Optional | The date that the contract became active. | getStartDate(): ?\DateTime | setStartDate(?\DateTime startDate): void |
| `siteId` | `?int` | Optional | The ID of the site where the contract was issued. | getSiteId(): ?int | setSiteId(?int siteId): void |
| `upcomingAutopayEvents` | [`?(UpcomingAutopayEvent[])`](../../doc/models/upcoming-autopay-event.md) | Optional | Contains details of the autopay events. | getUpcomingAutopayEvents(): ?array | setUpcomingAutopayEvents(?array upcomingAutopayEvents): void |
| `contractID` | `?int` | Optional | The ID of the contract. | getContractID(): ?int | setContractID(?int contractID): void |
| `terminationDate` | `?DateTime` | Optional | The date that the contract was terminated. | getTerminationDate(): ?\DateTime | setTerminationDate(?\DateTime terminationDate): void |

## Example (as JSON)

```json
{
  "AgreementDate": "2016-03-13T12:52:32.123Z",
  "AutopayStatus": "Suspended",
  "AutoRenewing": false,
  "FirstAutoPay": 152.34,
  "LastAutoPay": 0.68
}
```

