
# Deactivate Promo Code Request

## Structure

`DeactivatePromoCodeRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `promotionId` | `int` | Required | The promocodeID | getPromotionId(): int | setPromotionId(int promotionId): void |

## Example (as JSON)

```json
{
  "PromotionId": 236
}
```

