
# Add Client to Class Visit

## Structure

`AddClientToClassVisit`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `appointmentId` | `?int` | Optional | The appointment’s ID. | getAppointmentId(): ?int | setAppointmentId(?int appointmentId): void |
| `appointmentGenderPreference` | [`?string(AppointmentGenderPreference1Enum)`](../../doc/models/appointment-gender-preference-1-enum.md) | Optional | The gender of staff member with whom the client prefers to book appointments. | getAppointmentGenderPreference(): ?string | setAppointmentGenderPreference(?string appointmentGenderPreference): void |
| `appointmentStatus` | [`?string(AppointmentStatusEnum)`](../../doc/models/appointment-status-enum.md) | Optional | The status of the appointment. | getAppointmentStatus(): ?string | setAppointmentStatus(?string appointmentStatus): void |
| `classId` | `?int` | Optional | The class ID that was used to retrieve the visits. | getClassId(): ?int | setClassId(?int classId): void |
| `clientId` | `?string` | Optional | The ID of the client associated with the visit. | getClientId(): ?string | setClientId(?string clientId): void |
| `startDateTime` | `?DateTime` | Optional | The time this class is scheduled to start. | getStartDateTime(): ?\DateTime | setStartDateTime(?\DateTime startDateTime): void |
| `endDateTime` | `?DateTime` | Optional | The date and time the visit ends. The Public API returns UTC dates and times. For example, a class that occurs on June 25th, 2018 at 2:15PM (EST) appears as “2018-06-25T19:15:00Z” because EST is five hours behind UTC. Date time pairs always return in the format YYYY-MM-DDTHH:mm:ssZ. | getEndDateTime(): ?\DateTime | setEndDateTime(?\DateTime endDateTime): void |
| `id` | `?int` | Optional | The ID of the visit. | getId(): ?int | setId(?int id): void |
| `lastModifiedDateTime` | `?DateTime` | Optional | When included in the request, only records modified on or after the specified `LastModifiedDate` are included in the response. The Public API returns UTC dates and times. For example, a class that occurs on June 25th, 2018 at 2:15PM (EST) appears as “2018-06-25T19:15:00Z” because EST is five hours behind UTC. Date time pairs always return in the format YYYY-MM-DDTHH:mm:ssZ. | getLastModifiedDateTime(): ?\DateTime | setLastModifiedDateTime(?\DateTime lastModifiedDateTime): void |
| `lateCancelled` | `?bool` | Optional | When `true`, indicates that the class has been `LateCancelled`.<br /><br>When `false`, indicates that the class has not been `LateCancelled`. | getLateCancelled(): ?bool | setLateCancelled(?bool lateCancelled): void |
| `locationId` | `?int` | Optional | The ID of the location where the visit took place or is to take place. | getLocationId(): ?int | setLocationId(?int locationId): void |
| `makeUp` | `?bool` | Optional | When `true`, the client can make up this session and a session is not deducted from the pricing option that was used to sign the client into the enrollment. When the client has the make-up session, a session is automatically removed from a pricing option that matches the service category of the enrollment and is within the same date range of the missed session.<br /><br>When `false`, the client cannot make up this session. See [Enrollments: Make-ups](https://support.mindbodyonline.com/s/article/203259433-Enrollments-Make-ups?language=en_US) for more information. | getMakeUp(): ?bool | setMakeUp(?bool makeUp): void |
| `name` | `?string` | Optional | The name of the class. | getName(): ?string | setName(?string name): void |
| `serviceId` | `?int` | Optional | The ID of the client's pricing option applied to the class visit. | getServiceId(): ?int | setServiceId(?int serviceId): void |
| `serviceName` | `?string` | Optional | The name of the pricing option applied to the class visit. | getServiceName(): ?string | setServiceName(?string serviceName): void |
| `productId` | `?int` | Optional | The business' ID of the type of pricing option used to pay for the class visit. | getProductId(): ?int | setProductId(?int productId): void |
| `signedIn` | `?bool` | Optional | When `true`, indicates that the client has been signed in.<br /><br>When `false`, indicates that the client has not been signed in. | getSignedIn(): ?bool | setSignedIn(?bool signedIn): void |
| `staffId` | `?int` | Optional | The ID of the staff member who is teaching the class. | getStaffId(): ?int | setStaffId(?int staffId): void |
| `webSignup` | `?bool` | Optional | When `true`, indicates that the client signed up online.<br /><br>When `false`, indicates that the client was signed up by a staff member. | getWebSignup(): ?bool | setWebSignup(?bool webSignup): void |
| `action` | [`?string(Action1Enum)`](../../doc/models/action-1-enum.md) | Optional | The action taken. | getAction(): ?string | setAction(?string action): void |
| `crossRegionalBookingPerformed` | `?bool` | Optional | When `true`, indicates that the client is paying for the visit using a pricing option from one of their associated cross-regional profiles. | getCrossRegionalBookingPerformed(): ?bool | setCrossRegionalBookingPerformed(?bool crossRegionalBookingPerformed): void |
| `siteId` | `?int` | Optional | The ID of the business from which cross-regional payment is applied. | getSiteId(): ?int | setSiteId(?int siteId): void |
| `waitlistEntryId` | `?int` | Optional | When this value is not null, it indicates that the client is on the waiting list for the requested class. The only additional fields that are populated when this is not null are:<br><br>* ClassId<br>* ClientId<br><br>You can call GET WaitlistEntries using `WaitlistEntryId` to obtain more data about this waiting list entry. | getWaitlistEntryId(): ?int | setWaitlistEntryId(?int waitlistEntryId): void |

## Example (as JSON)

```json
{
  "AppointmentId": 128,
  "AppointmentGenderPreference": "Female",
  "AppointmentStatus": "Completed",
  "ClassId": 208,
  "ClientId": "ClientId6"
}
```

