
# Transaction Response

## Structure

`TransactionResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `transactionId` | `?int` | Optional | The Transaction ID. | getTransactionId(): ?int | setTransactionId(?int transactionId): void |
| `authenticationUrl` | `?string` | Optional | The optional valid URL provided by the bank. | getAuthenticationUrl(): ?string | setAuthenticationUrl(?string authenticationUrl): void |

## Example (as JSON)

```json
{
  "TransactionId": 118,
  "AuthenticationUrl": "AuthenticationUrl6"
}
```

