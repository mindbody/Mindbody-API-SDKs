
# Add Appointment Outcome

Contains information about an appointment creation outcome.

## Structure

`AddAppointmentOutcome`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `appointment` | [`?Appointment`](../../doc/models/appointment.md) | Optional | Contains information about an appointment. | getAppointment(): ?Appointment | setAppointment(?Appointment appointment): void |
| `error` | [`?ApiError`](../../doc/models/api-error.md) | Optional | - | getError(): ?ApiError | setError(?ApiError error): void |
| `request` | [`?AddAppointmentRequest`](../../doc/models/add-appointment-request.md) | Optional | Represents a request to add a new appointment, including details such as client information, appointment timing, location, and additional preferences. | getRequest(): ?AddAppointmentRequest | setRequest(?AddAppointmentRequest request): void |

## Example (as JSON)

```json
{
  "Appointment": {
    "GenderPreference": "None",
    "Duration": 182,
    "ProviderId": "ProviderId6",
    "Id": 136,
    "Status": "None"
  },
  "Error": {
    "Message": "Message0",
    "Code": "Code4"
  },
  "Request": {
    "ApplyPayment": false,
    "ClientId": "ClientId6",
    "Duration": 150,
    "Execute": "Execute8",
    "EndDateTime": "2016-03-13T12:52:32.123Z",
    "GenderPreference": "GenderPreference2",
    "LocationId": 164,
    "SessionTypeId": 8,
    "StaffId": 114,
    "StartDateTime": "2016-03-13T12:52:32.123Z"
  }
}
```

