
# Get Client Schedule Response

## Structure

`GetClientScheduleResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `visits` | [`?(VisitWithWaitlistInfo[])`](../../doc/models/visit-with-waitlist-info.md) | Optional | Contains information about client visits including waitlist entries info | getVisits(): ?array | setVisits(?array visits): void |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "Visits": [
    {
      "WaitlistInfo": {
        "WaitlistId": 98,
        "WaitlistOrderNumber": 238
      },
      "AppointmentId": 196,
      "AppointmentGenderPreference": "Male",
      "AppointmentStatus": "Booked",
      "ClassId": 140
    }
  ]
}
```

