
# Time Card Event

## Structure

`TimeCardEvent`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `staffId` | `?int` | Optional | The ID of the requested staff member. | getStaffId(): ?int | setStaffId(?int staffId): void |
| `task` | `?string` | Optional | The staff member’s job title. | getTask(): ?string | setTask(?string task): void |
| `timeIn` | `?DateTime` | Optional | The time that the staff member started the job task. | getTimeIn(): ?\DateTime | setTimeIn(?\DateTime timeIn): void |
| `timeOut` | `?DateTime` | Optional | The time that the staff member stopped doing the job task. | getTimeOut(): ?\DateTime | setTimeOut(?\DateTime timeOut): void |
| `hours` | `?float` | Optional | The number of hours on this time card, rounded to the nearest fourth decimal place. | getHours(): ?float | setHours(?float hours): void |
| `hourlyRate` | `?float` | Optional | The hourly rate the business pays this staff for this `Task`. | getHourlyRate(): ?float | setHourlyRate(?float hourlyRate): void |
| `earnings` | `?float` | Optional | The total amount earned by the staff member for this time card entry. | getEarnings(): ?float | setEarnings(?float earnings): void |

## Example (as JSON)

```json
{
  "StaffId": 80,
  "Task": "Task8",
  "TimeIn": "2016-03-13T12:52:32.123Z",
  "TimeOut": "2016-03-13T12:52:32.123Z",
  "Hours": 52.56
}
```

