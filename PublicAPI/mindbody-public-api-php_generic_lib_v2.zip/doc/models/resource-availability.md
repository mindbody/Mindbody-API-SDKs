
# Resource Availability

An availability of a resource

## Structure

`ResourceAvailability`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `resourceId` | `?int` | Optional | Id | getResourceId(): ?int | setResourceId(?int resourceId): void |
| `startDateTime` | `?DateTime` | Optional | Starts | getStartDateTime(): ?\DateTime | setStartDateTime(?\DateTime startDateTime): void |
| `endDateTime` | `?DateTime` | Optional | Ends | getEndDateTime(): ?\DateTime | setEndDateTime(?\DateTime endDateTime): void |

## Example (as JSON)

```json
{
  "ResourceId": 170,
  "StartDateTime": "2016-03-13T12:52:32.123Z",
  "EndDateTime": "2016-03-13T12:52:32.123Z"
}
```

