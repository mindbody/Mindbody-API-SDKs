# Class

```php
$mClassController = $client->getMClassController();
```

## Class Name

`MClassController`

## Methods

* [Get Class Descriptions](../../doc/controllers/class.md#get-class-descriptions)
* [Get Classes](../../doc/controllers/class.md#get-classes)
* [Get Class Schedules](../../doc/controllers/class.md#get-class-schedules)
* [Get Class Visits](../../doc/controllers/class.md#get-class-visits)
* [Get Courses](../../doc/controllers/class.md#get-courses)
* [Get Semesters](../../doc/controllers/class.md#get-semesters)
* [Get Waitlist Entries](../../doc/controllers/class.md#get-waitlist-entries)
* [Add Class Schedule](../../doc/controllers/class.md#add-class-schedule)
* [Add Client to Class](../../doc/controllers/class.md#add-client-to-class)
* [Cancel Single Class](../../doc/controllers/class.md#cancel-single-class)
* [Remove Client From Class](../../doc/controllers/class.md#remove-client-from-class)
* [Remove Clients From Classes](../../doc/controllers/class.md#remove-clients-from-classes)
* [Remove From Waitlist](../../doc/controllers/class.md#remove-from-waitlist)
* [Substitute Class Teacher](../../doc/controllers/class.md#substitute-class-teacher)
* [Update Class Schedule](../../doc/controllers/class.md#update-class-schedule)
* [Update Class Schedule Notes](../../doc/controllers/class.md#update-class-schedule-notes)


# Get Class Descriptions

To find class descriptions associated with **scheduled classes**, pass `StaffId`, `StartClassDateTime`, `EndClassDateTime`, or `LocationId` in the request.

```php
function getClassDescriptions(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?int $requestClassDescriptionId = null,
    ?\DateTime $requestEndClassDateTime = null,
    ?bool $requestIncludeInactive = null,
    ?int $requestLimit = null,
    ?int $requestLocationId = null,
    ?int $requestOffset = null,
    ?array $requestProgramIds = null,
    ?int $requestStaffId = null,
    ?\DateTime $requestStartClassDateTime = null
): GetClassDescriptionsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestClassDescriptionId` | `?int` | Query, Optional | The ID of the requested client. |
| `requestEndClassDateTime` | `?DateTime` | Query, Optional | Filters the results to class descriptions for scheduled classes that happen before the given date and time. |
| `requestIncludeInactive` | `?bool` | Query, Optional | Includes inactive class descriptions, defaulting to true. When set to false, it filters out inactive class descriptions. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `?int` | Query, Optional | Filters results to classes descriptions for schedule classes as the given location. |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestProgramIds` | `?(int[])` | Query, Optional | A list of requested program IDs. |
| `requestStaffId` | `?int` | Query, Optional | Filters results to class descriptions for scheduled classes taught by the given staff member. |
| `requestStartClassDateTime` | `?DateTime` | Query, Optional | Filters the results to class descriptions for scheduled classes that happen on or after the given date and time. |

## Response Type

[`GetClassDescriptionsResponse`](../../doc/models/get-class-descriptions-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$requestClassDescriptionId = 62;

$requestEndClassDateTime = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');

$requestIncludeInactive = false;

$requestLimit = 62;

$requestLocationId = 90;

$requestOffset = 100;

$requestProgramIds = [
    91,
    92,
    93
];

$requestStaffId = 180;

$requestStartClassDateTime = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');

$result = $mClassController->getClassDescriptions(
    $version,
    $siteId,
    $authorization,
    $requestClassDescriptionId,
    $requestEndClassDateTime,
    $requestIncludeInactive,
    $requestLimit,
    $requestLocationId,
    $requestOffset,
    $requestProgramIds,
    $requestStaffId,
    $requestStartClassDateTime
);
```


# Get Classes

Get scheduled classes.

```php
function getClasses(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?array $requestClassDescriptionIds = null,
    ?array $requestClassIds = null,
    ?array $requestClassScheduleIds = null,
    ?string $requestClientId = null,
    ?\DateTime $requestEndDateTime = null,
    ?bool $requestHideCanceledClasses = null,
    ?\DateTime $requestLastModifiedDate = null,
    ?int $requestLimit = null,
    ?array $requestLocationIds = null,
    ?int $requestOffset = null,
    ?array $requestProgramIds = null,
    ?bool $requestSchedulingWindow = null,
    ?array $requestSemesterIds = null,
    ?array $requestSessionTypeIds = null,
    ?array $requestStaffIds = null,
    ?\DateTime $requestStartDateTime = null,
    ?int $requestUniqueClientId = null
): GetClassesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestClassDescriptionIds` | `?(int[])` | Query, Optional | The requested class description IDs. |
| `requestClassIds` | `?(int[])` | Query, Optional | The requested class IDs. |
| `requestClassScheduleIds` | `?(int[])` | Query, Optional | The requested classSchedule Ids. |
| `requestClientId` | `?string` | Query, Optional | The client ID of the client who is viewing this class list. Based on identity, the client may be able to see additional information, such as membership specials. |
| `requestEndDateTime` | `?DateTime` | Query, Optional | The requested end date for filtering.<br>NOTE: ClassDate does not take Class Time into consideration.<br><br />Default: **today’s date** |
| `requestHideCanceledClasses` | `?bool` | Query, Optional | When `true`, canceled classes are removed from the response.<br /><br>When `false`, canceled classes are included in the response.<br /><br>Default: **false** |
| `requestLastModifiedDate` | `?DateTime` | Query, Optional | When included in the request, only records modified on or after the `LastModifiedDate` specified are included in the response. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationIds` | `?(int[])` | Query, Optional | A list of location IDs on which to base the search. |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestProgramIds` | `?(int[])` | Query, Optional | A list of program IDs on which to base the search. |
| `requestSchedulingWindow` | `?bool` | Query, Optional | When `true`, classes outside scheduling window are removed from the response.<br /><br>When `false`, classes are included in the response, regardless of the scheduling window.<br /><br>Default: **false** |
| `requestSemesterIds` | `?(int[])` | Query, Optional | A list of semester IDs on which to base the search. |
| `requestSessionTypeIds` | `?(int[])` | Query, Optional | A list of session type IDs on which to base the search. |
| `requestStaffIds` | `?(int[])` | Query, Optional | The requested IDs of the teaching staff members. |
| `requestStartDateTime` | `?DateTime` | Query, Optional | The requested start date for filtering. This also determines what you will see for the ‘BookingWindow’ StartDateTime in the response. For example, if you pass a StartDateTime that is on OR before the BookingWindow ‘Open’ days of the class, you will retrieve the actual ‘StartDateTime’ for the Booking Window. If you pass a StartDateTime that is after the BookingWindow ‘date’, then you will receive results based on that start date.<br>NOTE: ClassDate does not take Class Time into consideration. |
| `requestUniqueClientId` | `?int` | Query, Optional | The unique ID of the client who is viewing this class list. Based on identity, the client may be able to see additional information, such as membership specials.<br>Note: you need to provide the 'UniqueClientId' OR the 'ClientId'. If both are provided, the 'UniqueClientId' takes precedence. |

## Response Type

[`GetClassesResponse`](../../doc/models/get-classes-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$requestClassDescriptionIds = [
    107,
    108
];

$requestClassIds = [
    87,
    88,
    89
];

$requestClassScheduleIds = [
    149,
    150,
    151
];

$requestClientId = 'request.clientId2';

$requestEndDateTime = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');

$requestHideCanceledClasses = false;

$requestLastModifiedDate = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');

$requestLimit = 62;

$requestLocationIds = [
    192
];

$requestOffset = 100;

$requestProgramIds = [
    91,
    92,
    93
];

$requestSchedulingWindow = false;

$requestSemesterIds = [
    251,
    252
];

$requestSessionTypeIds = [
    228,
    229
];

$requestStaffIds = [
    23,
    24,
    25
];

$requestStartDateTime = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');

$requestUniqueClientId = 226;

$result = $mClassController->getClasses(
    $version,
    $siteId,
    $authorization,
    $requestClassDescriptionIds,
    $requestClassIds,
    $requestClassScheduleIds,
    $requestClientId,
    $requestEndDateTime,
    $requestHideCanceledClasses,
    $requestLastModifiedDate,
    $requestLimit,
    $requestLocationIds,
    $requestOffset,
    $requestProgramIds,
    $requestSchedulingWindow,
    $requestSemesterIds,
    $requestSessionTypeIds,
    $requestStaffIds,
    $requestStartDateTime,
    $requestUniqueClientId
);
```


# Get Class Schedules

Get class schedules.

```php
function getClassSchedules(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?array $requestClassScheduleIds = null,
    ?\DateTime $requestEndDate = null,
    ?int $requestLimit = null,
    ?array $requestLocationIds = null,
    ?int $requestOffset = null,
    ?array $requestProgramIds = null,
    ?array $requestSessionTypeIds = null,
    ?array $requestStaffIds = null,
    ?\DateTime $requestStartDate = null
): GetClassSchedulesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestClassScheduleIds` | `?(int[])` | Query, Optional | The class schedule IDs.<br><br />Default: **all** |
| `requestEndDate` | `?DateTime` | Query, Optional | The end date of the range. Return any active enrollments that occur on or before this day.<br><br />Default: **StartDate** |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationIds` | `?(int[])` | Query, Optional | The location IDs.<br><br />Default: **all** |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestProgramIds` | `?(int[])` | Query, Optional | The program IDs.<br><br />Default: **all** |
| `requestSessionTypeIds` | `?(int[])` | Query, Optional | The session type IDs.<br><br />Default: **all** |
| `requestStaffIds` | `?(int[])` | Query, Optional | The staff IDs.<br><br />Default: **all** |
| `requestStartDate` | `?DateTime` | Query, Optional | The start date of the range. Return any active enrollments that occur on or after this day.<br><br />Default: **today’s date** |

## Response Type

[`GetClassSchedulesResponse`](../../doc/models/get-class-schedules-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$requestClassScheduleIds = [
    149,
    150,
    151
];

$requestEndDate = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');

$requestLimit = 62;

$requestLocationIds = [
    192
];

$requestOffset = 100;

$requestProgramIds = [
    91,
    92,
    93
];

$requestSessionTypeIds = [
    228,
    229
];

$requestStaffIds = [
    23,
    24,
    25
];

$requestStartDate = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');

$result = $mClassController->getClassSchedules(
    $version,
    $siteId,
    $authorization,
    $requestClassScheduleIds,
    $requestEndDate,
    $requestLimit,
    $requestLocationIds,
    $requestOffset,
    $requestProgramIds,
    $requestSessionTypeIds,
    $requestStaffIds,
    $requestStartDate
);
```


# Get Class Visits

Returns a list of visits that contain information for a specified class. On success, this request returns the class object in the response with a list of visits.

```php
function getClassVisits(
    string $version,
    int $requestClassID,
    string $siteId,
    ?string $authorization = null,
    ?\DateTime $requestLastModifiedDate = null
): GetClassVisitsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClassID` | `int` | Query, Required | The class ID. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestLastModifiedDate` | `?DateTime` | Query, Optional | When included in the request, only records modified on or after the `LastModifiedDate` specified are included in the response. |

## Response Type

[`GetClassVisitsResponse`](../../doc/models/get-class-visits-response.md)

## Example Usage

```php
$version = '6';

$requestClassID = 222;

$siteId = '-99';

$authorization = 'authorization6';

$requestLastModifiedDate = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');

$result = $mClassController->getClassVisits(
    $version,
    $requestClassID,
    $siteId,
    $authorization,
    $requestLastModifiedDate
);
```


# Get Courses

This endpoint will provide all the data related to courses depending on the access level.<br />
Note: The Authorization is an optional header.If Authorization header is not passed, the response will be masked else full response will be provided.

```php
function getCourses(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?array $getCoursesRequestCourseIDs = null,
    ?\DateTime $getCoursesRequestEndDate = null,
    ?int $getCoursesRequestLimit = null,
    ?array $getCoursesRequestLocationIDs = null,
    ?int $getCoursesRequestOffset = null,
    ?array $getCoursesRequestProgramIDs = null,
    ?array $getCoursesRequestSemesterIDs = null,
    ?array $getCoursesRequestStaffIDs = null,
    ?\DateTime $getCoursesRequestStartDate = null
): GetCoursesReponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `getCoursesRequestCourseIDs` | `?(int[])` | Query, Optional | Return only courses that are available for the specified CourseIds. |
| `getCoursesRequestEndDate` | `?DateTime` | Query, Optional | The end date range. Any active courses that are on or before this day.<br><br />(optional) Defaults to StartDate. |
| `getCoursesRequestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `getCoursesRequestLocationIDs` | `?(int[])` | Query, Optional | Return only courses that are available for the specified LocationIds. |
| `getCoursesRequestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `getCoursesRequestProgramIDs` | `?(int[])` | Query, Optional | Return only courses that are available for the specified ProgramIds. |
| `getCoursesRequestSemesterIDs` | `?(int[])` | Query, Optional | Return only courses that are available for the specified SemesterIds. |
| `getCoursesRequestStaffIDs` | `?(int[])` | Query, Optional | Return only courses that are available for the specified StaffIds. |
| `getCoursesRequestStartDate` | `?DateTime` | Query, Optional | The start date range. Any active courses that are on or after this day.<br><br />(optional) Defaults to today. |

## Response Type

[`GetCoursesReponse`](../../doc/models/get-courses-reponse.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$getCoursesRequestCourseIDs = [
    11,
    12,
    13
];

$getCoursesRequestEndDate = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');

$getCoursesRequestLimit = 158;

$getCoursesRequestLocationIDs = [
    175,
    176
];

$getCoursesRequestOffset = 92;

$getCoursesRequestProgramIDs = [
    250
];

$getCoursesRequestSemesterIDs = [
    73,
    74,
    75
];

$getCoursesRequestStaffIDs = [
    73
];

$getCoursesRequestStartDate = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');

$result = $mClassController->getCourses(
    $version,
    $siteId,
    $authorization,
    $getCoursesRequestCourseIDs,
    $getCoursesRequestEndDate,
    $getCoursesRequestLimit,
    $getCoursesRequestLocationIDs,
    $getCoursesRequestOffset,
    $getCoursesRequestProgramIDs,
    $getCoursesRequestSemesterIDs,
    $getCoursesRequestStaffIDs,
    $getCoursesRequestStartDate
);
```


# Get Semesters

This endpoint retrieves the business class semesters.

```php
function getSemesters(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?bool $requestActive = null,
    ?\DateTime $requestEndDate = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?array $requestSemesterIDs = null,
    ?\DateTime $requestStartDate = null
): GetSemestersResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestActive` | `?bool` | Query, Optional | When true, the response only contains semesters which are activated. When false, only deactivated semesters are returned.<br>Default: **All semesters** |
| `requestEndDate` | `?DateTime` | Query, Optional | The end date for the range. All semesters that are on or before this day.<br>Default: **StartDate** |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestSemesterIDs` | `?(int[])` | Query, Optional | The requested semester IDs. |
| `requestStartDate` | `?DateTime` | Query, Optional | The start date for the range. All semesters that are on or after this day.<br>Default: **today’s date** |

## Response Type

[`GetSemestersResponse`](../../doc/models/get-semesters-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$requestActive = false;

$requestEndDate = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');

$requestLimit = 62;

$requestOffset = 100;

$requestSemesterIDs = [
    126
];

$requestStartDate = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');

$result = $mClassController->getSemesters(
    $version,
    $siteId,
    $authorization,
    $requestActive,
    $requestEndDate,
    $requestLimit,
    $requestOffset,
    $requestSemesterIDs,
    $requestStartDate
);
```


# Get Waitlist Entries

Returns a list of waiting list entries for a specified class schedule or class. The request requires staff credentials and either a class schedule ID or class ID.

```php
function getWaitlistEntries(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?array $requestClassIds = null,
    ?array $requestClassScheduleIds = null,
    ?array $requestClientIds = null,
    ?bool $requestHidePastEntries = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?array $requestWaitlistEntryIds = null
): GetWaitlistEntriesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestClassIds` | `?(int[])` | Query, Optional | The requested class IDs. If a class ID is present, the request automatically disregards any class schedule IDs in the request. <br /><br>Either `ClassScheduleIds`, `ClientIds`, `WaitlistEntryIds`, or `ClassIds` is required; the others become optional.<br /><br>Default: **all ClassIds** |
| `requestClassScheduleIds` | `?(int[])` | Query, Optional | The requested class schedule IDs. If a class ID is present, the request automatically disregards any class schedule IDs in the request.<br /><br>Either `ClassScheduleIds`, `ClientIds`, `WaitlistEntryIds`, or `ClassIds` is required; the others become optional.<br /><br>Default: **all ClassScheduleIds** |
| `requestClientIds` | `?(string[])` | Query, Optional | The requested client IDs.<br /><br>Either `ClassScheduleIds`, `ClientIds`, `WaitlistEntryIds`, or `ClassIds` is required; the others become optional.<br /><br>Default: **all ClientIds** |
| `requestHidePastEntries` | `?bool` | Query, Optional | When `true`, indicates that past waiting list entries are hidden from clients.<br /><br>When `false`, indicates that past entries are not hidden from clients.<br /><br>Default: **false** |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestWaitlistEntryIds` | `?(int[])` | Query, Optional | The requested waiting list entry IDs.<br /><br>Either `ClassScheduleIds`, `ClientIds`, `WaitlistEntryIds`, or `ClassIds` is required; the others become optional.<br /><br>Default: **all WaitlistEntryIds** |

## Response Type

[`GetWaitlistEntriesResponse`](../../doc/models/get-waitlist-entries-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$requestClassIds = [
    87,
    88,
    89
];

$requestClassScheduleIds = [
    149,
    150,
    151
];

$requestClientIds = [
    'request.clientIds9',
    'request.clientIds0',
    'request.clientIds1'
];

$requestHidePastEntries = false;

$requestLimit = 62;

$requestOffset = 100;

$requestWaitlistEntryIds = [
    138,
    139
];

$result = $mClassController->getWaitlistEntries(
    $version,
    $siteId,
    $authorization,
    $requestClassIds,
    $requestClassScheduleIds,
    $requestClientIds,
    $requestHidePastEntries,
    $requestLimit,
    $requestOffset,
    $requestWaitlistEntryIds
);
```


# Add Class Schedule

This endpoint adds a class schedule. For a single day schedule, the EndDate parameter can be omitted.

```php
function addClassSchedule(
    string $version,
    AddClassEnrollmentScheduleRequest $request,
    string $siteId,
    ?string $authorization = null
): WrittenClassSchedulesInfo
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`AddClassEnrollmentScheduleRequest`](../../doc/models/add-class-enrollment-schedule-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`WrittenClassSchedulesInfo`](../../doc/models/written-class-schedules-info.md)

## Example Usage

```php
$version = '6';

$request = AddClassEnrollmentScheduleRequestBuilder::init()
    ->classDescriptionId(66)
    ->locationId(238)
    ->startDate(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
    ->endDate(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
    ->startTime(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
    ->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $mClassController->addClassSchedule(
    $version,
    $request,
    $siteId,
    $authorization
);
```


# Add Client to Class

This endpoint adds a client to a class or to a class waiting list. To prevent overbooking a class or booking outside the schedule windows set forth by the business, it is necessary to first check the capacity level of the class (‘MaxCapacity’ and 'TotalBooked’) and the 'IsAvailable’ parameter by running the GetClasses REQUEST. It is helpful to use this endpoint in the following situations:

* Use after calling `GET Clients` and `GET Classes` so that you are sure which client to book in which class.
* If adding a client to a class from a waiting list, use this call after you call `GET WaitlistEntries` and determine the ID of the waiting list from which you are moving the client.
* If adding a client to a class and using a pricing option that the client has already purchased, use this call after you call `GET ClientServices` to determine the ID of the pricing option that the client wants to use.

If you add a client to a class and the client purchases a new pricing option, use `GET Services`, `GET Classes`, and then `POST CheckoutShoppingCart` in place of this call.

This endpoint also supports cross-regional class bookings. If you want to perform a cross-regional class booking, set `CrossRegionalBooking` to `true`. This endpoint does not support adding a user to a waiting list using a cross-regional client pricing option(service). Cross-regional booking workflows do not support client service scheduling restrictions.

When performing a cross-regional class booking, this endpoint loops through the first ten sites that the client is associated with, looks for client pricing options at each of those sites, and then uses the oldest client pricing option found.It is important to note that this endpoint only loops through a maximum of ten associated client sites. If a `ClientID` is associated with more than ten sites in an organization, this endpoint only loops through the first ten.If you know that a client has a client service at another site, you can specify that site using the `CrossRegionalBookingClientServiceSiteId` query parameter.

If you perform a cross-regional booking, two additional fields are included in the `SessionType` object of the response:

* `SiteID`, which specifies where the client service is coming from
* `CrossRegionalBookingPerformed`, a Boolean field that is set to `true`

As a prerequisite to using this endpoint, your `SourceName` must have been granted access to the organization to which the site belongs.

```php
function addClientToClass(
    string $version,
    AddClientToClassRequest $request,
    string $siteId,
    ?string $authorization = null
): AddClientToClassResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`AddClientToClassRequest`](../../doc/models/add-client-to-class-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`AddClientToClassResponse`](../../doc/models/add-client-to-class-response.md)

## Example Usage

```php
$version = '6';

$request = AddClientToClassRequestBuilder::init(
    'ClientId0',
    90
)
    ->test(false)
    ->requirePayment(false)
    ->waitlist(false)
    ->sendEmail(false)
    ->waitlistEntryId(54)
    ->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $mClassController->addClientToClass(
    $version,
    $request,
    $siteId,
    $authorization
);
```


# Cancel Single Class

This endpoint will cancel a single class from studio.

```php
function cancelSingleClass(
    string $version,
    CancelSingleClassRequest $request,
    string $siteId,
    ?string $authorization = null
): CancelSingleClassResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`CancelSingleClassRequest`](../../doc/models/cancel-single-class-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`CancelSingleClassResponse`](../../doc/models/cancel-single-class-response.md)

## Example Usage

```php
$version = '6';

$request = CancelSingleClassRequestBuilder::init()
    ->classID(30)
    ->hideCancel(false)
    ->sendClientEmail(false)
    ->sendStaffEmail(false)
    ->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $mClassController->cancelSingleClass(
    $version,
    $request,
    $siteId,
    $authorization
);
```


# Remove Client From Class

Remove a client from a class.

```php
function removeClientFromClass(
    string $version,
    RemoveClientFromClassRequest $request,
    string $siteId,
    ?string $authorization = null
): RemoveClientFromClassResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`RemoveClientFromClassRequest`](../../doc/models/remove-client-from-class-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`RemoveClientFromClassResponse`](../../doc/models/remove-client-from-class-response.md)

## Example Usage

```php
$version = '6';

$request = RemoveClientFromClassRequestBuilder::init(
    90
)
    ->clientId('ClientId0')
    ->uniqueClientId(154)
    ->test(false)
    ->sendEmail(false)
    ->lateCancel(false)
    ->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $mClassController->removeClientFromClass(
    $version,
    $request,
    $siteId,
    $authorization
);
```


# Remove Clients From Classes

This endpoint can be utilized for removing multiple clients from multiple classes in one request.

```php
function removeClientsFromClasses(
    string $version,
    RemoveClientsFromClassesRequest $request,
    string $siteId,
    ?string $authorization = null
): RemoveClientsFromClassesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`RemoveClientsFromClassesRequest`](../../doc/models/remove-clients-from-classes-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`RemoveClientsFromClassesResponse`](../../doc/models/remove-clients-from-classes-response.md)

## Example Usage

```php
$version = '6';

$request = RemoveClientsFromClassesRequestBuilder::init()
    ->details(
        [
            ClassClientDetailBuilder::init(
                [
                    'ClientIds5'
                ],
                190
            )->build(),
            ClassClientDetailBuilder::init(
                [
                    'ClientIds5'
                ],
                190
            )->build()
        ]
    )
    ->test(false)
    ->sendEmail(false)
    ->lateCancel(false)
    ->limit(32)
    ->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $mClassController->removeClientsFromClasses(
    $version,
    $request,
    $siteId,
    $authorization
);
```


# Remove From Waitlist

This endpoint does not return a response. If a call to this endpoint results in a 200 OK HTTP status code, then the call was successful.

```php
function removeFromWaitlist(
    string $version,
    array $requestWaitlistEntryIds,
    string $siteId,
    ?string $authorization = null
): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestWaitlistEntryIds` | `int[]` | Query, Required | A list of `WaitlistEntryIds` to remove from the waiting list. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`array`

## Example Usage

```php
$version = '6';

$requestWaitlistEntryIds = [
    138,
    139
];

$siteId = '-99';

$authorization = 'authorization6';

$result = $mClassController->removeFromWaitlist(
    $version,
    $requestWaitlistEntryIds,
    $siteId,
    $authorization
);
```


# Substitute Class Teacher

Substitute a class teacher.

```php
function substituteClassTeacher(
    string $version,
    SubstituteClassTeacherRequest $request,
    string $siteId,
    ?string $authorization = null
): SubstituteClassTeacherResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`SubstituteClassTeacherRequest`](../../doc/models/substitute-class-teacher-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`SubstituteClassTeacherResponse`](../../doc/models/substitute-class-teacher-response.md)

## Example Usage

```php
$version = '6';

$request = SubstituteClassTeacherRequestBuilder::init(
    90,
    188
)
    ->overrideConflicts(false)
    ->sendClientEmail(false)
    ->sendOriginalTeacherEmail(false)
    ->sendSubstituteTeacherEmail(false)
    ->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $mClassController->substituteClassTeacher(
    $version,
    $request,
    $siteId,
    $authorization
);
```


# Update Class Schedule

This endpoint updates a class schedule.

```php
function updateClassSchedule(
    string $version,
    UpdateClassEnrollmentScheduleRequest $request,
    string $siteId,
    ?string $authorization = null
): WrittenClassSchedulesInfo
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`UpdateClassEnrollmentScheduleRequest`](../../doc/models/update-class-enrollment-schedule-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`WrittenClassSchedulesInfo`](../../doc/models/written-class-schedules-info.md)

## Example Usage

```php
$version = '6';

$request = UpdateClassEnrollmentScheduleRequestBuilder::init()
    ->classId(90)
    ->classDescriptionId(66)
    ->locationId(238)
    ->startDate(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
    ->endDate(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
    ->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $mClassController->updateClassSchedule(
    $version,
    $request,
    $siteId,
    $authorization
);
```


# Update Class Schedule Notes

This endpoint updates the notes of class instances based on the schedule's schedule ID.
Note: Every coming class instance for the given ScheduleID will have the notes updated the same way.

```php
function updateClassScheduleNotes(
    string $version,
    int $classScheduleId,
    UpdateClassScheduleNotesRequest $request,
    string $siteId,
    ?string $authorization = null
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `classScheduleId` | `int` | Template, Required | - |
| `request` | [`UpdateClassScheduleNotesRequest`](../../doc/models/update-class-schedule-notes-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`void`

## Example Usage

```php
$version = '6';

$classScheduleId = 142;

$request = UpdateClassScheduleNotesRequestBuilder::init()
    ->notes('Notes8')
    ->build();

$siteId = '-99';

$authorization = 'authorization6';

$mClassController->updateClassScheduleNotes(
    $version,
    $classScheduleId,
    $request,
    $siteId,
    $authorization
);
```

