# Pick a Spot

```php
$pickASpotController = $client->getPickASpotController();
```

## Class Name

`PickASpotController`

## Methods

* [Get Class List](../../doc/controllers/pick-a-spot.md#get-class-list)
* [Get Class](../../doc/controllers/pick-a-spot.md#get-class)
* [Get Reservation](../../doc/controllers/pick-a-spot.md#get-reservation)
* [Update Reservation](../../doc/controllers/pick-a-spot.md#update-reservation)
* [Create Reservation](../../doc/controllers/pick-a-spot.md#create-reservation)
* [Delete Reservation](../../doc/controllers/pick-a-spot.md#delete-reservation)


# Get Class List

This endpoint supports pagination. See Pagination object for a description.

```php
function getClassList(string $version, string $siteId, ?string $authorization = null): GetPickASpotClassResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`GetPickASpotClassResponse`](../../doc/models/get-pick-a-spot-class-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$result = $pickASpotController->getClassList(
    $version,
    $siteId,
    $authorization
);
```


# Get Class

Get a class filtered by classId.

```php
function getClass(
    string $version,
    string $classId,
    string $siteId,
    ?string $authorization = null
): GetPickASpotClassResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `classId` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`GetPickASpotClassResponse`](../../doc/models/get-pick-a-spot-class-response.md)

## Example Usage

```php
$version = '6';

$classId = 'classId0';

$siteId = '-99';

$authorization = 'authorization6';

$result = $pickASpotController->getClass(
    $version,
    $classId,
    $siteId,
    $authorization
);
```


# Get Reservation

Retrieves reservation for Pick a Spot.

```php
function getReservation(
    string $version,
    string $pathInfo,
    string $siteId,
    ?string $authorization = null
): GetReservationResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `pathInfo` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`GetReservationResponse`](../../doc/models/get-reservation-response.md)

## Example Usage

```php
$version = '6';

$pathInfo = 'pathInfo8';

$siteId = '-99';

$authorization = 'authorization6';

$result = $pickASpotController->getReservation(
    $version,
    $pathInfo,
    $siteId,
    $authorization
);
```


# Update Reservation

A user token is required for this endpoint.
This endpoint updates a single reservation.

```php
function updateReservation(
    string $version,
    string $pathInfo,
    string $siteId,
    ?string $authorization = null
): UpdateReservationResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `pathInfo` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`UpdateReservationResponse`](../../doc/models/update-reservation-response.md)

## Example Usage

```php
$version = '6';

$pathInfo = 'pathInfo8';

$siteId = '-99';

$authorization = 'authorization6';

$result = $pickASpotController->updateReservation(
    $version,
    $pathInfo,
    $siteId,
    $authorization
);
```


# Create Reservation

Creates a spot reservation for a given pick-a-spot class. The actual class visit must be created prior to calling this endpoint.
A user token is required for this endpoint.

Sample request:

    POST /pickaspot/v1/reservation
    {
        "SiteId": -1147483363,
        "LocationId": 1,
        "ClassId": "64b14ac8c20ae8f0afd2d409",
        "ReservationExternalId": "44724", // this is a Visit.Id and should be linked to a specific class visit
        "MemberExternalId": "100000136", // this is Client's UniqueId
        "SpotNumber": "5",
        "ReservationDisplayName": "ReservationDisplayName", // optional
        "ReservationType": "Member", // optional. Can be Member, Guest, Instructor, FamilyMember,
        "AutoConfirm": false, // optional. Default: false
        "AutoAssignSpot": false // optional. It will override the "SpotNumber" passed and auto assign one. Default: false
    }

```php
function createReservation(
    string $version,
    string $pathInfo,
    string $siteId,
    ?string $authorization = null
): CreateReservationResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `pathInfo` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`CreateReservationResponse`](../../doc/models/create-reservation-response.md)

## Example Usage

```php
$version = '6';

$pathInfo = 'pathInfo8';

$siteId = '-99';

$authorization = 'authorization6';

$result = $pickASpotController->createReservation(
    $version,
    $pathInfo,
    $siteId,
    $authorization
);
```


# Delete Reservation

A user token is required for this endpoint.
This endpoint deletes a single reservation.

```php
function deleteReservation(
    string $version,
    string $pathInfo,
    string $siteId,
    ?string $authorization = null
): HttpContent
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `pathInfo` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`HttpContent`](../../doc/models/http-content.md)

## Example Usage

```php
$version = '6';

$pathInfo = 'pathInfo8';

$siteId = '-99';

$authorization = 'authorization6';

$result = $pickASpotController->deleteReservation(
    $version,
    $pathInfo,
    $siteId,
    $authorization
);
```

