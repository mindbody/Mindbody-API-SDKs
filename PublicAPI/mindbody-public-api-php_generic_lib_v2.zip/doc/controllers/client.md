# Client

```php
$clientController = $client->getClientController();
```

## Class Name

`ClientController`

## Methods

* [Get Active Client Memberships](../../doc/controllers/client.md#get-active-client-memberships)
* [Get Active Clients Memberships](../../doc/controllers/client.md#get-active-clients-memberships)
* [Get Client Account Balances](../../doc/controllers/client.md#get-client-account-balances)
* [Get Client Complete Info](../../doc/controllers/client.md#get-client-complete-info)
* [Get Client Contracts](../../doc/controllers/client.md#get-client-contracts)
* [Get Direct Debit Info](../../doc/controllers/client.md#get-direct-debit-info)
* [Delete Direct Debit Info](../../doc/controllers/client.md#delete-direct-debit-info)
* [Get Client Duplicates](../../doc/controllers/client.md#get-client-duplicates)
* [Get Client Formula Notes](../../doc/controllers/client.md#get-client-formula-notes)
* [Get Client Indexes](../../doc/controllers/client.md#get-client-indexes)
* [Get Client Purchases](../../doc/controllers/client.md#get-client-purchases)
* [Get Client Referral Types](../../doc/controllers/client.md#get-client-referral-types)
* [Get Client Rewards](../../doc/controllers/client.md#get-client-rewards)
* [Update Client Rewards](../../doc/controllers/client.md#update-client-rewards)
* [Get Clients](../../doc/controllers/client.md#get-clients)
* [Get Client Schedule](../../doc/controllers/client.md#get-client-schedule)
* [Get Client Services](../../doc/controllers/client.md#get-client-services)
* [Get Client Visits](../../doc/controllers/client.md#get-client-visits)
* [Get Contact Logs](../../doc/controllers/client.md#get-contact-logs)
* [Get Contact Log Types](../../doc/controllers/client.md#get-contact-log-types)
* [Get Cross Regional Client Associations](../../doc/controllers/client.md#get-cross-regional-client-associations)
* [Get Custom Client Fields](../../doc/controllers/client.md#get-custom-client-fields)
* [Get Required Client Fields](../../doc/controllers/client.md#get-required-client-fields)
* [Add Arrival](../../doc/controllers/client.md#add-arrival)
* [Add Client](../../doc/controllers/client.md#add-client)
* [Add Client Direct Debit Info](../../doc/controllers/client.md#add-client-direct-debit-info)
* [Add Formula Note](../../doc/controllers/client.md#add-formula-note)
* [Add Contact Log](../../doc/controllers/client.md#add-contact-log)
* [Merge Client](../../doc/controllers/client.md#merge-client)
* [Send Auto Email](../../doc/controllers/client.md#send-auto-email)
* [Send Password Reset Email](../../doc/controllers/client.md#send-password-reset-email)
* [Suspend Contract](../../doc/controllers/client.md#suspend-contract)
* [Terminate Contract](../../doc/controllers/client.md#terminate-contract)
* [Update Client](../../doc/controllers/client.md#update-client)
* [Update Client Contract Autopays](../../doc/controllers/client.md#update-client-contract-autopays)
* [Update Client Service](../../doc/controllers/client.md#update-client-service)
* [Update Client Visit](../../doc/controllers/client.md#update-client-visit)
* [Update Contact Log](../../doc/controllers/client.md#update-contact-log)
* [Upload Client Document](../../doc/controllers/client.md#upload-client-document)
* [Upload Client Photo](../../doc/controllers/client.md#upload-client-photo)
* [Delete Client Formula Note](../../doc/controllers/client.md#delete-client-formula-note)
* [Delete Contact Log](../../doc/controllers/client.md#delete-contact-log)


# Get Active Client Memberships

Please note that client memberships with location restrictions can only be used to pay for scheduled services at the site to which they belong. Memberships with location restrictions can not be used to pay for scheduled services at other sites within an organization.

```php
function getActiveClientMemberships(
    string $version,
    string $requestClientId,
    string $siteId,
    ?string $authorization = null,
    ?int $requestClientAssociatedSitesOffset = null,
    ?bool $requestCrossRegionalLookup = null,
    ?int $requestLimit = null,
    ?int $requestLocationId = null,
    ?int $requestOffset = null,
    ?int $requestUniqueClientId = null
): GetActiveClientMembershipsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientId` | `string` | Query, Required | The ID of the client for whom memberships are returned. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestClientAssociatedSitesOffset` | `?int` | Query, Optional | Used to retrieve a client’s memberships from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br /><br>Default: **0**<br><br>For example, if a client is associated with 25 sites, you need to call GET `ActiveClientMemberships` three times, as follows:<br><br>* Use GET `CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.<br>* Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s memberships from sites 1-10<br>* Set `ClientAssociatedSitesOffset` to 10 to return the client’s memberships from sites 11-20<br>* Set `ClientAssociatedSitesOffset` to 20 to return the client’s memberships from sites 21-25 |
| `requestCrossRegionalLookup` | `?bool` | Query, Optional | Used to retrieve a client’s memberships from multiple sites within an organization. When included and set to `true`, it searches a maximum of ten sites with which this client is associated. When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.<br>Default: **false** |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `?int` | Query, Optional | Filters results to memberships that can be used to pay for scheduled services at that location. This parameter can not be passed when `CrossRegionalLookup` is `true`. |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestUniqueClientId` | `?int` | Query, Optional | The Unique ID of the client for whom memberships are returned. Note that UniqueClientId takes precedence over ClientId if both are provided. |

## Response Type

[`GetActiveClientMembershipsResponse`](../../doc/models/get-active-client-memberships-response.md)

## Example Usage

```php
$version = '6';

$requestClientId = 'request.clientId2';

$siteId = '-99';

$authorization = 'authorization6';

$requestClientAssociatedSitesOffset = 146;

$requestCrossRegionalLookup = false;

$requestLimit = 62;

$requestLocationId = 90;

$requestOffset = 100;

$requestUniqueClientId = 226;

$result = $clientController->getActiveClientMemberships(
    $version,
    $requestClientId,
    $siteId,
    $authorization,
    $requestClientAssociatedSitesOffset,
    $requestCrossRegionalLookup,
    $requestLimit,
    $requestLocationId,
    $requestOffset,
    $requestUniqueClientId
);
```


# Get Active Clients Memberships

The endpoint returns a list of memberships for multiple clients we pass in query parameter. Please note that clients memberships with location restrictions can only be used to pay for scheduled services at the site to which they belong. Memberships with location restrictions can not be used to pay for scheduled services at other sites within an organization.

```php
function getActiveClientsMemberships(
    string $version,
    array $requestClientIds,
    string $siteId,
    ?string $authorization = null,
    ?int $requestClientAssociatedSitesOffset = null,
    ?bool $requestCrossRegionalLookup = null,
    ?int $requestLimit = null,
    ?int $requestLocationId = null,
    ?int $requestOffset = null
): GetActiveClientsMembershipsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientIds` | `string[]` | Query, Required | The ID of the client for whom memberships are returned. Maximum allowed : 200. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestClientAssociatedSitesOffset` | `?int` | Query, Optional | Used to retrieve a client’s memberships from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br /><br>Default: **0**<br><br>For example, if a client is associated with 25 sites, you need to call `GetClientServices` three times, as follows:<br><br>* Use `GET CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.<br>* Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s services (pricing options) from sites 1-10.<br>* Set `ClientAssociatedSitesOffset` to 10 to return the client pricing options from sites 11-20<br>* Set `ClientAssociatedSitesOffset` to 20 to return the client pricing options from sites 21-25 |
| `requestCrossRegionalLookup` | `?bool` | Query, Optional | Used to retrieve a client’s memberships from multiple sites within an organization. When included and set to `true`, it searches a maximum of ten sites with which this client is associated. When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.<br>Default: **false** |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `?int` | Query, Optional | Filters results to memberships that can be used to pay for scheduled services at that location. This parameter can not be passed when `CrossRegionalLookup` is `true`. |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`GetActiveClientsMembershipsResponse`](../../doc/models/get-active-clients-memberships-response.md)

## Example Usage

```php
$version = '6';

$requestClientIds = [
    'request.clientIds9',
    'request.clientIds0',
    'request.clientIds1'
];

$siteId = '-99';

$authorization = 'authorization6';

$requestClientAssociatedSitesOffset = 146;

$requestCrossRegionalLookup = false;

$requestLimit = 62;

$requestLocationId = 90;

$requestOffset = 100;

$result = $clientController->getActiveClientsMemberships(
    $version,
    $requestClientIds,
    $siteId,
    $authorization,
    $requestClientAssociatedSitesOffset,
    $requestCrossRegionalLookup,
    $requestLimit,
    $requestLocationId,
    $requestOffset
);
```


# Get Client Account Balances

Get account balance information for one or more client(s).

```php
function getClientAccountBalances(
    string $version,
    array $requestClientIds,
    string $siteId,
    ?string $authorization = null,
    ?\DateTime $requestBalanceDate = null,
    ?int $requestClassId = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null
): GetClientAccountBalancesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientIds` | `string[]` | Query, Required | The list of clients IDs for which you want account balances. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestBalanceDate` | `?DateTime` | Query, Optional | The date you want a balance relative to.<br>Default: **the current date** |
| `requestClassId` | `?int` | Query, Optional | The class ID of the event for which you want a balance. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`GetClientAccountBalancesResponse`](../../doc/models/get-client-account-balances-response.md)

## Example Usage

```php
$version = '6';

$requestClientIds = [
    'request.clientIds9',
    'request.clientIds0',
    'request.clientIds1'
];

$siteId = '-99';

$authorization = 'authorization6';

$requestBalanceDate = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');

$requestClassId = 206;

$requestLimit = 62;

$requestOffset = 100;

$result = $clientController->getClientAccountBalances(
    $version,
    $requestClientIds,
    $siteId,
    $authorization,
    $requestBalanceDate,
    $requestClassId,
    $requestLimit,
    $requestOffset
);
```


# Get Client Complete Info

This endpoint returns complete client information along with list of purchased services, contract details, membership details and arrival programs for a specific client.

```php
function getClientCompleteInfo(
    string $version,
    string $requestClientId,
    string $siteId,
    ?string $authorization = null,
    ?string $consumerIdentityToken = null,
    ?int $requestClientAssociatedSitesOffset = null,
    ?bool $requestCrossRegionalLookup = null,
    ?\DateTime $requestEndDate = null,
    ?bool $requestExcludeInactiveSites = null,
    ?array $requestRequiredClientData = null,
    ?bool $requestShowActiveOnly = null,
    ?\DateTime $requestStartDate = null,
    ?int $requestUniqueClientId = null,
    ?bool $requestUseActivateDate = null
): GetClientCompleteInfoResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientId` | `string` | Query, Required | Filters results to client with these ID. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `consumerIdentityToken` | `?string` | Header, Optional | A consumers authorization token to replace the need of clientId in the request. |
| `requestClientAssociatedSitesOffset` | `?int` | Query, Optional | Used to retrieve a client’s pricing options from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br /><br>Default: **0**<br><br>For example, if a client is associated with 25 sites, you need to call `GetClientServices` three times, as follows:<br><br>* Use `GET CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.<br>* Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s services (pricing options) from sites 1-10.<br>* Set `ClientAssociatedSitesOffset` to 10 to return the client pricing options from sites 11-20<br>* Set `ClientAssociatedSitesOffset` to 20 to return the client pricing options from sites 21-25 |
| `requestCrossRegionalLookup` | `?bool` | Query, Optional | Used to retrieve a clients pricing options from multiple sites within an organization.When included and set to `true`,<br>it searches a maximum of ten sites with which this client is associated.When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated.<br>You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with.<br>Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.<br>Default: **false** |
| `requestEndDate` | `?DateTime` | Query, Optional | Filters results to pricing options that are purchased on or before this date.<br>Default: **today’s date**. |
| `requestExcludeInactiveSites` | `?bool` | Query, Optional | When this flag is set to `true`, will exclude inactive sites from the response<br>Default: **false** |
| `requestRequiredClientData` | `?(string[])` | Query, Optional | Used to retrieve list of purchased services, contract details, membership details and arrival programs for a specific client.<br>Default `ClientServices`, `ClientContracts`, `ClientMemberships` and `ClientArrivals` will be returned when `RequiredClientDatais` not set.<br>When `RequiredClientData` is set to `Contracts` then only `ClientContracts` will be returned in the response.<br>When `RequiredClientData` is set to Services then only `ClientServices` will be returned in the response.<br>When `RequiredClientData` is set to `Memberships` then only `ClientMemberships` will be returned in the response.<br>When `RequiredClientData` is set to `ArrivalPrograms` then only `ClientArrivals` will be returned in the response. |
| `requestShowActiveOnly` | `?bool` | Query, Optional | When `true`, includes active services only. Set this field to `true` when trying to determine if a client has a<br>service that can pay for a class or appointment.<br>Default: **false** |
| `requestStartDate` | `?DateTime` | Query, Optional | Filters results to pricing options that are purchased on or after this date.<br>Default: **today’s date**. |
| `requestUniqueClientId` | `?int` | Query, Optional | The unique ID of the client who is viewing this class list. |
| `requestUseActivateDate` | `?bool` | Query, Optional | When this flag is set to `true`, the date filtering will use activate date to filter the pricing options.<br>When this flag is set to `false`, the date filtering will use purchase date to filter the pricing options.<br>Default: **false** |

## Response Type

[`GetClientCompleteInfoResponse`](../../doc/models/get-client-complete-info-response.md)

## Example Usage

```php
$version = '6';

$requestClientId = 'request.clientId2';

$siteId = '-99';

$authorization = 'authorization6';

$consumerIdentityToken = 'consumer-identity-token6';

$requestClientAssociatedSitesOffset = 146;

$requestCrossRegionalLookup = false;

$requestEndDate = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');

$requestExcludeInactiveSites = false;

$requestRequiredClientData = [
    'request.requiredClientData4',
    'request.requiredClientData5'
];

$requestShowActiveOnly = false;

$requestStartDate = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');

$requestUniqueClientId = 226;

$requestUseActivateDate = false;

$result = $clientController->getClientCompleteInfo(
    $version,
    $requestClientId,
    $siteId,
    $authorization,
    $consumerIdentityToken,
    $requestClientAssociatedSitesOffset,
    $requestCrossRegionalLookup,
    $requestEndDate,
    $requestExcludeInactiveSites,
    $requestRequiredClientData,
    $requestShowActiveOnly,
    $requestStartDate,
    $requestUniqueClientId,
    $requestUseActivateDate
);
```


# Get Client Contracts

Get contracts that a client has purchased.

```php
function getClientContracts(
    string $version,
    string $requestClientId,
    string $siteId,
    ?string $authorization = null,
    ?int $requestClientAssociatedSitesOffset = null,
    ?bool $requestCrossRegionalLookup = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?int $requestUniqueClientId = null
): GetClientContractsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientId` | `string` | Query, Required | The ID of the client (RssId). |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestClientAssociatedSitesOffset` | `?int` | Query, Optional | Determines how many sites are skipped over when retrieving a client’s cross regional contracts. Used when a client ID is linked to more than ten sites in an organization. Only a maximum of ten site databases are queried when this call is made and `CrossRegionalLookup` is set to `true`. To change which sites are queried, change this offset value.<br>Default: **0** |
| `requestCrossRegionalLookup` | `?bool` | Query, Optional | When `true`, indicates that the requesting client’s cross regional contracts are returned, if any.<br /><br>When `false`, indicates that cross regional contracts are not returned. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestUniqueClientId` | `?int` | Query, Optional | The unique ID of the requested client. |

## Response Type

[`GetClientContractsResponse`](../../doc/models/get-client-contracts-response.md)

## Example Usage

```php
$version = '6';

$requestClientId = 'request.clientId2';

$siteId = '-99';

$authorization = 'authorization6';

$requestClientAssociatedSitesOffset = 146;

$requestCrossRegionalLookup = false;

$requestLimit = 62;

$requestOffset = 100;

$requestUniqueClientId = 226;

$result = $clientController->getClientContracts(
    $version,
    $requestClientId,
    $siteId,
    $authorization,
    $requestClientAssociatedSitesOffset,
    $requestCrossRegionalLookup,
    $requestLimit,
    $requestOffset,
    $requestUniqueClientId
);
```


# Get Direct Debit Info

This endpoint returns direct debit info stored on a client's account. This endpoint requires staff user credentials.

A null response from this endpoint indicates that the client has no usable direct debit information on their account.Use the POST AddClientDirectDebitInfo endpoint to add direct debit information to a client’s account.

```php
function getDirectDebitInfo(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?string $clientId = null
): DirectDebitInfo
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `clientId` | `?string` | Query, Optional | The ID of the client. |

## Response Type

[`DirectDebitInfo`](../../doc/models/direct-debit-info.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$clientId = 'clientId6';

$result = $clientController->getDirectDebitInfo(
    $version,
    $siteId,
    $authorization,
    $clientId
);
```


# Delete Direct Debit Info

This endpoint deletes direct debit info from a client’s account. This endpoint requires staff user credentials.

```php
function deleteDirectDebitInfo(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?string $clientId = null
): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `clientId` | `?string` | Query, Optional | The ID of the client. |

## Response Type

`array`

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$clientId = 'clientId6';

$result = $clientController->deleteDirectDebitInfo(
    $version,
    $siteId,
    $authorization,
    $clientId
);
```


# Get Client Duplicates

This endpoint gets client records that would be considered duplicates based on case-insensitive matching of the client's first name, last name, and email. For there to be results, all three parameters must match a client record. This endpoint requires staff user credentials.

An empty `ClientDuplicates` object in the response from this endpoint indicates that there were no client records found that match the first name, last name, and email fields passed in.

If one client record is returned, it is not a duplicate itself, but no other client record can be created or updated that would match this client's first name, last name, and email combination.

If more than one client record is returned, these clients are duplicates of each other.We recommend discussing with the business how they would like to resolve duplicate records in the event the response contains more than one client record.Businesses can use the Merge Duplicate Clients tool in the Core Business Mode software to resolve the duplicate client records.

```php
function getClientDuplicates(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?string $requestEmail = null,
    ?string $requestFirstName = null,
    ?string $requestLastName = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null
): GetClientDuplicatesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestEmail` | `?string` | Query, Optional | The client email to match on when searching for duplicates. |
| `requestFirstName` | `?string` | Query, Optional | The client first name to match on when searching for duplicates. |
| `requestLastName` | `?string` | Query, Optional | The client last name to match on when searching for duplicates. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`GetClientDuplicatesResponse`](../../doc/models/get-client-duplicates-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$requestEmail = 'request.email4';

$requestFirstName = 'request.firstName8';

$requestLastName = 'request.lastName8';

$requestLimit = 62;

$requestOffset = 100;

$result = $clientController->getClientDuplicates(
    $version,
    $siteId,
    $authorization,
    $requestEmail,
    $requestFirstName,
    $requestLastName,
    $requestLimit,
    $requestOffset
);
```


# Get Client Formula Notes

***QueryParams***: Enables to retrieve cross regional formula notes for a client, or for a specific appointment. The two parameters are optional, however at least one must be provided. This endpoint supports pagination.

```php
function getClientFormulaNotes(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?int $requestAppointmentId = null,
    ?string $requestClientId = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null
): GetClientFormulaNotesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestAppointmentId` | `?int` | Query, Optional | The appointment ID of an appointment in the studio specified in the header of the request. |
| `requestClientId` | `?string` | Query, Optional | The client ID of the client whose formula notes are being requested. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`GetClientFormulaNotesResponse`](../../doc/models/get-client-formula-notes-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$requestAppointmentId = 194;

$requestClientId = 'request.clientId2';

$requestLimit = 62;

$requestOffset = 100;

$result = $clientController->getClientFormulaNotes(
    $version,
    $siteId,
    $authorization,
    $requestAppointmentId,
    $requestClientId,
    $requestLimit,
    $requestOffset
);
```


# Get Client Indexes

Client indexes are used to analyze client demographics. A business owner can set up different categories with sets of values which they can assign to each client. Client indexes are used in client searches, for tagging clients so that the owner can send mass emails to similar groups, and for many reports.

For more information, see Client Indexes and [Client Index Values (video tutorial)](https://support.mindbodyonline.com/s/article/203261653-Client-indexes-and-client-index-values-video-tutorial?language=en_USclient).

```php
function getClientIndexes(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?bool $requestRequiredOnly = null
): GetClientIndexesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestRequiredOnly` | `?bool` | Query, Optional | When `true`, filters the results to only indexes that are required on creation.<br /><br>When `false` or omitted, returns all of the client indexes. |

## Response Type

[`GetClientIndexesResponse`](../../doc/models/get-client-indexes-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$requestRequiredOnly = false;

$result = $clientController->getClientIndexes(
    $version,
    $siteId,
    $authorization,
    $requestRequiredOnly
);
```


# Get Client Purchases

Gets a list of purchases made by a specific client.

```php
function getClientPurchases(
    string $version,
    string $requestClientId,
    string $siteId,
    ?string $authorization = null,
    ?\DateTime $requestEndDate = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?int $requestSaleId = null,
    ?\DateTime $requestStartDate = null,
    ?int $requestUniqueClientId = null
): GetClientPurchasesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientId` | `string` | Query, Required | The ID of the client you are querying for purchases. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestEndDate` | `?DateTime` | Query, Optional | Filters results to purchases made before this timestamp.<br /><br>Default: **end of today** |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestSaleId` | `?int` | Query, Optional | Filters results to the single record associated with this ID. |
| `requestStartDate` | `?DateTime` | Query, Optional | Filters results to purchases made on or after this timestamp.<br /><br>Default: **now** |
| `requestUniqueClientId` | `?int` | Query, Optional | The unique ID of the requested client. |

## Response Type

[`GetClientPurchasesResponse`](../../doc/models/get-client-purchases-response.md)

## Example Usage

```php
$version = '6';

$requestClientId = 'request.clientId2';

$siteId = '-99';

$authorization = 'authorization6';

$requestEndDate = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');

$requestLimit = 62;

$requestOffset = 100;

$requestSaleId = 32;

$requestStartDate = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');

$requestUniqueClientId = 226;

$result = $clientController->getClientPurchases(
    $version,
    $requestClientId,
    $siteId,
    $authorization,
    $requestEndDate,
    $requestLimit,
    $requestOffset,
    $requestSaleId,
    $requestStartDate,
    $requestUniqueClientId
);
```


# Get Client Referral Types

Gets a list of referral types. Referral types are options that new clients can choose to identify how they learned about the business. Referral types are typically used for the sign-up process.

```php
function getClientReferralTypes(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?bool $requestIncludeInactive = null
): GetClientReferralTypesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestIncludeInactive` | `?bool` | Query, Optional | When `true`, filters the results to include subtypes and inactive referral types.<br /><br>When `false`, includes no subtypes and only active types.<br>Default:**false** |

## Response Type

[`GetClientReferralTypesResponse`](../../doc/models/get-client-referral-types-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$requestIncludeInactive = false;

$result = $clientController->getClientReferralTypes(
    $version,
    $siteId,
    $authorization,
    $requestIncludeInactive
);
```


# Get Client Rewards

Gets the client rewards.

```php
function getClientRewards(
    string $version,
    string $requestClientId,
    string $siteId,
    ?string $authorization = null,
    ?\DateTime $requestEndDate = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?\DateTime $requestStartDate = null
): GetClientRewardsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientId` | `string` | Query, Required | The ID of the client. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestEndDate` | `?DateTime` | Query, Optional | The end date of transaction.<br>Default: **StartDate** |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestStartDate` | `?DateTime` | Query, Optional | The start date of transaction.<br>Default: **today** |

## Response Type

[`GetClientRewardsResponse`](../../doc/models/get-client-rewards-response.md)

## Example Usage

```php
$version = '6';

$requestClientId = 'request.clientId2';

$siteId = '-99';

$authorization = 'authorization6';

$requestEndDate = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');

$requestLimit = 62;

$requestOffset = 100;

$requestStartDate = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');

$result = $clientController->getClientRewards(
    $version,
    $requestClientId,
    $siteId,
    $authorization,
    $requestEndDate,
    $requestLimit,
    $requestOffset,
    $requestStartDate
);
```


# Update Client Rewards

Earns or redeems rewards points for a given client, based on site settings. Cross regional rewards are not supported at this time.

```php
function updateClientRewards(
    string $version,
    UpdateClientRewardsRequest $request,
    string $siteId,
    ?string $authorization = null
): GetClientRewardsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`UpdateClientRewardsRequest`](../../doc/models/update-client-rewards-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`GetClientRewardsResponse`](../../doc/models/get-client-rewards-response.md)

## Example Usage

```php
$version = '6';

$request = UpdateClientRewardsRequestBuilder::init(
    'ClientId0',
    10,
    'Action6'
)
    ->source('Source6')
    ->sourceId(112)
    ->actionDateTime(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
    ->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $clientController->updateClientRewards(
    $version,
    $request,
    $siteId,
    $authorization
);
```


# Get Clients

This endpoint requires staff user credentials. This endpoint supports pagination. See Pagination for a description of the Pagination information.

```php
function getClients(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?array $requestClientIDs = null,
    ?bool $requestIncludeInactive = null,
    ?bool $requestIsProspect = null,
    ?\DateTime $requestLastModifiedDate = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?string $requestSearchText = null,
    ?array $requestUniqueIds = null
): GetClientsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestClientIDs` | `?(string[])` | Query, Optional | The requested client IDs.<br>Default: **all IDs** that the authenticated user’s access level allows.<br /><br>Note: You can fetch information for maximum 20 clients at once. |
| `requestIncludeInactive` | `?bool` | Query, Optional | When `true`, indicates the results to include active and inactive clients.<br /><br>When `false`, indicates that only those clients who are marked as active should be returned.<br>Default: **false** |
| `requestIsProspect` | `?bool` | Query, Optional | When `true`, filters the results to include only those clients marked as prospects for the business.<br /><br>When `false`, indicates that only those clients who are not marked prospects should be returned. |
| `requestLastModifiedDate` | `?DateTime` | Query, Optional | Filters the results to include only the clients that have been modified on or after this date. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestSearchText` | `?string` | Query, Optional | Text to use in the search. Can include FirstName, LastName, and Email. Note that user credentials must be provided. |
| `requestUniqueIds` | `?(int[])` | Query, Optional | Filters results to clients with these `UniqueIDs`. This parameter cannot be used with `ClientIDs` or `SearchText`.<br>Default: **all UniqueIDs** that the authenticated user’s access level allows. |

## Response Type

[`GetClientsResponse`](../../doc/models/get-clients-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$requestClientIDs = [
    'request.clientIDs9',
    'request.clientIDs0',
    'request.clientIDs1'
];

$requestIncludeInactive = false;

$requestIsProspect = false;

$requestLastModifiedDate = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');

$requestLimit = 62;

$requestOffset = 100;

$requestSearchText = 'request.searchText0';

$requestUniqueIds = [
    123,
    124,
    125
];

$result = $clientController->getClients(
    $version,
    $siteId,
    $authorization,
    $requestClientIDs,
    $requestIncludeInactive,
    $requestIsProspect,
    $requestLastModifiedDate,
    $requestLimit,
    $requestOffset,
    $requestSearchText,
    $requestUniqueIds
);
```


# Get Client Schedule

This endpoint can be utilized to retrieve scheduled visits which is associated with the requested client.

```php
function getClientSchedule(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?int $requestClientAssociatedSitesOffset = null,
    ?string $requestClientId = null,
    ?bool $requestCrossRegionalLookup = null,
    ?\DateTime $requestEndDate = null,
    ?bool $requestIncludeWaitlistEntries = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?\DateTime $requestStartDate = null,
    ?int $requestUniqueClientId = null
): GetClientScheduleResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestClientAssociatedSitesOffset` | `?int` | Query, Optional | The number of sites to skip when returning the site associated with a client. |
| `requestClientId` | `?string` | Query, Optional | The ID of the requested client. |
| `requestCrossRegionalLookup` | `?bool` | Query, Optional | When `true`, indicates that past and scheduled client visits across all sites in the region are returned.<br>When `false`, indicates that only visits at the current site are returned. |
| `requestEndDate` | `?DateTime` | Query, Optional | The date past which class visits are not returned.<br>Default is today’s date |
| `requestIncludeWaitlistEntries` | `?bool` | Query, Optional | When `true`, waitlist entries are included in the response.<br>When `false`, waitlist entries are removed from the response.<br>Default: **false** |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestStartDate` | `?DateTime` | Query, Optional | The date before which class visits are not returned.<br>Default is the end date |
| `requestUniqueClientId` | `?int` | Query, Optional | The unique ID of the requested client.<br>Note: you need to provide the 'UniqueClientId' OR the 'ClientId'. If both are provided, the 'UniqueClientId' takes precedence. |

## Response Type

[`GetClientScheduleResponse`](../../doc/models/get-client-schedule-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$requestClientAssociatedSitesOffset = 146;

$requestClientId = 'request.clientId2';

$requestCrossRegionalLookup = false;

$requestEndDate = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');

$requestIncludeWaitlistEntries = false;

$requestLimit = 62;

$requestOffset = 100;

$requestStartDate = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');

$requestUniqueClientId = 226;

$result = $clientController->getClientSchedule(
    $version,
    $siteId,
    $authorization,
    $requestClientAssociatedSitesOffset,
    $requestClientId,
    $requestCrossRegionalLookup,
    $requestEndDate,
    $requestIncludeWaitlistEntries,
    $requestLimit,
    $requestOffset,
    $requestStartDate,
    $requestUniqueClientId
);
```


# Get Client Services

Get pricing options that a client has purchased.

```php
function getClientServices(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?int $requestClassId = null,
    ?array $requestClassScheduleID = null,
    ?int $requestClientAssociatedSitesOffset = null,
    ?string $requestClientId = null,
    ?array $requestClientIds = null,
    ?bool $requestCrossRegionalLookup = null,
    ?\DateTime $requestEndDate = null,
    ?bool $requestExcludeInactiveSites = null,
    ?bool $requestIgnoreCrossRegionalSiteLimit = null,
    ?int $requestLimit = null,
    ?array $requestLocationIds = null,
    ?int $requestOffset = null,
    ?array $requestProgramIds = null,
    ?int $requestSessionTypeId = null,
    ?bool $requestShowActiveOnly = null,
    ?\DateTime $requestStartDate = null,
    ?int $requestUniqueClientId = null,
    ?array $requestUniqueClientIds = null,
    ?bool $requestUseActivateDate = null,
    ?int $requestVisitCount = null
): GetClientServicesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestClassId` | `?int` | Query, Optional | Filters results to only those pricing options that can be used to pay for this class. |
| `requestClassScheduleID` | `?(int[])` | Query, Optional | Filters results to pricing options which are associated with one of the ClassScheduleIDs |
| `requestClientAssociatedSitesOffset` | `?int` | Query, Optional | Used to retrieve a client’s pricing options from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br /><br>Default: **0**<br><br>For example, if a client is associated with 25 sites, you need to call `GetClientServices` three times, as follows:<br><br>* Use `GET CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.<br>* Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s services (pricing options) from sites 1-10.<br>* Set `ClientAssociatedSitesOffset` to 10 to return the client pricing options from sites 11-20<br>* Set `ClientAssociatedSitesOffset` to 20 to return the client pricing options from sites 21-25 |
| `requestClientId` | `?string` | Query, Optional | The ID of the client to query. The results are a list of pricing options that the client has purchased. Note that “service” and “pricing option” are synonymous in this section of the documentation. |
| `requestClientIds` | `?(string[])` | Query, Optional | The IDs of the clients to query. The results are a list of pricing options that the clients have purchased.<br>ClientId parameter takes priority over ClientIds due to backward compatibility.<br>So if you want to use ClientIds, then ClientId needs to be empty.<br>Either of ClientId or ClientIds need to be specified |
| `requestCrossRegionalLookup` | `?bool` | Query, Optional | Used to retrieve a client’s pricing options from multiple sites within an organization. When included and set to `true`, it searches a maximum of ten sites with which this client is associated. When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.<br>Default: **false** |
| `requestEndDate` | `?DateTime` | Query, Optional | Filters results to pricing options that are purchased on or before this date.<br>Default: **today’s date** |
| `requestExcludeInactiveSites` | `?bool` | Query, Optional | When this flag is set to `true`, will exclude inactive sites from the response.<br>Default: **false** |
| `requestIgnoreCrossRegionalSiteLimit` | `?bool` | Query, Optional | Used to specify if the number of cross regional sites used to search for client’s pricing options should be ignored.<br>Default: **false** |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationIds` | `?(int[])` | Query, Optional | Filters results to pricing options that can be used at the listed location IDs. |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestProgramIds` | `?(int[])` | Query, Optional | Filters results to pricing options that belong to one of the given program IDs. |
| `requestSessionTypeId` | `?int` | Query, Optional | Filters results to pricing options that will pay for the given session type ID. Use this to find pricing options that will pay for a specific appointment type. |
| `requestShowActiveOnly` | `?bool` | Query, Optional | When `true`, includes active services only.<br>Default: **false** |
| `requestStartDate` | `?DateTime` | Query, Optional | Filters results to pricing options that are purchased on or after this date.<br>Default: **today’s date** |
| `requestUniqueClientId` | `?int` | Query, Optional | The unique ID of the client to query. Note that UniqueClientId takes precedence over ClientId. |
| `requestUniqueClientIds` | `?(int[])` | Query, Optional | The Unique IDs of the clients to query. Note that UniqueClientIds collection takes precedence over ClientIds collection. |
| `requestUseActivateDate` | `?bool` | Query, Optional | When this flag is set to `true`, the date filtering will use activate date to filter the pricing options.<br>When this flag is set to `false`, the date filtering will use purchase date to filter the pricing options.<br>Default: **false** |
| `requestVisitCount` | `?int` | Query, Optional | A filter on the minimum number of visits a service can pay for. |

## Response Type

[`GetClientServicesResponse`](../../doc/models/get-client-services-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$requestClassId = 206;

$requestClassScheduleID = [
    118,
    119
];

$requestClientAssociatedSitesOffset = 146;

$requestClientId = 'request.clientId2';

$requestClientIds = [
    'request.clientIds9',
    'request.clientIds0',
    'request.clientIds1'
];

$requestCrossRegionalLookup = false;

$requestEndDate = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');

$requestExcludeInactiveSites = false;

$requestIgnoreCrossRegionalSiteLimit = false;

$requestLimit = 62;

$requestLocationIds = [
    192
];

$requestOffset = 100;

$requestProgramIds = [
    91,
    92,
    93
];

$requestSessionTypeId = 100;

$requestShowActiveOnly = false;

$requestStartDate = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');

$requestUniqueClientId = 226;

$requestUniqueClientIds = [
    219,
    220
];

$requestUseActivateDate = false;

$requestVisitCount = 18;

$result = $clientController->getClientServices(
    $version,
    $siteId,
    $authorization,
    $requestClassId,
    $requestClassScheduleID,
    $requestClientAssociatedSitesOffset,
    $requestClientId,
    $requestClientIds,
    $requestCrossRegionalLookup,
    $requestEndDate,
    $requestExcludeInactiveSites,
    $requestIgnoreCrossRegionalSiteLimit,
    $requestLimit,
    $requestLocationIds,
    $requestOffset,
    $requestProgramIds,
    $requestSessionTypeId,
    $requestShowActiveOnly,
    $requestStartDate,
    $requestUniqueClientId,
    $requestUniqueClientIds,
    $requestUseActivateDate,
    $requestVisitCount
);
```


# Get Client Visits

Gets the Client Visits for a specific client.

```php
function getClientVisits(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?int $requestClientAssociatedSitesOffset = null,
    ?string $requestClientId = null,
    ?bool $requestCrossRegionalLookup = null,
    ?\DateTime $requestEndDate = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?\DateTime $requestStartDate = null,
    ?int $requestUniqueClientId = null,
    ?bool $requestUnpaidsOnly = null
): GetClientVisitsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestClientAssociatedSitesOffset` | `?int` | Query, Optional | The number of sites to skip when returning the site associated with a client. |
| `requestClientId` | `?string` | Query, Optional | The ID of the requested client. |
| `requestCrossRegionalLookup` | `?bool` | Query, Optional | When `true`, indicates that past and scheduled client visits across all sites in the region are returned.<br /><br>When `false`, indicates that only visits at the current site are returned. |
| `requestEndDate` | `?DateTime` | Query, Optional | The date past which class visits are not returned.<br>Default: **today's date** |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestStartDate` | `?DateTime` | Query, Optional | The date before which class visits are not returned.<br>Default: **the end date** |
| `requestUniqueClientId` | `?int` | Query, Optional | The unique ID of the requested client.<br>Note: you need to provide the 'UniqueClientId' OR the 'ClientId'. If both are provided, the 'UniqueClientId' takes precedence. |
| `requestUnpaidsOnly` | `?bool` | Query, Optional | When `true`, indicates that only visits that have not been paid for are returned.<br /><br>When `false`, indicates that all visits are returned, regardless of whether they have been paid for.<br /><br>Default: **false** |

## Response Type

[`GetClientVisitsResponse`](../../doc/models/get-client-visits-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$requestClientAssociatedSitesOffset = 146;

$requestClientId = 'request.clientId2';

$requestCrossRegionalLookup = false;

$requestEndDate = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');

$requestLimit = 62;

$requestOffset = 100;

$requestStartDate = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');

$requestUniqueClientId = 226;

$requestUnpaidsOnly = false;

$result = $clientController->getClientVisits(
    $version,
    $siteId,
    $authorization,
    $requestClientAssociatedSitesOffset,
    $requestClientId,
    $requestCrossRegionalLookup,
    $requestEndDate,
    $requestLimit,
    $requestOffset,
    $requestStartDate,
    $requestUniqueClientId,
    $requestUnpaidsOnly
);
```


# Get Contact Logs

This endpoint contains a variety of filters that can return not just all contact logs, but also system-generated contact logs, contact logs assigned to specific staff members, and contact logs of specific types or subtypes.

```php
function getContactLogs(
    string $version,
    string $requestClientId,
    string $siteId,
    ?string $authorization = null,
    ?\DateTime $requestEndDate = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?bool $requestShowSystemGenerated = null,
    ?array $requestStaffIds = null,
    ?\DateTime $requestStartDate = null,
    ?array $requestSubtypeIds = null,
    ?array $requestTypeIds = null
): GetContactLogsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientId` | `string` | Query, Required | The ID of the client whose contact logs are being requested. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestEndDate` | `?DateTime` | Query, Optional | Filters the results to contact logs created before this date.<br /><br>Default: **the start date** |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestShowSystemGenerated` | `?bool` | Query, Optional | When `true`, system-generated contact logs are returned in the results.<br /><br>Default: **false** |
| `requestStaffIds` | `?(int[])` | Query, Optional | Filters the results to return contact logs assigned to one or more staff IDs. |
| `requestStartDate` | `?DateTime` | Query, Optional | Filters the results to contact logs created on or after this date.<br /><br>Default: **the current date** |
| `requestSubtypeIds` | `?(int[])` | Query, Optional | Filters the results to contact logs assigned one or more of these subtype IDs. |
| `requestTypeIds` | `?(int[])` | Query, Optional | Filters the results to contact logs assigned one or more of these type IDs. |

## Response Type

[`GetContactLogsResponse`](../../doc/models/get-contact-logs-response.md)

## Example Usage

```php
$version = '6';

$requestClientId = 'request.clientId2';

$siteId = '-99';

$authorization = 'authorization6';

$requestEndDate = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');

$requestLimit = 62;

$requestOffset = 100;

$requestShowSystemGenerated = false;

$requestStaffIds = [
    23,
    24,
    25
];

$requestStartDate = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');

$requestSubtypeIds = [
    141
];

$requestTypeIds = [
    63
];

$result = $clientController->getContactLogs(
    $version,
    $requestClientId,
    $siteId,
    $authorization,
    $requestEndDate,
    $requestLimit,
    $requestOffset,
    $requestShowSystemGenerated,
    $requestStaffIds,
    $requestStartDate,
    $requestSubtypeIds,
    $requestTypeIds
);
```


# Get Contact Log Types

This endpoint contains a variety of filters that can return not just all contact logs, but also system-generated contact logs, contact logs assigned to specific staff members, and contact logs of specific types or subtypes.

```php
function getContactLogTypes(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?int $requestContactLogTypeId = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null
): GetContactLogTypesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestContactLogTypeId` | `?int` | Query, Optional | The requested ContactLogType ID.<br>Default: **all** IDs that the authenticated user’s access level allows. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`GetContactLogTypesResponse`](../../doc/models/get-contact-log-types-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$requestContactLogTypeId = 24;

$requestLimit = 62;

$requestOffset = 100;

$result = $clientController->getContactLogTypes(
    $version,
    $siteId,
    $authorization,
    $requestContactLogTypeId,
    $requestLimit,
    $requestOffset
);
```


# Get Cross Regional Client Associations

Returns a list of sites that a particular client ID (also referred to as an RSSID) or a client email address is associated with in a cross-regional organization. Either the `ClientID` or `Email` parameter is required. If both are provided, the `ClientID` is used.

Use this endpoint to retrieve information for other Public API endpoints, about the same client at multiple sites within an organization. To use this endpoint, your developer account must have been granted permission to the site's entire organization.

Note that this endpoint does not work on the Developer Sandbox site, as it is not set up for cross-regional use cases.

```php
function getCrossRegionalClientAssociations(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?string $requestClientId = null,
    ?string $requestEmail = null,
    ?bool $requestExcludeInactiveSites = null,
    ?string $requestFirstName = null,
    ?string $requestLastName = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?int $requestUniqueClientId = null,
    ?bool $requestV2 = null
): GetCrossRegionalClientAssociationsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestClientId` | `?string` | Query, Optional | Looks up the cross regional associations by the client’s ID. |
| `requestEmail` | `?string` | Query, Optional | Looks up the cross regional associations by the client’s email address. |
| `requestExcludeInactiveSites` | `?bool` | Query, Optional | Used to exclude inactive and deleted sites from the results.<br>When this flag is set to `true`, client profiles associated with inactive and deleted sites are not getting returned.<br>When this flag is set to `false`,client profiles associated with inactive and deleted sites are getting returned.<br>Default: **true** |
| `requestFirstName` | `?string` | Query, Optional | First name (used for email queries) |
| `requestLastName` | `?string` | Query, Optional | Last name (used for email queries) |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestUniqueClientId` | `?int` | Query, Optional | Looks up the cross regional associations by the unique client’s ID.<br>Note: you need to provide the 'UniqueClientId' OR the 'ClientId' OR the 'Email'.<br>'UniqueClientId' takes precedence when provided. If not, but both 'ClientId' and 'Email' are provided, 'ClientId' is used by default. |
| `requestV2` | `?bool` | Query, Optional | Use newer method |

## Response Type

[`GetCrossRegionalClientAssociationsResponse`](../../doc/models/get-cross-regional-client-associations-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$requestClientId = 'request.clientId2';

$requestEmail = 'request.email4';

$requestExcludeInactiveSites = false;

$requestFirstName = 'request.firstName8';

$requestLastName = 'request.lastName8';

$requestLimit = 62;

$requestOffset = 100;

$requestUniqueClientId = 226;

$requestV2 = false;

$result = $clientController->getCrossRegionalClientAssociations(
    $version,
    $siteId,
    $authorization,
    $requestClientId,
    $requestEmail,
    $requestExcludeInactiveSites,
    $requestFirstName,
    $requestLastName,
    $requestLimit,
    $requestOffset,
    $requestUniqueClientId,
    $requestV2
);
```


# Get Custom Client Fields

Get a site's configured custom client fields.

```php
function getCustomClientFields(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null
): GetCustomClientFieldsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`GetCustomClientFieldsResponse`](../../doc/models/get-custom-client-fields-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$requestLimit = 62;

$requestOffset = 100;

$result = $clientController->getCustomClientFields(
    $version,
    $siteId,
    $authorization,
    $requestLimit,
    $requestOffset
);
```


# Get Required Client Fields

Gets the list of fields that a new client has to fill out in business mode, specifically for the sign-up process. `AddClient` and `UpdateClient` validate against these fields.

This endpoint has no query parameters.

```php
function getRequiredClientFields(
    string $version,
    string $siteId,
    ?string $authorization = null
): GetRequiredClientFieldsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`GetRequiredClientFieldsResponse`](../../doc/models/get-required-client-fields-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$result = $clientController->getRequiredClientFields(
    $version,
    $siteId,
    $authorization
);
```


# Add Arrival

Marks a client as arrived for a specified location. A staff user token must be included with staff assigned the LaunchSignInScreen permission.

When used on a site that is part of a region, the following additional logic will apply:

* When a client exists within the region but not at the studio where the arrival is being logged, a local client record will be automatically created.
* If the local client does not have an applicable local membership or pricing option, a membership or pricing option will be automatically used if it exists elsewhere within the region.

```php
function addArrival(
    string $version,
    AddArrivalRequest $request,
    string $siteId,
    ?string $authorization = null
): AddArrivalResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`AddArrivalRequest`](../../doc/models/add-arrival-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`AddArrivalResponse`](../../doc/models/add-arrival-response.md)

## Example Usage

```php
$version = '6';

$request = AddArrivalRequestBuilder::init(
    'ClientId0',
    238
)
    ->arrivalTypeId(120)
    ->leadChannelId(216)
    ->test(false)
    ->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $clientController->addArrival(
    $version,
    $request,
    $siteId,
    $authorization
);
```


# Add Client

Starting the week of May 11th, 2020 all versions of the Public API will no longer allow duplicate clients to be created. This applies to both adding a client and updating a client record. A duplicate client is created when two profiles have the same first name, last name and email.<br />
Creates a new client record at the specified business.Passing a User Token as Authorization will create a client and respect Business Mode required fields.Omitting the token will create a client and respect Consumer Mode required fi elds. To make sure you are collecting all required pieces of information, first run GetRequired ClientFields.<br />
If you have purchased an Ultimate tier then this endpoint will automatically start showing new opportunity on Sales Pipeline.

```php
function addClient(
    string $version,
    AddClientRequest $request,
    string $siteId,
    ?string $authorization = null
): AddClientResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`AddClientRequest`](../../doc/models/add-client-request.md) | Body, Required | The `FirstName` and `LastName` parameters are always required in this request.<br>All other parameters are optional, but note that any of the optional parameters could be required by a particular business,<br>depending on how the business has configured the site settings. If `GetRequiredClientFields` returns `EmergContact` in the list of required fields,<br>then all emergency contact parameters are required, which includes `EmergencyContactInfoEmail`, `EmergencyContactInfoName`, `EmergencyContactInfoPhone`, and `EmergencyContactInfoRelationship`. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`AddClientResponse`](../../doc/models/add-client-response.md)

## Example Usage

```php
$version = '6';

$request = AddClientRequestBuilder::init(
    'FirstName8',
    'LastName8'
)
    ->accountBalance(60.74)
    ->action(Action1Enum::ADDED)
    ->active(false)
    ->addressLine1('AddressLine12')
    ->addressLine2('AddressLine26')
    ->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $clientController->addClient(
    $version,
    $request,
    $siteId,
    $authorization
);
```


# Add Client Direct Debit Info

This endpoint adds direct debit info to a client’s account. This endpoint requires staff user credentials.

```php
function addClientDirectDebitInfo(
    string $version,
    AddClientDirectDebitInfoRequest $request,
    string $siteId,
    ?string $authorization = null
): AddClientDirectDebitInfoResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`AddClientDirectDebitInfoRequest`](../../doc/models/add-client-direct-debit-info-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`AddClientDirectDebitInfoResponse`](../../doc/models/add-client-direct-debit-info-response.md)

## Example Usage

```php
$version = '6';

$request = AddClientDirectDebitInfoRequestBuilder::init()
    ->test(false)
    ->clientId('ClientId0')
    ->nameOnAccount('NameOnAccount0')
    ->routingNumber('RoutingNumber6')
    ->accountNumber('AccountNumber0')
    ->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $clientController->addClientDirectDebitInfo(
    $version,
    $request,
    $siteId,
    $authorization
);
```


# Add Formula Note

This endpoint adds a formula note for a specified client or specified client appointment. A staff user token must be included with staff assigned permission to view client profile or have both ViewAppointmentDetails and ModifyAppointment permissions.

```php
function addFormulaNote(
    string $version,
    AddFormulaNoteRequest $request,
    string $siteId,
    ?string $authorization = null
): FormulaNoteResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`AddFormulaNoteRequest`](../../doc/models/add-formula-note-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`FormulaNoteResponse`](../../doc/models/formula-note-response.md)

## Example Usage

```php
$version = '6';

$request = AddFormulaNoteRequestBuilder::init(
    'ClientId0',
    'Note6'
)
    ->appointmentId(246)
    ->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $clientController->addFormulaNote(
    $version,
    $request,
    $siteId,
    $authorization
);
```


# Add Contact Log

Add a contact log to a client's account.

```php
function addContactLog(
    string $version,
    AddContactLogRequest $request,
    string $siteId,
    ?string $authorization = null
): ContactLog
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`AddContactLogRequest`](../../doc/models/add-contact-log-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`ContactLog`](../../doc/models/contact-log.md)

## Example Usage

```php
$version = '6';

$request = AddContactLogRequestBuilder::init(
    'ClientId0',
    'ContactMethod0'
)
    ->assignedToStaffId(202)
    ->text('Text8')
    ->followupByDate(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
    ->contactName('ContactName6')
    ->isComplete(false)
    ->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $clientController->addContactLog(
    $version,
    $request,
    $siteId,
    $authorization
);
```


# Merge Client

This endpoint helps to merge clients.

```php
function mergeClient(
    string $version,
    MergeClientsRequest $request,
    string $siteId,
    ?string $authorization = null
): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MergeClientsRequest`](../../doc/models/merge-clients-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`array`

## Example Usage

```php
$version = '6';

$request = MergeClientsRequestBuilder::init()
    ->sourceClientId(120)
    ->targetClientId(110)
    ->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $clientController->mergeClient(
    $version,
    $request,
    $siteId,
    $authorization
);
```


# Send Auto Email

This endpoint requires staff user credentials.

```php
function sendAutoEmail(
    string $version,
    SendAutoEmailRequest $request,
    string $siteId,
    ?string $authorization = null
): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`SendAutoEmailRequest`](../../doc/models/send-auto-email-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`array`

## Example Usage

```php
$version = '6';

$request = SendAutoEmailRequestBuilder::init(
    'ClientId0',
    'EmailType4'
)->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $clientController->sendAutoEmail(
    $version,
    $request,
    $siteId,
    $authorization
);
```


# Send Password Reset Email

Send a password reset email to a client.

```php
function sendPasswordResetEmail(
    string $version,
    SendPasswordResetEmailRequest $request,
    string $siteId,
    ?string $authorization = null
): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`SendPasswordResetEmailRequest`](../../doc/models/send-password-reset-email-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`array`

## Example Usage

```php
$version = '6';

$request = SendPasswordResetEmailRequestBuilder::init(
    'UserEmail2',
    'UserFirstName2',
    'UserLastName8'
)->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $clientController->sendPasswordResetEmail(
    $version,
    $request,
    $siteId,
    $authorization
);
```


# Suspend Contract

Suspend client contract

```php
function suspendContract(
    string $version,
    SuspendContractRequest $request,
    string $siteId,
    ?string $authorization = null
): SuspendContractResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`SuspendContractRequest`](../../doc/models/suspend-contract-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`SuspendContractResponse`](../../doc/models/suspend-contract-response.md)

## Example Usage

```php
$version = '6';

$request = SuspendContractRequestBuilder::init(
    'ClientId0',
    118
)
    ->suspensionType('SuspensionType0')
    ->suspensionStart(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
    ->duration(224)
    ->durationUnit(102)
    ->openEnded(false)
    ->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $clientController->suspendContract(
    $version,
    $request,
    $siteId,
    $authorization
);
```


# Terminate Contract

This endpoint terminates a client contract. This endpoint requires staff user credentials with TerminateClientContract permission.

```php
function terminateContract(
    string $version,
    TerminateContractRequest $request,
    string $siteId,
    ?string $authorization = null
): TerminateContractResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`TerminateContractRequest`](../../doc/models/terminate-contract-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`TerminateContractResponse`](../../doc/models/terminate-contract-response.md)

## Example Usage

```php
$version = '6';

$request = TerminateContractRequestBuilder::init(
    'ClientId0',
    118,
    DateTimeHelper::fromRfc3339DateTimeRequired('2016-03-13T12:52:32.123Z')
)
    ->terminationCode('TerminationCode0')
    ->terminationComments('TerminationComments8')
    ->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $clientController->terminateContract(
    $version,
    $request,
    $siteId,
    $authorization
);
```


# Update Client

Starting the week of May 11th, 2020 all versions of the Public API will no longer allow duplicate clients to be created. This applies to both adding a client and updating a client record. A duplicate client is created when two profiles have the same first name, last name and email.<br />
Updates an existing client for a specific subscriber.Passing a User Token as Authorization respects Business Mode required fields.Omitting the token respects Consumer Mode required fields.To make sure you are collecting all required pieces of information, first run GetRequiredClientFields.
<br />.
Use this endpoint as follows:

* If you need to update the `ReferredBy` parameter, use this endpoint after calling `GET ClientReferralTypes`.
* When updating a client's home location, use after calling `GET Locations`.
* If you are updating a client's stored credit card, use after calling `GET AcceptedCardTypes` so that you can make sure the card is a type that is accepted at the subscriber.
* If this endpoint is used on a cross-regional site, passing in a client's RSSID and email address creates a cross-regional link. This means that the client is created in cross-regional sites where the client does not exist and `GET CrossRegionalClientAssociations` returns all appropriate cross-regional sites.
* When `CrossRegionalUpdate` is omitted or set to `true`, the client's updated information is propagated to all of the region's sites. If `CrossRegionalUpdate` is set to `false`, only the local client is updated.
* Important: Starting in June 2025, the fields RSSID, Prefix, Name, Email, Birthday, Phone, and Address will automatically update cross-regionally when changed, regardless of the CrossRegionalUpdate setting. The update is rolling out on a per customer basis and is expected to complete to all customers by September 2025.

Note that the following items cannot be updated for a cross-regional client:

* `ClientIndexes`
* `ClientRelationships`
* `CustomClientFields`
* `SalesReps`
* `SendAccountEmails`
* `SendAccountTexts`
* `SendPromotionalEmails`
* `SendPromotionalTexts`
* `SendScheduleEmails`
* `SendScheduleTexts`
* `Gender` (for site custom values)

Custom client Gender options can only be created with non-cross-regional requests.

If you have purchased an Ultimate tier then this endpoint will automatically start showing a new opportunity on Sales Pipeline.It will create a new opportunity if the current request modify the contact as follows::

* You need to update the `IsProspect` parameter, to `true`.
* You need to update the `ProspectStage`.`Description parameter`, to `New Lead`.<br />

Updates made to any inactive clients will automatically reactivate the client unless the `Acive` property is explicitly set to `false` in the request body.

```php
function updateClient(
    string $version,
    UpdateClientRequest $request,
    string $siteId,
    ?string $authorization = null
): UpdateClientResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`UpdateClientRequest`](../../doc/models/update-client-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`UpdateClientResponse`](../../doc/models/update-client-response.md)

## Example Usage

```php
$version = '6';

$request = UpdateClientRequestBuilder::init(
    ClientWithSuspensionInfoBuilder::init()
        ->suspensionInfo(
            ClientSuspensionInfoBuilder::init()
                ->bookingSuspended(false)
                ->suspensionStartDate('SuspensionStartDate8')
                ->suspensionEndDate('SuspensionEndDate2')
                ->build()
        )
        ->appointmentGenderPreference(AppointmentGenderPreference1Enum::NONE)
        ->birthDate(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
        ->country('Country8')
        ->creationDate(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
        ->build()
)
    ->test(false)
    ->crossRegionalUpdate(false)
    ->newId('NewId2')
    ->leadChannelId(216)
    ->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $clientController->updateClient(
    $version,
    $request,
    $siteId,
    $authorization
);
```


# Update Client Contract Autopays

This endpoint can be used to update the amount and/or the item of a client’s autopay schedule.

```php
function updateClientContractAutopays(
    string $version,
    UpdateClientContractAutopaysRequest $request,
    string $siteId,
    ?string $authorization = null
): Contract
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`UpdateClientContractAutopaysRequest`](../../doc/models/update-client-contract-autopays-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Contract`](../../doc/models/contract.md)

## Example Usage

```php
$version = '6';

$request = UpdateClientContractAutopaysRequestBuilder::init()
    ->clientContractId(118)
    ->autopayStartDate(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
    ->autopayEndDate(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
    ->productId(136)
    ->replaceWithProductId(56)
    ->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $clientController->updateClientContractAutopays(
    $version,
    $request,
    $siteId,
    $authorization
);
```


# Update Client Service

Updates the active date and/or expiration date of a client pricing option. This request requires staff user credentials. If the active date is modified, the expiration date is also modified accordingly. If the expiration date is modified, the active date is unchanged.

```php
function updateClientService(
    string $version,
    UpdateClientServiceRequest $request,
    string $siteId,
    ?string $authorization = null
): UpdateClientServiceResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`UpdateClientServiceRequest`](../../doc/models/update-client-service-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`UpdateClientServiceResponse`](../../doc/models/update-client-service-response.md)

## Example Usage

```php
$version = '6';

$request = UpdateClientServiceRequestBuilder::init(
    130
)
    ->activeDate(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
    ->expirationDate(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
    ->count(242)
    ->test(false)
    ->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $clientController->updateClientService(
    $version,
    $request,
    $siteId,
    $authorization
);
```


# Update Client Visit

Updates the status of the specified visit.

```php
function updateClientVisit(
    string $version,
    UpdateClientVisitRequest $request,
    string $siteId,
    ?string $authorization = null
): UpdateClientVisitResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`UpdateClientVisitRequest`](../../doc/models/update-client-visit-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`UpdateClientVisitResponse`](../../doc/models/update-client-visit-response.md)

## Example Usage

```php
$version = '6';

$request = UpdateClientVisitRequestBuilder::init(
    92
)
    ->makeup(false)
    ->signedIn(false)
    ->clientServiceId(244)
    ->execute('Execute2')
    ->test(false)
    ->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $clientController->updateClientVisit(
    $version,
    $request,
    $siteId,
    $authorization
);
```


# Update Contact Log

Update a contact log on a client's account.

```php
function updateContactLog(
    string $version,
    UpdateContactLogRequest $request,
    string $siteId,
    ?string $authorization = null
): ContactLog
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`UpdateContactLogRequest`](../../doc/models/update-contact-log-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`ContactLog`](../../doc/models/contact-log.md)

## Example Usage

```php
$version = '6';

$request = UpdateContactLogRequestBuilder::init()
    ->id(178)
    ->test(false)
    ->assignedToStaffId(202)
    ->text('Text8')
    ->contactName('ContactName6')
    ->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $clientController->updateContactLog(
    $version,
    $request,
    $siteId,
    $authorization
);
```


# Upload Client Document

Uploads a document file for a specific client. Returns a string representation of the image byte array. The maximum size file that can be uploaded is **4MB**.

```php
function uploadClientDocument(
    string $version,
    UploadClientDocumentRequest $request,
    string $siteId,
    ?string $authorization = null
): UploadClientDocumentResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`UploadClientDocumentRequest`](../../doc/models/upload-client-document-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`UploadClientDocumentResponse`](../../doc/models/upload-client-document-response.md)

## Example Usage

```php
$version = '6';

$request = UploadClientDocumentRequestBuilder::init(
    'ClientId0',
    ClientDocumentBuilder::init(
        'FileName6',
        'MediaType6',
        'Buffer8'
    )->build()
)->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $clientController->uploadClientDocument(
    $version,
    $request,
    $siteId,
    $authorization
);
```


# Upload Client Photo

Uploads a client’s profile photo. The maximum file size is 4 MB and acceptable file types are:

* bmp
* jpeg
* gif
* tiff
* png

```php
function uploadClientPhoto(
    string $version,
    UploadClientPhotoRequest $request,
    string $siteId,
    ?string $authorization = null
): UploadClientPhotoResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`UploadClientPhotoRequest`](../../doc/models/upload-client-photo-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`UploadClientPhotoResponse`](../../doc/models/upload-client-photo-response.md)

## Example Usage

```php
$version = '6';

$request = UploadClientPhotoRequestBuilder::init(
    'Bytes6',
    'ClientId0'
)->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $clientController->uploadClientPhoto(
    $version,
    $request,
    $siteId,
    $authorization
);
```


# Delete Client Formula Note

This endpoint deletes an existing formula note. A staff user token must be included with staff assigned permission to view client profile or have both ViewAppointmentDetails and ModifyAppointment permissions.

```php
function deleteClientFormulaNote(
    string $version,
    string $requestClientId,
    int $requestFormulaNoteId,
    string $siteId,
    ?string $authorization = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientId` | `string` | Query, Required | The client ID of the client whose formula note needs to be deleted. |
| `requestFormulaNoteId` | `int` | Query, Required | The formula note ID for the note to be deleted. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |

## Response Type

`void`

## Example Usage

```php
$version = '6';

$requestClientId = 'request.clientId2';

$requestFormulaNoteId = 72;

$siteId = '-99';

$authorization = 'authorization6';

$requestLimit = 62;

$requestOffset = 100;

$clientController->deleteClientFormulaNote(
    $version,
    $requestClientId,
    $requestFormulaNoteId,
    $siteId,
    $authorization,
    $requestLimit,
    $requestOffset
);
```


# Delete Contact Log

This endpoint deletes contactlog of client. This endpoint requires staff user credentials.

```php
function deleteContactLog(
    string $version,
    string $requestClientId,
    int $requestContactLogId,
    string $siteId,
    ?string $authorization = null,
    ?bool $requestTest = null
): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientId` | `string` | Query, Required | The client ID of the client whose Contact Log is being deleted. |
| `requestContactLogId` | `int` | Query, Required | The Contact Log ID. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestTest` | `?bool` | Query, Optional | When `true`, indicates that this is a test request and no data is inserted into the subscriber’s database.<br>When `false`, the database is updated. |

## Response Type

`array`

## Example Usage

```php
$version = '6';

$requestClientId = 'request.clientId2';

$requestContactLogId = 90;

$siteId = '-99';

$authorization = 'authorization6';

$requestTest = false;

$result = $clientController->deleteContactLog(
    $version,
    $requestClientId,
    $requestContactLogId,
    $siteId,
    $authorization,
    $requestTest
);
```

