# Site

```php
$siteController = $client->getSiteController();
```

## Class Name

`SiteController`

## Methods

* [Get Activation Code](../../doc/controllers/site.md#get-activation-code)
* [Get Categories](../../doc/controllers/site.md#get-categories)
* [Get Genders](../../doc/controllers/site.md#get-genders)
* [Get Liability Waiver](../../doc/controllers/site.md#get-liability-waiver)
* [Get Locations](../../doc/controllers/site.md#get-locations)
* [Get Memberships](../../doc/controllers/site.md#get-memberships)
* [Get Mobile Providers](../../doc/controllers/site.md#get-mobile-providers)
* [Get Payment Types](../../doc/controllers/site.md#get-payment-types)
* [Get Programs](../../doc/controllers/site.md#get-programs)
* [Get Promo Codes](../../doc/controllers/site.md#get-promo-codes)
* [Get Prospect Stages](../../doc/controllers/site.md#get-prospect-stages)
* [Get Relationships](../../doc/controllers/site.md#get-relationships)
* [Get Resource Availabilities](../../doc/controllers/site.md#get-resource-availabilities)
* [Get Resources](../../doc/controllers/site.md#get-resources)
* [Get Session Types](../../doc/controllers/site.md#get-session-types)
* [Get Sites](../../doc/controllers/site.md#get-sites)
* [Add Client Index](../../doc/controllers/site.md#add-client-index)
* [Add Promo Code](../../doc/controllers/site.md#add-promo-code)
* [Deactivate Promo Code](../../doc/controllers/site.md#deactivate-promo-code)
* [Update Client Index](../../doc/controllers/site.md#update-client-index)


# Get Activation Code

Before you can use this endpoint, MINDBODY must approve your developer account for live access. If you have finished testing in the sandbox and are ready to begin working with MINDBODY customers, log into your account and request to go live.

See [Accessing Business Data From MINDBODY](https://developers.mindbodyonline.com/PublicDocumentation/V6#accessing-business-data) for more information about the activation code and how to use it.

Once you are approved, this endpoint returns an activation code.This endpoint supports only one site per call.

```php
function getActivationCode(string $version, ?string $authorization = null): GetActivationCodeResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`GetActivationCodeResponse`](../../doc/models/get-activation-code-response.md)

## Example Usage

```php
$version = '6';

$authorization = 'authorization6';

$result = $siteController->getActivationCode(
    $version,
    $authorization
);
```


# Get Categories

Gets the categories.

```php
function getCategories(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?bool $requestActive = null,
    ?array $requestCategoryIds = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?bool $requestService = null,
    ?array $requestSubCategoryIds = null
): GetCategoriesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestActive` | `?bool` | Query, Optional | When `true`, the response only contains categories which are activated.<br>When `false`, only deactivated categories are returned.<br>Default: **All Categories** |
| `requestCategoryIds` | `?(int[])` | Query, Optional | When included, the response only contains details about the specified category Ids. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestService` | `?bool` | Query, Optional | When `true`, the response only contains details about Revenue Categories.<br>When `false`, only Product Revenue Categories are returned.<br>Default: **All Categories** |
| `requestSubCategoryIds` | `?(int[])` | Query, Optional | When included, the response only contains details about the specified subcategory Ids. |

## Response Type

[`GetCategoriesResponse`](../../doc/models/get-categories-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$requestActive = false;

$requestCategoryIds = [
    140,
    141
];

$requestLimit = 62;

$requestOffset = 100;

$requestService = false;

$requestSubCategoryIds = [
    173,
    174,
    175
];

$result = $siteController->getCategories(
    $version,
    $siteId,
    $authorization,
    $requestActive,
    $requestCategoryIds,
    $requestLimit,
    $requestOffset,
    $requestService,
    $requestSubCategoryIds
);
```


# Get Genders

The endpoint returns a list of configured client gender options for a site. Custom gender options are assignable to client genders only. Currently, custom values returned from this endpoint cannot be used as input for other endpoints to specify the genders of staff or client preferences.

```php
function getGenders(string $version, string $siteId, ?string $authorization = null): GetGendersResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`GetGendersResponse`](../../doc/models/get-genders-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$result = $siteController->getGenders(
    $version,
    $siteId,
    $authorization
);
```


# Get Liability Waiver

Gets Liability Waiver content at the specified business.
This endpoint requires staff user credentials.

```php
function getLiabilityWaiver(
    string $version,
    string $siteId,
    ?string $authorization = null
): GetLiabilityWaiverResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`GetLiabilityWaiverResponse`](../../doc/models/get-liability-waiver-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$result = $siteController->getLiabilityWaiver(
    $version,
    $siteId,
    $authorization
);
```


# Get Locations

Get locations for a site.

```php
function getLocations(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null
): GetLocationsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`GetLocationsResponse`](../../doc/models/get-locations-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$requestLimit = 62;

$requestOffset = 100;

$result = $siteController->getLocations(
    $version,
    $siteId,
    $authorization,
    $requestLimit,
    $requestOffset
);
```


# Get Memberships

Get the memberships at a site.

```php
function getMemberships(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?array $requestMembershipIds = null
): GetMembershipsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestMembershipIds` | `?(int[])` | Query, Optional | The requested membership IDs.<br /><br>Default: **all** IDs that the authenticated user’s access level allows. |

## Response Type

[`GetMembershipsResponse`](../../doc/models/get-memberships-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$requestMembershipIds = [
    213,
    214
];

$result = $siteController->getMemberships(
    $version,
    $siteId,
    $authorization,
    $requestMembershipIds
);
```


# Get Mobile Providers

Get the list of mobile providers that are supported by the business.

```php
function getMobileProviders(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?bool $requestActive = null
): GetMobileProvidersResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestActive` | `?bool` | Query, Optional | When `true`, the response only contains mobile providers which are activated.<br>When `false`, only deactivated mobile providers are returned.<br>Default: **All Mobile Providers** |

## Response Type

[`GetMobileProvidersResponse`](../../doc/models/get-mobile-providers-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$requestActive = false;

$result = $siteController->getMobileProviders(
    $version,
    $siteId,
    $authorization,
    $requestActive
);
```


# Get Payment Types

Get payment types for a site.

```php
function getPaymentTypes(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?bool $requestActive = null
): GetPaymentTypesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestActive` | `?bool` | Query, Optional | When `true`, the response only contains payment types which are activated.<br>When `false`, only deactivated payment types are returned.<br>Default: **All Payment Types** |

## Response Type

[`GetPaymentTypesResponse`](../../doc/models/get-payment-types-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$requestActive = false;

$result = $siteController->getPaymentTypes(
    $version,
    $siteId,
    $authorization,
    $requestActive
);
```


# Get Programs

Get service categories offered at a site.

```php
function getPrograms(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?bool $requestOnlineOnly = null,
    ?array $requestProgramIds = null,
    ?string $requestScheduleType = null
): GetProgramsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestOnlineOnly` | `?bool` | Query, Optional | If `true`, filters results to show only those programs that are shown online.<br /><br>If `false`, all programs are returned.<br /><br>Default: **false** |
| `requestProgramIds` | `?(int[])` | Query, Optional | Program Ids to filter for |
| `requestScheduleType` | [`?string(RequestScheduleTypeEnum)`](../../doc/models/request-schedule-type-enum.md) | Query, Optional | A schedule type used to filter the returned results. Possible values are:<br><br>* All<br>* Class<br>* Enrollment<br>* Appointment<br>* Resource<br>* Media<br>* Arrival |

## Response Type

[`GetProgramsResponse`](../../doc/models/get-programs-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$requestLimit = 62;

$requestOffset = 100;

$requestOnlineOnly = false;

$requestProgramIds = [
    91,
    92,
    93
];

$requestScheduleType = RequestScheduleTypeEnum::RESOURCE;

$result = $siteController->getPrograms(
    $version,
    $siteId,
    $authorization,
    $requestLimit,
    $requestOffset,
    $requestOnlineOnly,
    $requestProgramIds,
    $requestScheduleType
);
```


# Get Promo Codes

Gets a list of promocodes at the specified business. This endpoint requires staff user credentials.
This staff member should have enabled the Set up promotions / **Semester discounts** staff permission.

```php
function getPromoCodes(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?bool $requestActiveOnly = null,
    ?\DateTime $requestEndDate = null,
    ?\DateTime $requestLastModifiedDate = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?bool $requestOnlineOnly = null,
    ?\DateTime $requestStartDate = null
): GetPromoCodesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestActiveOnly` | `?bool` | Query, Optional | If true, filters results to show only promocodes that are active. If **false**, all promocodes are returned.<br>Default: **true** |
| `requestEndDate` | `?DateTime` | Query, Optional | Filters results to promocodes that were activated before this date. |
| `requestLastModifiedDate` | `?DateTime` | Query, Optional | Filters results to promocodes that were modified on or after this date. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestOnlineOnly` | `?bool` | Query, Optional | If `true`, filters results to show only promocodes that can be used for online sale.<br>If `false`, all promocodes are returned.<br>Default: **false** |
| `requestStartDate` | `?DateTime` | Query, Optional | Filters results to promocodes that were activated after this date. |

## Response Type

[`GetPromoCodesResponse`](../../doc/models/get-promo-codes-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$requestActiveOnly = false;

$requestEndDate = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');

$requestLastModifiedDate = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');

$requestLimit = 62;

$requestOffset = 100;

$requestOnlineOnly = false;

$requestStartDate = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');

$result = $siteController->getPromoCodes(
    $version,
    $siteId,
    $authorization,
    $requestActiveOnly,
    $requestEndDate,
    $requestLastModifiedDate,
    $requestLimit,
    $requestOffset,
    $requestOnlineOnly,
    $requestStartDate
);
```


# Get Prospect Stages

Get the list of prospect stages that represent the prospect stage options for prospective clients.

```php
function getProspectStages(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?bool $requestActive = null
): GetProspectStagesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestActive` | `?bool` | Query, Optional | When `true`, the response only contains prospect stages which are activated.<br>When `false`, only deactivated prospect stages are returned.<br>Default: **All Prospect Stages** |

## Response Type

[`GetProspectStagesResponse`](../../doc/models/get-prospect-stages-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$requestActive = false;

$result = $siteController->getProspectStages(
    $version,
    $siteId,
    $authorization,
    $requestActive
);
```


# Get Relationships

This endpoint retrieves the business site relationships.

```php
function getRelationships(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?bool $requestActive = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null
): GetRelationshipsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestActive` | `?bool` | Query, Optional | When `true`, the response only contains relationships which are activated.<br>When `false`, only deactivated relationships are returned.<br>Default: **All Relationships** |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`GetRelationshipsResponse`](../../doc/models/get-relationships-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$requestActive = false;

$requestLimit = 62;

$requestOffset = 100;

$result = $siteController->getRelationships(
    $version,
    $siteId,
    $authorization,
    $requestActive,
    $requestLimit,
    $requestOffset
);
```


# Get Resource Availabilities

Get resource availabilities used at a site.

```php
function getResourceAvailabilities(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?\DateTime $requestEndDate = null,
    ?int $requestLimit = null,
    ?array $requestLocationIds = null,
    ?int $requestOffset = null,
    ?array $requestProgramIds = null,
    ?array $requestResourceIds = null,
    ?array $requestScheduleTypes = null,
    ?\DateTime $requestStartDate = null
): GetResourcesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestEndDate` | `?DateTime` | Query, Optional | End date. If default, StartDate is used. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationIds` | `?(int[])` | Query, Optional | Filter by location ids (optional) |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestProgramIds` | `?(int[])` | Query, Optional | Filter by program ids (optional) |
| `requestResourceIds` | `?(int[])` | Query, Optional | Filter on resourceIds |
| `requestScheduleTypes` | [`?(string(RequestScheduleTypeEnum)[])`](../../doc/models/request-schedule-type-enum.md) | Query, Optional | Filter by schedule types (optional) |
| `requestStartDate` | `?DateTime` | Query, Optional | Start time |

## Response Type

[`GetResourcesResponse`](../../doc/models/get-resources-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$requestEndDate = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');

$requestLimit = 62;

$requestLocationIds = [
    192
];

$requestOffset = 100;

$requestProgramIds = [
    91,
    92,
    93
];

$requestResourceIds = [
    62
];

$requestScheduleTypes = [
    RequestScheduleTypeEnum::APPOINTMENT,
    RequestScheduleTypeEnum::RESOURCE,
    RequestScheduleTypeEnum::MEDIA
];

$requestStartDate = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');

$result = $siteController->getResourceAvailabilities(
    $version,
    $siteId,
    $authorization,
    $requestEndDate,
    $requestLimit,
    $requestLocationIds,
    $requestOffset,
    $requestProgramIds,
    $requestResourceIds,
    $requestScheduleTypes,
    $requestStartDate
);
```


# Get Resources

Get resources used at a site.

```php
function getResources(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?bool $requestIncludeInactive = null,
    ?int $requestLimit = null,
    ?array $requestLocationIds = null,
    ?int $requestOffset = null,
    ?array $requestProgramIds = null,
    ?array $requestResourceIds = null,
    ?array $requestScheduleTypes = null
): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestIncludeInactive` | `?bool` | Query, Optional | Enable to include inactive |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationIds` | `?(int[])` | Query, Optional | Filter by location ids (optional) |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestProgramIds` | `?(int[])` | Query, Optional | Filter by program ids (optional) |
| `requestResourceIds` | `?(int[])` | Query, Optional | Filter on resourceIds |
| `requestScheduleTypes` | [`?(string(RequestScheduleTypeEnum)[])`](../../doc/models/request-schedule-type-enum.md) | Query, Optional | Filter by schedule types (optional) |

## Response Type

`array`

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$requestIncludeInactive = false;

$requestLimit = 62;

$requestLocationIds = [
    192
];

$requestOffset = 100;

$requestProgramIds = [
    91,
    92,
    93
];

$requestResourceIds = [
    62
];

$requestScheduleTypes = [
    RequestScheduleTypeEnum::APPOINTMENT,
    RequestScheduleTypeEnum::RESOURCE,
    RequestScheduleTypeEnum::MEDIA
];

$result = $siteController->getResources(
    $version,
    $siteId,
    $authorization,
    $requestIncludeInactive,
    $requestLimit,
    $requestLocationIds,
    $requestOffset,
    $requestProgramIds,
    $requestResourceIds,
    $requestScheduleTypes
);
```


# Get Session Types

Get the session types used at a site.

```php
function getSessionTypes(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?bool $requestOnlineOnly = null,
    ?array $requestProgramIDs = null
): GetSessionTypesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestOnlineOnly` | `?bool` | Query, Optional | When `true`, indicates that only the session types that can be booked online should be returned.<br /><br>Default: **false** |
| `requestProgramIDs` | `?(int[])` | Query, Optional | Filters results to session types that belong to one of the given program IDs. If omitted, all program IDs return. |

## Response Type

[`GetSessionTypesResponse`](../../doc/models/get-session-types-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$requestLimit = 62;

$requestOffset = 100;

$requestOnlineOnly = false;

$requestProgramIDs = [
    52,
    53,
    54
];

$result = $siteController->getSessionTypes(
    $version,
    $siteId,
    $authorization,
    $requestLimit,
    $requestOffset,
    $requestOnlineOnly,
    $requestProgramIDs
);
```


# Get Sites

Gets a list of sites that the developer has permission to view.

* Passing in no `SiteIds` returns all sites that the developer has access to.
* Passing in one `SiteIds` returns more detailed information about the specified site.

```php
function getSites(
    string $version,
    ?string $authorization = null,
    ?bool $requestIncludeLeadChannels = null,
    ?bool $requestIncludePerStaffPricing = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?array $requestSiteIds = null
): GetSitesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestIncludeLeadChannels` | `?bool` | Query, Optional | This is an optional parameter to get lead channels for a Site. |
| `requestIncludePerStaffPricing` | `?bool` | Query, Optional | Include whether or not studios have per staff pricing enabled. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestSiteIds` | `?(int[])` | Query, Optional | List of the requested site IDs. When omitted, returns all sites that the source has access to. |

## Response Type

[`GetSitesResponse`](../../doc/models/get-sites-response.md)

## Example Usage

```php
$version = '6';

$authorization = 'authorization6';

$requestIncludeLeadChannels = false;

$requestIncludePerStaffPricing = false;

$requestLimit = 62;

$requestOffset = 100;

$requestSiteIds = [
    135,
    136
];

$result = $siteController->getSites(
    $version,
    $authorization,
    $requestIncludeLeadChannels,
    $requestIncludePerStaffPricing,
    $requestLimit,
    $requestOffset,
    $requestSiteIds
);
```


# Add Client Index

Creates a new client index record at the specified business.
This endpoint requires staff user credentials.

```php
function addClientIndex(
    string $version,
    AddSiteClientIndexRequest $request,
    string $siteId,
    ?string $authorization = null
): AddSiteClientIndexResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`AddSiteClientIndexRequest`](../../doc/models/add-site-client-index-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`AddSiteClientIndexResponse`](../../doc/models/add-site-client-index-response.md)

## Example Usage

```php
$version = '6';

$request = AddSiteClientIndexRequestBuilder::init(
    'ClientIndexName2'
)
    ->active(false)
    ->showOnNewClient(false)
    ->showOnEnrollmentRoster(false)
    ->editOnEnrollmentRoster(false)
    ->sortOrder(50)
    ->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $siteController->addClientIndex(
    $version,
    $request,
    $siteId,
    $authorization
);
```


# Add Promo Code

Creates a new promocode record at the specified business.
This endpoint requires staff user credentials. This staff memeber should have enabled the **Set up promotions / Semester discounts** staff permission.

```php
function addPromoCode(
    string $version,
    AddPromoCodeRequest $request,
    string $siteId,
    ?string $authorization = null
): AddPromoCodeResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`AddPromoCodeRequest`](../../doc/models/add-promo-code-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`AddPromoCodeResponse`](../../doc/models/add-promo-code-response.md)

## Example Usage

```php
$version = '6';

$request = AddPromoCodeRequestBuilder::init(
    'Code6',
    'Name6'
)
    ->active(false)
    ->discount(
        DiscountBuilder::init()
            ->type('Type6')
            ->amount(80.68)
            ->build()
    )
    ->activationDate(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
    ->expirationDate(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
    ->maxUses(192)
    ->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $siteController->addPromoCode(
    $version,
    $request,
    $siteId,
    $authorization
);
```


# Deactivate Promo Code

Deactivates an existing promocode record at the specified business.
This endpoint requires staff user credentials. This staff memeber should have enabled the **Set up promotions / Semester discounts** staff permission.

```php
function deactivatePromoCode(
    string $version,
    DeactivatePromoCodeRequest $request,
    string $siteId,
    ?string $authorization = null
): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`DeactivatePromoCodeRequest`](../../doc/models/deactivate-promo-code-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`array`

## Example Usage

```php
$version = '6';

$request = DeactivatePromoCodeRequestBuilder::init(
    42
)->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $siteController->deactivatePromoCode(
    $version,
    $request,
    $siteId,
    $authorization
);
```


# Update Client Index

Updates an exisitng client index record at the specified business.
This endpoint requires staff user credentials.

```php
function updateClientIndex(
    string $version,
    UpdateSiteClientIndexRequest $request,
    string $siteId,
    ?string $authorization = null
): UpdateSiteClientIndexResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`UpdateSiteClientIndexRequest`](../../doc/models/update-site-client-index-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`UpdateSiteClientIndexResponse`](../../doc/models/update-site-client-index-response.md)

## Example Usage

```php
$version = '6';

$request = UpdateSiteClientIndexRequestBuilder::init(
    194,
    'ClientIndexName2'
)
    ->active(false)
    ->showOnNewClient(false)
    ->showOnEnrollmentRoster(false)
    ->editOnEnrollmentRoster(false)
    ->sortOrder(50)
    ->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $siteController->updateClientIndex(
    $version,
    $request,
    $siteId,
    $authorization
);
```

