# User Token

```php
$userTokenController = $client->getUserTokenController();
```

## Class Name

`UserTokenController`

## Methods

* [Issue Token](../../doc/controllers/user-token.md#issue-token)
* [Renew Token](../../doc/controllers/user-token.md#renew-token)
* [Revoke Token](../../doc/controllers/user-token.md#revoke-token)


# Issue Token

When users interact with your Public API integration as staff members, they need to get a staff user token for authentication.
You can use the issue endpoint to get a staff user token, then pass the token in the headers for all of your requests.

```php
function issueToken(string $version, IssueRequest $request, string $siteId): IssueResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`IssueRequest`](../../doc/models/issue-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |

## Response Type

[`IssueResponse`](../../doc/models/issue-response.md)

## Example Usage

```php
$version = '6';

$request = IssueRequestBuilder::init()
    ->username('Username4')
    ->password('Password6')
    ->build();

$siteId = '-99';

$result = $userTokenController->issueToken(
    $version,
    $request,
    $siteId
);
```


# Renew Token

Renews a token. Can be used to extend the lifetime of a token.
Current lifetime expansion: 24hrs from current expiration, up to 7 renewals.

```php
function renewToken(string $version, string $siteId, ?string $authorization = null): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`array`

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$result = $userTokenController->renewToken(
    $version,
    $siteId,
    $authorization
);
```


# Revoke Token

Revokes the user token in the Authorization header.

```php
function revokeToken(string $version, string $siteId, ?string $authorization = null): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`array`

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$result = $userTokenController->revokeToken(
    $version,
    $siteId,
    $authorization
);
```

